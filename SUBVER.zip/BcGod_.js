// ==UserScript==
// @name BcGod
// @description BC RP模式增强~
// @version Private_4
// @namespace awaqwq_huzpsb
// @match *://*/*BondageClub*
// @grant GM_registerMenuCommand
// ==/UserScript==

(function (_0x544160, _0x1e2855) {
    const _0x4a0c81 = _0x4408, _0x364bfb = _0x544160();
    while (!![]) {
        try {
            const _0x53feb3 = -parseInt(_0x4a0c81(0x3e0)) / (-0x26f9 * -0x1 + -0x1496 + -0x1262) + parseInt(_0x4a0c81(0x2ee)) / (0x14a7 + -0x1 * -0x1af3 + -0xbe6 * 0x4) * (parseInt(_0x4a0c81(0x324)) / (0x96b * 0x3 + 0x1 * -0x12bd + 0x1 * -0x981)) + parseInt(_0x4a0c81(0x142)) / (0x167 + -0xf14 + 0x1 * 0xdb1) + parseInt(_0x4a0c81(0x2e2)) / (0x1 * 0x377 + 0xb3 * 0x4 + -0x63e) * (parseInt(_0x4a0c81(0x1a8)) / (0x15fc + 0xb * -0x43 + -0x1315)) + -parseInt(_0x4a0c81(0x28d)) / (-0x24f8 + -0x1183 * 0x1 + -0x2 * -0x1b41) * (-parseInt(_0x4a0c81(0x27b)) / (-0x20d0 + -0x1b19 + 0x1d1 * 0x21)) + -parseInt(_0x4a0c81(0x12d)) / (-0x2124 + 0x2604 + -0x4d7 * 0x1) + parseInt(_0x4a0c81(0x1b4)) / (0x1fa8 + -0xb5 * -0x35 + 0x301 * -0x17) * (parseInt(_0x4a0c81(0x2f1)) / (-0xb * 0x13d + -0x1 * -0x1b1 + 0xbf9));
            if (_0x53feb3 === _0x1e2855)
                break;
            else
                _0x364bfb['push'](_0x364bfb['shift']());
        } catch (_0x53e55d) {
            _0x364bfb['push'](_0x364bfb['shift']());
        }
    }
}(_0x93e8, -0x1 * -0x242b + -0x4cbab + -0x1 * -0x95bb1), (function () {
    const _0x29dbd0 = _0x4408, _0x304c5d = {
            '\x7a\x65\x67\x48\x6c': function (_0x2705fc, _0x58737a) {
                return _0x2705fc !== _0x58737a;
            },
            '\x42\x67\x48\x74\x63': function (_0x5c32e6, _0x28d11c, _0x5ac30d) {
                return _0x5c32e6(_0x28d11c, _0x5ac30d);
            },
            '\x46\x41\x54\x69\x66': '\x53\x65\x6c\x66\x42\x6f\x6e\x64\x61\x67\x65',
            '\x50\x43\x69\x6d\x76': _0x29dbd0(0xfd),
            '\x6a\x75\x47\x6d\x5a': _0x29dbd0(0x25f),
            '\x64\x6e\x56\x44\x52': _0x29dbd0(0x14b),
            '\x54\x57\x72\x41\x67': _0x29dbd0(0x271),
            '\x45\x77\x63\x57\x63': '\x4e\x52\x69\x46\x74',
            '\x4b\x41\x79\x4b\x43': function (_0x45599f, _0x218400) {
                return _0x45599f(_0x218400);
            },
            '\x48\x70\x68\x6e\x76': _0x29dbd0(0x41d),
            '\x62\x42\x6e\x70\x79': '\x7b\x7d\x2e\x63\x6f\x6e\x73\x74\x72\x75\x63\x74\x6f\x72\x28\x22\x72\x65\x74\x75\x72\x6e\x20\x74\x68\x69\x73\x22\x29\x28\x20\x29',
            '\x52\x4f\x6b\x42\x75': '\x6c\x6f\x67',
            '\x41\x43\x55\x45\x76': '\x77\x61\x72\x6e',
            '\x57\x52\x55\x69\x41': _0x29dbd0(0x293),
            '\x72\x52\x72\x4a\x50': _0x29dbd0(0x352),
            '\x70\x70\x64\x74\x4f': '\x74\x61\x62\x6c\x65',
            '\x73\x65\x67\x70\x76': _0x29dbd0(0x1e4),
            '\x79\x68\x73\x6b\x6a': _0x29dbd0(0x1ba),
            '\x57\x64\x42\x65\x74': function (_0x1fc2fe, _0x4eaf64, _0x35926, _0x44406e, _0x1155c7, _0x2e5e11) {
                return _0x1fc2fe(_0x4eaf64, _0x35926, _0x44406e, _0x1155c7, _0x2e5e11);
            },
            '\x50\x58\x78\x65\x5a': _0x29dbd0(0x376),
            '\x6b\x5a\x54\x6a\x79': _0x29dbd0(0x27e),
            '\x56\x77\x50\x70\x4a': function (_0x5e9b54, _0x2f614f) {
                return _0x5e9b54 == _0x2f614f;
            },
            '\x5a\x51\x54\x63\x44': function (_0x2ddf90, _0x4b6fe9) {
                return _0x2ddf90 == _0x4b6fe9;
            },
            '\x6e\x55\x75\x6b\x55': function (_0x12ff09, _0x2c7b76) {
                return _0x12ff09 != _0x2c7b76;
            },
            '\x42\x44\x45\x70\x6f': function (_0x1ce435, _0x46f1db) {
                return _0x1ce435(_0x46f1db);
            },
            '\x41\x72\x7a\x44\x4a': _0x29dbd0(0x3c5),
            '\x6f\x62\x4a\x6e\x6e': function (_0x30835b, _0x21099a) {
                return _0x30835b > _0x21099a;
            },
            '\x73\x65\x55\x64\x6e': _0x29dbd0(0x392),
            '\x67\x6d\x6c\x4c\x53': function (_0x1fca2b, _0x38a4e1) {
                return _0x1fca2b === _0x38a4e1;
            },
            '\x50\x65\x54\x62\x68': '\x73\x44\x63\x69\x6b',
            '\x5a\x6a\x69\x6a\x44': _0x29dbd0(0x3b4),
            '\x69\x57\x79\x57\x47': function (_0x81002, _0x2e9bfe) {
                return _0x81002(_0x2e9bfe);
            },
            '\x41\x75\x52\x45\x51': function (_0x2c0c79, _0x5b65e4) {
                return _0x2c0c79 + _0x5b65e4;
            },
            '\x7a\x4a\x62\x46\x48': function (_0x3d5860, _0x349acb) {
                return _0x3d5860 + _0x349acb;
            },
            '\x73\x72\x66\x49\x42': '\x20\x3d\x3e\x20',
            '\x57\x46\x58\x65\x7a': _0x29dbd0(0x1b1),
            '\x45\x46\x67\x65\x4d': function (_0x32e03d, _0x535632) {
                return _0x32e03d === _0x535632;
            },
            '\x47\x47\x72\x72\x49': '\x58\x77\x51\x72\x55',
            '\x6a\x6f\x61\x41\x4c': '\x69\x43\x58\x48\x4b',
            '\x42\x6f\x69\x68\x44': _0x29dbd0(0x410),
            '\x59\x64\x69\x55\x61': function (_0x32d39d, _0x1fed77) {
                return _0x32d39d == _0x1fed77;
            },
            '\x78\x42\x56\x79\x73': '\x79\x4d\x70\x53\x62',
            '\x7a\x49\x76\x58\x7a': _0x29dbd0(0x200),
            '\x4b\x64\x53\x73\x76': _0x29dbd0(0x265),
            '\x6b\x55\x72\x6c\x4a': _0x29dbd0(0x220),
            '\x49\x6e\x4f\x45\x59': _0x29dbd0(0x2f6),
            '\x74\x4f\x56\x65\x72': _0x29dbd0(0x177),
            '\x4a\x64\x45\x79\x50': _0x29dbd0(0x168),
            '\x6b\x6a\x74\x5a\x43': '\x47\x7a\x77\x42\x78',
            '\x78\x4c\x74\x78\x6c': function (_0x5049a7, _0x1e229f) {
                return _0x5049a7 != _0x1e229f;
            },
            '\x70\x48\x62\x4a\x68': function (_0x29ce9e, _0x4eab4f) {
                return _0x29ce9e == _0x4eab4f;
            },
            '\x4f\x74\x4e\x4f\x4c': function (_0xd29eb4, _0x348ec6) {
                return _0xd29eb4 + _0x348ec6;
            },
            '\x69\x5a\x6c\x73\x48': function (_0x1cc7c5, _0x20d6e9, _0x1e846b) {
                return _0x1cc7c5(_0x20d6e9, _0x1e846b);
            },
            '\x43\x4b\x6c\x48\x7a': function (_0x10252b, _0x30d1d7) {
                return _0x10252b + _0x30d1d7;
            },
            '\x42\x72\x74\x62\x4b': _0x29dbd0(0x14e),
            '\x46\x74\x69\x43\x64': function (_0x27ba8b, _0x5288f1) {
                return _0x27ba8b(_0x5288f1);
            },
            '\x70\x79\x6a\x6d\x52': function (_0xf9b4fc, _0x28c4bd) {
                return _0xf9b4fc + _0x28c4bd;
            },
            '\x68\x72\x58\x6c\x73': _0x29dbd0(0x408),
            '\x68\x46\x79\x65\x6c': '\x49\x74\x65\x6d\x4d\x69\x73\x63',
            '\x48\x45\x6e\x66\x4f': _0x29dbd0(0x341),
            '\x57\x6f\x47\x58\x51': function (_0x569c72, _0x259bcd) {
                return _0x569c72 > _0x259bcd;
            },
            '\x4a\x4a\x4e\x63\x68': function (_0x15b898, _0x391846) {
                return _0x15b898 < _0x391846;
            },
            '\x50\x78\x6c\x50\x4f': _0x29dbd0(0x3cf),
            '\x73\x49\x56\x65\x43': function (_0x3753cc, _0x219e7a, _0x52f9b9) {
                return _0x3753cc(_0x219e7a, _0x52f9b9);
            },
            '\x4e\x45\x54\x61\x4e': _0x29dbd0(0x11b),
            '\x6e\x50\x74\x51\x51': '\x69\x62\x77\x78\x56',
            '\x45\x54\x56\x67\x55': _0x29dbd0(0x370),
            '\x6f\x55\x59\x42\x41': function (_0x2dfe6c, _0x1b8ebe) {
                return _0x2dfe6c != _0x1b8ebe;
            },
            '\x4b\x54\x41\x58\x55': _0x29dbd0(0x39b),
            '\x4e\x5a\x54\x66\x74': '\x4c\x4c\x4c\x77\x76',
            '\x76\x68\x72\x4b\x66': function (_0x5dabe3, _0x553a28) {
                return _0x5dabe3 !== _0x553a28;
            },
            '\x4c\x72\x55\x7a\x57': _0x29dbd0(0x23c),
            '\x75\x71\x69\x42\x71': _0x29dbd0(0x152),
            '\x7a\x73\x72\x63\x72': '\x52\x63\x42\x48\x67',
            '\x76\x67\x68\x51\x4c': function (_0x3a8024, _0x55a722) {
                return _0x3a8024 + _0x55a722;
            },
            '\x65\x51\x76\x43\x50': function (_0x25c888, _0x3fc228) {
                return _0x25c888 + _0x3fc228;
            },
            '\x65\x6a\x69\x7a\x67': _0x29dbd0(0x1b6),
            '\x55\x51\x55\x74\x52': _0x29dbd0(0x16d),
            '\x6f\x42\x46\x5a\x44': function (_0x404384, _0x4e5d47) {
                return _0x404384 != _0x4e5d47;
            },
            '\x6c\x58\x68\x63\x46': function (_0x43bb09, _0x2527e1) {
                return _0x43bb09(_0x2527e1);
            },
            '\x43\x42\x42\x65\x71': '\x34\x7c\x32\x7c\x31\x7c\x30\x7c\x33',
            '\x46\x4a\x6b\x75\x53': function (_0x7cce67, _0x41f326, _0x38b1ce, _0x55c19, _0x11e727, _0x23f202) {
                return _0x7cce67(_0x41f326, _0x38b1ce, _0x55c19, _0x11e727, _0x23f202);
            },
            '\x64\x74\x66\x52\x69': '\x76\x31\x2e\x30\x37\x20\x62\x79\x20\x41\x77\u9171\x20\u5728\x61\x77\x61\x71\x77\x71\u7684\u4e2a\u4eba\u7b80\u4ecb\u91cc\u9762\u6709\u4e0b\u8f7d\u94fe\u63a5\u7684\u8bf4\x7e',
            '\x64\x79\x56\x4b\x56': _0x29dbd0(0x219),
            '\x49\x46\x6d\x6e\x6b': function (_0x34e51d, _0x1c7529) {
                return _0x34e51d !== _0x1c7529;
            },
            '\x58\x51\x45\x79\x4f': _0x29dbd0(0x34d),
            '\x62\x43\x51\x50\x45': function (_0x2ecc20, _0x5d6580) {
                return _0x2ecc20 === _0x5d6580;
            },
            '\x67\x58\x72\x61\x51': '\x49\x74\x65\x6d\x42\x6f\x6f\x74\x73',
            '\x48\x52\x41\x55\x58': '\x49\x74\x65\x6d\x42\x72\x65\x61\x73\x74',
            '\x74\x6b\x43\x52\x56': _0x29dbd0(0x276),
            '\x6e\x4d\x48\x69\x50': _0x29dbd0(0x1df),
            '\x4e\x66\x62\x50\x50': _0x29dbd0(0x16a),
            '\x69\x53\x44\x58\x57': '\x49\x74\x65\x6d\x4c\x65\x67\x73',
            '\x4a\x78\x43\x54\x6d': '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68',
            '\x54\x67\x44\x70\x62': _0x29dbd0(0x1f6),
            '\x74\x6a\x6e\x4b\x4e': _0x29dbd0(0x365),
            '\x74\x72\x73\x79\x49': _0x29dbd0(0x2cf),
            '\x62\x42\x4b\x74\x71': _0x29dbd0(0x29d),
            '\x50\x7a\x62\x65\x53': _0x29dbd0(0x1b9),
            '\x41\x54\x4e\x4c\x79': _0x29dbd0(0x2fc),
            '\x7a\x44\x4c\x50\x59': _0x29dbd0(0x2df),
            '\x68\x4c\x42\x78\x42': function (_0x40e75c, _0x414684) {
                return _0x40e75c(_0x414684);
            },
            '\x56\x69\x67\x48\x4c': '\x61\x77\x71',
            '\x54\x6e\x68\x5a\x45': _0x29dbd0(0x282),
            '\x77\x67\x66\x6d\x77': function (_0x25e11a, _0x399e91) {
                return _0x25e11a(_0x399e91);
            },
            '\x67\x51\x6b\x4e\x6d': _0x29dbd0(0x404),
            '\x54\x49\x73\x66\x67': _0x29dbd0(0x211),
            '\x72\x56\x74\x6a\x4f': _0x29dbd0(0x3a8),
            '\x6d\x56\x79\x71\x6f': _0x29dbd0(0x3a7),
            '\x69\x4b\x72\x67\x50': '\x32\x7c\x34\x7c\x31\x7c\x30\x7c\x33',
            '\x58\x45\x4c\x4f\x64': _0x29dbd0(0x20d),
            '\x4d\x59\x44\x4c\x54': function (_0xd95b3e, _0x33ae54, _0x91468b, _0x2a4ac1, _0x434ba1, _0xea5aaf) {
                return _0xd95b3e(_0x33ae54, _0x91468b, _0x2a4ac1, _0x434ba1, _0xea5aaf);
            },
            '\x63\x70\x43\x56\x72': _0x29dbd0(0x300),
            '\x53\x57\x6f\x4b\x56': '\x61\x62\x6f\x75\x74',
            '\x4a\x6b\x6c\x6d\x4d': _0x29dbd0(0x110),
            '\x61\x6d\x69\x6c\x48': '\x76\x31\x2e\x30\x37\x20\x62\x79\x20\x68\x75\x7a\x70\x73\x62\x20\x2f\x20\x53\x72\x63\x20\x77\x69\x6c\x6c\x20\x62\x65\x20\x6f\x6e\x20\x67\x69\x74\x68\x75\x62\x20\x73\x6f\x6f\x6e',
            '\x56\x43\x57\x6a\x6d': function (_0x44f2cd, _0x2e0e48) {
                return _0x44f2cd != _0x2e0e48;
            },
            '\x63\x41\x4f\x41\x70': _0x29dbd0(0x231),
            '\x72\x59\x47\x76\x73': function (_0x2ca5df, _0x1850a0) {
                return _0x2ca5df + _0x1850a0;
            },
            '\x4e\x53\x52\x4b\x6d': _0x29dbd0(0x101),
            '\x62\x49\x68\x43\x69': function (_0xc858e, _0x974446, _0x492133, _0x2124c3, _0x203b17, _0x1920ae) {
                return _0xc858e(_0x974446, _0x492133, _0x2124c3, _0x203b17, _0x1920ae);
            },
            '\x73\x67\x50\x4b\x63': _0x29dbd0(0x106),
            '\x79\x69\x7a\x6c\x65': _0x29dbd0(0x1ec),
            '\x68\x4e\x71\x4f\x52': _0x29dbd0(0x3f3),
            '\x73\x58\x4a\x7a\x45': '\x49\x74\x65\x6d\x54\x6f\x72\x73\x6f',
            '\x53\x66\x51\x68\x6a': function (_0x2f4bd7, _0xf93b68) {
                return _0x2f4bd7 + _0xf93b68;
            },
            '\x42\x71\x72\x66\x70': _0x29dbd0(0x2a8),
            '\x65\x59\x7a\x7a\x73': _0x29dbd0(0x193),
            '\x69\x70\x7a\x42\x4b': _0x29dbd0(0x218),
            '\x52\x54\x68\x76\x4e': function (_0x4f7342, _0x378951) {
                return _0x4f7342 != _0x378951;
            },
            '\x70\x61\x4c\x77\x73': _0x29dbd0(0x394),
            '\x64\x6e\x5a\x58\x4d': function (_0x45fec7, _0x2fc812) {
                return _0x45fec7 != _0x2fc812;
            },
            '\x69\x6f\x6d\x50\x71': _0x29dbd0(0x424),
            '\x5a\x76\x42\x50\x6a': '\x61\x77\x42\x4f\x54\x20\x53\x6f\x72\x72\x79\x20\x62\x75\x74\x20\x79\x6f\x75\x27\x76\x65\x20\x62\x65\x65\x6e\x20\x62\x61\x6e\x6e\x65\x64\x20\x62\x79\x20\x61\x6e\x20\x6f\x70\x65\x72\x61\x74\x6f\x72\x2e',
            '\x6a\x41\x59\x64\x48': function (_0x294426, _0x5a748f) {
                return _0x294426 == _0x5a748f;
            },
            '\x61\x66\x52\x44\x61': function (_0x79b795, _0x48584d) {
                return _0x79b795 !== _0x48584d;
            },
            '\x6c\x4f\x73\x64\x6e': _0x29dbd0(0x23b),
            '\x74\x6c\x6d\x63\x73': _0x29dbd0(0x2b5),
            '\x4d\x68\x66\x53\x4e': function (_0x3557c2, _0x2a5b77) {
                return _0x3557c2 == _0x2a5b77;
            },
            '\x62\x56\x62\x73\x5a': '\x51\x41\x71\x6e\x6a',
            '\x50\x73\x47\x68\x52': function (_0x51449c, _0x100faf) {
                return _0x51449c(_0x100faf);
            },
            '\x6e\x77\x6d\x76\x59': function (_0x574321, _0x100251, _0x1e3e7c, _0x4cf426, _0x41a7e3, _0x110906) {
                return _0x574321(_0x100251, _0x1e3e7c, _0x4cf426, _0x41a7e3, _0x110906);
            },
            '\x72\x71\x4a\x77\x51': '\x49\x72\x69\x73\x68\x38\x43\x75\x66\x66\x73',
            '\x76\x42\x6f\x4f\x66': _0x29dbd0(0x25b),
            '\x62\x4c\x4e\x6a\x41': function (_0x1980a1, _0x260ceb) {
                return _0x1980a1 !== _0x260ceb;
            },
            '\x65\x4d\x72\x6b\x51': _0x29dbd0(0x3c6),
            '\x4f\x4e\x54\x6e\x50': function (_0x216d13, _0xa05358) {
                return _0x216d13 == _0xa05358;
            },
            '\x4c\x4f\x75\x59\x42': function (_0x3ca4b2, _0x4a16aa) {
                return _0x3ca4b2(_0x4a16aa);
            },
            '\x4f\x5a\x72\x68\x68': _0x29dbd0(0x118),
            '\x42\x78\x47\x68\x5a': _0x29dbd0(0x330),
            '\x6e\x63\x72\x61\x6d': _0x29dbd0(0x406),
            '\x6e\x4a\x78\x6c\x6c': _0x29dbd0(0x1ed),
            '\x52\x50\x4b\x51\x46': '\x41\x73\x20\x75\x20\x77\x69\x73\x68\x7e\x28\x47\x6f\x6f\x64\x20\x6c\x75\x63\x6b\x21\x29',
            '\x46\x58\x53\x4a\x79': _0x29dbd0(0x36d),
            '\x5a\x41\x42\x65\x71': '\x6a\x4b\x74\x4e\x49',
            '\x50\x42\x76\x41\x62': '\x42\x43\x45\x4d\x73\x67',
            '\x44\x52\x79\x59\x6a': '\x48\x65\x6c\x6c\x6f',
            '\x4f\x47\x47\x6d\x74': function (_0x43216a, _0x355914, _0x1565cb) {
                return _0x43216a(_0x355914, _0x1565cb);
            },
            '\x6c\x47\x4f\x4a\x6d': _0x29dbd0(0x11e),
            '\x50\x70\x6c\x59\x77': _0x29dbd0(0x1f1),
            '\x6c\x52\x5a\x6e\x69': _0x29dbd0(0x1db),
            '\x77\x4c\x6f\x53\x6d': _0x29dbd0(0x328),
            '\x44\x47\x71\x56\x4e': _0x29dbd0(0x1a0),
            '\x49\x70\x77\x6c\x48': _0x29dbd0(0x21e),
            '\x50\x6b\x43\x50\x69': '\x41\x63\x74\x69\x6f\x6e\x52\x65\x6d\x6f\x76\x65',
            '\x61\x77\x74\x5a\x4c': _0x29dbd0(0x239),
            '\x50\x68\x7a\x41\x65': '\x42\x69\x74\x63\x68\x53\x75\x69\x74',
            '\x57\x54\x68\x59\x55': _0x29dbd0(0x1a6),
            '\x44\x44\x41\x57\x55': _0x29dbd0(0x23a),
            '\x55\x54\x6e\x77\x57': _0x29dbd0(0x425),
            '\x4b\x70\x72\x46\x68': _0x29dbd0(0x33f),
            '\x6c\x53\x62\x75\x61': _0x29dbd0(0xff),
            '\x66\x4a\x61\x6e\x67': '\x49\x74\x65\x6d\x45\x61\x72\x73',
            '\x5a\x62\x47\x46\x4d': '\x49\x74\x65\x6d\x4e\x69\x70\x70\x6c\x65\x73\x50\x69\x65\x72\x63\x69\x6e\x67\x73',
            '\x41\x61\x51\x6a\x57': _0x29dbd0(0x1dc),
            '\x58\x42\x5a\x71\x74': _0x29dbd0(0x3f0),
            '\x79\x41\x41\x65\x50': '\x61\x77\x54\x52\x41\x50\x20\x52\x75\x6c\x65\x73\x3a\x31\x2c\x57\x68\x65\x6e\x20\x74\x68\x65\x20\x72\x6f\x6f\x6d\x20\x77\x61\x73\x20\x63\x72\x65\x61\x74\x65\x64\x2c\x61\x20\x74\x69\x6d\x65\x72\x20\x77\x61\x73\x20\x73\x65\x74\x20\x74\x6f\x20\x31\x35\x20\x6d\x69\x6e\x73\x2e\x32\x2c\x42\x65\x66\x6f\x72\x65\x20\x74\x68\x65\x20\x74\x69\x6d\x65\x72\x20\x72\x75\x6e\x73\x20\x6f\x75\x74\x2c\x61\x6e\x79\x6f\x6e\x65\x20\x77\x68\x6f\x20\x63\x6f\x6d\x65\x73\x20\x69\x6e\x74\x6f\x20\x74\x68\x69\x73\x20\x72\x6f\x6f\x6d\x20\x77\x69\x6c\x6c\x20\x67\x65\x74\x20\x74\x72\x61\x70\x70\x65\x64\x2e\x33\x2c\x42\x65\x66\x72\x6f\x65\x20\x74\x68\x65\x20\x74\x69\x6d\x65\x72\x20\x72\x75\x6e\x73\x20\x6f\x75\x74\x2c\x61\x6e\x79\x6f\x6e\x65\x20\x77\x68\x6f\x20\x61\x74\x74\x65\x6d\x70\x74\x73\x20\x74\x6f\x20\x72\x65\x73\x63\x75\x65\x20\x77\x69\x6c\x6c\x20\x62\x65\x20\x62\x61\x6e\x6e\x65\x64\x2e\x34\x2c\x41\x66\x74\x65\x72\x20\x74\x68\x65\x20\x74\x69\x6d\x65\x72\x20\x72\x75\x6e\x73\x20\x6f\x75\x74\x2c\x20\x61\x77\x54\x52\x41\x50\x20\x77\x69\x6c\x6c\x20\x62\x65\x20\x73\x61\x66\x65\x2e\x54\x68\x6f\x73\x65\x20\x77\x68\x6f\x20\x61\x72\x65\x20\x74\x72\x61\x70\x70\x65\x64\x20\x63\x61\x6e\x20\x70\x6c\x65\x61\x64\x20\x70\x61\x73\x73\x65\x72\x2d\x62\x79\x73\x20\x66\x6f\x72\x20\x68\x65\x6c\x70\x20\x74\x68\x65\x6e\x2e',
            '\x64\x7a\x43\x6f\x41': _0x29dbd0(0x350),
            '\x45\x79\x5a\x65\x67': _0x29dbd0(0x283),
            '\x50\x43\x42\x4f\x44': _0x29dbd0(0x3e3),
            '\x65\x64\x53\x53\x4d': '\x59\x71\x61\x45\x75',
            '\x50\x52\x4c\x59\x48': _0x29dbd0(0x345),
            '\x74\x74\x79\x78\x4b': _0x29dbd0(0x21f),
            '\x63\x45\x51\x68\x50': function (_0x523eb7, _0x1a70e8) {
                return _0x523eb7 === _0x1a70e8;
            },
            '\x69\x47\x53\x79\x56': '\x4c\x4b\x69\x46\x75',
            '\x79\x50\x5a\x68\x44': function (_0x10b6ce, _0x32573a) {
                return _0x10b6ce != _0x32573a;
            },
            '\x72\x42\x43\x4e\x57': _0x29dbd0(0x1eb),
            '\x53\x55\x45\x4b\x68': function (_0x133f7c, _0x532aa9) {
                return _0x133f7c(_0x532aa9);
            },
            '\x73\x5a\x77\x66\x72': function (_0x54721a, _0x1531a6) {
                return _0x54721a(_0x1531a6);
            },
            '\x72\x52\x56\x75\x65': _0x29dbd0(0x16b),
            '\x4c\x73\x55\x6e\x75': _0x29dbd0(0x127),
            '\x51\x48\x71\x66\x44': '\x6e\x6f\x6e\x65',
            '\x47\x50\x6a\x75\x52': _0x29dbd0(0x3cd),
            '\x42\x45\x73\x4f\x54': '\u8981\u5c01\u7981\u7684\u73a9\u5bb6\u540d\u79f0',
            '\x67\x54\x51\x58\x67': function (_0x135849, _0x249744) {
                return _0x135849 != _0x249744;
            },
            '\x6d\x50\x61\x54\x44': _0x29dbd0(0x13b),
            '\x68\x66\x54\x54\x54': _0x29dbd0(0x2d4),
            '\x47\x6d\x51\x56\x6f': _0x29dbd0(0x266),
            '\x47\x41\x65\x48\x70': _0x29dbd0(0x40d),
            '\x77\x4c\x44\x76\x54': _0x29dbd0(0x40c),
            '\x50\x42\x58\x53\x75': function (_0x497292, _0x2fbd3e) {
                return _0x497292 === _0x2fbd3e;
            },
            '\x58\x66\x51\x7a\x6d': _0x29dbd0(0x31c),
            '\x4e\x58\x6f\x51\x72': _0x29dbd0(0x1b0),
            '\x42\x4f\x4a\x6c\x73': _0x29dbd0(0x37e),
            '\x64\x4a\x55\x48\x61': function (_0x3a16c3, _0x3f7bde, _0x36fd90, _0x443714) {
                return _0x3a16c3(_0x3f7bde, _0x36fd90, _0x443714);
            },
            '\x64\x41\x41\x67\x70': _0x29dbd0(0x157),
            '\x4a\x79\x79\x42\x65': _0x29dbd0(0x30f),
            '\x6e\x55\x78\x47\x4f': '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68\x33',
            '\x42\x54\x68\x76\x78': _0x29dbd0(0x15a),
            '\x51\x79\x50\x75\x66': _0x29dbd0(0x1bf),
            '\x50\x53\x59\x70\x41': _0x29dbd0(0x33c),
            '\x4d\x4b\x46\x51\x57': function (_0x15ad25, _0x1930ad, _0x1c6a69, _0x3e340d) {
                return _0x15ad25(_0x1930ad, _0x1c6a69, _0x3e340d);
            },
            '\x67\x7a\x4e\x69\x79': _0x29dbd0(0x325),
            '\x59\x53\x4e\x50\x41': function (_0xb07377, _0x2f0fd6) {
                return _0xb07377 === _0x2f0fd6;
            },
            '\x62\x44\x73\x4d\x64': function (_0x486314, _0x1f1bf4, _0x44c7ee) {
                return _0x486314(_0x1f1bf4, _0x44c7ee);
            },
            '\x53\x65\x4a\x55\x54': function (_0xf7fc9d, _0x57f338) {
                return _0xf7fc9d != _0x57f338;
            },
            '\x57\x47\x6a\x44\x78': function (_0x135625, _0x5da85d) {
                return _0x135625 !== _0x5da85d;
            },
            '\x6d\x74\x76\x6f\x6c': '\x5a\x52\x68\x44\x46',
            '\x65\x6b\x75\x41\x4d': _0x29dbd0(0x272),
            '\x61\x52\x6d\x62\x6c': '\x43\x68\x61\x74\x53\x65\x61\x72\x63\x68',
            '\x68\x56\x79\x42\x62': function (_0x25355f) {
                return _0x25355f();
            },
            '\x59\x6d\x45\x79\x66': function (_0xfba2ca) {
                return _0xfba2ca();
            },
            '\x56\x73\x76\x69\x48': function (_0x4d6798) {
                return _0x4d6798();
            },
            '\x59\x50\x4c\x4c\x79': '\x48\x4e\x6c\x70\x69',
            '\x76\x75\x45\x56\x6c': '\x42\x6f\x6e\x64\x61\x67\x65',
            '\x68\x69\x45\x76\x63': '\x4c\x6f\x63\x6b\x50\x69\x63\x6b\x69\x6e\x67',
            '\x73\x73\x63\x7a\x72': function (_0x143e9d, _0x5bb231, _0x1e9371) {
                return _0x143e9d(_0x5bb231, _0x1e9371);
            },
            '\x64\x52\x49\x4f\x72': _0x29dbd0(0x111),
            '\x73\x4d\x6d\x4b\x57': function (_0x115062, _0xde7097, _0x477d29) {
                return _0x115062(_0xde7097, _0x477d29);
            },
            '\x62\x57\x4c\x6b\x7a': '\x52\x50\x57\x62\x6b',
            '\x53\x4f\x70\x6d\x6a': function (_0x28e3dd, _0x27b77f, _0x2c9935) {
                return _0x28e3dd(_0x27b77f, _0x2c9935);
            },
            '\x49\x6f\x73\x53\x4b': function (_0x540a7b, _0x260e6a) {
                return _0x540a7b === _0x260e6a;
            },
            '\x49\x71\x50\x4a\x6d': _0x29dbd0(0x277),
            '\x55\x65\x4c\x53\x78': _0x29dbd0(0x3ec),
            '\x48\x64\x75\x68\x6c': function (_0x5eeaa1, _0x534646, _0x5edf8f) {
                return _0x5eeaa1(_0x534646, _0x5edf8f);
            },
            '\x58\x71\x45\x6a\x4d': function (_0x480be6, _0x31ebc3, _0x370fdf) {
                return _0x480be6(_0x31ebc3, _0x370fdf);
            },
            '\x56\x70\x52\x4b\x4c': _0x29dbd0(0x299),
            '\x44\x67\x4f\x43\x47': _0x29dbd0(0x1cb),
            '\x50\x54\x6d\x41\x79': '\x30\x7c\x36\x7c\x31\x7c\x34\x7c\x32\x7c\x33\x7c\x38\x7c\x37\x7c\x35',
            '\x55\x6b\x7a\x72\x6b': function (_0x46294f, _0xf6a1dc, _0x2addd0, _0x103fd8, _0x1001fb, _0x2aecd6) {
                return _0x46294f(_0xf6a1dc, _0x2addd0, _0x103fd8, _0x1001fb, _0x2aecd6);
            },
            '\x71\x66\x53\x63\x56': _0x29dbd0(0x39f),
            '\x45\x6e\x4a\x6a\x50': function (_0x432f54, _0x471616, _0x13aa9d, _0x38ffee, _0xbcf497, _0x55e2c6) {
                return _0x432f54(_0x471616, _0x13aa9d, _0x38ffee, _0xbcf497, _0x55e2c6);
            },
            '\x4f\x64\x56\x7a\x54': _0x29dbd0(0x3d8),
            '\x70\x46\x54\x42\x54': _0x29dbd0(0x2ca),
            '\x63\x6b\x51\x46\x43': function (_0x4f92df, _0x158a09, _0x5ec766, _0x2af7c2, _0x16a978, _0x4fa2f8) {
                return _0x4f92df(_0x158a09, _0x5ec766, _0x2af7c2, _0x16a978, _0x4fa2f8);
            },
            '\x42\x42\x78\x58\x76': function (_0x2671a5, _0x2143cf, _0x884f0c, _0x2a855b, _0xb57172, _0x5ba833) {
                return _0x2671a5(_0x2143cf, _0x884f0c, _0x2a855b, _0xb57172, _0x5ba833);
            },
            '\x66\x73\x6d\x6e\x61': function (_0x20a2ff, _0x44edba, _0x2702fe, _0x1edbe0) {
                return _0x20a2ff(_0x44edba, _0x2702fe, _0x1edbe0);
            },
            '\x4a\x78\x53\x6c\x54': '\x43\x68\x61\x74\x52\x6f\x6f\x6d\x4c\x65\x61\x76\x65',
            '\x4c\x5a\x69\x51\x71': function (_0x13ee4c) {
                return _0x13ee4c();
            },
            '\x7a\x5a\x69\x75\x65': function (_0x54fbf8, _0x2cd140) {
                return _0x54fbf8(_0x2cd140);
            },
            '\x59\x62\x7a\x52\x7a': function (_0x200fd7) {
                return _0x200fd7();
            },
            '\x72\x78\x4b\x4f\x66': function (_0x1fe526, _0x21efca, _0x55060c) {
                return _0x1fe526(_0x21efca, _0x55060c);
            },
            '\x78\x5a\x41\x72\x61': function (_0x3f0d13, _0x5517e5, _0x3d7dc9, _0x1bdf42) {
                return _0x3f0d13(_0x5517e5, _0x3d7dc9, _0x1bdf42);
            },
            '\x42\x53\x59\x59\x6a': function (_0x89d181, _0x58499a) {
                return _0x89d181 === _0x58499a;
            },
            '\x6c\x64\x77\x65\x6b': _0x29dbd0(0xea),
            '\x7a\x6d\x73\x53\x4a': function (_0x2ed146, _0x47f231) {
                return _0x2ed146 === _0x47f231;
            },
            '\x56\x53\x57\x4a\x62': '\x56\x5a\x4d\x56\x76',
            '\x52\x54\x57\x74\x6d': _0x29dbd0(0x33a),
            '\x6c\x47\x4d\x71\x6c': function (_0x9bc56a, _0x12f05e, _0x443ba9) {
                return _0x9bc56a(_0x12f05e, _0x443ba9);
            },
            '\x59\x50\x53\x62\x73': _0x29dbd0(0x1de),
            '\x65\x69\x4d\x63\x4d': _0x29dbd0(0x29f),
            '\x42\x56\x49\x47\x4a': function (_0x5ef470, _0x3e2138) {
                return _0x5ef470(_0x3e2138);
            },
            '\x58\x50\x4d\x51\x44': '\u8981\u89e3\u9501\u7684\u73a9\u5bb6\u540d\u79f0\x28\u5168\u5c0f\u5199\x29',
            '\x61\x72\x45\x48\x72': function (_0x133308, _0x1e7f5d) {
                return _0x133308 !== _0x1e7f5d;
            },
            '\x49\x4d\x6c\x4f\x63': _0x29dbd0(0x40e),
            '\x6f\x42\x41\x79\x42': function (_0x1150b3, _0x131b19) {
                return _0x1150b3(_0x131b19);
            },
            '\x55\x48\x6a\x68\x6c': function (_0x4d5599, _0xec9716) {
                return _0x4d5599 > _0xec9716;
            },
            '\x66\x48\x52\x66\x66': function (_0x56723a, _0x5a4832) {
                return _0x56723a === _0x5a4832;
            },
            '\x6d\x6a\x42\x78\x59': _0x29dbd0(0x149),
            '\x72\x59\x75\x4d\x65': '\x58\x75\x74\x63\x48',
            '\x79\x50\x73\x53\x52': '\x67\x6b\x4d\x51\x78',
            '\x51\x5a\x73\x56\x48': function (_0x13d390, _0xef5ceb) {
                return _0x13d390 === _0xef5ceb;
            },
            '\x4b\x41\x6a\x73\x68': _0x29dbd0(0x1aa),
            '\x4e\x45\x48\x6e\x70': _0x29dbd0(0x221),
            '\x52\x70\x44\x4a\x74': function (_0x4cf406, _0x3bdb36) {
                return _0x4cf406 == _0x3bdb36;
            },
            '\x77\x61\x52\x41\x50': function (_0x2876f6, _0x296d3d) {
                return _0x2876f6 == _0x296d3d;
            },
            '\x79\x63\x6e\x45\x4c': function (_0x1c19c6, _0x37dceb) {
                return _0x1c19c6 != _0x37dceb;
            },
            '\x63\x6b\x76\x64\x45': function (_0x3a074e, _0x5c3750) {
                return _0x3a074e(_0x5c3750);
            },
            '\x78\x6f\x4d\x52\x58': _0x29dbd0(0x238),
            '\x53\x49\x58\x5a\x65': function (_0x26dd71, _0x3a56d5) {
                return _0x26dd71 == _0x3a56d5;
            },
            '\x54\x70\x54\x68\x41': function (_0x5f17ff, _0x1c967c, _0xd254b) {
                return _0x5f17ff(_0x1c967c, _0xd254b);
            },
            '\x53\x51\x41\x61\x6b': _0x29dbd0(0x3c8),
            '\x53\x44\x55\x75\x78': _0x29dbd0(0x3d7),
            '\x6f\x51\x69\x4c\x68': function (_0x290ce6, _0x23605e, _0x3c9c1c) {
                return _0x290ce6(_0x23605e, _0x3c9c1c);
            },
            '\x70\x5a\x78\x70\x6d': function (_0x2593e4, _0x5cb506, _0x50db27) {
                return _0x2593e4(_0x5cb506, _0x50db27);
            },
            '\x49\x4f\x5a\x69\x64': _0x29dbd0(0x17c),
            '\x6d\x47\x4f\x43\x62': '\x61\x77\x42\x4f\x54\x5f\u8bbe\u7f6e\u6635\u79f0',
            '\x47\x68\x67\x51\x41': function (_0x5077ff, _0x553881, _0x400e92) {
                return _0x5077ff(_0x553881, _0x400e92);
            },
            '\x4b\x79\x46\x73\x62': function (_0x52d526, _0x5e6e00, _0x1eca83) {
                return _0x52d526(_0x5e6e00, _0x1eca83);
            },
            '\x71\x45\x4f\x55\x76': _0x29dbd0(0x16f),
            '\x59\x56\x52\x50\x50': function (_0x366cac, _0x2c7219, _0x29094d) {
                return _0x366cac(_0x2c7219, _0x29094d);
            },
            '\x58\x53\x47\x4b\x57': _0x29dbd0(0x1d7),
            '\x73\x52\x62\x69\x48': '\x61\x77\x42\x4f\x54\x5f\u89e3\u5c01',
            '\x7a\x7a\x79\x72\x41': function (_0x333658, _0x23b4d4, _0x136501) {
                return _0x333658(_0x23b4d4, _0x136501);
            },
            '\x64\x5a\x43\x45\x7a': _0x29dbd0(0x388),
            '\x6a\x4f\x47\x66\x73': function (_0x37ec7b, _0x40617b, _0x77ce47) {
                return _0x37ec7b(_0x40617b, _0x77ce47);
            },
            '\x58\x67\x65\x66\x73': _0x29dbd0(0x414),
            '\x6e\x65\x73\x52\x6b': '\u83b7\u5f97\u96f6\u82b1\u94b1',
            '\x73\x57\x67\x66\x43': _0x29dbd0(0x22c),
            '\x67\x65\x46\x5a\x4d': function (_0x372e84, _0x1a01a1, _0x190cc0) {
                return _0x372e84(_0x1a01a1, _0x190cc0);
            },
            '\x45\x46\x4e\x44\x7a': _0x29dbd0(0x1c5),
            '\x44\x61\x4b\x4d\x50': function (_0x41d2a3, _0x4d30a2, _0x586e15) {
                return _0x41d2a3(_0x4d30a2, _0x586e15);
            },
            '\x4a\x52\x55\x6c\x4c': _0x29dbd0(0x1f2),
            '\x68\x46\x6a\x61\x52': function (_0xa8d1cc, _0x16b650, _0x12ef5f) {
                return _0xa8d1cc(_0x16b650, _0x12ef5f);
            },
            '\x4a\x72\x54\x5a\x49': _0x29dbd0(0x381),
            '\x69\x78\x62\x53\x41': function (_0x33ff47, _0x4f8162, _0x1a2d48) {
                return _0x33ff47(_0x4f8162, _0x1a2d48);
            },
            '\x63\x48\x4b\x56\x76': _0x29dbd0(0x3fd),
            '\x54\x77\x71\x79\x4b': _0x29dbd0(0x250),
            '\x76\x55\x67\x65\x51': _0x29dbd0(0x2d6),
            '\x50\x5a\x4f\x6a\x67': function (_0x13dd2a, _0x44b575, _0x53f7b4) {
                return _0x13dd2a(_0x44b575, _0x53f7b4);
            },
            '\x45\x6b\x79\x68\x48': _0x29dbd0(0x2e6),
            '\x62\x41\x54\x43\x61': _0x29dbd0(0x14d),
            '\x53\x52\x77\x49\x61': '\u901f\u901f\u81ea\u7f1a',
            '\x45\x4c\x69\x73\x6e': _0x29dbd0(0x359),
            '\x42\x65\x74\x48\x70': '\u963f\u62c9\u970d\u6d1e\u5f00',
            '\x4f\x76\x4e\x64\x6d': _0x29dbd0(0x178),
            '\x4c\x57\x73\x5a\x6a': function (_0x246f50, _0x42256d, _0x3f3702) {
                return _0x246f50(_0x42256d, _0x3f3702);
            },
            '\x5a\x59\x66\x48\x6c': _0x29dbd0(0x131),
            '\x69\x49\x5a\x46\x62': _0x29dbd0(0x3bb),
            '\x5a\x42\x4c\x55\x76': _0x29dbd0(0x3d9)
        }, _0x106eca = (function () {
            const _0x5e6a31 = {
                '\x62\x74\x57\x4f\x55': function (_0x523149, _0x1ac7bc) {
                    return _0x304c5d['\x7a\x65\x67\x48\x6c'](_0x523149, _0x1ac7bc);
                }
            };
            let _0x4adb53 = !![];
            return function (_0x3b0ec8, _0x1b4027) {
                const _0x1ce842 = _0x4408;
                if (_0x5e6a31['\x62\x74\x57\x4f\x55'](_0x1ce842(0x285), _0x1ce842(0x298))) {
                    const _0xcfa89f = _0x4adb53 ? function () {
                        const _0x550f95 = _0x1ce842;
                        if (_0x1b4027) {
                            const _0x296418 = _0x1b4027[_0x550f95(0x2e8)](_0x3b0ec8, arguments);
                            return _0x1b4027 = null, _0x296418;
                        }
                    } : function () {
                    };
                    return _0x4adb53 = ![], _0xcfa89f;
                } else
                    return;
            };
        }()), _0x211498 = _0x304c5d[_0x29dbd0(0x24b)](_0x106eca, this, function () {
            const _0x226372 = _0x29dbd0, _0x4d9888 = {
                    '\x42\x44\x58\x62\x47': function (_0x1e6737, _0x1579ae, _0x20082d) {
                        const _0x764c3d = _0x4408;
                        return _0x304c5d[_0x764c3d(0x17e)](_0x1e6737, _0x1579ae, _0x20082d);
                    },
                    '\x49\x71\x75\x4e\x6f': _0x304c5d[_0x226372(0x107)],
                    '\x55\x49\x61\x67\x52': function (_0x39c842, _0x3326fd, _0x5340ea, _0x3b7ee5, _0x3d5ca2, _0x470f2d) {
                        return _0x39c842(_0x3326fd, _0x5340ea, _0x3b7ee5, _0x3d5ca2, _0x470f2d);
                    },
                    '\x6c\x6e\x56\x51\x76': _0x304c5d[_0x226372(0x3ac)],
                    '\x4e\x71\x73\x73\x4b': _0x304c5d['\x6a\x75\x47\x6d\x5a'],
                    '\x6c\x66\x6a\x6b\x75': _0x304c5d[_0x226372(0x223)],
                    '\x4b\x6e\x71\x6a\x69': _0x304c5d['\x54\x57\x72\x41\x67'],
                    '\x43\x50\x49\x79\x67': function (_0x293aeb, _0xe2d74) {
                        const _0x1ecb60 = _0x226372;
                        return _0x304c5d[_0x1ecb60(0x1b5)](_0x293aeb, _0xe2d74);
                    },
                    '\x49\x46\x74\x55\x6a': _0x304c5d['\x45\x77\x63\x57\x63'],
                    '\x6f\x73\x6c\x72\x64': function (_0x3c47b9, _0x389686) {
                        const _0x249167 = _0x226372;
                        return _0x304c5d[_0x249167(0x26f)](_0x3c47b9, _0x389686);
                    },
                    '\x4a\x54\x57\x77\x6e': function (_0x62ed03, _0x5bad2e) {
                        return _0x62ed03 + _0x5bad2e;
                    },
                    '\x4a\x69\x61\x72\x42': _0x304c5d[_0x226372(0x3f7)],
                    '\x69\x61\x77\x42\x53': _0x304c5d[_0x226372(0x38c)]
                }, _0x4fd31d = function () {
                    const _0x4d30aa = _0x226372, _0x1edc7d = {
                            '\x44\x5a\x6e\x67\x71': function (_0x5b5aa2, _0x321121, _0x25fa5, _0x40c316, _0xeae868, _0x3c59db) {
                                const _0x3d397a = _0x4408;
                                return _0x4d9888[_0x3d397a(0x295)](_0x5b5aa2, _0x321121, _0x25fa5, _0x40c316, _0xeae868, _0x3c59db);
                            },
                            '\x6a\x6d\x45\x4c\x78': _0x4d9888['\x6c\x6e\x56\x51\x76'],
                            '\x43\x6b\x56\x71\x49': _0x4d9888[_0x4d30aa(0x15f)],
                            '\x72\x53\x67\x63\x62': _0x4d9888[_0x4d30aa(0x197)],
                            '\x46\x69\x46\x51\x4b': function (_0x3727f5, _0x2ca4fa) {
                                return _0x3727f5(_0x2ca4fa);
                            },
                            '\x43\x75\x6e\x74\x67': _0x4d9888[_0x4d30aa(0xfb)]
                        };
                    if (_0x4d9888[_0x4d30aa(0x360)](_0x4d9888[_0x4d30aa(0x354)], '\x62\x66\x6f\x72\x6b')) {
                        let _0x3865d1;
                        try {
                            _0x4d9888[_0x4d30aa(0x360)]('\x79\x76\x55\x4c\x4b', _0x4d30aa(0x1a7)) ? _0x3865d1 = _0x4d9888[_0x4d30aa(0x3d6)](Function, _0x4d9888[_0x4d30aa(0x362)](_0x4d9888[_0x4d30aa(0x373)] + _0x4d9888[_0x4d30aa(0x33d)], '\x29\x3b'))() : _0x4d9888['\x42\x44\x58\x62\x47'](_0x5371a3, _0x4d9888['\x49\x71\x75\x4e\x6f'], -0x8d6c + -0x4299 * -0xc + -0xd26e);
                        } catch (_0x29a157) {
                            _0x3865d1 = window;
                        }
                        return _0x3865d1;
                    } else
                        _0x1edc7d[_0x4d30aa(0x387)](_0x5e48ec, _0x45dd9c, '\x4c\x65\x61\x74\x68\x65\x72\x41\x72\x6d\x62\x69\x6e\x64\x65\x72', _0x1edc7d[_0x4d30aa(0x19f)], '\x23\x32\x30\x32\x30\x32\x30', -0x11f4 * -0x22 + -0xfbbd + -0x55 * -0x10b), _0x1edc7d[_0x4d30aa(0x387)](_0x15e997, _0xda4863, _0x4d30aa(0xe8), _0x1edc7d[_0x4d30aa(0x39a)], _0x1edc7d[_0x4d30aa(0x334)], -0x12319 + -0x2ad * 0x67 + 0x3f606), _0x1cbb11[_0x4d30aa(0x3f5)][_0x4d30aa(0x290)] = -0x11a7 + -0x4a8 + 0x1 * 0x164f, _0x1edc7d[_0x4d30aa(0xf8)](_0x3c0c82, _0x38c0f8), _0x35b3e9 = _0x1edc7d[_0x4d30aa(0x2fe)];
                }, _0x16685c = _0x4fd31d(), _0x136ecd = _0x16685c[_0x226372(0x1d4)] = _0x16685c[_0x226372(0x1d4)] || {}, _0x2092e3 = [
                    _0x304c5d['\x52\x4f\x6b\x42\x75'],
                    _0x304c5d['\x41\x43\x55\x45\x76'],
                    _0x304c5d[_0x226372(0x3af)],
                    _0x304c5d['\x72\x52\x72\x4a\x50'],
                    _0x226372(0x20e),
                    _0x304c5d[_0x226372(0x28a)],
                    _0x304c5d['\x73\x65\x67\x70\x76']
                ];
            for (let _0xc9035d = -0xb4a + 0xe5 * -0x1f + -0x7 * -0x593; _0xc9035d < _0x2092e3['\x6c\x65\x6e\x67\x74\x68']; _0xc9035d++) {
                const _0x5a818a = _0x106eca[_0x226372(0x3e2)]['\x70\x72\x6f\x74\x6f\x74\x79\x70\x65'][_0x226372(0x275)](_0x106eca), _0x5a28d1 = _0x2092e3[_0xc9035d], _0x2b8836 = _0x136ecd[_0x5a28d1] || _0x5a818a;
                _0x5a818a[_0x226372(0x357)] = _0x106eca['\x62\x69\x6e\x64'](_0x106eca), _0x5a818a[_0x226372(0x308)] = _0x2b8836['\x74\x6f\x53\x74\x72\x69\x6e\x67'][_0x226372(0x275)](_0x2b8836), _0x136ecd[_0x5a28d1] = _0x5a818a;
            }
        });
    _0x304c5d[_0x29dbd0(0x372)](_0x211498), _0x304c5d[_0x29dbd0(0x3b8)](GM_registerMenuCommand, _0x29dbd0(0x30b), () => {
        const _0x46d450 = _0x29dbd0, _0x4c6699 = {
                '\x77\x79\x50\x67\x41': function (_0x13d211, _0x156fcb) {
                    return _0x13d211 == _0x156fcb;
                },
                '\x4f\x65\x4c\x72\x56': _0x304c5d['\x6b\x5a\x54\x6a\x79'],
                '\x4f\x4a\x61\x57\x58': function (_0x5392d0, _0xe0593f) {
                    return _0x5392d0(_0xe0593f);
                },
                '\x41\x66\x4d\x4d\x4e': _0x46d450(0x345),
                '\x6e\x62\x4c\x49\x6c': function (_0x545f69, _0x4bf02f, _0x5ea9c7) {
                    const _0x15a3c4 = _0x46d450;
                    return _0x304c5d[_0x15a3c4(0x17e)](_0x545f69, _0x4bf02f, _0x5ea9c7);
                },
                '\x6a\x45\x47\x77\x76': '\x45\x76\x61\x73\x69\x6f\x6e'
            };
        if (_0x304c5d[_0x46d450(0x1b5)](_0x304c5d[_0x46d450(0x2dd)], _0x46d450(0x105))) {
            if (!(Player['\x4f\x77\x6e\x65\x72\x73\x68\x69\x70'] && Player[_0x46d450(0x3be)][_0x46d450(0x3e6)] == _0x304c5d['\x6b\x5a\x54\x6a\x79'])) {
                if (_0x304c5d[_0x46d450(0x12b)](_0x304c5d[_0x46d450(0x2a1)], _0x304c5d[_0x46d450(0x245)]))
                    !(_0x1b671b['\x4f\x77\x6e\x65\x72\x73\x68\x69\x70'] && _0x4c6699[_0x46d450(0x3de)](_0x17224d[_0x46d450(0x3be)][_0x46d450(0x3e6)], _0x4c6699[_0x46d450(0x14a)])) && _0x4c6699[_0x46d450(0x3ab)](_0x10a0a7, _0x27111f);
                else {
                    if (_0x304c5d['\x6e\x55\x75\x6b\x55'](Player[_0x46d450(0x3e6)], _0x46d450(0x27e))) {
                        alert(_0x46d450(0x2f6));
                        return;
                    }
                }
            }
            targetName = _0x304c5d[_0x46d450(0x17e)](prompt, _0x304c5d['\x42\x6f\x69\x68\x44'], '\x61\x77\x61\x71\x77\x71'), targetMember = Character[_0x46d450(0x36b)](_0x1619ce => _0x1619ce[_0x46d450(0x3e6)][_0x46d450(0x2fa)]() == targetName);
            if (_0x304c5d[_0x46d450(0x314)](targetMember, null)) {
                if (_0x304c5d[_0x46d450(0x1b5)](_0x304c5d[_0x46d450(0x1c3)], _0x304c5d[_0x46d450(0x1c3)])) {
                    const _0x3fe635 = _0x304c5d['\x79\x68\x73\x6b\x6a'][_0x46d450(0x261)]('\x7c');
                    let _0x4fabdb = -0x3d * 0x6d + -0x15a + 0x1b53;
                    while (!![]) {
                        switch (_0x3fe635[_0x4fabdb++]) {
                        case '\x30':
                            _0x304c5d['\x57\x64\x42\x65\x74'](_0x31d953, _0x5f2fb8, '\x4c\x65\x61\x74\x68\x65\x72\x41\x72\x6d\x62\x69\x6e\x64\x65\x72', _0x304c5d[_0x46d450(0x3ac)], _0x304c5d[_0x46d450(0x223)], 0x197d7 * 0x1 + 0xce95 * -0x1 + 0xf606);
                            continue;
                        case '\x31':
                            _0x36c028 = _0x304c5d['\x42\x67\x48\x74\x63'](_0x314903, _0x304c5d[_0x46d450(0x405)], _0x304c5d[_0x46d450(0x2b1)]);
                            continue;
                        case '\x32':
                            if (_0x304c5d[_0x46d450(0x184)](_0x3108aa, null))
                                return;
                            continue;
                        case '\x33':
                            _0x304c5d['\x57\x64\x42\x65\x74'](_0x409272, _0x3a44a9, _0x46d450(0xe8), _0x304c5d[_0x46d450(0x137)], _0x304c5d[_0x46d450(0x223)], 0x1 * 0x2c0c3 + -0x14 * -0x227c + -0x47 * 0xd57);
                            continue;
                        case '\x34':
                            _0x1b5c69 = _0x4aaa1d['\x66\x69\x6e\x64'](_0x315ca8 => _0x315ca8[_0x46d450(0x3e6)][_0x46d450(0x2fa)]() == _0x394d84);
                            continue;
                        case '\x35':
                            _0x304c5d['\x4b\x41\x79\x4b\x43'](_0x5412d6, _0x2e505b);
                            continue;
                        case '\x36':
                            if (!(_0x122f72[_0x46d450(0x3be)] && _0x304c5d[_0x46d450(0x27a)](_0x162fc4[_0x46d450(0x3be)]['\x4e\x61\x6d\x65'], _0x304c5d[_0x46d450(0x2b1)]))) {
                                if (_0x304c5d['\x6e\x55\x75\x6b\x55'](_0x41648d[_0x46d450(0x3e6)], _0x46d450(0x27e))) {
                                    _0x304c5d[_0x46d450(0x26f)](_0x3a1600, _0x46d450(0x2f6));
                                    return;
                                }
                            }
                            continue;
                        case '\x37':
                            _0x42d1fc[_0x46d450(0x3f5)][_0x46d450(0x290)] = -0x2392 + -0x1f7 * -0x6 + 0x4 * 0x5f2;
                            continue;
                        }
                        break;
                    }
                } else
                    return;
            }
            targetMember['\x41\x70\x70\x65\x61\x72\x61\x6e\x63\x65'][_0x46d450(0x2c4)](_0x3c1c76 => {
                const _0x291de2 = _0x46d450, _0x3fbe05 = {
                        '\x6b\x6b\x4f\x5a\x52': _0x304c5d[_0x291de2(0x2b1)],
                        '\x41\x62\x4e\x6c\x73': function (_0xd1d86b, _0x3098a2) {
                            const _0x3f88dc = _0x291de2;
                            return _0x304c5d[_0x3f88dc(0x3c9)](_0xd1d86b, _0x3098a2);
                        },
                        '\x67\x57\x47\x42\x77': function (_0x18476f, _0x1e58ee) {
                            return _0x304c5d['\x42\x44\x45\x70\x6f'](_0x18476f, _0x1e58ee);
                        },
                        '\x7a\x4c\x44\x62\x6f': _0x291de2(0x2f6)
                    };
                if (_0x304c5d[_0x291de2(0x1b5)](_0x304c5d[_0x291de2(0x411)], _0x304c5d[_0x291de2(0x411)])) {
                    if (_0x29285d['\x4e\x61\x6d\x65'] != _0x3fbe05['\x6b\x6b\x4f\x5a\x52']) {
                        _0x3fbe05[_0x291de2(0x286)](_0x2eeb6e, _0x291de2(0x2f6));
                        return;
                    }
                } else {
                    if (_0x304c5d[_0x291de2(0x35b)](_0x3c1c76[_0x291de2(0x22e)], 0x216c + -0x7e8 * -0x1 + 0x2 * -0x14aa) && _0x3c1c76[_0x291de2(0xee)]) {
                        if (_0x291de2(0x392) === _0x304c5d[_0x291de2(0x2a3)]) {
                            let _0x547035 = _0x291de2(0x3b4), _0x19666c = _0x291de2(0x3b4);
                            _0x3c1c76[_0x291de2(0xee)][_0x291de2(0x3a3)] && (_0x19666c = _0x3c1c76[_0x291de2(0xee)][_0x291de2(0x3a3)]), _0x3c1c76[_0x291de2(0xee)][_0x291de2(0x3da)] && (_0x19666c = _0x3c1c76[_0x291de2(0xee)][_0x291de2(0x3da)]), _0x3c1c76['\x41\x73\x73\x65\x74']['\x4e\x61\x6d\x65'] && (_0x304c5d[_0x291de2(0xf0)](_0x304c5d[_0x291de2(0x38d)], _0x304c5d[_0x291de2(0x38d)]) ? _0x547035 = _0x3c1c76[_0x291de2(0x1e9)][_0x291de2(0x3e6)] : _0x59d955[_0x291de2(0xee)][_0x291de2(0x29c)][_0x291de2(0x30a)](_0x4c6699[_0x291de2(0x3a9)])), _0x19666c != _0x304c5d[_0x291de2(0x133)] && _0x304c5d[_0x291de2(0x2b8)](ChatRoomSendLocal, _0x304c5d[_0x291de2(0x16c)](_0x304c5d[_0x291de2(0x2be)](_0x547035, _0x304c5d['\x73\x72\x66\x49\x42']), _0x19666c));
                        } else {
                            _0x3fbe05[_0x291de2(0x123)](_0x35369a, _0x3fbe05[_0x291de2(0x422)]);
                            return;
                        }
                    }
                }
            });
        } else
            _0x4c6699[_0x46d450(0x1f8)](_0x50555d, _0x4c6699[_0x46d450(0x35c)], -0x2185b + 0x2bf69 * 0x1 + 0x24 * 0x7c9);
    }), _0x304c5d[_0x29dbd0(0x156)](GM_registerMenuCommand, _0x29dbd0(0x1ed), () => {
        const _0x5a2ca9 = _0x29dbd0, _0x2ad3e2 = {
                '\x70\x50\x55\x4d\x7a': '\x61\x77\x61\x71\x77\x71',
                '\x46\x71\x65\x42\x6a': function (_0x954af5, _0xbf7d71) {
                    return _0x304c5d['\x46\x74\x69\x43\x64'](_0x954af5, _0xbf7d71);
                },
                '\x6d\x68\x54\x78\x46': _0x304c5d[_0x5a2ca9(0x327)],
                '\x6b\x79\x68\x44\x6c': function (_0x32ef5, _0x582330) {
                    const _0x5b4553 = _0x5a2ca9;
                    return _0x304c5d[_0x5b4553(0x2be)](_0x32ef5, _0x582330);
                },
                '\x6f\x72\x4c\x6c\x50': function (_0x358642, _0x2de400) {
                    const _0x376eef = _0x5a2ca9;
                    return _0x304c5d[_0x376eef(0x26b)](_0x358642, _0x2de400);
                },
                '\x75\x7a\x44\x4e\x6b': _0x304c5d[_0x5a2ca9(0x304)],
                '\x78\x55\x65\x65\x64': _0x304c5d[_0x5a2ca9(0xed)],
                '\x67\x4a\x42\x51\x61': _0x304c5d[_0x5a2ca9(0x1a2)],
                '\x51\x61\x75\x70\x6d': function (_0x424697, _0x364a8a) {
                    const _0x51a160 = _0x5a2ca9;
                    return _0x304c5d[_0x51a160(0x12b)](_0x424697, _0x364a8a);
                },
                '\x6c\x56\x51\x5a\x57': _0x5a2ca9(0x259),
                '\x57\x62\x51\x4d\x6a': _0x304c5d[_0x5a2ca9(0x242)],
                '\x76\x41\x71\x79\x43': function (_0x17f8dc, _0x2a37b4) {
                    const _0x1bfb6b = _0x5a2ca9;
                    return _0x304c5d[_0x1bfb6b(0x395)](_0x17f8dc, _0x2a37b4);
                },
                '\x71\x6a\x6a\x59\x69': function (_0x3ecafb, _0x59f716) {
                    const _0x19c853 = _0x5a2ca9;
                    return _0x304c5d[_0x19c853(0x2ec)](_0x3ecafb, _0x59f716);
                },
                '\x45\x59\x64\x73\x61': _0x304c5d['\x50\x78\x6c\x50\x4f'],
                '\x58\x69\x53\x45\x73': function (_0x347a66, _0x39caf7, _0x53d654) {
                    return _0x304c5d['\x73\x49\x56\x65\x43'](_0x347a66, _0x39caf7, _0x53d654);
                },
                '\x46\x65\x50\x61\x59': _0x304c5d[_0x5a2ca9(0x19e)],
                '\x46\x6c\x4a\x4c\x77': _0x304c5d[_0x5a2ca9(0x150)],
                '\x63\x53\x50\x61\x56': function (_0x52269b, _0x3a2af8) {
                    const _0x47a9f5 = _0x5a2ca9;
                    return _0x304c5d[_0x47a9f5(0x3b5)](_0x52269b, _0x3a2af8);
                },
                '\x54\x50\x72\x4d\x6e': _0x304c5d[_0x5a2ca9(0x2a7)],
                '\x58\x48\x5a\x53\x76': _0x5a2ca9(0x198),
                '\x52\x53\x57\x41\x68': _0x5a2ca9(0x249),
                '\x6c\x6f\x68\x65\x5a': function (_0x35f581, _0x239caf) {
                    const _0x48339b = _0x5a2ca9;
                    return _0x304c5d[_0x48339b(0x3d0)](_0x35f581, _0x239caf);
                },
                '\x6f\x70\x47\x49\x4d': _0x5a2ca9(0x2f0),
                '\x67\x52\x6f\x79\x62': _0x304c5d[_0x5a2ca9(0x34f)],
                '\x57\x63\x62\x4d\x6c': _0x304c5d['\x4e\x5a\x54\x66\x74'],
                '\x5a\x75\x67\x56\x66': function (_0x36cc61, _0x4c0226) {
                    return _0x36cc61 > _0x4c0226;
                },
                '\x5a\x54\x6d\x56\x73': function (_0x1d5408, _0x4e16d1) {
                    const _0x6092d2 = _0x5a2ca9;
                    return _0x304c5d[_0x6092d2(0xf3)](_0x1d5408, _0x4e16d1);
                },
                '\x56\x50\x52\x67\x6b': _0x5a2ca9(0x3e5),
                '\x74\x6a\x7a\x76\x76': _0x304c5d['\x4c\x72\x55\x7a\x57'],
                '\x70\x62\x64\x6a\x50': _0x304c5d[_0x5a2ca9(0x32c)],
                '\x66\x42\x63\x6e\x56': function (_0x241202, _0x2b04c8) {
                    return _0x241202 == _0x2b04c8;
                },
                '\x4b\x78\x43\x42\x45': function (_0x4bdbd7, _0x463d5a) {
                    return _0x4bdbd7 < _0x463d5a;
                },
                '\x53\x4c\x55\x4c\x50': '\x44\x72\x65\x73\x73\x61\x67\x65',
                '\x54\x52\x47\x6a\x70': _0x5a2ca9(0x3f2),
                '\x6e\x57\x73\x78\x72': function (_0xcded9d, _0x3023b3) {
                    const _0x4c3ead = _0x5a2ca9;
                    return _0x304c5d[_0x4c3ead(0x1b5)](_0xcded9d, _0x3023b3);
                },
                '\x6e\x72\x69\x66\x65': _0x304c5d[_0x5a2ca9(0x296)],
                '\x4b\x7a\x78\x70\x64': function (_0x297a99, _0x4c325d) {
                    const _0x5f51ec = _0x5a2ca9;
                    return _0x304c5d[_0x5f51ec(0x3d0)](_0x297a99, _0x4c325d);
                },
                '\x78\x50\x65\x66\x77': function (_0x3732d9, _0x12c009) {
                    const _0x3178b9 = _0x5a2ca9;
                    return _0x304c5d[_0x3178b9(0x3fa)](_0x3732d9, _0x12c009);
                },
                '\x75\x74\x4a\x7a\x5a': function (_0x2ce22e, _0x5aef97) {
                    return _0x304c5d['\x65\x51\x76\x43\x50'](_0x2ce22e, _0x5aef97);
                },
                '\x43\x4f\x42\x66\x47': _0x304c5d[_0x5a2ca9(0x306)],
                '\x55\x6d\x4b\x64\x5a': _0x304c5d[_0x5a2ca9(0x371)],
                '\x4a\x6b\x51\x45\x55': function (_0x96b6ae, _0x219455) {
                    const _0x532cbe = _0x5a2ca9;
                    return _0x304c5d[_0x532cbe(0x367)](_0x96b6ae, _0x219455);
                },
                '\x59\x5a\x53\x72\x48': function (_0x2f7f42, _0x3a4362) {
                    return _0x304c5d['\x6c\x58\x68\x63\x46'](_0x2f7f42, _0x3a4362);
                },
                '\x79\x66\x61\x71\x6a': _0x304c5d[_0x5a2ca9(0x3db)],
                '\x54\x79\x65\x68\x67': function (_0x5dadbe, _0x32e522, _0x2e3bae, _0x349ef6, _0x6f38b7, _0x5cc033) {
                    const _0x16d4d0 = _0x5a2ca9;
                    return _0x304c5d[_0x16d4d0(0x10c)](_0x5dadbe, _0x32e522, _0x2e3bae, _0x349ef6, _0x6f38b7, _0x5cc033);
                },
                '\x48\x52\x51\x5a\x59': _0x5a2ca9(0xe8),
                '\x70\x6a\x43\x47\x6e': _0x304c5d[_0x5a2ca9(0x137)],
                '\x41\x77\x67\x5a\x47': _0x304c5d[_0x5a2ca9(0x223)],
                '\x72\x4a\x66\x45\x64': _0x304c5d[_0x5a2ca9(0x3ac)],
                '\x77\x64\x68\x77\x41': _0x5a2ca9(0x15d),
                '\x59\x4c\x6d\x6a\x48': _0x304c5d[_0x5a2ca9(0xf9)],
                '\x6b\x54\x6e\x52\x69': _0x304c5d[_0x5a2ca9(0x1e0)],
                '\x57\x51\x6e\x63\x44': function (_0x21b582, _0x73fbbb, _0x102732, _0x5e9c56, _0x306c29, _0x5eb286) {
                    return _0x21b582(_0x73fbbb, _0x102732, _0x5e9c56, _0x306c29, _0x5eb286);
                },
                '\x45\x68\x6e\x50\x45': _0x5a2ca9(0xfa),
                '\x48\x49\x64\x77\x41': function (_0x490148, _0x10bad6) {
                    const _0x36c4c7 = _0x5a2ca9;
                    return _0x304c5d[_0x36c4c7(0x3c9)](_0x490148, _0x10bad6);
                },
                '\x76\x54\x69\x65\x43': function (_0x10ddf0, _0x5292b4) {
                    return _0x304c5d['\x49\x46\x6d\x6e\x6b'](_0x10ddf0, _0x5292b4);
                },
                '\x7a\x79\x6f\x6b\x79': _0x304c5d[_0x5a2ca9(0x302)],
                '\x69\x6e\x7a\x42\x45': _0x5a2ca9(0x1a6),
                '\x6e\x64\x46\x68\x66': function (_0x605a36, _0x87d3cd) {
                    const _0x7799cc = _0x5a2ca9;
                    return _0x304c5d[_0x7799cc(0x413)](_0x605a36, _0x87d3cd);
                },
                '\x51\x64\x46\x4a\x74': _0x5a2ca9(0x3ea),
                '\x77\x78\x52\x54\x47': _0x304c5d[_0x5a2ca9(0x2f7)],
                '\x78\x70\x74\x6a\x72': _0x304c5d[_0x5a2ca9(0x3c1)],
                '\x63\x66\x6e\x76\x4d': _0x5a2ca9(0x157),
                '\x73\x6b\x7a\x44\x55': _0x304c5d['\x74\x6b\x43\x52\x56'],
                '\x71\x4c\x55\x61\x67': '\x49\x74\x65\x6d\x45\x61\x72\x73',
                '\x66\x72\x6a\x54\x69': _0x304c5d[_0x5a2ca9(0x2a6)],
                '\x43\x54\x70\x59\x41': _0x304c5d['\x4e\x66\x62\x50\x50'],
                '\x4f\x4f\x53\x49\x6f': _0x304c5d[_0x5a2ca9(0x25d)],
                '\x71\x72\x49\x73\x62': _0x304c5d[_0x5a2ca9(0x20a)],
                '\x63\x70\x51\x4e\x72': _0x304c5d[_0x5a2ca9(0x3c3)],
                '\x4d\x70\x78\x42\x54': '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68\x33',
                '\x6b\x4a\x52\x71\x7a': _0x304c5d['\x74\x6a\x6e\x4b\x4e'],
                '\x7a\x59\x4e\x68\x4c': _0x304c5d['\x74\x72\x73\x79\x49'],
                '\x69\x73\x54\x42\x48': _0x304c5d[_0x5a2ca9(0x237)],
                '\x47\x6a\x6f\x46\x56': _0x5a2ca9(0x15a),
                '\x45\x54\x7a\x63\x6d': _0x304c5d[_0x5a2ca9(0x309)],
                '\x42\x48\x79\x78\x78': _0x304c5d[_0x5a2ca9(0x316)],
                '\x70\x64\x6e\x4b\x57': _0x304c5d[_0x5a2ca9(0x3f6)],
                '\x6f\x42\x49\x74\x42': function (_0x46e1b9, _0x158bbe) {
                    return _0x304c5d['\x68\x4c\x42\x78\x42'](_0x46e1b9, _0x158bbe);
                },
                '\x74\x52\x50\x52\x6c': '\u5927\u7b11\x7e\x20\x28\u987a\u624b\u62d6\u5165\u5c01\u7981\u540d\u5355\x29\x7e',
                '\x62\x4c\x4f\x66\x79': _0x5a2ca9(0x2b5),
                '\x53\x47\x54\x4a\x6c': function (_0x56d4ab, _0x25bd31) {
                    return _0x56d4ab + _0x25bd31;
                },
                '\x54\x69\x62\x45\x79': _0x304c5d[_0x5a2ca9(0x3a5)],
                '\x42\x51\x64\x4d\x74': _0x304c5d[_0x5a2ca9(0x3aa)],
                '\x6e\x6d\x47\x41\x66': _0x5a2ca9(0x32e),
                '\x6f\x74\x78\x72\x62': function (_0x99d86d, _0x25d36b) {
                    const _0x242e20 = _0x5a2ca9;
                    return _0x304c5d[_0x242e20(0x21d)](_0x99d86d, _0x25d36b);
                },
                '\x79\x73\x4a\x79\x65': _0x304c5d[_0x5a2ca9(0x1ca)],
                '\x42\x5a\x71\x48\x47': _0x304c5d[_0x5a2ca9(0x225)],
                '\x68\x56\x5a\x43\x7a': function (_0x46a830, _0x37145f) {
                    return _0x46a830 === _0x37145f;
                },
                '\x56\x50\x4a\x4f\x58': _0x304c5d['\x72\x56\x74\x6a\x4f'],
                '\x52\x4f\x41\x56\x58': _0x304c5d[_0x5a2ca9(0x378)],
                '\x76\x56\x78\x75\x77': _0x304c5d['\x69\x4b\x72\x67\x50'],
                '\x50\x64\x77\x74\x78': function (_0x77b792, _0x1c84b4) {
                    const _0x9332bb = _0x5a2ca9;
                    return _0x304c5d[_0x9332bb(0x2f2)](_0x77b792, _0x1c84b4);
                },
                '\x49\x4d\x51\x61\x59': function (_0x323293, _0x1cddd5, _0x3c42c0, _0x122411, _0x202f80, _0x14b726) {
                    const _0x73e4a4 = _0x5a2ca9;
                    return _0x304c5d[_0x73e4a4(0x214)](_0x323293, _0x1cddd5, _0x3c42c0, _0x122411, _0x202f80, _0x14b726);
                },
                '\x73\x69\x78\x54\x56': _0x304c5d[_0x5a2ca9(0x303)],
                '\x78\x65\x57\x68\x74': function (_0x598fd6, _0x530c25, _0x51e8f5, _0x46988b, _0x315f3c, _0x174cc2) {
                    const _0x19d525 = _0x5a2ca9;
                    return _0x304c5d[_0x19d525(0x279)](_0x598fd6, _0x530c25, _0x51e8f5, _0x46988b, _0x315f3c, _0x174cc2);
                },
                '\x4e\x63\x4d\x61\x6f': function (_0x2d0216, _0x51c8bf) {
                    const _0x19e551 = _0x5a2ca9;
                    return _0x304c5d[_0x19e551(0x3d0)](_0x2d0216, _0x51c8bf);
                },
                '\x47\x57\x62\x4d\x70': _0x304c5d[_0x5a2ca9(0x36a)],
                '\x51\x75\x55\x6a\x61': '\x41\x73\x20\x75\x20\x77\x69\x73\x68\x7e\x28\x47\x6f\x6f\x64\x20\x6c\x75\x63\x6b\x21\x29',
                '\x75\x43\x56\x4f\x46': _0x304c5d[_0x5a2ca9(0x2b4)],
                '\x58\x49\x73\x42\x57': _0x304c5d[_0x5a2ca9(0x402)],
                '\x55\x6f\x50\x78\x45': _0x304c5d[_0x5a2ca9(0x165)],
                '\x59\x54\x6b\x51\x7a': function (_0x56bb96, _0x3429e) {
                    const _0x3b1955 = _0x5a2ca9;
                    return _0x304c5d[_0x3b1955(0x3f1)](_0x56bb96, _0x3429e);
                },
                '\x65\x62\x6d\x78\x42': _0x304c5d[_0x5a2ca9(0x154)],
                '\x53\x6f\x4d\x63\x65': function (_0x513f6c, _0x49b754) {
                    const _0x51df8a = _0x5a2ca9;
                    return _0x304c5d[_0x51df8a(0x116)](_0x513f6c, _0x49b754);
                },
                '\x74\x52\x54\x74\x6e': _0x304c5d[_0x5a2ca9(0x323)],
                '\x76\x7a\x72\x7a\x7a': function (_0x3b12d3, _0x3c1378, _0x2792fd, _0x2c08f1, _0x2fc698, _0x1c3901) {
                    const _0x181f95 = _0x5a2ca9;
                    return _0x304c5d[_0x181f95(0x144)](_0x3b12d3, _0x3c1378, _0x2792fd, _0x2c08f1, _0x2fc698, _0x1c3901);
                },
                '\x4d\x78\x76\x45\x50': _0x5a2ca9(0x1bf),
                '\x41\x4d\x56\x61\x52': function (_0x6e1502, _0x459ae0) {
                    return _0x6e1502 != _0x459ae0;
                },
                '\x6c\x68\x76\x6d\x58': _0x304c5d[_0x5a2ca9(0x19b)],
                '\x4a\x58\x75\x4f\x6e': _0x304c5d['\x79\x69\x7a\x6c\x65'],
                '\x61\x50\x44\x6c\x51': '\x49\x74\x65\x6d\x48\x6f\x6f\x64',
                '\x57\x67\x61\x45\x46': _0x304c5d[_0x5a2ca9(0x138)],
                '\x61\x6e\x71\x47\x69': _0x304c5d[_0x5a2ca9(0xfe)],
                '\x49\x43\x58\x67\x67': function (_0x1432b6, _0xf61adb) {
                    return _0x1432b6(_0xf61adb);
                },
                '\x78\x58\x43\x6a\x63': function (_0x581f2d, _0x31de6b, _0x35500c) {
                    const _0x4b2922 = _0x5a2ca9;
                    return _0x304c5d[_0x4b2922(0x3dd)](_0x581f2d, _0x31de6b, _0x35500c);
                },
                '\x72\x68\x6c\x68\x76': function (_0x55ff1e, _0x4734ad) {
                    const _0x2970cd = _0x5a2ca9;
                    return _0x304c5d[_0x2970cd(0x1a9)](_0x55ff1e, _0x4734ad);
                },
                '\x57\x6d\x4a\x6f\x65': _0x5a2ca9(0xeb),
                '\x4b\x71\x44\x70\x71': _0x304c5d['\x42\x71\x72\x66\x70'],
                '\x46\x4b\x6f\x6b\x51': _0x304c5d[_0x5a2ca9(0x2a5)],
                '\x63\x59\x64\x50\x6c': function (_0x157681, _0x48fcd2) {
                    const _0x217d38 = _0x5a2ca9;
                    return _0x304c5d[_0x217d38(0x413)](_0x157681, _0x48fcd2);
                },
                '\x4f\x64\x46\x45\x49': _0x5a2ca9(0x125),
                '\x4d\x48\x49\x52\x45': _0x304c5d['\x69\x70\x7a\x42\x4b'],
                '\x78\x72\x4e\x6d\x4f': '\x62\x42\x7a\x50\x5a',
                '\x5a\x6e\x59\x48\x54': function (_0x4e9d13, _0x5924ad) {
                    const _0x2838e6 = _0x5a2ca9;
                    return _0x304c5d[_0x2838e6(0x33e)](_0x4e9d13, _0x5924ad);
                },
                '\x43\x53\x76\x6b\x54': _0x304c5d[_0x5a2ca9(0x320)],
                '\x52\x47\x68\x76\x78': function (_0x4ed6b6, _0xf5dbc6) {
                    return _0x304c5d['\x64\x6e\x5a\x58\x4d'](_0x4ed6b6, _0xf5dbc6);
                },
                '\x4c\x69\x66\x45\x50': _0x304c5d['\x69\x6f\x6d\x50\x71'],
                '\x48\x45\x45\x78\x47': _0x304c5d['\x5a\x76\x42\x50\x6a']
            };
        if (!(Player[_0x5a2ca9(0x3be)] && _0x304c5d[_0x5a2ca9(0x338)](Player[_0x5a2ca9(0x3be)][_0x5a2ca9(0x3e6)], _0x304c5d['\x6b\x5a\x54\x6a\x79']))) {
            if (_0x304c5d['\x61\x66\x52\x44\x61'](_0x5a2ca9(0x128), '\x59\x4b\x77\x41\x57')) {
                if (_0x567d28[_0x5a2ca9(0x3e6)] != _0x2ad3e2[_0x5a2ca9(0x2d5)]) {
                    _0x2ad3e2['\x46\x71\x65\x42\x6a'](_0x315ebe, _0x2ad3e2[_0x5a2ca9(0x343)]);
                    return;
                }
            } else {
                if (_0x304c5d[_0x5a2ca9(0x37a)](Player['\x4e\x61\x6d\x65'], _0x304c5d['\x6b\x5a\x54\x6a\x79'])) {
                    if (_0x304c5d['\x6c\x4f\x73\x64\x6e'] === _0x304c5d['\x6c\x4f\x73\x64\x6e']) {
                        _0x304c5d[_0x5a2ca9(0x115)](alert, '\u4f60\u5fc5\u987b\u662f\x61\x77\x61\x71\x77\x71\u7684\x73\x75\x62\u624d\u80fd\u8fd9\u4e48\u505a\u5462\x7e');
                        return;
                    } else
                        _0x2a8ba6 = _0x11fa05['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x5a2ca9(0x3a3)];
                }
            }
        }
        AwNick = '\x61\x77\u9171', AwReply = _0x5a2ca9(0x1ed), AwBotLast = '\x61\x77\x61\x71\x77\x71\x20\x69\x73\x20\x68\x75\x7a\x70\x73\x62', AwBotBan = [], SpeechGarble = function (_0x140fe9, _0x1cde59, _0x2363c7) {
            const _0x2a2975 = _0x5a2ca9, _0xdbf069 = {
                    '\x57\x72\x6f\x74\x4b': _0x304c5d['\x7a\x49\x76\x58\x7a'],
                    '\x42\x52\x4a\x6d\x6d': _0x304c5d[_0x2a2975(0x1f0)],
                    '\x66\x63\x4d\x68\x4e': function (_0x5cf6a2, _0x3a7958, _0x1edcba, _0xd4210e) {
                        return _0x5cf6a2(_0x3a7958, _0x1edcba, _0xd4210e);
                    },
                    '\x7a\x47\x6a\x69\x50': _0x304c5d['\x6b\x55\x72\x6c\x4a'],
                    '\x6f\x4c\x48\x48\x64': function (_0x31357e, _0x1f6b50, _0x3485be, _0x2a17f2) {
                        return _0x31357e(_0x1f6b50, _0x3485be, _0x2a17f2);
                    },
                    '\x4a\x49\x6a\x67\x42': function (_0x1ea8b5, _0x5b31ef) {
                        const _0x479c80 = _0x2a2975;
                        return _0x304c5d[_0x479c80(0x2b8)](_0x1ea8b5, _0x5b31ef);
                    },
                    '\x67\x6a\x61\x79\x73': _0x304c5d['\x49\x6e\x4f\x45\x59'],
                    '\x59\x74\x78\x7a\x54': _0x304c5d['\x74\x4f\x56\x65\x72'],
                    '\x48\x54\x61\x41\x77': _0x304c5d['\x4a\x64\x45\x79\x50']
                };
            if (_0x304c5d[_0x2a2975(0x12b)]('\x53\x65\x6e\x67\x50', _0x304c5d[_0x2a2975(0x103)]))
                return !![];
            else {
                _0x304c5d[_0x2a2975(0x37a)](AwBotLast, _0x304c5d[_0x2a2975(0x16c)](_0x1cde59, _0x140fe9[_0x2a2975(0x3e6)])) && _0x304c5d[_0x2a2975(0x3b5)](_0x1cde59[_0x2a2975(0x1ef)](AwReply), -(-0x18c4 + 0x2333 + -0x1bd * 0x6)) && setTimeout(function () {
                    const _0x145b72 = _0x2a2975, _0x6447c = {
                            '\x4a\x6f\x54\x7a\x48': function (_0x96a216, _0xeb6060) {
                                return _0x2ad3e2['\x46\x71\x65\x42\x6a'](_0x96a216, _0xeb6060);
                            },
                            '\x4f\x67\x4d\x44\x57': _0x2ad3e2[_0x145b72(0x343)],
                            '\x4c\x4d\x4a\x6e\x63': function (_0x2eb64d, _0x298826) {
                                const _0x34e9ab = _0x145b72;
                                return _0x2ad3e2[_0x34e9ab(0x11d)](_0x2eb64d, _0x298826);
                            },
                            '\x6c\x56\x6c\x55\x49': function (_0x2559a0, _0x254e50) {
                                const _0x60a3ec = _0x145b72;
                                return _0x2ad3e2[_0x60a3ec(0x34e)](_0x2559a0, _0x254e50);
                            },
                            '\x6e\x63\x58\x4f\x4c': _0x2ad3e2[_0x145b72(0x176)],
                            '\x6e\x64\x6e\x71\x6d': _0x2ad3e2[_0x145b72(0x3d2)],
                            '\x6c\x56\x44\x4e\x6e': _0x2ad3e2[_0x145b72(0x2f3)],
                            '\x70\x6f\x4d\x51\x75': function (_0x439563, _0x22fd1f) {
                                const _0x215d71 = _0x145b72;
                                return _0x2ad3e2[_0x215d71(0x41b)](_0x439563, _0x22fd1f);
                            },
                            '\x6d\x4b\x78\x43\x4d': _0x2ad3e2['\x6c\x56\x51\x5a\x57'],
                            '\x64\x42\x6a\x4c\x79': _0x2ad3e2[_0x145b72(0x2aa)],
                            '\x4b\x79\x6e\x6d\x4b': function (_0x2e8c33, _0x24407d) {
                                const _0x524d4d = _0x145b72;
                                return _0x2ad3e2[_0x524d4d(0x1ac)](_0x2e8c33, _0x24407d);
                            },
                            '\x4f\x57\x44\x77\x47': function (_0x177270, _0x52aaf8) {
                                return _0x2ad3e2['\x71\x6a\x6a\x59\x69'](_0x177270, _0x52aaf8);
                            },
                            '\x57\x4f\x4c\x59\x6b': _0x145b72(0x345),
                            '\x61\x55\x51\x53\x6d': _0x2ad3e2[_0x145b72(0x353)],
                            '\x73\x48\x51\x64\x4b': _0x145b72(0x21f),
                            '\x46\x78\x6a\x48\x4d': function (_0x26395a, _0x6f8e33, _0x5a5f56) {
                                return _0x26395a(_0x6f8e33, _0x5a5f56);
                            },
                            '\x63\x4f\x61\x6b\x71': _0x145b72(0x2b5),
                            '\x62\x48\x52\x44\x49': function (_0x319fbf, _0x156537, _0x4e74aa) {
                                const _0x15fb26 = _0x145b72;
                                return _0x2ad3e2[_0x15fb26(0x1b8)](_0x319fbf, _0x156537, _0x4e74aa);
                            },
                            '\x78\x54\x63\x68\x4b': _0x2ad3e2[_0x145b72(0x206)],
                            '\x4b\x6d\x6c\x71\x64': function (_0x1293d9, _0x3718d4) {
                                return _0x2ad3e2['\x76\x41\x71\x79\x43'](_0x1293d9, _0x3718d4);
                            },
                            '\x6f\x45\x6b\x50\x6e': _0x2ad3e2[_0x145b72(0x427)],
                            '\x7a\x78\x6e\x6d\x64': function (_0x6aa639, _0x16ee18) {
                                const _0x5c7fc8 = _0x145b72;
                                return _0x2ad3e2[_0x5c7fc8(0x257)](_0x6aa639, _0x16ee18);
                            },
                            '\x66\x57\x74\x42\x74': function (_0x2995f8, _0x47c824) {
                                return _0x2995f8 === _0x47c824;
                            },
                            '\x44\x48\x63\x6a\x66': _0x2ad3e2[_0x145b72(0x268)],
                            '\x79\x46\x47\x48\x56': function (_0x5eebaf, _0x633cff) {
                                const _0x1ae392 = _0x145b72;
                                return _0x2ad3e2[_0x1ae392(0x257)](_0x5eebaf, _0x633cff);
                            },
                            '\x79\x55\x55\x45\x47': _0x2ad3e2[_0x145b72(0x3b6)],
                            '\x4b\x78\x71\x70\x52': '\x50\x61\x6e\x64\x6f\x72\x61\x50\x61\x64\x6c\x6f\x63\x6b',
                            '\x4b\x73\x74\x43\x4c': _0x2ad3e2['\x52\x53\x57\x41\x68'],
                            '\x56\x6b\x6b\x4a\x46': _0x145b72(0x27e),
                            '\x77\x70\x72\x4f\x4e': function (_0x56c8d8, _0x2b3971) {
                                const _0x188d35 = _0x145b72;
                                return _0x2ad3e2[_0x188d35(0x117)](_0x56c8d8, _0x2b3971);
                            },
                            '\x79\x77\x65\x58\x73': '\u5c01\u7981\u5931\u8d25\x3a\u73a9\u5bb6\u5df2\u7ecf\u88ab\u5c01\u7981',
                            '\x59\x42\x41\x5a\x65': function (_0x4ceff1, _0x3c0c37) {
                                return _0x4ceff1(_0x3c0c37);
                            },
                            '\x4a\x67\x6b\x75\x63': _0x2ad3e2[_0x145b72(0x2eb)],
                            '\x6a\x62\x6a\x68\x43': _0x2ad3e2[_0x145b72(0x145)],
                            '\x4a\x51\x6d\x56\x77': _0x145b72(0x2a8),
                            '\x69\x54\x72\x6c\x56': _0x2ad3e2[_0x145b72(0x1ae)],
                            '\x78\x52\x43\x79\x6f': function (_0x3c06da, _0x3bdba1) {
                                const _0x5c744b = _0x145b72;
                                return _0x2ad3e2[_0x5c744b(0x32a)](_0x3c06da, _0x3bdba1);
                            },
                            '\x54\x43\x71\x6d\x46': function (_0x106f92, _0x397968) {
                                const _0x28804c = _0x145b72;
                                return _0x2ad3e2[_0x28804c(0x1af)](_0x106f92, _0x397968);
                            },
                            '\x61\x6e\x65\x4b\x4a': _0x2ad3e2[_0x145b72(0x399)],
                            '\x42\x51\x48\x50\x4a': _0x2ad3e2[_0x145b72(0x19a)],
                            '\x64\x50\x78\x64\x6f': function (_0x3a3f6b, _0x912eab) {
                                const _0x3dd6d3 = _0x145b72;
                                return _0x2ad3e2[_0x3dd6d3(0x1af)](_0x3a3f6b, _0x912eab);
                            },
                            '\x74\x71\x71\x7a\x41': _0x2ad3e2[_0x145b72(0x216)],
                            '\x70\x4d\x4e\x72\x67': function (_0x571233, _0x2e805a) {
                                const _0x1e6416 = _0x145b72;
                                return _0x2ad3e2[_0x1e6416(0x187)](_0x571233, _0x2e805a);
                            },
                            '\x55\x61\x74\x59\x65': function (_0x62cb92, _0x1a1748) {
                                const _0x459583 = _0x145b72;
                                return _0x2ad3e2[_0x459583(0x1fe)](_0x62cb92, _0x1a1748);
                            },
                            '\x47\x44\x4e\x48\x46': function (_0x1a6333, _0x8ea6ee, _0x2d64aa) {
                                return _0x1a6333(_0x8ea6ee, _0x2d64aa);
                            },
                            '\x66\x76\x41\x4c\x72': _0x2ad3e2['\x53\x4c\x55\x4c\x50']
                        };
                    if (_0x2ad3e2[_0x145b72(0x41b)](_0x2ad3e2[_0x145b72(0x134)], _0x2ad3e2[_0x145b72(0x134)])) {
                        if (_0x2ad3e2['\x66\x42\x63\x6e\x56'](AwBotBan['\x69\x6e\x64\x65\x78\x4f\x66'](_0x140fe9['\x4e\x61\x6d\x65']), -(-0xb68 + -0x16d2 + 0x17d * 0x17))) {
                            if (_0x2ad3e2[_0x145b72(0x339)](_0x145b72(0x3bd), _0x2ad3e2[_0x145b72(0x15c)]))
                                _0x6447c[_0x145b72(0x1d3)](_0x405d75, '\u5c01\u7981\u5931\u8d25\x3a\u73a9\u5bb6\u6ca1\u6709\u88ab\u5c01\u7981');
                            else {
                                if (_0x2ad3e2[_0x145b72(0x26d)](_0x1cde59[_0x145b72(0x1ef)](AwNick), -(-0xedb + -0x25a5 + 0x3481))) {
                                    let _0x27351b = _0x2ad3e2[_0x145b72(0x3e7)](_0x2ad3e2[_0x145b72(0x269)](_0x2ad3e2[_0x145b72(0x297)], AwNick), _0x2ad3e2[_0x145b72(0x1c1)]);
                                    if (_0x2ad3e2[_0x145b72(0x255)](_0x1cde59[_0x145b72(0x1ef)]('\u6551\u6211'), -(-0x1ebb + -0x1c02 + -0x3abe * -0x1)))
                                        CharacterReleaseTotal(_0x140fe9), _0x140fe9['\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73']['\x50\x72\x6f\x67\x72\x65\x73\x73'] = 0x457 * 0x7 + -0x1b67 * 0x1 + -0x2fa, _0x2ad3e2['\x59\x5a\x53\x72\x48'](ChatRoomCharacterUpdate, _0x140fe9), _0x27351b = _0x145b72(0x18d);
                                    else {
                                        if (_0x2ad3e2[_0x145b72(0x117)](_0x1cde59['\x69\x6e\x64\x65\x78\x4f\x66']('\u6346\u6211'), -(-0x122d + 0x1 * 0xec2 + 0x4 * 0xdb))) {
                                            const _0x11fffc = _0x2ad3e2[_0x145b72(0x199)][_0x145b72(0x261)]('\x7c');
                                            let _0x1b1322 = -0x539 * -0x5 + 0x1 * -0x1b31 + 0x114;
                                            while (!![]) {
                                                switch (_0x11fffc[_0x1b1322++]) {
                                                case '\x30':
                                                    _0x2ad3e2[_0x145b72(0x10d)](ChatRoomCharacterUpdate, _0x140fe9);
                                                    continue;
                                                case '\x31':
                                                    _0x140fe9['\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73']['\x50\x72\x6f\x67\x72\x65\x73\x73'] = -0x1 * -0x5e7 + 0x15bc + -0x19 * 0x11b;
                                                    continue;
                                                case '\x32':
                                                    _0x2ad3e2[_0x145b72(0x167)](InventoryWear, _0x140fe9, _0x2ad3e2[_0x145b72(0x163)], _0x2ad3e2[_0x145b72(0x423)], _0x2ad3e2[_0x145b72(0x126)], 0x24d3b + -0x4f * -0x9ff + 0x23 * -0x1a9e);
                                                    continue;
                                                case '\x33':
                                                    _0x27351b = _0x145b72(0x25b);
                                                    continue;
                                                case '\x34':
                                                    InventoryWear(_0x140fe9, _0x145b72(0x20d), _0x2ad3e2[_0x145b72(0x2ed)], _0x2ad3e2['\x41\x77\x67\x5a\x47'], -0x2b05d * 0x1 + -0x4 * 0xd9bf + 0x7d6ab);
                                                    continue;
                                                }
                                                break;
                                            }
                                        } else {
                                            if (_0x1cde59['\x69\x6e\x64\x65\x78\x4f\x66']('\u5173\u4e8e') != -(0x1 * -0x1feb + -0x144 * 0x1d + 0x6 * 0xb70)) {
                                                if (_0x2ad3e2['\x77\x64\x68\x77\x41'] === _0x2ad3e2['\x77\x64\x68\x77\x41'])
                                                    _0x27351b = _0x2ad3e2[_0x145b72(0x33b)];
                                                else {
                                                    _0xb66920(_0x6447c[_0x145b72(0x32f)]);
                                                    return;
                                                }
                                            } else {
                                                if (_0x2ad3e2['\x4b\x7a\x78\x70\x64'](_0x1cde59[_0x145b72(0x1ef)]('\u8214\u6211'), -(-0x89f + 0x314 + -0x2 * -0x2c6)))
                                                    _0x27351b = _0x2ad3e2['\x6f\x72\x4c\x6c\x50'](_0x2ad3e2[_0x145b72(0x269)](_0x2ad3e2['\x6b\x54\x6e\x52\x69'], _0x140fe9['\x4e\x61\x6d\x65']), '\x2e');
                                                else {
                                                    if (_0x1cde59[_0x145b72(0x1ef)]('\u73a9\u6211') != -(-0x624 + 0x191 * 0x1 + 0x494))
                                                        _0x2ad3e2[_0x145b72(0x1af)](_0x145b72(0x2cc), _0x145b72(0x2cc)) ? _0x30cef9 = _0x6447c[_0x145b72(0x229)](_0x6447c[_0x145b72(0x229)](_0x6447c[_0x145b72(0x35e)](_0x6447c[_0x145b72(0x2b0)], _0x5cf776), '\x20'), _0x4f4e17) : (_0x2ad3e2[_0x145b72(0x2c0)](InventoryWear, _0x140fe9, _0x2ad3e2[_0x145b72(0x17b)], _0x2ad3e2[_0x145b72(0x2ed)], _0x2ad3e2[_0x145b72(0x126)], 0x15a8 * 0x1 + -0xe2ef * 0x3 + 0x45277), _0x140fe9[_0x145b72(0x3f5)]['\x50\x72\x6f\x67\x72\x65\x73\x73'] = 0x17d3 + 0x1bbe + -0x133 * 0x2b, _0x2ad3e2[_0x145b72(0x2f4)](ChatRoomCharacterUpdate, _0x140fe9), _0x27351b = _0x145b72(0x1a6));
                                                    else {
                                                        if (_0x1cde59[_0x145b72(0x1ef)]('\u9501\u6211') != -(-0x17cf * -0x1 + -0x1360 + 0x1b * -0x2a))
                                                            _0x2ad3e2[_0x145b72(0x2d8)](_0x2ad3e2[_0x145b72(0x1d1)], _0x2ad3e2['\x7a\x79\x6f\x6b\x79']) ? _0x20a7a2[_0x145b72(0xee)][_0x145b72(0x29c)][_0x145b72(0x30a)]('\x4c\x6f\x63\x6b') : (_0x140fe9[_0x145b72(0x17d)][_0x145b72(0x2c4)](_0x404e37 => {
                                                                const _0x39b270 = _0x145b72, _0x2af2d5 = {};
                                                                _0x2af2d5[_0x39b270(0x164)] = '\x42\x6f\x75\x6e\x74\x79\x53\x75\x69\x74\x63\x61\x73\x65', _0x2af2d5[_0x39b270(0x2ab)] = _0x6447c[_0x39b270(0x336)];
                                                                const _0x24eb7d = _0x2af2d5;
                                                                if (_0x6447c[_0x39b270(0x3c0)](_0x6447c[_0x39b270(0x361)], _0x6447c['\x64\x42\x6a\x4c\x79']))
                                                                    _0x14a07f(_0x1f2ee5, _0x24eb7d['\x48\x52\x65\x45\x6d'], _0x24eb7d[_0x39b270(0x2ab)]);
                                                                else {
                                                                    let _0x4f50db = 0x1 * -0xc29 + -0x1 * -0x162f + 0x503 * -0x2;
                                                                    _0x6447c[_0x39b270(0x20f)](_0x404e37['\x44\x69\x66\x66\x69\x63\x75\x6c\x74\x79'], -0x26be + 0x257 * -0x5 + 0x3271) && (_0x404e37[_0x39b270(0xee)] == null && (_0x404e37[_0x39b270(0xee)] = {}), _0x404e37[_0x39b270(0xee)]['\x45\x66\x66\x65\x63\x74'] == null && (_0x404e37[_0x39b270(0xee)][_0x39b270(0x29c)] = []), _0x6447c['\x4f\x57\x44\x77\x47'](_0x404e37['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x39b270(0x29c)][_0x39b270(0x1ef)](_0x6447c['\x57\x4f\x4c\x59\x6b']), -0x9ff * -0x1 + 0x231b + 0x17 * -0x1f6) && (_0x6447c['\x61\x55\x51\x53\x6d'] !== _0x6447c[_0x39b270(0x1fb)] ? (this[_0x39b270(0x2a2)] = ![], _0x6447c[_0x39b270(0x1d3)](_0x22395b, _0x6447c[_0x39b270(0x25e)])) : _0x404e37[_0x39b270(0xee)][_0x39b270(0x29c)][_0x39b270(0x30a)](_0x39b270(0x345))), _0x6447c[_0x39b270(0x20f)](Math[_0x39b270(0x1ec)](), -0x31 * -0x1 + 0x75 * -0xc + 0x54b + 0.5) ? _0x404e37[_0x39b270(0xee)][_0x39b270(0x315)] = _0x6447c[_0x39b270(0x246)] : _0x404e37[_0x39b270(0xee)][_0x39b270(0x315)] = _0x39b270(0x220), _0x404e37[_0x39b270(0xee)][_0x39b270(0x2bb)] = Player[_0x39b270(0x2ea)], _0x140fe9[_0x39b270(0x17d)][_0x4f50db] = _0x404e37), _0x4f50db++;
                                                                }
                                                            }), _0x140fe9[_0x145b72(0x3f5)][_0x145b72(0x290)] = 0xb74 + 0x25ee + -0x15 * 0x25a, _0x2ad3e2[_0x145b72(0x40b)](ChatRoomCharacterUpdate, _0x140fe9), _0x27351b = _0x2ad3e2[_0x145b72(0x358)]);
                                                        else {
                                                            if (_0x2ad3e2[_0x145b72(0x117)](_0x1cde59[_0x145b72(0x1ef)](_0x145b72(0x317)), -(0x2 * -0x607 + -0x1ae8 + 0x299 * 0xf))) {
                                                                if (_0x2ad3e2[_0x145b72(0x3b1)](_0x2ad3e2['\x51\x64\x46\x4a\x74'], _0x2ad3e2[_0x145b72(0x40a)])) {
                                                                    let _0x555ee0 = [
                                                                        _0x2ad3e2[_0x145b72(0x2ed)],
                                                                        _0x2ad3e2[_0x145b72(0x194)],
                                                                        _0x2ad3e2[_0x145b72(0xef)],
                                                                        _0x2ad3e2[_0x145b72(0x1a3)],
                                                                        _0x2ad3e2[_0x145b72(0x185)],
                                                                        _0x2ad3e2[_0x145b72(0x24e)],
                                                                        _0x2ad3e2[_0x145b72(0x423)],
                                                                        _0x2ad3e2[_0x145b72(0x346)],
                                                                        _0x2ad3e2[_0x145b72(0x18f)],
                                                                        _0x145b72(0x30f),
                                                                        _0x2ad3e2[_0x145b72(0x3eb)],
                                                                        _0x145b72(0x28e),
                                                                        _0x2ad3e2[_0x145b72(0x2ba)],
                                                                        _0x2ad3e2['\x63\x70\x51\x4e\x72'],
                                                                        _0x2ad3e2[_0x145b72(0x1c4)],
                                                                        _0x2ad3e2[_0x145b72(0x35a)],
                                                                        _0x2ad3e2['\x7a\x59\x4e\x68\x4c'],
                                                                        _0x2ad3e2['\x69\x73\x54\x42\x48'],
                                                                        _0x2ad3e2[_0x145b72(0x41a)],
                                                                        '\x49\x74\x65\x6d\x4e\x69\x70\x70\x6c\x65\x73\x50\x69\x65\x72\x63\x69\x6e\x67\x73',
                                                                        _0x145b72(0x3f3),
                                                                        _0x2ad3e2[_0x145b72(0x3cb)],
                                                                        _0x145b72(0x393),
                                                                        _0x2ad3e2['\x42\x48\x79\x78\x78'],
                                                                        _0x2ad3e2[_0x145b72(0x1f5)]
                                                                    ];
                                                                    _0x555ee0[_0x145b72(0x2c4)](_0x4beaaf => {
                                                                        const _0x3c8209 = _0x145b72;
                                                                        _0xdbf069[_0x3c8209(0x403)] !== _0xdbf069[_0x3c8209(0x112)] ? _0xdbf069['\x66\x63\x4d\x68\x4e'](InventoryWearRandom, _0x140fe9, _0x4beaaf, -0x36ea7 + 0x3 * 0xf1 + 0x52b26) : _0x37e661[_0x3c8209(0xee)][_0x3c8209(0x29c)] = [];
                                                                    }), _0x140fe9[_0x145b72(0x17d)][_0x145b72(0x2c4)](_0x2719bf => {
                                                                        const _0x351070 = _0x145b72, _0x56d8d2 = {
                                                                                '\x50\x61\x54\x48\x6a': function (_0x37e84b, _0x3925d8, _0x5c93cc) {
                                                                                    const _0x10e220 = _0x4408;
                                                                                    return _0x6447c[_0x10e220(0x363)](_0x37e84b, _0x3925d8, _0x5c93cc);
                                                                                },
                                                                                '\x65\x78\x49\x47\x73': _0x6447c['\x63\x4f\x61\x6b\x71'],
                                                                                '\x62\x69\x43\x79\x4c': '\x42\x65\x65\x70',
                                                                                '\x4b\x62\x75\x4c\x49': function (_0x865169, _0x5e1dda, _0x3b98df) {
                                                                                    const _0x2494ee = _0x4408;
                                                                                    return _0x6447c[_0x2494ee(0x31a)](_0x865169, _0x5e1dda, _0x3b98df);
                                                                                },
                                                                                '\x57\x49\x72\x66\x54': '\u4f60\u8981\u8bf4\u7684\u8bdd',
                                                                                '\x51\x43\x6c\x68\x71': _0x6447c[_0x351070(0xf2)]
                                                                            };
                                                                        let _0x807487 = 0x1d9f * 0x1 + -0xc5 * 0x2 + -0x1c15;
                                                                        if (_0x6447c[_0x351070(0x247)](_0x2719bf['\x44\x69\x66\x66\x69\x63\x75\x6c\x74\x79'], -0x24d + -0xe98 + 0x10e5)) {
                                                                            if (_0x6447c[_0x351070(0x38f)] !== _0x6447c['\x6f\x45\x6b\x50\x6e'])
                                                                                _0x56d8d2[_0x351070(0x3ee)](_0x2bfbef, _0x56d8d2[_0x351070(0x14c)], {
                                                                                    '\x43\x6f\x6e\x74\x65\x6e\x74': _0x56d8d2['\x62\x69\x43\x79\x4c'],
                                                                                    '\x54\x79\x70\x65': _0x351070(0x1a0),
                                                                                    '\x54\x61\x72\x67\x65\x74': null,
                                                                                    '\x44\x69\x63\x74\x69\x6f\x6e\x61\x72\x79': [{
                                                                                            '\x54\x61\x67': _0x351070(0x33a),
                                                                                            '\x54\x65\x78\x74': _0x56d8d2['\x4b\x62\x75\x4c\x49'](_0x55b242, _0x56d8d2[_0x351070(0x418)], _0x56d8d2[_0x351070(0x227)])
                                                                                        }]
                                                                                });
                                                                            else {
                                                                                if (_0x6447c[_0x351070(0x30c)](_0x2719bf[_0x351070(0xee)], null)) {
                                                                                    if (_0x6447c[_0x351070(0x264)]('\x74\x74\x59\x6b\x4e', _0x6447c[_0x351070(0x262)]))
                                                                                        _0x2719bf[_0x351070(0xee)] = {};
                                                                                    else
                                                                                        return;
                                                                                }
                                                                                _0x6447c['\x79\x46\x47\x48\x56'](_0x2719bf[_0x351070(0xee)][_0x351070(0x29c)], null) && (_0x2719bf[_0x351070(0xee)][_0x351070(0x29c)] = []), _0x6447c[_0x351070(0x2e0)](_0x2719bf[_0x351070(0xee)][_0x351070(0x29c)][_0x351070(0x1ef)](_0x6447c[_0x351070(0x202)]), -0x592 * 0x4 + -0x1fa8 + 0x35f0) && ('\x78\x6b\x67\x72\x61' === _0x6447c['\x79\x55\x55\x45\x47'] ? _0x2719bf[_0x351070(0xee)][_0x351070(0x29c)][_0x351070(0x30a)]('\x4c\x6f\x63\x6b') : _0x2b113f[_0x351070(0xee)] = {}), Math[_0x351070(0x1ec)]() > 0xfaf + 0x5de * -0x5 + 0xda7 + 0.5 ? _0x2719bf['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x351070(0x315)] = _0x351070(0x21f) : _0x2719bf[_0x351070(0xee)]['\x4c\x6f\x63\x6b\x65\x64\x42\x79'] = _0x6447c[_0x351070(0x1b7)], _0x2719bf[_0x351070(0xee)][_0x351070(0x2bb)] = Player[_0x351070(0x2ea)], _0x140fe9[_0x351070(0x17d)][_0x807487] = _0x2719bf;
                                                                            }
                                                                        }
                                                                        _0x807487++;
                                                                    }), _0x140fe9['\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73'][_0x145b72(0x290)] = -0x20 * 0x19 + -0x1b * -0x12 + 0x13a, _0x2ad3e2['\x6f\x42\x49\x74\x42'](ChatRoomCharacterUpdate, _0x140fe9), _0x27351b = _0x2ad3e2[_0x145b72(0x1d0)], AwBotBan[_0x145b72(0x30a)](_0x140fe9[_0x145b72(0x3e6)]);
                                                                } else
                                                                    _0x20095e['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x145b72(0x315)] = _0xdbf069[_0x145b72(0x232)];
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    ServerSend(_0x2ad3e2[_0x145b72(0x287)], {
                                        '\x43\x6f\x6e\x74\x65\x6e\x74': _0x2ad3e2[_0x145b72(0x209)](AwReply + '\x20', _0x27351b),
                                        '\x54\x79\x70\x65': _0x145b72(0x2a8)
                                    });
                                } else {
                                    if (_0x2ad3e2[_0x145b72(0x117)](_0x1cde59['\x69\x6e\x64\x65\x78\x4f\x66'](_0x2ad3e2[_0x145b72(0x25a)]), -(-0x1047 + -0x6 * 0x226 + -0x1 * -0x1d2c))) {
                                        let _0x160057 = _0x2ad3e2[_0x145b72(0x3f8)];
                                        if (_0x1cde59[_0x145b72(0x1ef)](_0x2ad3e2['\x6e\x6d\x47\x41\x66']) != -(0x1c9 * 0x11 + -0xd * 0x1c1 + -0x78b))
                                            _0x2ad3e2['\x6f\x74\x78\x72\x62'](CharacterReleaseTotal, _0x140fe9), _0x140fe9[_0x145b72(0x3f5)][_0x145b72(0x290)] = -0x2 * 0x6b + 0x1c6a + -0x1b94, ChatRoomCharacterUpdate(_0x140fe9), _0x160057 = _0x2ad3e2[_0x145b72(0x24c)];
                                        else {
                                            if (_0x1cde59[_0x145b72(0x1ef)](_0x2ad3e2[_0x145b72(0x348)]) != -(0x219e + -0x1352 * 0x2 + 0x507)) {
                                                if (_0x2ad3e2[_0x145b72(0x3ed)](_0x2ad3e2[_0x145b72(0x332)], _0x2ad3e2[_0x145b72(0x104)]))
                                                    _0x512d6a['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x145b72(0x29c)] = [];
                                                else {
                                                    const _0x472b4e = _0x2ad3e2[_0x145b72(0x2f5)]['\x73\x70\x6c\x69\x74']('\x7c');
                                                    let _0x4c8e62 = -0x484 * 0x7 + -0x11 * 0x4e + 0x24ca;
                                                    while (!![]) {
                                                        switch (_0x472b4e[_0x4c8e62++]) {
                                                        case '\x30':
                                                            _0x2ad3e2[_0x145b72(0x1c0)](ChatRoomCharacterUpdate, _0x140fe9);
                                                            continue;
                                                        case '\x31':
                                                            _0x140fe9[_0x145b72(0x3f5)][_0x145b72(0x290)] = 0x1 * -0xc61 + 0x3 * -0x3fb + 0xc29 * 0x2;
                                                            continue;
                                                        case '\x32':
                                                            _0x2ad3e2[_0x145b72(0x162)](InventoryWear, _0x140fe9, _0x2ad3e2[_0x145b72(0x10e)], _0x2ad3e2[_0x145b72(0x2ed)], _0x2ad3e2[_0x145b72(0x126)], 0x89 * 0x1d + -0x13cd4 + 0x243 * 0x14b);
                                                            continue;
                                                        case '\x33':
                                                            _0x160057 = _0x145b72(0x271);
                                                            continue;
                                                        case '\x34':
                                                            _0x2ad3e2[_0x145b72(0x2d0)](InventoryWear, _0x140fe9, _0x2ad3e2[_0x145b72(0x163)], _0x145b72(0x25f), _0x2ad3e2[_0x145b72(0x126)], -0x14f * 0x5a + 0x1ea7 * -0x1 + 0x1d * 0x148b);
                                                            continue;
                                                        }
                                                        break;
                                                    }
                                                }
                                            } else {
                                                if (_0x2ad3e2[_0x145b72(0x1d6)](_0x1cde59[_0x145b72(0x1ef)](_0x2ad3e2[_0x145b72(0x383)]), -(-0x2620 + 0x2549 + 0xd8)))
                                                    AwBotBan[_0x145b72(0x30a)](_0x140fe9[_0x145b72(0x3e6)]), _0x160057 = _0x2ad3e2[_0x145b72(0x22a)];
                                                else {
                                                    if (_0x1cde59[_0x145b72(0x1ef)](_0x2ad3e2[_0x145b72(0x3b0)]) != -(-0x7f * 0xd + -0x6a5 + -0x1 * -0xd19))
                                                        _0x2ad3e2[_0x145b72(0x195)] !== _0x2ad3e2['\x58\x49\x73\x42\x57'] ? _0x1239e0[_0x145b72(0x17d)] = _0x53a32c : _0x160057 = _0x2ad3e2[_0x145b72(0x217)];
                                                    else {
                                                        if (_0x2ad3e2[_0x145b72(0x2c2)](_0x1cde59[_0x145b72(0x1ef)](_0x145b72(0x27c)), -(-0x71 * -0x2d + -0x1 * 0x1b86 + 0x12 * 0x6d)))
                                                            _0x2ad3e2[_0x145b72(0x2a0)] === _0x145b72(0x231) ? _0x160057 = _0x2ad3e2[_0x145b72(0x236)](_0x2ad3e2[_0x145b72(0x269)](_0x2ad3e2['\x6b\x54\x6e\x52\x69'], _0x140fe9[_0x145b72(0x3e6)]), '\x2e') : (_0x248efa = _0x6447c[_0x145b72(0x363)](_0x672896, _0x6447c['\x4b\x73\x74\x43\x4c'], _0x6447c[_0x145b72(0x2c5)]), _0x6447c['\x77\x70\x72\x4f\x4e'](_0x51f62c[_0x145b72(0x1ef)](_0x2f658f), -(0xb49 * -0x2 + 0x5 * 0x3cb + 0x39c)) && _0x6447c[_0x145b72(0x1d3)](_0x2c367c, _0x6447c['\x79\x77\x65\x58\x73']), _0x4cc494[_0x145b72(0x30a)](_0x562605));
                                                        else {
                                                            if (_0x1cde59[_0x145b72(0x1ef)](_0x2ad3e2['\x74\x52\x54\x74\x6e']) != -(-0xaf6 * -0x1 + 0x2 * -0x98b + -0x821 * -0x1))
                                                                _0x2ad3e2['\x76\x7a\x72\x7a\x7a'](InventoryWear, _0x140fe9, _0x2ad3e2['\x45\x68\x6e\x50\x45'], _0x2ad3e2['\x72\x4a\x66\x45\x64'], _0x2ad3e2[_0x145b72(0x126)], 0xd54a + 0x1967e + -0x19 * 0x6e6), _0x140fe9[_0x145b72(0x3f5)][_0x145b72(0x290)] = 0x1f23 * -0x1 + -0xef * -0x9 + 0x16bc, _0x2ad3e2[_0x145b72(0x3a2)](ChatRoomCharacterUpdate, _0x140fe9), _0x160057 = _0x2ad3e2[_0x145b72(0x258)];
                                                            else {
                                                                if (_0x2ad3e2[_0x145b72(0xf7)](_0x1cde59[_0x145b72(0x1ef)](_0x2ad3e2[_0x145b72(0x173)]), -(0x85f * 0x1 + -0x1f76 + 0x1718 * 0x1)))
                                                                    _0x140fe9['\x41\x70\x70\x65\x61\x72\x61\x6e\x63\x65'][_0x145b72(0x2c4)](_0x2e7927 => {
                                                                        const _0x30d687 = _0x145b72, _0x454bcc = {};
                                                                        _0x454bcc[_0x30d687(0x1e6)] = _0x6447c['\x4f\x67\x4d\x44\x57'];
                                                                        const _0x4b9e9b = _0x454bcc;
                                                                        if (_0x6447c[_0x30d687(0x41f)] === _0x30d687(0x3c2)) {
                                                                            if (_0x309596[_0x30d687(0x3e6)] != _0x30d687(0x27e)) {
                                                                                _0x460078(_0x4b9e9b['\x63\x43\x70\x47\x59']);
                                                                                return;
                                                                            }
                                                                        } else {
                                                                            let _0x859059 = -0x1852 + 0x1 * -0x13bb + 0x15 * 0x219;
                                                                            if (_0x6447c[_0x30d687(0x28f)](_0x2e7927[_0x30d687(0x22e)], -0x1 * -0x599 + 0xad * -0x2 + 0x1 * -0x43f)) {
                                                                                if (_0x6447c[_0x30d687(0x253)](_0x6447c[_0x30d687(0x401)], _0x6447c[_0x30d687(0x291)]))
                                                                                    _0x6447c[_0x30d687(0x179)](_0x2e7927[_0x30d687(0xee)], null) && (_0x6447c[_0x30d687(0x27d)]('\x72\x56\x4d\x41\x79', _0x6447c[_0x30d687(0x114)]) ? (this['\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x5a\x68'] = ![], _0x6447c[_0x30d687(0x2e3)](_0x20845c, _0x6447c['\x4a\x67\x6b\x75\x63'])) : _0x2e7927[_0x30d687(0xee)] = {}), _0x6447c[_0x30d687(0x2c7)](_0x2e7927[_0x30d687(0xee)][_0x30d687(0x29c)], null) && (_0x2e7927[_0x30d687(0xee)][_0x30d687(0x29c)] = []), _0x6447c[_0x30d687(0x428)](_0x2e7927[_0x30d687(0xee)][_0x30d687(0x29c)][_0x30d687(0x1ef)](_0x6447c[_0x30d687(0x202)]), 0x20b1 + 0x3 * 0x481 + 0xb8d * -0x4) && _0x2e7927[_0x30d687(0xee)]['\x45\x66\x66\x65\x63\x74'][_0x30d687(0x30a)](_0x6447c['\x57\x4f\x4c\x59\x6b']), _0x6447c[_0x30d687(0x20f)](Math[_0x30d687(0x1ec)](), 0xb3f + 0x1c97 + -0x27d6 + 0.5) ? _0x2e7927[_0x30d687(0xee)][_0x30d687(0x315)] = _0x30d687(0x21f) : _0x2e7927[_0x30d687(0xee)][_0x30d687(0x315)] = _0x6447c[_0x30d687(0x1b7)], _0x2e7927['\x50\x72\x6f\x70\x65\x72\x74\x79']['\x4c\x6f\x63\x6b\x4d\x65\x6d\x62\x65\x72\x4e\x75\x6d\x62\x65\x72'] = Player['\x4d\x65\x6d\x62\x65\x72\x4e\x75\x6d\x62\x65\x72'], _0x140fe9['\x41\x70\x70\x65\x61\x72\x61\x6e\x63\x65'][_0x859059] = _0x2e7927;
                                                                                else {
                                                                                    const _0x43109d = {};
                                                                                    _0x43109d['\x43\x6f\x6e\x74\x65\x6e\x74'] = _0x6447c[_0x30d687(0x1ee)], _0x43109d[_0x30d687(0x235)] = _0x6447c[_0x30d687(0x11a)], _0x5adda6(_0x30d687(0x2b5), _0x43109d);
                                                                                }
                                                                            }
                                                                            _0x859059++;
                                                                        }
                                                                    }), _0x140fe9[_0x145b72(0x3f5)][_0x145b72(0x290)] = -0x3 * -0xc4b + 0xad * 0x26 + -0xc83 * 0x5, _0x2ad3e2[_0x145b72(0x10d)](ChatRoomCharacterUpdate, _0x140fe9), _0x160057 = _0x2ad3e2[_0x145b72(0x258)];
                                                                else {
                                                                    if (_0x2ad3e2[_0x145b72(0x26d)](_0x1cde59['\x69\x6e\x64\x65\x78\x4f\x66'](_0x2ad3e2[_0x145b72(0x2d2)]), -(0x1 * 0x1b73 + 0x613 + 0x2185 * -0x1))) {
                                                                        let _0x5da4ed = [
                                                                            _0x2ad3e2['\x72\x4a\x66\x45\x64'],
                                                                            _0x145b72(0x3fb),
                                                                            '\x49\x74\x65\x6d\x42\x72\x65\x61\x73\x74',
                                                                            _0x145b72(0x157),
                                                                            _0x2ad3e2[_0x145b72(0x185)],
                                                                            _0x2ad3e2['\x71\x4c\x55\x61\x67'],
                                                                            _0x2ad3e2[_0x145b72(0x423)],
                                                                            '\x49\x74\x65\x6d\x48\x61\x6e\x64\x73',
                                                                            _0x2ad3e2[_0x145b72(0x18f)],
                                                                            _0x2ad3e2['\x61\x50\x44\x6c\x51'],
                                                                            _0x2ad3e2[_0x145b72(0x3eb)],
                                                                            _0x2ad3e2[_0x145b72(0x2f3)],
                                                                            _0x145b72(0x1d8),
                                                                            _0x2ad3e2[_0x145b72(0x17f)],
                                                                            _0x145b72(0x333),
                                                                            _0x2ad3e2['\x6b\x4a\x52\x71\x7a'],
                                                                            _0x2ad3e2['\x7a\x59\x4e\x68\x4c'],
                                                                            _0x2ad3e2['\x69\x73\x54\x42\x48'],
                                                                            '\x49\x74\x65\x6d\x4e\x69\x70\x70\x6c\x65\x73',
                                                                            _0x145b72(0x132),
                                                                            _0x2ad3e2[_0x145b72(0x1ab)],
                                                                            _0x2ad3e2[_0x145b72(0x3cb)],
                                                                            _0x2ad3e2[_0x145b72(0x1cc)],
                                                                            _0x2ad3e2['\x42\x48\x79\x78\x78'],
                                                                            _0x2ad3e2[_0x145b72(0x1f5)]
                                                                        ];
                                                                        _0x5da4ed['\x66\x6f\x72\x45\x61\x63\x68'](_0x1e8b45 => {
                                                                            const _0x3745a2 = _0x145b72;
                                                                            _0xdbf069[_0x3745a2(0x3df)](InventoryWearRandom, _0x140fe9, _0x1e8b45, 0x19 * 0xeed + -0x7879 + 0xc2a6);
                                                                        }), _0x140fe9[_0x145b72(0x3f5)][_0x145b72(0x290)] = -0xd51 + -0x67 * -0x12 + 0x613, _0x2ad3e2['\x49\x43\x58\x67\x67'](ChatRoomCharacterUpdate, _0x140fe9), _0x160057 = _0x2ad3e2['\x4d\x78\x76\x45\x50'];
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        _0x2ad3e2[_0x145b72(0x400)](ServerSend, _0x2ad3e2['\x62\x4c\x4f\x66\x79'], {
                                            '\x43\x6f\x6e\x74\x65\x6e\x74': _0x2ad3e2['\x72\x68\x6c\x68\x76'](_0x2ad3e2[_0x145b72(0x1c8)], _0x160057),
                                            '\x54\x79\x70\x65': _0x2ad3e2['\x4b\x71\x44\x70\x71']
                                        });
                                    } else {
                                        if (_0x2ad3e2[_0x145b72(0x255)](_0x1cde59[_0x145b72(0x1ef)](_0x2ad3e2[_0x145b72(0x166)]), -(-0x21d5 + -0x4a8 + 0x267e))) {
                                            if (_0x2ad3e2['\x63\x59\x64\x50\x6c'](_0x2ad3e2[_0x145b72(0x3ae)], '\x61\x41\x54\x73\x44')) {
                                                _0xdbf069[_0x145b72(0x109)](_0xfdfa90, _0xdbf069[_0x145b72(0x121)]);
                                                return;
                                            } else {
                                                const _0x3e9431 = {};
                                                _0x3e9431[_0x145b72(0x2ad)] = _0x2ad3e2[_0x145b72(0x3c4)], _0x3e9431[_0x145b72(0x235)] = _0x2ad3e2[_0x145b72(0x13e)], ServerSend(_0x145b72(0x2b5), _0x3e9431);
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            if (_0x2ad3e2[_0x145b72(0x1af)](_0x145b72(0x39e), _0x2ad3e2['\x78\x72\x4e\x6d\x4f'])) {
                                if (_0x2ad3e2[_0x145b72(0x13a)](_0x1cde59['\x69\x6e\x64\x65\x78\x4f\x66'](_0x145b72(0x330)), -(-0xca6 + 0x1 * 0x425 + -0x882 * -0x1)))
                                    _0x2ad3e2['\x5a\x54\x6d\x56\x73'](_0x145b72(0xe9), _0x2ad3e2[_0x145b72(0x25c)]) ? ServerSend(_0x2ad3e2[_0x145b72(0x287)], {
                                        '\x43\x6f\x6e\x74\x65\x6e\x74': _0x145b72(0x39b),
                                        '\x54\x79\x70\x65': _0x2ad3e2[_0x145b72(0x13e)]
                                    }) : _0x472cdc[_0x145b72(0xee)][_0x145b72(0x315)] = _0x6447c[_0x145b72(0x246)];
                                else {
                                    if (_0x2ad3e2['\x52\x47\x68\x76\x78'](_0x1cde59[_0x145b72(0x1ef)](_0x2ad3e2[_0x145b72(0x25a)]), -(0x2590 + 0x22f0 + 0x1 * -0x487f))) {
                                        if (_0x2ad3e2[_0x145b72(0x3c7)](_0x145b72(0x424), _0x2ad3e2[_0x145b72(0x3d1)])) {
                                            const _0x41d511 = {};
                                            _0x41d511[_0x145b72(0x2ad)] = _0x2ad3e2['\x48\x45\x45\x78\x47'], _0x41d511['\x54\x79\x70\x65'] = _0x2ad3e2[_0x145b72(0x13e)], ServerSend('\x43\x68\x61\x74\x52\x6f\x6f\x6d\x43\x68\x61\x74', _0x41d511);
                                        } else
                                            _0x149ca3[_0x145b72(0xee)][_0x145b72(0x315)] = _0xdbf069[_0x145b72(0x232)];
                                    }
                                }
                            } else
                                _0x15ece9(_0xdbf069[_0x145b72(0x21a)], {
                                    '\x4d\x65\x6d\x62\x65\x72\x4e\x75\x6d\x62\x65\x72': _0x46ef5d['\x4d\x65\x6d\x62\x65\x72\x4e\x75\x6d\x62\x65\x72'],
                                    '\x41\x63\x74\x69\x6f\x6e': _0xdbf069[_0x145b72(0x1e7)]
                                });
                        }
                    } else
                        _0x6447c[_0x145b72(0x1e1)](_0x3f3e43, _0x6447c[_0x145b72(0x3fe)], 0x6823 + 0x14fe9 + 0x13 * 0x62);
                }, 0xb * 0x1ef + 0x266 + -0x13c3);
                AwBotLast = _0x304c5d[_0x2a2975(0x1a1)](_0x1cde59, _0x140fe9[_0x2a2975(0x3e6)]);
                let _0x3d69b4 = _0x1cde59, _0x1d9bfa = _0x304c5d[_0x2a2975(0x2f8)](SpeechGetTotalGagLevel, _0x140fe9, _0x2363c7);
                return _0x304c5d[_0x2a2975(0x35b)](_0x1d9bfa, -0x1684 + -0x184c + 0x358 * 0xe) && (_0x3d69b4 = _0x304c5d[_0x2a2975(0x3d3)](_0x304c5d[_0x2a2975(0x304)] + _0x1d9bfa, '\x20') + _0x3d69b4), _0x3d69b4;
            }
        };
    }), GM_registerMenuCommand(_0x304c5d[_0x29dbd0(0x2c9)], () => {
        const _0x3344af = _0x29dbd0;
        this[_0x3344af(0x26c)] == ![] || _0x304c5d[_0x3344af(0x390)](this[_0x3344af(0x26c)], undefined) ? (this['\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x5a\x68'] = !![], _0x304c5d[_0x3344af(0x21d)](ChatRoomSendLocal, _0x3344af(0x375))) : _0x304c5d['\x45\x46\x67\x65\x4d'](_0x3344af(0x1e3), _0x304c5d[_0x3344af(0xf6)]) ? _0x5d14e9(_0x304c5d[_0x3344af(0x342)], {
            '\x43\x6f\x6e\x74\x65\x6e\x74': '\x61\x77\x42\x4f\x54\x20\x53\x6f\x72\x72\x79\x20\x62\x75\x74\x20\x79\x6f\x75\x27\x76\x65\x20\x62\x65\x65\x6e\x20\x62\x61\x6e\x6e\x65\x64\x20\x62\x79\x20\x61\x6e\x20\x6f\x70\x65\x72\x61\x74\x6f\x72\x2e',
            '\x54\x79\x70\x65': _0x304c5d[_0x3344af(0x36c)]
        }) : (this[_0x3344af(0x26c)] = ![], _0x304c5d[_0x3344af(0x215)](ChatRoomSendLocal, _0x3344af(0x2f0)));
    }), _0x304c5d[_0x29dbd0(0x1cd)](GM_registerMenuCommand, _0x29dbd0(0x15e), () => {
        const _0x41a9e4 = _0x29dbd0, _0x24bf9d = {
                '\x74\x67\x48\x49\x69': function (_0x45f22a, _0x2f9b0b, _0x84d32a, _0xc83ddd, _0x4f8e52, _0x3b5cfe) {
                    return _0x304c5d['\x6e\x77\x6d\x76\x59'](_0x45f22a, _0x2f9b0b, _0x84d32a, _0xc83ddd, _0x4f8e52, _0x3b5cfe);
                },
                '\x79\x48\x6a\x75\x44': _0x304c5d[_0x41a9e4(0x223)],
                '\x45\x55\x53\x4f\x64': function (_0x2f3ed6, _0x4bb334, _0x4fdb4e, _0x4b38ca, _0x2d733a, _0xcd5a6a) {
                    return _0x2f3ed6(_0x4bb334, _0x4fdb4e, _0x4b38ca, _0x2d733a, _0xcd5a6a);
                },
                '\x42\x67\x42\x42\x77': _0x304c5d[_0x41a9e4(0x175)],
                '\x45\x43\x4a\x7a\x63': '\x49\x74\x65\x6d\x46\x65\x65\x74',
                '\x6a\x77\x6e\x41\x47': function (_0x1863b0, _0x4d562e) {
                    const _0x5bb9a9 = _0x41a9e4;
                    return _0x304c5d[_0x5bb9a9(0x26f)](_0x1863b0, _0x4d562e);
                },
                '\x4b\x47\x50\x47\x44': _0x304c5d[_0x41a9e4(0x26a)]
            };
        if (_0x304c5d[_0x41a9e4(0x2cb)](_0x304c5d[_0x41a9e4(0x37b)], _0x304c5d[_0x41a9e4(0x37b)])) {
            const _0x218313 = _0x286287[_0x41a9e4(0x2e8)](_0x4cb69c, arguments);
            return _0x3c1146 = null, _0x218313;
        } else
            _0x304c5d[_0x41a9e4(0x326)](this['\x41\x77\x50\x61\x73\x74\x65'], ![]) || this[_0x41a9e4(0x2a2)] == undefined ? (this['\x41\x77\x50\x61\x73\x74\x65'] = !![], _0x304c5d[_0x41a9e4(0x100)](ChatRoomSendLocal, _0x41a9e4(0x421))) : _0x304c5d[_0x41a9e4(0x12b)](_0x304c5d[_0x41a9e4(0x120)], _0x41a9e4(0x146)) ? (_0x24bf9d[_0x41a9e4(0x2ac)](_0x5c8333, _0x14c386, _0x41a9e4(0x20d), _0x41a9e4(0xfd), _0x24bf9d[_0x41a9e4(0x203)], 0x3231e + 0x19e56 + -0x30222), _0x24bf9d[_0x41a9e4(0x2ef)](_0x217e24, _0x2609d4, _0x24bf9d[_0x41a9e4(0x172)], _0x24bf9d[_0x41a9e4(0x1f4)], _0x41a9e4(0x14b), -0x197c8 + -0x1c1 * -0x25 + -0xc8b * -0x3f), _0x3822bc[_0x41a9e4(0x3f5)][_0x41a9e4(0x290)] = 0x254e + 0x236b + -0x48b9, _0x24bf9d[_0x41a9e4(0x181)](_0x2d7c18, _0x210c80), _0x36c785 = _0x24bf9d[_0x41a9e4(0x140)]) : (this[_0x41a9e4(0x2a2)] = ![], _0x304c5d[_0x41a9e4(0x100)](ChatRoomSendLocal, _0x41a9e4(0x408)));
    }), _0x304c5d[_0x29dbd0(0x24b)](GM_registerMenuCommand, _0x304c5d[_0x29dbd0(0x196)], () => {
        const _0x266461 = _0x29dbd0;
        AwNick = _0x304c5d[_0x266461(0x2f8)](prompt, _0x266461(0x122), _0x304c5d[_0x266461(0x208)]), AwReply = prompt(_0x304c5d['\x6e\x63\x72\x61\x6d'], _0x304c5d[_0x266461(0x2bf)]);
    }), _0x304c5d['\x47\x68\x67\x51\x41'](GM_registerMenuCommand, '\u5047\u88c5\u6709\x42\x43\x45\u4e0e\x42\x43\x58', () => {
        const _0x19379e = _0x29dbd0, _0x1c827e = {};
        _0x1c827e[_0x19379e(0x135)] = _0x304c5d[_0x19379e(0x130)];
        const _0x3a8233 = _0x1c827e;
        if (_0x304c5d['\x76\x68\x72\x4b\x66'](_0x304c5d[_0x19379e(0x34a)], _0x304c5d[_0x19379e(0x18c)])) {
            _0x304c5d[_0x19379e(0x2f8)](ServerSend, _0x19379e(0x2b5), {
                '\x43\x6f\x6e\x74\x65\x6e\x74': _0x304c5d[_0x19379e(0x351)],
                '\x54\x79\x70\x65': _0x19379e(0x1f1),
                '\x44\x69\x63\x74\x69\x6f\x6e\x61\x72\x79': [{
                        '\x6d\x65\x73\x73\x61\x67\x65': {
                            '\x74\x79\x70\x65': _0x304c5d[_0x19379e(0x143)],
                            '\x76\x65\x72\x73\x69\x6f\x6e': '\x33\x2e\x36\x2e\x31',
                            '\x61\x6c\x74\x65\x72\x6e\x61\x74\x65\x41\x72\x6f\x75\x73\x61\x6c': !![],
                            '\x72\x65\x70\x6c\x79\x52\x65\x71\x75\x65\x73\x74\x65\x64': ![],
                            '\x63\x61\x70\x61\x62\x69\x6c\x69\x74\x69\x65\x73': ['\x63\x6c\x75\x62\x73\x6c\x61\x76\x65'],
                            '\x6e\x69\x63\x6b': null
                        }
                    }]
            });
            const _0x15c4d4 = {};
            _0x15c4d4['\x45\x66\x66\x65\x63\x74'] = [], _0x304c5d['\x4f\x47\x47\x6d\x74'](ServerSend, _0x19379e(0x2b5), {
                '\x43\x6f\x6e\x74\x65\x6e\x74': _0x304c5d['\x6c\x47\x4f\x4a\x6d'],
                '\x54\x79\x70\x65': _0x304c5d['\x50\x70\x6c\x59\x77'],
                '\x44\x69\x63\x74\x69\x6f\x6e\x61\x72\x79': {
                    '\x74\x79\x70\x65': _0x304c5d['\x6c\x52\x5a\x6e\x69'],
                    '\x6d\x65\x73\x73\x61\x67\x65': {
                        '\x76\x65\x72\x73\x69\x6f\x6e': _0x304c5d[_0x19379e(0x256)],
                        '\x72\x65\x71\x75\x65\x73\x74': ![],
                        '\x65\x66\x66\x65\x63\x74\x73': _0x15c4d4,
                        '\x74\x79\x70\x69\x6e\x67\x49\x6e\x64\x69\x63\x61\x74\x6f\x72\x45\x6e\x61\x62\x6c\x65': ![],
                        '\x73\x63\x72\x65\x65\x6e\x49\x6e\x64\x69\x63\x61\x74\x6f\x72\x45\x6e\x61\x62\x6c\x65': ![]
                    }
                }
            });
        } else
            _0x3379c1['\x70\x75\x73\x68'](_0x1cf88e[_0x19379e(0x3e6)]), _0x5d9ece = _0x3a8233['\x61\x48\x69\x79\x6e'];
    }), _0x304c5d[_0x29dbd0(0x3bf)](GM_registerMenuCommand, _0x304c5d[_0x29dbd0(0x382)], () => {
        const _0x419a9c = _0x29dbd0, _0x44181d = {
                '\x70\x57\x43\x6f\x4d': function (_0x5b8de4, _0x2120a8) {
                    return _0x304c5d['\x70\x48\x62\x4a\x68'](_0x5b8de4, _0x2120a8);
                },
                '\x61\x41\x63\x6b\x79': _0x304c5d['\x44\x47\x71\x56\x4e'],
                '\x68\x45\x5a\x76\x58': function (_0x2bd48c, _0x2d83e6) {
                    const _0x4f9e04 = _0x4408;
                    return _0x304c5d[_0x4f9e04(0x314)](_0x2bd48c, _0x2d83e6);
                },
                '\x4a\x4e\x77\x4f\x56': _0x304c5d[_0x419a9c(0x3a1)],
                '\x57\x74\x65\x74\x71': function (_0xf1f093, _0xd9531a) {
                    const _0x39f288 = _0x419a9c;
                    return _0x304c5d[_0x39f288(0x3b5)](_0xf1f093, _0xd9531a);
                },
                '\x45\x68\x41\x56\x64': _0x304c5d[_0x419a9c(0x3ef)],
                '\x66\x6b\x6a\x51\x65': function (_0x2dbc80, _0x22f898, _0xd6b0ce) {
                    const _0x41cd4e = _0x419a9c;
                    return _0x304c5d[_0x41cd4e(0x1d9)](_0x2dbc80, _0x22f898, _0xd6b0ce);
                },
                '\x41\x67\x57\x4e\x4e': _0x304c5d[_0x419a9c(0x1c6)],
                '\x77\x58\x65\x57\x6b': function (_0x1413e2, _0x274fd3) {
                    const _0x5d4d4a = _0x419a9c;
                    return _0x304c5d[_0x5d4d4a(0xf0)](_0x1413e2, _0x274fd3);
                },
                '\x46\x6c\x53\x50\x6d': _0x304c5d[_0x419a9c(0x39d)],
                '\x69\x53\x76\x4e\x65': _0x304c5d[_0x419a9c(0x407)],
                '\x44\x42\x52\x79\x59': _0x304c5d[_0x419a9c(0x3ac)],
                '\x62\x62\x41\x4b\x4b': _0x304c5d['\x64\x6e\x56\x44\x52'],
                '\x6a\x6b\x4e\x64\x77': _0x304c5d['\x57\x54\x68\x59\x55'],
                '\x6e\x44\x6a\x58\x78': _0x304c5d[_0x419a9c(0x1e0)],
                '\x4f\x4c\x43\x73\x48': _0x304c5d[_0x419a9c(0x2fb)],
                '\x52\x4c\x45\x6e\x63': _0x304c5d['\x55\x54\x6e\x77\x57'],
                '\x49\x4b\x61\x4a\x44': _0x304c5d[_0x419a9c(0x3b2)],
                '\x59\x77\x71\x74\x65': _0x304c5d[_0x419a9c(0x312)],
                '\x4f\x78\x6c\x66\x62': _0x304c5d[_0x419a9c(0x2f7)],
                '\x53\x52\x7a\x4d\x54': _0x304c5d[_0x419a9c(0x3c1)],
                '\x47\x6c\x49\x47\x4b': _0x304c5d[_0x419a9c(0x305)],
                '\x45\x75\x4e\x45\x77': _0x304c5d[_0x419a9c(0x274)],
                '\x5a\x58\x61\x48\x4a': _0x419a9c(0x25f),
                '\x4f\x70\x73\x41\x49': _0x304c5d[_0x419a9c(0x380)],
                '\x68\x61\x70\x66\x50': _0x419a9c(0x30f),
                '\x71\x57\x77\x57\x78': _0x304c5d[_0x419a9c(0x1a2)],
                '\x6b\x53\x6d\x74\x6a': _0x304c5d[_0x419a9c(0x20a)],
                '\x4a\x77\x54\x75\x69': _0x304c5d[_0x419a9c(0x3c3)],
                '\x69\x79\x70\x72\x4a': '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68\x33',
                '\x54\x53\x76\x44\x4d': _0x304c5d[_0x419a9c(0x3d4)],
                '\x49\x62\x72\x59\x45': _0x419a9c(0x2cf),
                '\x58\x63\x5a\x53\x69': _0x304c5d[_0x419a9c(0x237)],
                '\x6f\x57\x59\x49\x70': _0x419a9c(0x15a),
                '\x62\x4f\x7a\x52\x4b': _0x304c5d[_0x419a9c(0x3d5)],
                '\x69\x79\x7a\x45\x48': _0x304c5d['\x68\x4e\x71\x4f\x52'],
                '\x6a\x55\x61\x75\x76': _0x419a9c(0x1b9),
                '\x43\x64\x68\x78\x44': _0x304c5d[_0x419a9c(0xfe)],
                '\x44\x64\x72\x4e\x69': _0x304c5d[_0x419a9c(0x316)],
                '\x4f\x6b\x4b\x6e\x59': function (_0x187d84, _0x48608a) {
                    return _0x304c5d['\x77\x67\x66\x6d\x77'](_0x187d84, _0x48608a);
                },
                '\x6a\x4d\x68\x76\x6d': _0x304c5d['\x41\x61\x51\x6a\x57'],
                '\x59\x71\x61\x50\x69': _0x304c5d[_0x419a9c(0x342)],
                '\x6d\x66\x4c\x47\x69': _0x304c5d[_0x419a9c(0x16e)],
                '\x77\x70\x6d\x67\x45': _0x304c5d[_0x419a9c(0x36c)],
                '\x4d\x62\x44\x49\x7a': _0x304c5d[_0x419a9c(0x379)],
                '\x71\x66\x52\x7a\x45': function (_0x41d8d4, _0x4da77e, _0x57aaba, _0x16decf, _0x4320d4, _0x2897d4) {
                    const _0x2fa4d8 = _0x419a9c;
                    return _0x304c5d[_0x2fa4d8(0x23d)](_0x41d8d4, _0x4da77e, _0x57aaba, _0x16decf, _0x4320d4, _0x2897d4);
                },
                '\x4b\x44\x6d\x64\x78': '\x4c\x65\x61\x74\x68\x65\x72\x48\x61\x72\x6e\x65\x73\x73',
                '\x74\x6f\x51\x70\x4b': _0x304c5d[_0x419a9c(0x386)],
                '\x6f\x73\x79\x4f\x62': _0x304c5d['\x69\x53\x44\x58\x57'],
                '\x58\x55\x73\x76\x67': _0x304c5d[_0x419a9c(0x303)],
                '\x63\x45\x58\x4b\x59': _0x304c5d[_0x419a9c(0x170)],
                '\x70\x61\x67\x63\x48': '\x49\x74\x65\x6d\x48\x61\x6e\x64\x73',
                '\x4d\x77\x57\x66\x73': _0x304c5d[_0x419a9c(0x335)],
                '\x69\x6c\x56\x4b\x75': _0x304c5d[_0x419a9c(0x175)],
                '\x64\x74\x44\x74\x46': _0x419a9c(0x180),
                '\x73\x6d\x78\x7a\x65': _0x304c5d[_0x419a9c(0x2b1)],
                '\x4f\x6e\x44\x50\x67': function (_0x276086, _0x3583e3) {
                    return _0x276086 !== _0x3583e3;
                },
                '\x58\x7a\x79\x66\x52': function (_0xd78629, _0x5cb326) {
                    const _0x5d30ec = _0x419a9c;
                    return _0x304c5d[_0x5d30ec(0x35b)](_0xd78629, _0x5cb326);
                },
                '\x6a\x68\x4a\x56\x4f': _0x304c5d[_0x419a9c(0x1a5)],
                '\x55\x53\x6a\x79\x46': function (_0x44904e, _0x4ec826) {
                    return _0x44904e < _0x4ec826;
                },
                '\x75\x4c\x68\x6a\x48': _0x304c5d['\x50\x52\x4c\x59\x48'],
                '\x64\x52\x6c\x43\x76': _0x304c5d[_0x419a9c(0x26e)],
                '\x56\x55\x77\x4b\x6f': _0x304c5d[_0x419a9c(0x337)]
            };
        if (_0x304c5d[_0x419a9c(0x23f)](_0x304c5d[_0x419a9c(0x15b)], _0x419a9c(0xf5))) {
            if (!(Player[_0x419a9c(0x3be)] && _0x304c5d['\x4f\x4e\x54\x6e\x50'](Player[_0x419a9c(0x3be)][_0x419a9c(0x3e6)], _0x304c5d[_0x419a9c(0x2b1)]))) {
                if (_0x304c5d[_0x419a9c(0x29b)](Player[_0x419a9c(0x3e6)], _0x304c5d['\x6b\x5a\x54\x6a\x79'])) {
                    if (_0x304c5d['\x72\x42\x43\x4e\x57'] !== '\x6e\x64\x61\x52\x6c') {
                        _0x304c5d[_0x419a9c(0x224)](alert, _0x419a9c(0x2f6));
                        return;
                    } else
                        _0x149ea6(_0xfd8584, _0x812f78, 0x16e94 + -0xb * 0x421 + -0x1 * -0x7e29);
                }
            }
            this[_0x419a9c(0x19c)] == ![] || _0x304c5d[_0x419a9c(0x326)](this[_0x419a9c(0x19c)], undefined) ? (this[_0x419a9c(0x26c)] = !![], this[_0x419a9c(0x2a2)] = ![], _0x304c5d[_0x419a9c(0x31f)](ChatRoomSendLocal, _0x304c5d[_0x419a9c(0x3cc)]), AwAutoKickOn = !![], AwAutoKicker = function (_0x50cd0a) {
                const _0x59241e = _0x419a9c;
                let _0x4b67d2 = ChatRoomCharacter[_0x59241e(0x36b)](_0xe53fe4 => _0xe53fe4[_0x59241e(0x2ea)] === _0x50cd0a['\x53\x65\x6e\x64\x65\x72']);
                if (_0x44181d[_0x59241e(0x3ca)](_0x50cd0a['\x54\x79\x70\x65'], _0x44181d[_0x59241e(0x153)]) && (_0x44181d[_0x59241e(0x24d)](_0x50cd0a[_0x59241e(0x2ad)], _0x44181d['\x4a\x4e\x77\x4f\x56']) || _0x44181d['\x57\x74\x65\x74\x71'](_0x50cd0a[_0x59241e(0x2ad)], _0x44181d[_0x59241e(0x2a9)]))) {
                    const _0x139602 = {};
                    _0x139602[_0x59241e(0x2ea)] = _0x4b67d2['\x4d\x65\x6d\x62\x65\x72\x4e\x75\x6d\x62\x65\x72'], _0x139602[_0x59241e(0x1a0)] = _0x59241e(0x168), _0x44181d['\x66\x6b\x6a\x51\x65'](ServerSend, _0x44181d[_0x59241e(0x182)], _0x139602);
                }
                ;
            }, ServerSocket['\x6f\x6e'](_0x304c5d['\x4c\x73\x55\x6e\x75'], AwAutoKicker), AwBotTrap = _0x304c5d[_0x419a9c(0x1dd)], ChatRoomNotificationRaiseChatJoin = function (_0x32909d) {
                const _0x521dea = _0x419a9c, _0x3bb3e0 = {
                        '\x71\x74\x6c\x6d\x4f': function (_0x47a8aa, _0x2d7cb2, _0x39cb53, _0x2d7a23, _0x386609, _0x2739d8) {
                            return _0x44181d['\x71\x66\x52\x7a\x45'](_0x47a8aa, _0x2d7cb2, _0x39cb53, _0x2d7a23, _0x386609, _0x2739d8);
                        },
                        '\x70\x61\x41\x55\x41': _0x44181d[_0x521dea(0x284)],
                        '\x6e\x56\x78\x43\x45': _0x44181d['\x43\x64\x68\x78\x44'],
                        '\x71\x6c\x53\x64\x64': _0x44181d[_0x521dea(0x2bc)],
                        '\x58\x46\x7a\x67\x5a': function (_0x1686c5, _0x1c83ed, _0x5b9a53, _0x5dca42, _0x356fca, _0xc41c3b) {
                            const _0x20fd80 = _0x521dea;
                            return _0x44181d[_0x20fd80(0x3e4)](_0x1686c5, _0x1c83ed, _0x5b9a53, _0x5dca42, _0x356fca, _0xc41c3b);
                        },
                        '\x45\x54\x4e\x4c\x59': _0x521dea(0x3d8),
                        '\x4d\x43\x53\x63\x44': _0x44181d['\x49\x62\x72\x59\x45'],
                        '\x69\x76\x61\x62\x4e': _0x44181d[_0x521dea(0x207)],
                        '\x48\x6c\x47\x56\x68': _0x44181d[_0x521dea(0x186)],
                        '\x7a\x43\x41\x49\x49': _0x521dea(0x2ca),
                        '\x48\x42\x66\x59\x74': _0x44181d[_0x521dea(0x3ba)],
                        '\x44\x77\x64\x65\x62': _0x44181d[_0x521dea(0x37f)],
                        '\x43\x51\x64\x71\x4d': _0x44181d[_0x521dea(0x244)],
                        '\x75\x66\x50\x61\x65': _0x44181d[_0x521dea(0x38a)],
                        '\x75\x70\x71\x7a\x44': _0x44181d['\x70\x61\x67\x63\x48'],
                        '\x63\x4a\x50\x53\x58': _0x44181d[_0x521dea(0x3fc)],
                        '\x78\x57\x44\x6a\x78': _0x44181d[_0x521dea(0x113)],
                        '\x71\x75\x43\x6a\x4b': _0x44181d['\x69\x6c\x56\x4b\x75'],
                        '\x42\x56\x6a\x56\x6a': _0x521dea(0x25f),
                        '\x6d\x54\x79\x43\x66': function (_0x41ee5e, _0x5f1510, _0x1fa23b) {
                            return _0x41ee5e(_0x5f1510, _0x1fa23b);
                        },
                        '\x4e\x62\x46\x41\x72': _0x44181d[_0x521dea(0x1cf)],
                        '\x7a\x4d\x64\x6e\x49': _0x44181d[_0x521dea(0x38b)],
                        '\x58\x52\x43\x48\x58': function (_0x188cb9, _0x2f66c4) {
                            const _0x1fe08f = _0x521dea;
                            return _0x44181d[_0x1fe08f(0x148)](_0x188cb9, _0x2f66c4);
                        },
                        '\x62\x59\x57\x4d\x43': function (_0x461a9a, _0x15ec35) {
                            const _0x3e062c = _0x521dea;
                            return _0x44181d[_0x3e062c(0x29e)](_0x461a9a, _0x15ec35);
                        },
                        '\x58\x72\x65\x77\x41': _0x521dea(0x1ff),
                        '\x52\x45\x4b\x6a\x43': function (_0x19b222, _0x5bbb58) {
                            return _0x44181d['\x58\x7a\x79\x66\x52'](_0x19b222, _0x5bbb58);
                        },
                        '\x7a\x61\x78\x77\x77': function (_0x2ce5bb, _0x5299a1) {
                            return _0x2ce5bb == _0x5299a1;
                        },
                        '\x57\x6a\x63\x4f\x63': function (_0x47bd55, _0x4edb81) {
                            return _0x47bd55 === _0x4edb81;
                        },
                        '\x41\x74\x5a\x6c\x47': _0x44181d[_0x521dea(0x240)],
                        '\x66\x54\x4a\x47\x4a': function (_0x32b1fc, _0x531764) {
                            const _0x4773f1 = _0x521dea;
                            return _0x44181d[_0x4773f1(0x270)](_0x32b1fc, _0x531764);
                        },
                        '\x59\x65\x50\x70\x4b': _0x44181d['\x75\x4c\x68\x6a\x48'],
                        '\x65\x47\x6b\x6a\x49': _0x44181d['\x64\x52\x6c\x43\x76'],
                        '\x43\x4e\x66\x52\x63': _0x521dea(0x37c),
                        '\x74\x45\x53\x44\x44': _0x44181d['\x56\x55\x77\x4b\x6f']
                    };
                return _0x44181d[_0x521dea(0x1ea)](setTimeout, function () {
                    const _0x514161 = _0x521dea, _0x38db7d = {
                            '\x47\x61\x55\x5a\x6f': function (_0x525745, _0x27a69a) {
                                const _0x5ca55c = _0x4408;
                                return _0x44181d[_0x5ca55c(0x417)](_0x525745, _0x27a69a);
                            },
                            '\x4a\x73\x6f\x75\x7a': _0x44181d['\x46\x6c\x53\x50\x6d'],
                            '\x6e\x5a\x47\x65\x6e': _0x44181d[_0x514161(0x3a4)],
                            '\x6b\x58\x51\x5a\x73': _0x44181d[_0x514161(0x244)],
                            '\x56\x66\x53\x70\x41': _0x44181d[_0x514161(0x2bc)],
                            '\x53\x59\x72\x44\x51': _0x44181d[_0x514161(0x1bd)],
                            '\x66\x67\x41\x5a\x72': _0x44181d['\x6e\x44\x6a\x58\x78']
                        };
                    if (_0x44181d[_0x514161(0x12f)] !== _0x44181d['\x4f\x4c\x43\x73\x48']) {
                        const _0xfdb72d = _0x514161(0x11c)[_0x514161(0x261)]('\x7c');
                        let _0x460cb7 = -0xb83 * -0x2 + 0x4b1 * -0x1 + 0xf7 * -0x13;
                        while (!![]) {
                            switch (_0xfdb72d[_0x460cb7++]) {
                            case '\x30':
                                _0x3bb3e0[_0x514161(0x38e)](_0x38b57a, _0x528e2a, _0x3bb3e0[_0x514161(0x368)], _0x3bb3e0['\x6e\x56\x78\x43\x45'], _0x3bb3e0[_0x514161(0x205)], -0x23a6a + 0x2925d * 0x1 + 0x1675f);
                                continue;
                            case '\x31':
                                _0x3bb3e0[_0x514161(0x1d2)](_0x328c8a, _0x355841, _0x3bb3e0['\x45\x54\x4e\x4c\x59'], _0x3bb3e0['\x4d\x43\x53\x63\x44'], _0x514161(0x14b), -0x33eb8 + -0x4fc * 0x56 + 0x6aab2);
                                continue;
                            case '\x32':
                                _0x5a9a5e(_0x11e915, _0x514161(0x2cd), _0x3bb3e0[_0x514161(0x369)], '\x23\x32\x30\x32\x30\x32\x30', 0x1 * 0x1b793 + -0x11cee * -0x3 + -0x34f0b);
                                continue;
                            case '\x33':
                                _0x3bb3e0[_0x514161(0x38e)](_0x30b0bb, _0x53af24, _0x3bb3e0['\x48\x6c\x47\x56\x68'], _0x514161(0x16a), _0x3bb3e0['\x71\x6c\x53\x64\x64'], 0x57 * 0x30b + -0x659 + 0xbcee);
                                continue;
                            case '\x34':
                                _0x3bb3e0['\x71\x74\x6c\x6d\x4f'](_0x330756, _0x2011dc, _0x3bb3e0[_0x514161(0x3b9)], _0x3bb3e0[_0x514161(0x310)], _0x514161(0x14b), 0x1e0 * 0x19b + -0x253a3 + 0x1005 * 0x11);
                                continue;
                            case '\x35':
                                _0x3bb3e0[_0x514161(0x38e)](_0x1b00c3, _0x2e38fb, _0x3bb3e0[_0x514161(0x24a)], _0x3bb3e0[_0x514161(0x2f9)], _0x3bb3e0[_0x514161(0x205)], -0xd438 + -0x6b * 0x6fd + 0x57f49);
                                continue;
                            case '\x36':
                                _0x26dc4f(_0x41466d, _0x3bb3e0[_0x514161(0x2bd)], _0x3bb3e0[_0x514161(0x21c)], _0x3bb3e0['\x71\x6c\x53\x64\x64'], 0x1d7bb + 0x1 * 0x23665 + -0x1 * 0x24ece);
                                continue;
                            case '\x37':
                                _0x82ce89(_0x2487f8, _0x3bb3e0[_0x514161(0x147)], _0x3bb3e0[_0x514161(0x389)], _0x514161(0x14b), -0x30a18 + 0x1aa8e * 0x1 + 0x31edc);
                                continue;
                            case '\x38':
                                _0x3bb3e0[_0x514161(0x1d2)](_0x179686, _0x2b650f, _0x3bb3e0[_0x514161(0x141)], _0x3bb3e0['\x42\x56\x6a\x56\x6a'], _0x3bb3e0[_0x514161(0x205)], 0x2d6b2 + -0x1 * -0x2717a + -0x1c46d * 0x2);
                                continue;
                            }
                            break;
                        }
                    } else {
                        if (AwBotTrap != _0x32909d[_0x514161(0x3e6)]) {
                            if (_0x44181d['\x77\x58\x65\x57\x6b'](_0x44181d[_0x514161(0x409)], _0x44181d['\x52\x4c\x45\x6e\x63'])) {
                                AwBotTrap = _0x32909d[_0x514161(0x3e6)];
                                if (this[_0x514161(0x2a2)]) {
                                    if (_0x44181d['\x49\x4b\x61\x4a\x44'] !== _0x44181d[_0x514161(0x384)])
                                        _0x32909d[_0x514161(0x17d)] = clipboard;
                                    else {
                                        _0x30fe4f = _0x3bb3e0[_0x514161(0x34c)](_0xc13ab2, _0x3bb3e0['\x4e\x62\x46\x41\x72'], _0x3bb3e0[_0x514161(0x2d3)]), _0x2b5502 = _0x1b41fc[_0x514161(0x36b)](_0x541fdb => _0x541fdb['\x4e\x61\x6d\x65'][_0x514161(0x2fa)]() == _0x15b28f);
                                        if (_0x4d77fe == null)
                                            return;
                                        _0x4b6154(_0x502a6c), _0x2ad3f2[_0x514161(0x3f5)][_0x514161(0x290)] = 0x7 * -0x54e + -0x139d + -0xc7 * -0x49, _0x3bb3e0[_0x514161(0x1b2)](_0xf2ba8f, _0x1b792b);
                                    }
                                } else {
                                    let _0x1c45b8 = [
                                        '\x49\x74\x65\x6d\x41\x72\x6d\x73',
                                        _0x44181d['\x4f\x78\x6c\x66\x62'],
                                        _0x44181d[_0x514161(0x41c)],
                                        _0x514161(0x157),
                                        _0x44181d[_0x514161(0x18b)],
                                        _0x44181d[_0x514161(0x278)],
                                        _0x44181d['\x5a\x58\x61\x48\x4a'],
                                        _0x514161(0x1df),
                                        _0x44181d['\x4f\x70\x73\x41\x49'],
                                        _0x44181d[_0x514161(0x41e)],
                                        _0x514161(0x37d),
                                        _0x44181d['\x71\x57\x77\x57\x78'],
                                        _0x44181d[_0x514161(0x113)],
                                        _0x44181d['\x4a\x77\x54\x75\x69'],
                                        _0x44181d[_0x514161(0x233)],
                                        _0x44181d[_0x514161(0x207)],
                                        _0x44181d[_0x514161(0x2a4)],
                                        _0x44181d['\x58\x63\x5a\x53\x69'],
                                        _0x44181d['\x6f\x57\x59\x49\x70'],
                                        _0x44181d[_0x514161(0x12e)],
                                        _0x44181d[_0x514161(0x12a)],
                                        _0x44181d[_0x514161(0x2e9)],
                                        _0x44181d[_0x514161(0x355)],
                                        _0x44181d[_0x514161(0x188)],
                                        _0x514161(0x2df)
                                    ];
                                    _0x1c45b8[_0x514161(0x2c4)](_0x380abe => {
                                        const _0x3091bd = _0x514161, _0x47248a = {};
                                        _0x47248a[_0x3091bd(0x230)] = '\x76\x31\x2e\x30\x37\x20\x62\x79\x20\x41\x77\u9171\x20\u5728\x61\x77\x61\x71\x77\x71\u7684\u4e2a\u4eba\u7b80\u4ecb\u91cc\u9762\u6709\u4e0b\u8f7d\u94fe\u63a5\u7684\u8bf4\x7e';
                                        const _0x4b5d9f = _0x47248a;
                                        _0x38db7d['\x47\x61\x55\x5a\x6f'](_0x3091bd(0x239), _0x38db7d['\x4a\x73\x6f\x75\x7a']) ? InventoryWearRandom(_0x32909d, _0x380abe, 0x1 * -0x118c3 + -0x2 * -0xe87e + -0x143d * -0xd) : _0x5e1e92 = _0x4b5d9f[_0x3091bd(0x230)];
                                    }), _0x32909d[_0x514161(0x17d)]['\x66\x6f\x72\x45\x61\x63\x68'](_0x58470d => {
                                        const _0x25d3ba = _0x514161, _0xdae3ba = {
                                                '\x67\x51\x48\x6c\x7a': function (_0x36535e, _0x176c6e) {
                                                    const _0x24d684 = _0x4408;
                                                    return _0x3bb3e0[_0x24d684(0x1b2)](_0x36535e, _0x176c6e);
                                                }
                                            };
                                        if (_0x3bb3e0['\x62\x59\x57\x4d\x43'](_0x3bb3e0[_0x25d3ba(0x1f7)], _0x3bb3e0[_0x25d3ba(0x1f7)]))
                                            _0xdae3ba[_0x25d3ba(0x222)](_0x855106, _0x5746d3);
                                        else {
                                            let _0x31521a = 0xba7 * 0x1 + 0x1c31 + -0x27d8;
                                            _0x3bb3e0['\x52\x45\x4b\x6a\x43'](_0x58470d[_0x25d3ba(0x22e)], -0x3e * -0x44 + 0x3 * 0x8eb + -0x2b39 * 0x1) && (_0x58470d[_0x25d3ba(0xee)] == null && (_0x58470d[_0x25d3ba(0xee)] = {}), _0x3bb3e0[_0x25d3ba(0x2fd)](_0x58470d['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x25d3ba(0x29c)], null) && (_0x3bb3e0['\x57\x6a\x63\x4f\x63'](_0x3bb3e0[_0x25d3ba(0x347)], _0x25d3ba(0x2ff)) ? _0x58470d['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x25d3ba(0x29c)] = [] : _0x251ab7[_0x25d3ba(0xee)] = {}), _0x3bb3e0['\x66\x54\x4a\x47\x4a'](_0x58470d[_0x25d3ba(0xee)][_0x25d3ba(0x29c)][_0x25d3ba(0x1ef)](_0x3bb3e0['\x59\x65\x50\x70\x4b']), 0x2093 + -0x1 * -0x1f15 + -0x3fa8) && _0x58470d['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x25d3ba(0x29c)][_0x25d3ba(0x30a)](_0x3bb3e0[_0x25d3ba(0x385)]), Math[_0x25d3ba(0x1ec)]() > 0x1a9 * 0x1 + 0x1450 + -0x465 * 0x5 + 0.5 ? _0x58470d[_0x25d3ba(0xee)][_0x25d3ba(0x315)] = _0x3bb3e0[_0x25d3ba(0x2c1)] : _0x3bb3e0[_0x25d3ba(0x119)] !== _0x25d3ba(0x37c) ? (_0x2f2a61(_0x276d62, _0x38db7d[_0x25d3ba(0x2af)], _0x38db7d[_0x25d3ba(0x329)], _0x38db7d[_0x25d3ba(0x226)], -0x101 * -0x7f + -0xcd * 0xc0 + 0x5 * 0x5eb7), _0x45dc18['\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73'][_0x25d3ba(0x290)] = 0x1af1 + -0xf70 + -0x1f * 0x5f, _0x4f6b36(_0x1b9059), _0x402a8d = _0x38db7d[_0x25d3ba(0x2b3)]) : _0x58470d[_0x25d3ba(0xee)][_0x25d3ba(0x315)] = _0x3bb3e0['\x74\x45\x53\x44\x44'], _0x58470d[_0x25d3ba(0xee)][_0x25d3ba(0x2bb)] = Player[_0x25d3ba(0x2ea)], _0x32909d[_0x25d3ba(0x17d)][_0x31521a] = _0x58470d), _0x31521a++;
                                        }
                                    }), _0x32909d[_0x514161(0x3f5)][_0x514161(0x290)] = 0x299 * -0xb + 0x1d6 * 0x3 + 0x1 * 0x1711;
                                }
                                _0x44181d['\x4f\x6b\x4b\x6e\x59'](ChatRoomCharacterUpdate, _0x32909d), this[_0x514161(0x26c)] ? _0x44181d[_0x514161(0x1a4)] !== _0x44181d[_0x514161(0x1a4)] ? _0x70c9c0[_0x514161(0xee)] = {} : _0x44181d[_0x514161(0x1ea)](ServerSend, _0x44181d[_0x514161(0x13c)], {
                                    '\x43\x6f\x6e\x74\x65\x6e\x74': _0x44181d[_0x514161(0x260)],
                                    '\x54\x79\x70\x65': _0x44181d[_0x514161(0x416)]
                                }) : _0x44181d['\x66\x6b\x6a\x51\x65'](ServerSend, '\x43\x68\x61\x74\x52\x6f\x6f\x6d\x43\x68\x61\x74', {
                                    '\x43\x6f\x6e\x74\x65\x6e\x74': _0x44181d['\x4d\x62\x44\x49\x7a'],
                                    '\x54\x79\x70\x65': _0x44181d[_0x514161(0x416)]
                                });
                            } else
                                _0x44ce53 = _0x38db7d['\x66\x67\x41\x5a\x72'] + _0x3d7346['\x4e\x61\x6d\x65'] + '\x2e';
                        }
                    }
                }, -0x14fa + -0x3 * 0x5a0 + 0x29c2), !![];
            }) : (AwAutoKickOn = ![], ServerSocket[_0x419a9c(0x1fd)](_0x304c5d[_0x419a9c(0x3b3)], AwAutoKicker), _0x304c5d[_0x419a9c(0x31f)](ChatRoomSendLocal, _0x304c5d[_0x419a9c(0x2db)]), ChatRoomNotificationRaiseChatJoin = function (_0x341872) {
                return !![];
            });
        } else
            _0x423c3c[_0x419a9c(0x17d)] = _0x16e217, _0x25eee8(_0x25c5a7);
    }), _0x304c5d[_0x29dbd0(0x20b)](GM_registerMenuCommand, _0x304c5d[_0x29dbd0(0x3a0)], () => {
        const _0x2aabc4 = _0x29dbd0;
        targetName = prompt(_0x304c5d['\x42\x45\x73\x4f\x54'], _0x304c5d[_0x2aabc4(0x2b1)]), _0x304c5d['\x67\x54\x51\x58\x67'](AwBotBan['\x69\x6e\x64\x65\x78\x4f\x66'](targetName), -(0x20ae + 0x7c3 * 0x1 + -0x2870)) && _0x304c5d[_0x2aabc4(0x21d)](alert, _0x304c5d[_0x2aabc4(0x2ae)]), AwBotBan[_0x2aabc4(0x30a)](targetName);
    }), _0x304c5d[_0x29dbd0(0x3b8)](GM_registerMenuCommand, _0x304c5d[_0x29dbd0(0x34b)], () => {
        const _0xd41d90 = _0x29dbd0;
        targetName = _0x304c5d[_0xd41d90(0x17e)](prompt, _0x304c5d[_0xd41d90(0x1e2)], _0x304c5d[_0xd41d90(0x2b1)]), banIndex = AwBotBan[_0xd41d90(0x1ef)](targetName), banIndex == -(-0x3 * 0x7eb + -0x6f + 0x1831) && _0x304c5d[_0xd41d90(0x2f2)](alert, _0x304c5d['\x47\x6d\x51\x56\x6f']), AwBotBan[_0xd41d90(0x18e)](banIndex, -0x22c + -0xde9 + 0x1016);
    }), _0x304c5d[_0x29dbd0(0x3b7)](GM_registerMenuCommand, _0x304c5d[_0x29dbd0(0x2d9)], () => {
        const _0xbaac52 = _0x29dbd0, _0x27ac9b = {
                '\x7a\x53\x74\x73\x6b': _0x304c5d[_0xbaac52(0x26e)],
                '\x41\x6f\x41\x47\x64': function (_0x199067, _0xd4f32b) {
                    return _0x304c5d['\x61\x66\x52\x44\x61'](_0x199067, _0xd4f32b);
                },
                '\x61\x70\x64\x4c\x57': _0x304c5d[_0xbaac52(0x2dc)],
                '\x72\x7a\x42\x4a\x65': '\x51\x64\x46\x53\x41',
                '\x4e\x58\x6d\x6b\x48': _0x304c5d[_0xbaac52(0x18a)],
                '\x43\x52\x43\x57\x44': function (_0x8d6dfc, _0x3926b2) {
                    const _0x3285d7 = _0xbaac52;
                    return _0x304c5d[_0x3285d7(0x16c)](_0x8d6dfc, _0x3926b2);
                }
            };
        SpeechGarble = function (_0x83459b, _0x3dd87d, _0x2dc902) {
            const _0x51424a = _0xbaac52;
            if (_0x27ac9b['\x41\x6f\x41\x47\x64'](_0x27ac9b[_0x51424a(0x331)], _0x27ac9b[_0x51424a(0x1ad)])) {
                let _0x436b41 = _0x3dd87d, _0x3230de = SpeechGetTotalGagLevel(_0x83459b, _0x2dc902);
                return _0x3230de > -0x401 * -0x1 + -0x14fe + 0x1 * 0x10fd && (_0x27ac9b['\x4e\x58\x6d\x6b\x48'] === _0x27ac9b[_0x51424a(0x2de)] ? _0x436b41 = _0x27ac9b[_0x51424a(0x3ad)](_0x27ac9b[_0x51424a(0x3ad)](_0x51424a(0x14e), _0x3230de) + '\x20', _0x436b41) : _0x41a67b[_0x51424a(0xee)][_0x51424a(0x315)] = _0x27ac9b[_0x51424a(0x281)]), _0x436b41;
            } else
                _0x375496['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x51424a(0x29c)] = [];
        };
    }), _0x304c5d[_0x29dbd0(0x2b7)](GM_registerMenuCommand, '\u526a\u5207\u677f\x5f\u4ece\u5f53\u524d\u9009\u62e9\u89d2\u8272\u590d\u5236', () => {
        const _0x9be81b = _0x29dbd0, _0x9c1403 = {
                '\x73\x4c\x53\x56\x6d': function (_0x195158, _0x2b8f46, _0xb48bc) {
                    const _0x2e86c9 = _0x4408;
                    return _0x304c5d[_0x2e86c9(0x1d9)](_0x195158, _0x2b8f46, _0xb48bc);
                },
                '\x56\x75\x78\x59\x62': _0x304c5d[_0x9be81b(0x1e2)],
                '\x46\x47\x67\x57\x59': _0x304c5d[_0x9be81b(0x2b1)],
                '\x6c\x6f\x53\x44\x64': _0x304c5d[_0x9be81b(0x288)]
            };
        _0x304c5d['\x50\x42\x58\x53\x75'](_0x9be81b(0x31c), _0x304c5d[_0x9be81b(0xf1)]) ? clipboard = CurrentCharacter[_0x9be81b(0x17d)] : (_0x1b30f9 = _0x9c1403[_0x9be81b(0x1bc)](_0x43bbad, _0x9c1403['\x56\x75\x78\x59\x62'], _0x9c1403['\x46\x47\x67\x57\x59']), _0x46b49a = _0x450d24[_0x9be81b(0x1ef)](_0x5521c7), _0x3cd5fc == -(-0x7db + 0xaf6 + -0x1 * 0x31a) && _0x2ea5e9(_0x9c1403['\x6c\x6f\x53\x44\x64']), _0x782c10[_0x9be81b(0x18e)](_0x19850e, 0x2668 + -0x1875 * -0x1 + -0x3edc));
    }), _0x304c5d[_0x29dbd0(0x1d9)](GM_registerMenuCommand, _0x29dbd0(0x415), () => {
        const _0x50e3b6 = _0x29dbd0, _0x49bd75 = {};
        _0x49bd75[_0x50e3b6(0x13d)] = '\x4d\x69\x73\x74\x72\x65\x73\x73\x50\x61\x64\x6c\x6f\x63\x6b';
        const _0x3a89fd = _0x49bd75;
        _0x304c5d[_0x50e3b6(0x23e)] === _0x304c5d[_0x50e3b6(0x14f)] ? _0xf0041c['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x50e3b6(0x315)] = _0x3a89fd[_0x50e3b6(0x13d)] : (CurrentCharacter[_0x50e3b6(0x17d)] = clipboard, ChatRoomCharacterUpdate(CurrentCharacter));
    }), _0x304c5d[_0x29dbd0(0x1cd)](GM_registerMenuCommand, _0x304c5d[_0x29dbd0(0x32d)], () => {
        const _0x41d798 = _0x29dbd0, _0x5a85cf = {
                '\x52\x4c\x54\x6c\x4c': function (_0x5507d8, _0x374736, _0x4fa0a5, _0x43fd6d) {
                    const _0x344e17 = _0x4408;
                    return _0x304c5d[_0x344e17(0x155)](_0x5507d8, _0x374736, _0x4fa0a5, _0x43fd6d);
                },
                '\x55\x48\x67\x4d\x6a': _0x41d798(0x3fb),
                '\x75\x7a\x48\x76\x4b': _0x304c5d[_0x41d798(0x292)],
                '\x67\x57\x69\x62\x74': _0x304c5d[_0x41d798(0x305)],
                '\x63\x6e\x6c\x53\x66': _0x41d798(0x36f),
                '\x44\x6b\x65\x55\x68': '\x49\x74\x65\x6d\x46\x65\x65\x74',
                '\x66\x6f\x59\x6f\x73': _0x41d798(0x1df),
                '\x4a\x65\x70\x67\x51': _0x304c5d[_0x41d798(0x380)],
                '\x59\x79\x69\x78\x72': _0x304c5d['\x4a\x79\x79\x42\x65'],
                '\x4d\x48\x71\x51\x42': _0x304c5d[_0x41d798(0x25d)],
                '\x6f\x49\x45\x74\x41': _0x304c5d[_0x41d798(0x1a2)],
                '\x56\x50\x43\x66\x62': _0x304c5d[_0x41d798(0x3c3)],
                '\x68\x6a\x59\x62\x69': _0x304c5d[_0x41d798(0xf4)],
                '\x74\x74\x50\x70\x68': _0x304c5d[_0x41d798(0x3d4)],
                '\x6c\x4c\x6e\x48\x42': _0x304c5d['\x74\x72\x73\x79\x49'],
                '\x78\x61\x6d\x51\x76': _0x304c5d['\x62\x42\x4b\x74\x71'],
                '\x79\x47\x7a\x55\x4d': _0x304c5d['\x42\x54\x68\x76\x78'],
                '\x53\x48\x64\x55\x4a': _0x304c5d[_0x41d798(0x3d5)],
                '\x43\x47\x51\x7a\x4f': _0x304c5d[_0x41d798(0x138)],
                '\x79\x46\x47\x6d\x63': _0x304c5d[_0x41d798(0x309)],
                '\x55\x7a\x51\x44\x6e': _0x304c5d['\x73\x58\x4a\x7a\x45'],
                '\x6f\x54\x49\x4d\x53': _0x304c5d[_0x41d798(0x316)],
                '\x6d\x59\x67\x70\x67': _0x304c5d[_0x41d798(0x3f6)],
                '\x62\x76\x79\x54\x72': function (_0x3ce8d8, _0x268593) {
                    return _0x304c5d['\x50\x73\x47\x68\x52'](_0x3ce8d8, _0x268593);
                },
                '\x6a\x6c\x41\x4d\x67': _0x304c5d[_0x41d798(0x22f)]
            };
        if (_0x304c5d['\x50\x42\x58\x53\x75'](_0x304c5d[_0x41d798(0x3ff)], _0x41d798(0x1f3))) {
            const _0x19cde9 = {
                '\x6c\x53\x48\x49\x73': function (_0xff6a29, _0x453899, _0x2008da, _0x47bfd7) {
                    const _0x2a9f61 = _0x41d798;
                    return _0x5a85cf[_0x2a9f61(0x1fc)](_0xff6a29, _0x453899, _0x2008da, _0x47bfd7);
                }
            };
            let _0x28a947 = [
                _0x41d798(0xfd),
                _0x5a85cf[_0x41d798(0x2b2)],
                _0x41d798(0x1c9),
                _0x5a85cf[_0x41d798(0x191)],
                _0x5a85cf['\x67\x57\x69\x62\x74'],
                _0x5a85cf[_0x41d798(0x2e7)],
                _0x5a85cf['\x44\x6b\x65\x55\x68'],
                _0x5a85cf[_0x41d798(0x1e8)],
                _0x5a85cf[_0x41d798(0x20c)],
                _0x5a85cf[_0x41d798(0x31b)],
                _0x5a85cf[_0x41d798(0x161)],
                _0x5a85cf[_0x41d798(0x263)],
                _0x41d798(0x1d8),
                _0x5a85cf[_0x41d798(0x192)],
                _0x5a85cf[_0x41d798(0x307)],
                _0x5a85cf['\x74\x74\x50\x70\x68'],
                _0x5a85cf['\x6c\x4c\x6e\x48\x42'],
                _0x5a85cf['\x78\x61\x6d\x51\x76'],
                _0x5a85cf['\x79\x47\x7a\x55\x4d'],
                _0x5a85cf['\x53\x48\x64\x55\x4a'],
                _0x5a85cf[_0x41d798(0x158)],
                _0x5a85cf[_0x41d798(0x40f)],
                _0x5a85cf[_0x41d798(0x35f)],
                _0x5a85cf[_0x41d798(0xfc)],
                _0x5a85cf[_0x41d798(0x420)]
            ];
            _0x28a947[_0x41d798(0x2c4)](_0x3e1050 => {
                const _0x14640a = _0x41d798;
                _0x19cde9[_0x14640a(0x243)](_0x2c31e1, _0x36152e, _0x3e1050, 0xd46 * -0x1d + 0x290b9 + -0xd1 * -0xd7);
            }), _0x1a7a52[_0x41d798(0x3f5)][_0x41d798(0x290)] = 0x2154 + 0x2461 * 0x1 + -0x45b5, _0x5a85cf[_0x41d798(0x3bc)](_0x4566b8, _0x177932), _0x20985b = _0x5a85cf[_0x41d798(0x10f)];
        } else
            _0x304c5d[_0x41d798(0x1f9)](InventoryWear, targetMember, _0x304c5d[_0x41d798(0x21b)], _0x304c5d[_0x41d798(0x1a2)]);
    }), GM_registerMenuCommand(_0x304c5d[_0x29dbd0(0x1c7)], () => {
        const _0x3f7e66 = _0x29dbd0, _0x32dec2 = {};
        _0x32dec2['\x72\x66\x71\x52\x4e'] = '\x50\x61\x6e\x64\x6f\x72\x61\x50\x61\x64\x6c\x6f\x63\x6b';
        const _0x3f6c97 = _0x32dec2;
        _0x304c5d[_0x3f7e66(0x364)](_0x3f7e66(0x2da), _0x3f7e66(0x22d)) ? _0x529241[_0x3f7e66(0xee)][_0x3f7e66(0x315)] = _0x3f6c97[_0x3f7e66(0x17a)] : (_0x304c5d['\x42\x44\x45\x70\x6f'](alert, _0x3f7e66(0x111)), _0x304c5d[_0x3f7e66(0x2c6)](CharacterChangeMoney, Player, -0x3c1 * 0x1 + 0x1b85 + -0xbb0 * 0x2));
    }), _0x304c5d[_0x29dbd0(0x344)](GM_registerMenuCommand, _0x304c5d[_0x29dbd0(0x1b3)], () => {
        const _0x189a61 = _0x29dbd0, _0x1afe1f = {
                '\x75\x55\x48\x76\x6b': function (_0x4b6ffe, _0x26a7ee, _0x530812) {
                    return _0x304c5d['\x4f\x47\x47\x6d\x74'](_0x4b6ffe, _0x26a7ee, _0x530812);
                },
                '\x79\x72\x79\x45\x41': _0x189a61(0x322)
            };
        if (!(Player[_0x189a61(0x3be)] && Player[_0x189a61(0x3be)][_0x189a61(0x3e6)] == _0x304c5d[_0x189a61(0x2b1)])) {
            if (_0x304c5d[_0x189a61(0x3a6)](Player[_0x189a61(0x3e6)], _0x304c5d[_0x189a61(0x2b1)])) {
                if (_0x304c5d[_0x189a61(0x3ce)](_0x189a61(0x321), _0x304c5d['\x6d\x74\x76\x6f\x6c'])) {
                    alert(_0x304c5d[_0x189a61(0x327)]);
                    return;
                } else
                    _0x1afe1f[_0x189a61(0x2e4)](_0x24d4e7, _0x1afe1f[_0x189a61(0x12c)], 0x13 * -0x2c73 + -0x82ca + 0x58ea5);
            }
        }
        if (CurrentScreen == _0x189a61(0x319)) {
            const _0x45b13b = '\x37\x7c\x36\x7c\x31\x7c\x33\x7c\x32\x7c\x30\x7c\x35\x7c\x34'[_0x189a61(0x261)]('\x7c');
            let _0x1e6576 = -0xb19 * -0x1 + -0x17c3 * 0x1 + -0xcaa * -0x1;
            while (!![]) {
                switch (_0x45b13b[_0x1e6576++]) {
                case '\x30':
                    CommonSetScreen(_0x304c5d[_0x189a61(0x28c)], _0x304c5d[_0x189a61(0x190)]);
                    continue;
                case '\x31':
                    _0x304c5d[_0x189a61(0x2c6)](ServerSend, '\x43\x68\x61\x74\x52\x6f\x6f\x6d\x4c\x65\x61\x76\x65', '');
                    continue;
                case '\x32':
                    ChatRoomLeashPlayer = null;
                    continue;
                case '\x33':
                    _0x304c5d[_0x189a61(0x215)](ChatRoomSetLastChatRoom, '');
                    continue;
                case '\x34':
                    _0x304c5d[_0x189a61(0x160)](ChatSearchExit);
                    continue;
                case '\x35':
                    _0x304c5d[_0x189a61(0x426)](CharacterDeleteAllOnline);
                    continue;
                case '\x36':
                    _0x304c5d[_0x189a61(0x372)](ChatRoomClearAllElements);
                    continue;
                case '\x37':
                    DialogLentLockpicks = ![];
                    continue;
                }
                break;
            }
        } else
            _0x304c5d[_0x189a61(0x254)](MainHallWalk, _0x189a61(0x22b));
    }), _0x304c5d[_0x29dbd0(0x29a)](GM_registerMenuCommand, _0x304c5d[_0x29dbd0(0x234)], () => {
        const _0x51faff = _0x29dbd0;
        if (_0x304c5d[_0x51faff(0x413)](_0x304c5d['\x59\x50\x4c\x4c\x79'], '\x4c\x41\x5a\x63\x4a')) {
            _0x304c5d[_0x51faff(0x254)](_0x3970c6, _0x304c5d['\x49\x6e\x4f\x45\x59']);
            return;
        } else
            StruggleProgress = 0x1a3e + -0x1 * 0x10ef + -0x2 * 0x469;
    }), _0x304c5d[_0x29dbd0(0x301)](GM_registerMenuCommand, _0x304c5d[_0x29dbd0(0x24f)], () => {
        const _0x2eac46 = _0x29dbd0;
        SkillProgress(_0x304c5d[_0x2eac46(0x2c3)], -0x1 * 0x2f7b9 + 0x25c52 + 0x25ab9 * 0x1);
    }), _0x304c5d[_0x29dbd0(0x174)](GM_registerMenuCommand, _0x304c5d['\x4a\x72\x54\x5a\x49'], () => {
        const _0x1061ba = _0x29dbd0;
        _0x304c5d[_0x1061ba(0x1d9)](SkillProgress, _0x304c5d[_0x1061ba(0x107)], -0x1f2c6 + -0x189d6 * 0x1 + -0x29df7 * -0x2);
    }), _0x304c5d['\x69\x78\x62\x53\x41'](GM_registerMenuCommand, _0x304c5d[_0x29dbd0(0x35d)], () => {
        const _0xbe0afb = _0x29dbd0;
        _0x304c5d[_0xbe0afb(0x2f8)](SkillProgress, _0x304c5d[_0xbe0afb(0x129)], 0x30c9a + -0x1 * 0x3c6e + 0xb * -0x18ce);
    }), GM_registerMenuCommand(_0x304c5d[_0x29dbd0(0x241)], () => {
        const _0x360dc9 = _0x29dbd0;
        _0x304c5d[_0x360dc9(0x204)](SkillProgress, _0x360dc9(0x3f4), -0x2 * 0x155a3 + -0x12d0 + 0x47d68);
    }), GM_registerMenuCommand('\u79fb\u9664\u6781\u9650\x43\x44\x28\u5fc5\u987b\u65b0\u5207\x52\x50\u540e\u7528\x29', () => {
        const _0x125129 = _0x29dbd0;
        Player[_0x125129(0x22e)][_0x125129(0x313)] = 0xcab + -0x8db + -0x3d0;
    }), _0x304c5d[_0x29dbd0(0x2d1)](GM_registerMenuCommand, _0x304c5d['\x76\x55\x67\x65\x51'], () => {
        const _0x233d5e = _0x29dbd0;
        _0x304c5d[_0x233d5e(0x413)](_0x304c5d[_0x233d5e(0x356)], _0x233d5e(0x396)) ? (_0x304c5d[_0x233d5e(0x224)](_0x1a54c3, _0x304c5d[_0x233d5e(0x412)]), _0x304c5d[_0x233d5e(0x1cd)](_0x41ddf0, _0x16066d, -0x11d3 * 0x1 + 0xb * -0x295 + 0x12 * 0x297)) : _0x304c5d['\x53\x4f\x70\x6d\x6a'](SkillProgress, _0x233d5e(0x31e), -0x15026 * 0x1 + 0x2accb * -0x1 + 0x5bc43);
    }), _0x304c5d[_0x29dbd0(0x213)](GM_registerMenuCommand, _0x304c5d[_0x29dbd0(0x2d7)], () => {
        const _0x3c6f56 = _0x29dbd0;
        if (_0x304c5d[_0x3c6f56(0x311)](_0x304c5d[_0x3c6f56(0x2b9)], _0x304c5d[_0x3c6f56(0x108)]))
            return;
        else
            _0x304c5d['\x48\x64\x75\x68\x6c'](SkillProgress, _0x3c6f56(0x171), 0x2a862 + -0xe93c + 0x2c);
    }), _0x304c5d[_0x29dbd0(0x20b)](GM_registerMenuCommand, _0x304c5d[_0x29dbd0(0x1fa)], () => {
        const _0x108734 = _0x29dbd0;
        _0x304c5d[_0x108734(0x267)](SkillProgress, _0x304c5d[_0x108734(0x30d)], -0x18981 + -0x46fb + 0x38fce);
    }), _0x304c5d['\x73\x49\x56\x65\x43'](GM_registerMenuCommand, _0x304c5d['\x53\x52\x77\x49\x61'], () => {
        const _0x3aea61 = _0x29dbd0;
        if (_0x304c5d[_0x3aea61(0x159)] !== _0x304c5d[_0x3aea61(0x159)])
            _0xfeadf[_0x3aea61(0xee)][_0x3aea61(0x29c)] = [];
        else {
            const _0x270888 = _0x304c5d[_0x3aea61(0x11f)][_0x3aea61(0x261)]('\x7c');
            let _0x2f2992 = 0x11 * -0xe + -0x223a + -0x384 * -0xa;
            while (!![]) {
                switch (_0x270888[_0x2f2992++]) {
                case '\x30':
                    _0x304c5d[_0x3aea61(0x280)](InventoryWear, Player, _0x304c5d['\x50\x43\x42\x4f\x44'], '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68', _0x304c5d[_0x3aea61(0x223)], -0x1 * -0x4044 + -0x56 * -0x9a + -0x2 * -0xa5a9);
                    continue;
                case '\x31':
                    _0x304c5d[_0x3aea61(0x144)](InventoryWear, Player, _0x304c5d['\x71\x66\x53\x63\x56'], _0x304c5d[_0x3aea61(0xfe)], _0x304c5d[_0x3aea61(0x223)], 0x199f * -0x2 + 0x1f * -0x8b5 + 0x3007b);
                    continue;
                case '\x32':
                    _0x304c5d[_0x3aea61(0x397)](InventoryWear, Player, _0x304c5d[_0x3aea61(0x248)], _0x304c5d[_0x3aea61(0x183)], _0x304c5d[_0x3aea61(0x223)], -0x2e328 + -0x5779 * -0x5 + 0x2ed1d);
                    continue;
                case '\x33':
                    _0x304c5d[_0x3aea61(0x279)](InventoryWear, Player, _0x304c5d['\x70\x46\x54\x42\x54'], _0x304c5d[_0x3aea61(0x25d)], _0x304c5d[_0x3aea61(0x223)], -0x49f0 + 0x20 * 0x1afc + -0x1563e);
                    continue;
                case '\x34':
                    _0x304c5d[_0x3aea61(0x1d5)](InventoryWear, Player, _0x3aea61(0x2cd), _0x3aea61(0x365), '\x23\x32\x30\x32\x30\x32\x30', 0x2471a * -0x1 + -0x218c5 + 0x61f31 * 0x1);
                    continue;
                case '\x35':
                    _0x304c5d[_0x3aea61(0x214)](InventoryWear, Player, _0x3aea61(0x283), _0x3aea61(0x1df), _0x3aea61(0x14b), 0x1 * 0x2755a + 0x1b7fd + 0xd * -0x2fd9);
                    continue;
                case '\x36':
                    InventoryWear(Player, _0x304c5d[_0x3aea61(0x386)], _0x304c5d['\x4e\x66\x62\x50\x50'], _0x304c5d[_0x3aea61(0x223)], 0xd * 0x4d5 + -0x3 * 0x16c1 + 0x1c4c4);
                    continue;
                case '\x37':
                    _0x304c5d[_0x3aea61(0x280)](InventoryWear, Player, _0x3aea61(0x20d), _0x304c5d[_0x3aea61(0x3ac)], _0x304c5d[_0x3aea61(0x223)], -0x2945b + 0x1 * 0x57f9 + 0x3fbb4);
                    continue;
                case '\x38':
                    _0x304c5d[_0x3aea61(0x2b6)](InventoryWear, Player, _0x304c5d[_0x3aea61(0x175)], _0x304c5d[_0x3aea61(0x137)], _0x304c5d[_0x3aea61(0x223)], -0xede6 + 0x10 * -0x219a + 0x4c6d8);
                    continue;
                }
                break;
            }
        }
    }), GM_registerMenuCommand(_0x304c5d[_0x29dbd0(0x36e)], () => {
        const _0x57e20e = _0x29dbd0;
        _0x304c5d[_0x57e20e(0x294)](InventoryWear, Player, _0x304c5d[_0x57e20e(0x21b)], _0x304c5d[_0x57e20e(0x1a2)]);
    }), _0x304c5d[_0x29dbd0(0x1cd)](GM_registerMenuCommand, _0x304c5d['\x42\x65\x74\x48\x70'], () => {
        const _0x31589e = _0x29dbd0;
        if (_0x304c5d[_0x31589e(0x252)](_0x304c5d[_0x31589e(0x31d)], _0x304c5d[_0x31589e(0x31d)])) {
            if (!(Player[_0x31589e(0x3be)] && _0x304c5d[_0x31589e(0x338)](Player[_0x31589e(0x3be)]['\x4e\x61\x6d\x65'], _0x31589e(0x27e)))) {
                if (_0x304c5d[_0x31589e(0x10a)](_0x304c5d[_0x31589e(0x30e)], _0x31589e(0x318))) {
                    const _0x19201c = _0x31589e(0x10b)[_0x31589e(0x261)]('\x7c');
                    let _0x5b8db4 = 0x5 + 0x643 * -0x6 + -0x1 * -0x258d;
                    while (!![]) {
                        switch (_0x19201c[_0x5b8db4++]) {
                        case '\x30':
                            _0x304c5d[_0x31589e(0x3b8)](_0x261dce, _0x304c5d[_0x31589e(0x1bb)], '');
                            continue;
                        case '\x31':
                            _0x3e9c4e = null;
                            continue;
                        case '\x32':
                            _0x304c5d['\x4c\x5a\x69\x51\x71'](_0x5b4130);
                            continue;
                        case '\x33':
                            _0x304c5d[_0x31589e(0x201)](_0x14b774, '');
                            continue;
                        case '\x34':
                            _0xc6d498 = ![];
                            continue;
                        case '\x35':
                            _0x304c5d['\x59\x62\x7a\x52\x7a'](_0x2b35c6);
                            continue;
                        case '\x36':
                            _0x304c5d['\x72\x78\x4b\x4f\x66'](_0x31bbd6, _0x31589e(0x272), _0x304c5d[_0x31589e(0x190)]);
                            continue;
                        case '\x37':
                            _0x2e21cc();
                            continue;
                        }
                        break;
                    }
                } else
                    _0x304c5d[_0x31589e(0x2b8)](CharacterReleaseTotal, Player);
            }
        } else
            _0x304c5d[_0x31589e(0x139)](_0x16d6d8, _0x397360, _0x14f9a3, 0x35acb + 0x16 * -0x9ee + -0xc105);
    }), _0x304c5d[_0x29dbd0(0x3e9)](GM_registerMenuCommand, _0x29dbd0(0x2e5), () => {
        const _0x395ed3 = _0x29dbd0;
        _0x304c5d['\x48\x64\x75\x68\x6c'](ServerSend, _0x304c5d[_0x395ed3(0x342)], {
            '\x43\x6f\x6e\x74\x65\x6e\x74': _0x304c5d[_0x395ed3(0x27f)],
            '\x54\x79\x70\x65': _0x304c5d['\x44\x47\x71\x56\x4e'],
            '\x54\x61\x72\x67\x65\x74': null,
            '\x44\x69\x63\x74\x69\x6f\x6e\x61\x72\x79': [{
                    '\x54\x61\x67': _0x304c5d[_0x395ed3(0x27f)],
                    '\x54\x65\x78\x74': _0x304c5d['\x6c\x47\x4d\x71\x6c'](prompt, _0x304c5d[_0x395ed3(0x289)], _0x304c5d[_0x395ed3(0x19e)])
                }]
        });
    }), _0x304c5d['\x58\x71\x45\x6a\x4d'](GM_registerMenuCommand, _0x304c5d['\x4f\x76\x4e\x64\x6d'], () => {
        const _0x4faa00 = _0x29dbd0, _0x5aa1ac = _0x304c5d[_0x4faa00(0x1ce)]['\x73\x70\x6c\x69\x74']('\x7c');
        let _0x138cab = 0x1cf9 * 0x1 + 0x12fe + 0x2ff7 * -0x1;
        while (!![]) {
            switch (_0x5aa1ac[_0x138cab++]) {
            case '\x30':
                _0x304c5d[_0x4faa00(0x215)](CharacterReleaseTotal, targetMember);
                continue;
            case '\x31':
                if (_0x304c5d[_0x4faa00(0x184)](targetMember, null))
                    return;
                continue;
            case '\x32':
                _0x304c5d[_0x4faa00(0x391)](ChatRoomCharacterUpdate, targetMember);
                continue;
            case '\x33':
                targetMember = Character[_0x4faa00(0x36b)](_0x3e795a => _0x3e795a['\x4e\x61\x6d\x65'][_0x4faa00(0x2fa)]() == targetName);
                continue;
            case '\x34':
                targetName = prompt(_0x304c5d['\x58\x50\x4d\x51\x44'], _0x4faa00(0x27e));
                continue;
            case '\x35':
                targetMember[_0x4faa00(0x3f5)]['\x50\x72\x6f\x67\x72\x65\x73\x73'] = 0x14c6 + -0x155 * -0x19 + 0x7f * -0x6d;
                continue;
            }
            break;
        }
    }), _0x304c5d[_0x29dbd0(0x398)](GM_registerMenuCommand, _0x304c5d['\x5a\x59\x66\x48\x6c'], () => {
        const _0x49b6b5 = _0x29dbd0, _0x48ab2d = {
                '\x77\x63\x77\x45\x44': function (_0x57ce1f, _0x52e0d0, _0x438022) {
                    const _0x3f1bfc = _0x4408;
                    return _0x304c5d[_0x3f1bfc(0x3dd)](_0x57ce1f, _0x52e0d0, _0x438022);
                },
                '\x77\x65\x48\x43\x71': _0x304c5d[_0x49b6b5(0x342)],
                '\x4e\x71\x76\x4e\x7a': _0x304c5d['\x42\x71\x72\x66\x70']
            };
        if (_0x304c5d[_0x49b6b5(0x2ce)](_0x304c5d[_0x49b6b5(0x377)], _0x49b6b5(0x273))) {
            if (!(Player[_0x49b6b5(0x3be)] && Player[_0x49b6b5(0x3be)][_0x49b6b5(0x3e6)] == _0x304c5d[_0x49b6b5(0x2b1)])) {
                if (Player[_0x49b6b5(0x3e6)] != _0x49b6b5(0x27e)) {
                    _0x304c5d[_0x49b6b5(0x2f2)](alert, _0x304c5d[_0x49b6b5(0x327)]);
                    return;
                }
            }
            targetName = _0x304c5d[_0x49b6b5(0x344)](prompt, _0x304c5d[_0x49b6b5(0x405)], _0x304c5d['\x6b\x5a\x54\x6a\x79']), targetMember = Character[_0x49b6b5(0x36b)](_0x454720 => _0x454720[_0x49b6b5(0x3e6)]['\x74\x6f\x4c\x6f\x77\x65\x72\x43\x61\x73\x65']() == targetName);
            if (targetMember == null)
                return;
            _0x304c5d[_0x49b6b5(0x1d5)](InventoryWear, targetMember, _0x304c5d[_0x49b6b5(0x303)], '\x49\x74\x65\x6d\x41\x72\x6d\x73', _0x304c5d['\x64\x6e\x56\x44\x52'], 0x1b65 * -0x17 + -0x17 * 0x5a7 + 0x4b75c), _0x304c5d[_0x49b6b5(0x10c)](InventoryWear, targetMember, _0x49b6b5(0xe8), _0x304c5d[_0x49b6b5(0x137)], _0x304c5d[_0x49b6b5(0x223)], 0x8d0c + 0x36d4 + 0xfb72), targetMember[_0x49b6b5(0x3f5)][_0x49b6b5(0x290)] = 0x12 * 0x6 + 0x1 * -0x1215 + 0x11a9, _0x304c5d[_0x49b6b5(0x3dc)](ChatRoomCharacterUpdate, targetMember);
        } else
            _0x48ab2d[_0x49b6b5(0x39c)](_0x361d7c, _0x48ab2d[_0x49b6b5(0x3e8)], {
                '\x43\x6f\x6e\x74\x65\x6e\x74': _0x49b6b5(0x218),
                '\x54\x79\x70\x65': _0x48ab2d[_0x49b6b5(0x189)]
            });
    }), GM_registerMenuCommand(_0x304c5d[_0x29dbd0(0x169)], () => {
        const _0x19e810 = _0x29dbd0, _0x5881bc = {
                '\x4e\x41\x50\x59\x6c': _0x304c5d[_0x19e810(0x3b3)],
                '\x43\x65\x6a\x6f\x49': '\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x3a\x20\x44\x69\x73\x61\x62\x6c\x65\x64\x2e',
                '\x66\x51\x6c\x58\x5a': function (_0x4de00d, _0x263fdd) {
                    const _0x5c651c = _0x19e810;
                    return _0x304c5d[_0x5c651c(0x251)](_0x4de00d, _0x263fdd);
                },
                '\x74\x43\x61\x72\x7a': _0x304c5d[_0x19e810(0x2e1)],
                '\x75\x69\x43\x73\x68': function (_0x5e8d15, _0x40f022) {
                    const _0x587363 = _0x19e810;
                    return _0x304c5d[_0x587363(0x314)](_0x5e8d15, _0x40f022);
                },
                '\x49\x73\x48\x68\x57': _0x19e810(0x19d),
                '\x64\x66\x6f\x71\x4b': _0x19e810(0x177)
            };
        if (_0x304c5d[_0x19e810(0x151)](_0x19e810(0x13f), _0x19e810(0x228)))
            _0x304c5d[_0x19e810(0x155)](_0x4d9623, _0x514d1c, _0x236d46, 0x6e39 * 0x6 + 0x17eb8 + -0x254bc);
        else {
            if (!(Player['\x4f\x77\x6e\x65\x72\x73\x68\x69\x70'] && _0x304c5d[_0x19e810(0x1e5)](Player[_0x19e810(0x3be)][_0x19e810(0x3e6)], _0x304c5d['\x6b\x5a\x54\x6a\x79']))) {
                if (_0x304c5d[_0x19e810(0x32b)](Player[_0x19e810(0x3e6)], _0x304c5d[_0x19e810(0x2b1)])) {
                    _0x304c5d[_0x19e810(0x124)](alert, _0x304c5d[_0x19e810(0x327)]);
                    return;
                }
            }
            targetName = prompt(_0x304c5d[_0x19e810(0x1be)], _0x304c5d[_0x19e810(0x2b1)]), targetMember = Character[_0x19e810(0x36b)](_0x12bb83 => _0x12bb83[_0x19e810(0x3e6)][_0x19e810(0x2fa)]() == targetName);
            if (_0x304c5d[_0x19e810(0x366)](targetMember, null))
                return;
            targetMember[_0x19e810(0x17d)]['\x66\x6f\x72\x45\x61\x63\x68'](_0x23850e => {
                const _0x1670d7 = _0x19e810;
                let _0x26e0c6 = 0x2 * 0x1a3 + -0x170f + 0x13c9;
                if (_0x304c5d[_0x1670d7(0x3f9)](_0x23850e[_0x1670d7(0x22e)], -0xcf5 + 0x5cf + -0x3d * -0x1e)) {
                    _0x304c5d[_0x1670d7(0x3b5)](_0x23850e[_0x1670d7(0xee)], null) && (_0x23850e[_0x1670d7(0xee)] = {});
                    _0x23850e[_0x1670d7(0xee)][_0x1670d7(0x29c)] == null && (_0x304c5d[_0x1670d7(0x374)](_0x304c5d[_0x1670d7(0x28b)], _0x304c5d[_0x1670d7(0x419)]) ? _0x4ca45a = _0x32e0a9[_0x1670d7(0x1e9)][_0x1670d7(0x3e6)] : _0x23850e[_0x1670d7(0xee)][_0x1670d7(0x29c)] = []);
                    _0x304c5d[_0x1670d7(0x2ec)](_0x23850e[_0x1670d7(0xee)][_0x1670d7(0x29c)][_0x1670d7(0x1ef)](_0x304c5d['\x50\x52\x4c\x59\x48']), -0x409 * 0x1 + 0x1f62 + -0x1b59 * 0x1) && (_0x304c5d[_0x1670d7(0x413)](_0x304c5d[_0x1670d7(0x2c8)], _0x1670d7(0x1da)) ? _0x118bb1 = _0x15c618 : _0x23850e[_0x1670d7(0xee)][_0x1670d7(0x29c)][_0x1670d7(0x30a)]('\x4c\x6f\x63\x6b'));
                    if (_0x304c5d['\x6f\x62\x4a\x6e\x6e'](Math[_0x1670d7(0x1ec)](), -0x64 + 0x3bf + -0x35b * 0x1 + 0.5))
                        _0x304c5d[_0x1670d7(0x151)](_0x1670d7(0x102), _0x304c5d[_0x1670d7(0x1c2)]) ? (_0x239540 = ![], _0x26a2ae['\x6f\x66\x66'](_0x5881bc['\x4e\x41\x50\x59\x6c'], _0x23abd3), _0x51ae04(_0x5881bc[_0x1670d7(0x349)]), _0x2a3f31 = function (_0x5e7da6) {
                            return !![];
                        }) : _0x23850e[_0x1670d7(0xee)][_0x1670d7(0x315)] = _0x304c5d['\x74\x74\x79\x78\x4b'];
                    else {
                        if (_0x304c5d[_0x1670d7(0x212)] !== _0x1670d7(0x221)) {
                            let _0x3f4d93 = _0x5a1ee1['\x66\x69\x6e\x64'](_0x23a734 => _0x23a734[_0x1670d7(0x2ea)] === _0x7a28d6['\x53\x65\x6e\x64\x65\x72']);
                            if (_0x5881bc[_0x1670d7(0x210)](_0x95cda['\x54\x79\x70\x65'], _0x5881bc['\x74\x43\x61\x72\x7a']) && (_0x5881bc[_0x1670d7(0x340)](_0x1c62fd[_0x1670d7(0x2ad)], _0x1670d7(0x21e)) || _0x3a1564[_0x1670d7(0x2ad)] == _0x5881bc['\x49\x73\x48\x68\x57'])) {
                                const _0x45c9c0 = {};
                                _0x45c9c0[_0x1670d7(0x2ea)] = _0x3f4d93[_0x1670d7(0x2ea)], _0x45c9c0[_0x1670d7(0x1a0)] = _0x1670d7(0x168), _0x59d65f(_0x5881bc[_0x1670d7(0x136)], _0x45c9c0);
                            }
                            ;
                        } else
                            _0x23850e[_0x1670d7(0xee)]['\x4c\x6f\x63\x6b\x65\x64\x42\x79'] = _0x304c5d['\x6b\x55\x72\x6c\x4a'];
                    }
                    _0x23850e[_0x1670d7(0xee)][_0x1670d7(0x2bb)] = Player[_0x1670d7(0x2ea)], targetMember[_0x1670d7(0x17d)][_0x26e0c6] = _0x23850e;
                }
                _0x26e0c6++;
            }), targetMember['\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73'][_0x19e810(0x290)] = -0x5c6 * -0x2 + 0x9 * 0x26e + 0x1 * -0x216a, ChatRoomCharacterUpdate(targetMember);
        }
    }), _0x304c5d['\x7a\x7a\x79\x72\x41'](GM_registerMenuCommand, _0x304c5d[_0x29dbd0(0x3e1)], () => {
        const _0x3e4eb6 = _0x29dbd0;
        ReputationChange(_0x304c5d['\x54\x70\x54\x68\x41'](prompt, _0x304c5d[_0x3e4eb6(0xec)], _0x304c5d['\x53\x44\x55\x75\x78']), 0x10de6 + 0x2b95 * 0x14 + 0x115b * -0x28, !![]);
    });
}()));
function _0x4408(_0x3f3f9c, _0x93e8a7) {
    const _0x4408c8 = _0x93e8();
    return _0x4408 = function (_0x4e34a9, _0x18be79) {
        _0x4e34a9 = _0x4e34a9 - (-0x1165 + -0xb25 + 0x1d72);
        let _0x4b68c9 = _0x4408c8[_0x4e34a9];
        return _0x4b68c9;
    }, _0x4408(_0x3f3f9c, _0x93e8a7);
}
function _0x93e8() {
    const _0x492861 = [
        '\x79\x50\x73\x53\x52',
        '\x49\x4f\x5a\x69\x64',
        '\x4c\x65\x61\x74\x68\x65\x72\x42\x65\x6c\x74',
        '\x62\x4c\x4e\x6a\x41',
        '\x61\x6d\x4a\x42\x6b',
        '\x53\x74\x65\x65\x6c\x50\x6f\x73\x74\x75\x72\x65\x43\x6f\x6c\x6c\x61\x72',
        '\x61\x72\x45\x48\x72',
        '\x49\x74\x65\x6d\x4e\x65\x63\x6b\x41\x63\x63\x65\x73\x73\x6f\x72\x69\x65\x73',
        '\x78\x65\x57\x68\x74',
        '\x54\x70\x54\x68\x41',
        '\x4a\x58\x75\x4f\x6e',
        '\x7a\x4d\x64\x6e\x49',
        '\u8981\u89e3\u5c01\u7684\u73a9\u5bb6\u540d\u79f0',
        '\x70\x50\x55\x4d\x7a',
        '\u63d0\u5347\u786c\u6491\u7b49\u7ea7',
        '\x45\x6b\x79\x68\x48',
        '\x76\x54\x69\x65\x43',
        '\x64\x5a\x43\x45\x7a',
        '\x70\x65\x57\x70\x54',
        '\x47\x50\x6a\x75\x52',
        '\x47\x41\x65\x48\x70',
        '\x57\x46\x58\x65\x7a',
        '\x4e\x58\x6d\x6b\x48',
        '\x49\x74\x65\x6d\x56\x75\x6c\x76\x61\x50\x69\x65\x72\x63\x69\x6e\x67\x73',
        '\x4f\x57\x44\x77\x47',
        '\x44\x47\x71\x56\x4e',
        '\x33\x30\x73\x6d\x47\x62\x4a\x5a',
        '\x59\x42\x41\x5a\x65',
        '\x75\x55\x48\x76\x6b',
        '\u58f0\u97f3\u6d2a\u4eae\x28\u8bf4\u4ec0\u4e48\u5c31\u662f\u4ec0\u4e48\x29',
        '\u63d0\u5347\u5185\u9b3c\u7b49\u7ea7',
        '\x63\x6e\x6c\x53\x66',
        '\x61\x70\x70\x6c\x79',
        '\x6a\x55\x61\x75\x76',
        '\x4d\x65\x6d\x62\x65\x72\x4e\x75\x6d\x62\x65\x72',
        '\x6f\x70\x47\x49\x4d',
        '\x4a\x4a\x4e\x63\x68',
        '\x72\x4a\x66\x45\x64',
        '\x34\x4c\x4e\x48\x47\x73\x62',
        '\x45\x55\x53\x4f\x64',
        '\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x3a\x20\x45\x6e\x67\x6c\x69\x73\x68\x2e',
        '\x34\x30\x37\x4c\x41\x70\x48\x7a\x6c',
        '\x68\x4c\x42\x78\x42',
        '\x67\x4a\x42\x51\x61',
        '\x48\x49\x64\x77\x41',
        '\x76\x56\x78\x75\x77',
        '\u4f60\u5fc5\u987b\u662f\x61\x77\x61\x71\x77\x71\u7684\x73\x75\x62\u624d\u80fd\u8fd9\u4e48\u505a\u5462\x7e',
        '\x67\x58\x72\x61\x51',
        '\x69\x5a\x6c\x73\x48',
        '\x43\x51\x64\x71\x4d',
        '\x74\x6f\x4c\x6f\x77\x65\x72\x43\x61\x73\x65',
        '\x44\x44\x41\x57\x55',
        '\x49\x74\x65\x6d\x56\x75\x6c\x76\x61',
        '\x7a\x61\x78\x77\x77',
        '\x43\x75\x6e\x74\x67',
        '\x59\x71\x61\x45\x75',
        '\x62\x61\x6e\x6d\x65',
        '\x44\x61\x4b\x4d\x50',
        '\x58\x51\x45\x79\x4f',
        '\x58\x45\x4c\x4f\x64',
        '\x42\x72\x74\x62\x4b',
        '\x74\x6b\x43\x52\x56',
        '\x65\x6a\x69\x7a\x67',
        '\x68\x6a\x59\x62\x69',
        '\x74\x6f\x53\x74\x72\x69\x6e\x67',
        '\x50\x7a\x62\x65\x53',
        '\x70\x75\x73\x68',
        '\u5bc6\u7801\u8bfb\u53d6',
        '\x7a\x78\x6e\x6d\x64',
        '\x56\x70\x52\x4b\x4c',
        '\x56\x53\x57\x4a\x62',
        '\x49\x74\x65\x6d\x48\x6f\x6f\x64',
        '\x48\x42\x66\x59\x74',
        '\x49\x6f\x73\x53\x4b',
        '\x6c\x53\x62\x75\x61',
        '\x4c\x61\x73\x74\x43\x68\x61\x6e\x67\x65',
        '\x59\x64\x69\x55\x61',
        '\x4c\x6f\x63\x6b\x65\x64\x42\x79',
        '\x41\x54\x4e\x4c\x79',
        '\u6346\u6b7b\u6211',
        '\x55\x79\x6e\x75\x64',
        '\x43\x68\x61\x74\x52\x6f\x6f\x6d',
        '\x62\x48\x52\x44\x49',
        '\x59\x79\x69\x78\x72',
        '\x56\x59\x4d\x56\x79',
        '\x6c\x64\x77\x65\x6b',
        '\x57\x69\x6c\x6c\x70\x6f\x77\x65\x72',
        '\x73\x5a\x77\x66\x72',
        '\x70\x61\x4c\x77\x73',
        '\x62\x4f\x52\x78\x4d',
        '\x4c\x6f\x63\x6b\x50\x69\x63\x6b\x69\x6e\x67',
        '\x4e\x53\x52\x4b\x6d',
        '\x35\x34\x38\x39\x39\x37\x6d\x65\x57\x63\x76\x65',
        '\x42\x6f\x75\x6e\x74\x79\x53\x75\x69\x74\x63\x61\x73\x65',
        '\x4f\x4e\x54\x6e\x50',
        '\x49\x6e\x4f\x45\x59',
        '\x30\x2e\x38\x2e\x33\x2d\x33\x65\x35\x34\x35\x62\x63\x32',
        '\x6b\x58\x51\x5a\x73',
        '\x5a\x75\x67\x56\x66',
        '\x79\x63\x6e\x45\x4c',
        '\x75\x71\x69\x42\x71',
        '\x58\x67\x65\x66\x73',
        '\x72\x65\x6c\x65\x61\x73\x65',
        '\x4f\x67\x4d\x44\x57',
        '\x61\x77\u9171',
        '\x61\x70\x64\x4c\x57',
        '\x56\x50\x4a\x4f\x58',
        '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68\x33',
        '\x72\x53\x67\x63\x62',
        '\x50\x43\x42\x4f\x44',
        '\x6c\x56\x44\x4e\x6e',
        '\x6b\x55\x72\x6c\x4a',
        '\x6a\x41\x59\x64\x48',
        '\x6e\x57\x73\x78\x72',
        '\x42\x65\x65\x70',
        '\x59\x4c\x6d\x6a\x48',
        '\x4f\x6a\x63\x61\x4d',
        '\x69\x61\x77\x42\x53',
        '\x52\x54\x68\x76\x4e',
        '\x58\x41\x64\x6a\x47',
        '\x75\x69\x43\x73\x68',
        '\x76\x46\x71\x59\x63',
        '\x74\x6c\x6d\x63\x73',
        '\x6d\x68\x54\x78\x46',
        '\x6c\x47\x4d\x71\x6c',
        '\x4c\x6f\x63\x6b',
        '\x66\x72\x6a\x54\x69',
        '\x41\x74\x5a\x6c\x47',
        '\x42\x5a\x71\x48\x47',
        '\x43\x65\x6a\x6f\x49',
        '\x46\x58\x53\x4a\x79',
        '\x73\x52\x62\x69\x48',
        '\x6d\x54\x79\x43\x66',
        '\x64\x45\x6f\x4c\x5a',
        '\x6f\x72\x4c\x6c\x50',
        '\x4b\x54\x41\x58\x55',
        '\x4c\x65\x61\x74\x68\x65\x72\x48\x6f\x6f\x64\x4f\x70\x65\x6e\x4d\x6f\x75\x74\x68',
        '\x50\x42\x76\x41\x62',
        '\x65\x72\x72\x6f\x72',
        '\x45\x59\x64\x73\x61',
        '\x49\x46\x74\x55\x6a',
        '\x43\x64\x68\x78\x44',
        '\x62\x57\x4c\x6b\x7a',
        '\x5f\x5f\x70\x72\x6f\x74\x6f\x5f\x5f',
        '\x69\x6e\x7a\x42\x45',
        '\u62ff\u7bb1\u5b50',
        '\x6b\x4a\x52\x71\x7a',
        '\x6f\x62\x4a\x6e\x6e',
        '\x6a\x45\x47\x77\x76',
        '\x63\x48\x4b\x56\x76',
        '\x6c\x56\x6c\x55\x49',
        '\x55\x7a\x51\x44\x6e',
        '\x43\x50\x49\x79\x67',
        '\x6d\x4b\x78\x43\x4d',
        '\x4a\x54\x57\x77\x6e',
        '\x46\x78\x6a\x48\x4d',
        '\x59\x53\x4e\x50\x41',
        '\x49\x74\x65\x6d\x4e\x65\x63\x6b',
        '\x53\x49\x58\x5a\x65',
        '\x6f\x42\x46\x5a\x44',
        '\x70\x61\x41\x55\x41',
        '\x69\x76\x61\x62\x4e',
        '\x63\x70\x43\x56\x72',
        '\x66\x69\x6e\x64',
        '\x42\x71\x72\x66\x70',
        '\x46\x56\x78\x6b\x65',
        '\x45\x4c\x69\x73\x6e',
        '\x49\x74\x65\x6d\x45\x61\x72\x73',
        '\x74\x74\x59\x6b\x4e',
        '\x55\x51\x55\x74\x52',
        '\x56\x73\x76\x69\x48',
        '\x4a\x69\x61\x72\x42',
        '\x66\x48\x52\x66\x66',
        '\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x3a\x20\u4e2d\u6587\x2e',
        '\u8981\u6346\u7684\u73a9\u5bb6\u540d\u79f0\x28\u5168\u5c0f\u5199\x29',
        '\x49\x4d\x6c\x4f\x63',
        '\x6d\x56\x79\x71\x6f',
        '\x79\x41\x41\x65\x50',
        '\x78\x4c\x74\x78\x6c',
        '\x65\x4d\x72\x6b\x51',
        '\x42\x4b\x4d\x4f\x74',
        '\x49\x74\x65\x6d\x4c\x65\x67\x73',
        '\x75\x76\x64\x77\x73',
        '\x58\x55\x73\x76\x67',
        '\x4e\x66\x62\x50\x50',
        '\u63d0\u5347\u81ea\u7f1a\u7b49\u7ea7',
        '\x71\x45\x4f\x55\x76',
        '\x47\x57\x62\x4d\x70',
        '\x59\x77\x71\x74\x65',
        '\x59\x65\x50\x70\x4b',
        '\x64\x7a\x43\x6f\x41',
        '\x44\x5a\x6e\x67\x71',
        '\u53e3\u7403\u7834\u8bd1',
        '\x78\x57\x44\x6a\x78',
        '\x63\x45\x58\x4b\x59',
        '\x73\x6d\x78\x7a\x65',
        '\x62\x42\x6e\x70\x79',
        '\x50\x65\x54\x62\x68',
        '\x71\x74\x6c\x6d\x4f',
        '\x6f\x45\x6b\x50\x6e',
        '\x4d\x68\x66\x53\x4e',
        '\x42\x56\x49\x47\x4a',
        '\x61\x74\x76\x4c\x49',
        '\x49\x74\x65\x6d\x54\x6f\x72\x73\x6f',
        '\x68\x43\x58\x59\x76',
        '\x57\x6f\x47\x58\x51',
        '\x56\x52\x7a\x72\x51',
        '\x45\x6e\x4a\x6a\x50',
        '\x4c\x57\x73\x5a\x6a',
        '\x56\x50\x52\x67\x6b',
        '\x43\x6b\x56\x71\x49',
        '\x61\x77\x42\x4f\x54\x20\u62b1\u6b49\x2c\u60a8\u5df2\u7ecf\u88ab\u5c01\u7981\u3002',
        '\x77\x63\x77\x45\x44',
        '\x61\x77\x74\x5a\x4c',
        '\x4a\x73\x69\x43\x72',
        '\x4c\x65\x61\x74\x68\x65\x72\x48\x61\x72\x6e\x65\x73\x73',
        '\x58\x53\x47\x4b\x57',
        '\x49\x70\x77\x6c\x48',
        '\x6f\x74\x78\x72\x62',
        '\x50\x61\x73\x73\x77\x6f\x72\x64',
        '\x69\x53\x76\x4e\x65',
        '\x56\x69\x67\x48\x4c',
        '\x53\x65\x4a\x55\x54',
        '\x51\x5a\x7a\x56\x78',
        '\x53\x45\x4c\x6c\x4a',
        '\x41\x66\x4d\x4d\x4e',
        '\x54\x6e\x68\x5a\x45',
        '\x4f\x4a\x61\x57\x58',
        '\x50\x43\x69\x6d\x76',
        '\x43\x52\x43\x57\x44',
        '\x4f\x64\x46\x45\x49',
        '\x57\x52\x55\x69\x41',
        '\x75\x43\x56\x4f\x46',
        '\x6e\x64\x46\x68\x66',
        '\x4b\x70\x72\x46\x68',
        '\x4c\x73\x55\x6e\x75',
        '\x75\x6e\x6b\x6e\x6f\x77\x6e',
        '\x70\x48\x62\x4a\x68',
        '\x58\x48\x5a\x53\x76',
        '\x7a\x7a\x79\x72\x41',
        '\x48\x64\x75\x68\x6c',
        '\x7a\x43\x41\x49\x49',
        '\x6f\x73\x79\x4f\x62',
        '\u4e0a\u9501\x28\u641e\u4e8b\u60c5\u4e13\u7528\x29',
        '\x62\x76\x79\x54\x72',
        '\x52\x63\x42\x48\x67',
        '\x4f\x77\x6e\x65\x72\x73\x68\x69\x70',
        '\x4b\x79\x46\x73\x62',
        '\x70\x6f\x4d\x51\x75',
        '\x48\x52\x41\x55\x58',
        '\x52\x59\x62\x51\x64',
        '\x54\x67\x44\x70\x62',
        '\x4d\x48\x49\x52\x45',
        '\x45\x46\x6d\x7a\x6a',
        '\x68\x44\x6b\x50\x53',
        '\x63\x59\x64\x50\x6c',
        '\u81ea\u5df1\u5220\u6389\u4e0d\u5bf9\u7684\x2c\x20\u8f93\u9519\u4e86\u540e\u679c\u81ea\u8d1f\x21',
        '\x42\x44\x45\x70\x6f',
        '\x70\x57\x43\x6f\x4d',
        '\x45\x54\x7a\x63\x6d',
        '\x72\x52\x56\x75\x65',
        '\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x3a\x20\x44\x69\x73\x61\x62\x6c\x65\x64\x2e',
        '\x57\x47\x6a\x44\x78',
        '\x59\x79\x69\x44\x70',
        '\x6f\x55\x59\x42\x41',
        '\x4c\x69\x66\x45\x50',
        '\x78\x55\x65\x65\x64',
        '\x43\x4b\x6c\x48\x7a',
        '\x74\x6a\x6e\x4b\x4e',
        '\x5a\x62\x47\x46\x4d',
        '\x6f\x73\x6c\x72\x64',
        '\x44\x6f\x6d\x69\x6e\x61\x6e\x74\x20\x20\x4b\x69\x64\x6e\x61\x70\x20\x20\x41\x42\x44\x4c\x20\x20\x47\x61\x6d\x69\x6e\x67\x20\x20\x4d\x61\x69\x64\x20\x20\x4c\x41\x52\x50\x20\x20\x41\x73\x79\x6c\x75\x6d\x20\x20\x47\x61\x6d\x62\x6c\x69\x6e\x67\x20\x20\x48\x6f\x75\x73\x65\x4d\x61\x69\x65\x73\x74\x61\x73\x20\x20\x48\x6f\x75\x73\x65\x56\x69\x6e\x63\x75\x6c\x61\x20\x20\x48\x6f\x75\x73\x65\x41\x6d\x70\x6c\x65\x63\x74\x6f\x72\x20\x20\x48\x6f\x75\x73\x65\x43\x6f\x72\x70\x6f\x72\x69\x73',
        '\x43\x6f\x6c\x6c\x61\x72\x43\x68\x61\x69\x6e\x4c\x6f\x6e\x67',
        '\u58f0\u540d\u8fdc\u626c\x28\u4fee\u6539\u5404\u7c7b\u58f0\u8a89\x29',
        '\x43\x6f\x6d\x62\x69\x6e\x61\x74\x69\x6f\x6e\x4e\x75\x6d\x62\x65\x72',
        '\x43\x42\x42\x65\x71',
        '\x6f\x42\x41\x79\x42',
        '\x73\x49\x56\x65\x43',
        '\x77\x79\x50\x67\x41',
        '\x6f\x4c\x48\x48\x64',
        '\x31\x36\x32\x33\x38\x39\x4a\x76\x64\x7a\x63\x68',
        '\x5a\x42\x4c\x55\x76',
        '\x63\x6f\x6e\x73\x74\x72\x75\x63\x74\x6f\x72',
        '\x57\x69\x66\x66\x6c\x65\x47\x61\x67',
        '\x71\x66\x52\x7a\x45',
        '\x71\x71\x6a\x45\x44',
        '\x4e\x61\x6d\x65',
        '\x78\x50\x65\x66\x77',
        '\x77\x65\x48\x43\x71',
        '\x53\x4f\x70\x6d\x6a',
        '\x78\x67\x49\x68\x7a',
        '\x4f\x4f\x53\x49\x6f',
        '\x78\x50\x49\x58\x67',
        '\x68\x56\x5a\x43\x7a',
        '\x50\x61\x54\x48\x6a',
        '\x50\x6b\x43\x50\x69',
        '\x61\x77\u9677\u9631\u5c4b\u89c4\u5219\x3a\x31\x2c\u5f53\u623f\u95f4\u88ab\u521b\u5efa\u65f6\x2c\u6211\u4eec\u4f1a\u5f00\u542f\u4e00\u4e2a\x31\x35\u5206\u949f\u7684\u5012\u8ba1\u65f6\x2e\x32\x2c\u5012\u8ba1\u65f6\u7ed3\u675f\u524d\x2c\u6240\u6709\u8fdb\u5165\u7684\u4eba\u90fd\u4f1a\u88ab\u6346\u7684\u6b7b\u6b7b\u7684\x3b\u4efb\u4f55\u5c1d\u8bd5\u8425\u6551\u7684\u4eba\u90fd\u4f1a\u88ab\u623f\u95f4\u5c01\u7981\x2e\x33\x2c\u5012\u8ba1\u65f6\u7ed3\u675f\u540e\x2c\u8fd9\u4e2a\u623f\u95f4\u5c31\u5b89\u5168\u4e86\x2e\u8def\u4eba\u5c31\u53ef\u4ee5\u8425\x28\x77\x61\x6e\x29\u6551\x28\x6e\x6f\x6e\x67\x29\u91cc\u9762\u7684\u5c0f\u53ef\u7231\u4eec\u4e86\u5462\x7e',
        '\x56\x43\x57\x6a\x6d',
        '\x72\x4d\x63\x51\x64',
        '\x49\x74\x65\x6d\x4e\x6f\x73\x65',
        '\x45\x76\x61\x73\x69\x6f\x6e',
        '\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73',
        '\x7a\x44\x4c\x50\x59',
        '\x48\x70\x68\x6e\x76',
        '\x42\x51\x64\x4d\x74',
        '\x55\x48\x6a\x68\x6c',
        '\x76\x67\x68\x51\x4c',
        '\x49\x74\x65\x6d\x42\x6f\x6f\x74\x73',
        '\x4d\x77\x57\x66\x73',
        '\u63d0\u5347\u64ac\u9501\u7b49\u7ea7',
        '\x66\x76\x41\x4c\x72',
        '\x50\x53\x59\x70\x41',
        '\x78\x58\x43\x6a\x63',
        '\x61\x6e\x65\x4b\x4a',
        '\x4a\x6b\x6c\x6d\x4d',
        '\x57\x72\x6f\x74\x4b',
        '\x41\x73\x20\x75\x20\x77\x69\x73\x68\x7e\x28\x4d\x61\x6b\x65\x20\x73\x75\x72\x65\x20\x75\x20\x72\x20\x6e\x6f\x74\x20\x6f\x77\x6e\x65\x72\x2f\x6c\x6f\x76\x65\x72\x20\x6c\x6f\x63\x6b\x65\x64\x20\x26\x20\x68\x61\x76\x65\x20\x70\x65\x72\x6d\x69\x74\x74\x65\x64\x20\x6d\x65\x29',
        '\x50\x58\x78\x65\x5a',
        '\x42\x4f\x54\u81ea\u79f0',
        '\x50\x68\x7a\x41\x65',
        '\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x3a\x20\u968f\u673a\x2e',
        '\x52\x4c\x45\x6e\x63',
        '\x51\x64\x46\x4a\x74',
        '\x59\x5a\x53\x72\x48',
        '\x78\x61\x67\x78\x79',
        '\x79\x54\x6a\x65\x56',
        '\x65\x7a\x79\x45\x4e',
        '\x79\x46\x47\x6d\x63',
        '\u8981\u8bfb\u53d6\u7684\u73a9\u5bb6\u540d\u79f0\x28\u5168\u5c0f\u5199\x29',
        '\x41\x72\x7a\x44\x4a',
        '\x64\x52\x49\x4f\x72',
        '\x62\x43\x51\x50\x45',
        '\u83b7\u53d6\u7bb1\u5b50',
        '\u526a\u5207\u677f\x5f\u7c98\u8d34\u5230\u5f53\u524d\u9009\u62e9\u89d2\u8272',
        '\x77\x70\x6d\x67\x45',
        '\x77\x58\x65\x57\x6b',
        '\x57\x49\x72\x66\x54',
        '\x72\x59\x75\x4d\x65',
        '\x47\x6a\x6f\x46\x56',
        '\x51\x61\x75\x70\x6d',
        '\x53\x52\x7a\x4d\x54',
        '\x72\x65\x74\x75\x72\x6e\x20\x28\x66\x75\x6e\x63\x74\x69\x6f\x6e\x28\x29\x20',
        '\x68\x61\x70\x66\x50',
        '\x69\x54\x72\x6c\x56',
        '\x6d\x59\x67\x70\x67',
        '\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x3a\x20\u7c98\u8d34\x2e',
        '\x7a\x4c\x44\x62\x6f',
        '\x70\x6a\x43\x47\x6e',
        '\x65\x6f\x7a\x79\x51',
        '\x4b\x50\x56\x45\x54',
        '\x59\x6d\x45\x79\x66',
        '\x46\x6c\x4a\x4c\x77',
        '\x55\x61\x74\x59\x65',
        '\x49\x72\x69\x73\x68\x38\x43\x75\x66\x66\x73',
        '\x59\x68\x6f\x70\x6b',
        '\x48\x78\x59\x46\x45',
        '\x61\x77\x42\x4f\x54\x20',
        '\x53\x51\x41\x61\x6b',
        '\x68\x72\x58\x6c\x73',
        '\x50\x72\x6f\x70\x65\x72\x74\x79',
        '\x78\x70\x74\x6a\x72',
        '\x67\x6d\x6c\x4c\x53',
        '\x58\x66\x51\x7a\x6d',
        '\x78\x54\x63\x68\x4b',
        '\x76\x68\x72\x4b\x66',
        '\x6e\x55\x78\x47\x4f',
        '\x4c\x4b\x69\x46\x75',
        '\x62\x56\x62\x73\x5a',
        '\x41\x4d\x56\x61\x52',
        '\x46\x69\x46\x51\x4b',
        '\x64\x74\x66\x52\x69',
        '\x42\x69\x74\x63\x68\x53\x75\x69\x74',
        '\x4b\x6e\x71\x6a\x69',
        '\x6f\x54\x49\x4d\x53',
        '\x49\x74\x65\x6d\x41\x72\x6d\x73',
        '\x73\x58\x4a\x7a\x45',
        '\x4d\x59\x47\x64\x65',
        '\x4c\x4f\x75\x59\x42',
        '\x70\x6c\x61\x79\x73\x75\x69\x74',
        '\x6b\x68\x58\x6b\x57',
        '\x6b\x6a\x74\x5a\x43',
        '\x52\x4f\x41\x56\x58',
        '\x4e\x47\x48\x69\x75',
        '\x6c\x6f\x63\x6b',
        '\x46\x41\x54\x69\x66',
        '\x55\x65\x4c\x53\x78',
        '\x4a\x49\x6a\x67\x42',
        '\x7a\x6d\x73\x53\x4a',
        '\x34\x7c\x32\x7c\x30\x7c\x33\x7c\x31\x7c\x36\x7c\x37\x7c\x35',
        '\x46\x4a\x6b\x75\x53',
        '\x46\x71\x65\x42\x6a',
        '\x73\x69\x78\x54\x56',
        '\x6a\x6c\x41\x4d\x67',
        '\x44\x4e\x57\x43\x65',
        '\x53\x63\x72\x69\x70\x74\x20\x6d\x61\x64\x65\x20\x62\x79\x3a\x61\x77\x61\x71\x77\x71\x5f\x68\x75\x7a\x70\x73\x62',
        '\x42\x52\x4a\x6d\x6d',
        '\x6b\x53\x6d\x74\x6a',
        '\x74\x71\x71\x7a\x41',
        '\x46\x74\x69\x43\x64',
        '\x72\x59\x47\x76\x73',
        '\x6c\x6f\x68\x65\x5a',
        '\x78\x64\x79\x67\x67',
        '\x43\x4e\x66\x52\x63',
        '\x4a\x51\x6d\x56\x77',
        '\u548c\u6211\u7b7e\u8ba2\u5951\u7ea6\uff0c\u6210\u4e3a\u9b54\u6cd5\u5c11\u5973\u5427\uff01',
        '\x37\x7c\x33\x7c\x30\x7c\x32\x7c\x31\x7c\x34\x7c\x38\x7c\x35\x7c\x36',
        '\x6b\x79\x68\x44\x6c',
        '\x42\x43\x58\x4d\x73\x67',
        '\x50\x54\x6d\x41\x79',
        '\x4f\x5a\x72\x68\x68',
        '\x67\x6a\x61\x79\x73',
        '\x42\x4f\x54\u6307\u4ee4\u8bcd',
        '\x67\x57\x47\x42\x77',
        '\x63\x6b\x76\x64\x45',
        '\x6e\x7a\x49\x48\x70',
        '\x41\x77\x67\x5a\x47',
        '\x43\x68\x61\x74\x52\x6f\x6f\x6d\x4d\x65\x73\x73\x61\x67\x65',
        '\x59\x4b\x77\x41\x57',
        '\x68\x69\x45\x76\x63',
        '\x69\x79\x7a\x45\x48',
        '\x45\x46\x67\x65\x4d',
        '\x79\x72\x79\x45\x41',
        '\x35\x35\x30\x32\x35\x36\x34\x78\x75\x5a\x54\x52\x74',
        '\x62\x4f\x7a\x52\x4b',
        '\x4f\x4c\x43\x73\x48',
        '\x52\x50\x4b\x51\x46',
        '\u901f\u901f\u7ed1\u7f1a\x28\u641e\u4e8b\u60c5\u4e13\u7528\x29',
        '\x49\x74\x65\x6d\x4e\x69\x70\x70\x6c\x65\x73\x50\x69\x65\x72\x63\x69\x6e\x67\x73',
        '\x5a\x6a\x69\x6a\x44',
        '\x54\x52\x47\x6a\x70',
        '\x61\x48\x69\x79\x6e',
        '\x64\x66\x6f\x71\x4b',
        '\x6a\x75\x47\x6d\x5a',
        '\x68\x4e\x71\x4f\x52',
        '\x78\x5a\x41\x72\x61',
        '\x5a\x6e\x59\x48\x54',
        '\u5c01\u7981\u5931\u8d25\x3a\u73a9\u5bb6\u5df2\u7ecf\u88ab\u5c01\u7981',
        '\x59\x71\x61\x50\x69',
        '\x66\x78\x4c\x46\x56',
        '\x4b\x71\x44\x70\x71',
        '\x67\x74\x71\x50\x45',
        '\x4b\x47\x50\x47\x44',
        '\x71\x75\x43\x6a\x4b',
        '\x38\x36\x32\x30\x37\x32\x69\x74\x73\x45\x6c\x6d',
        '\x44\x52\x79\x59\x6a',
        '\x62\x49\x68\x43\x69',
        '\x67\x52\x6f\x79\x62',
        '\x72\x44\x57\x77\x62',
        '\x63\x4a\x50\x53\x58',
        '\x4f\x6b\x4b\x6e\x59',
        '\x52\x43\x61\x6e\x6f',
        '\x4f\x65\x4c\x72\x56',
        '\x23\x32\x30\x32\x30\x32\x30',
        '\x65\x78\x49\x47\x73',
        '\u63d0\u5347\u7740\u88c5\u7b49\u7ea7',
        '\u53e3\u7403\x6c\x76',
        '\x42\x4f\x4a\x6c\x73',
        '\x6e\x50\x74\x51\x51',
        '\x51\x5a\x73\x56\x48',
        '\x72\x56\x4d\x41\x79',
        '\x61\x41\x63\x6b\x79',
        '\x63\x41\x4f\x41\x70',
        '\x64\x4a\x55\x48\x61',
        '\x70\x5a\x78\x70\x6d',
        '\x49\x74\x65\x6d\x42\x75\x74\x74',
        '\x43\x47\x51\x7a\x4f',
        '\x44\x67\x4f\x43\x47',
        '\x49\x74\x65\x6d\x4e\x69\x70\x70\x6c\x65\x73',
        '\x69\x47\x53\x79\x56',
        '\x6e\x72\x69\x66\x65',
        '\x50\x4c\x4f\x4e\x44',
        '\x61\x77\x42\x4f\x54\x5f\u5207\u6362\u9677\u9631\u5c4b\u6a21\u5f0f',
        '\x4e\x71\x73\x73\x4b',
        '\x68\x56\x79\x42\x62',
        '\x4d\x48\x71\x51\x42',
        '\x49\x4d\x51\x61\x59',
        '\x48\x52\x51\x5a\x59',
        '\x48\x52\x65\x45\x6d',
        '\x61\x6d\x69\x6c\x48',
        '\x46\x4b\x6f\x6b\x51',
        '\x54\x79\x65\x68\x67',
        '\x42\x61\x6e',
        '\x69\x49\x5a\x46\x62',
        '\x49\x74\x65\x6d\x48\x65\x61\x64',
        '\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x3a\x20\x52\x65\x61\x64\x79\x2e',
        '\x41\x75\x52\x45\x51',
        '\x27\u548c\u6307\u4ee4\uff0c\u6307\u4ee4\u5c31\u4f1a\u88ab\u6267\u884c\x7e',
        '\x58\x42\x5a\x71\x74',
        '\x61\x77\x42\x4f\x54\x5f\u5f00\u5173\u9677\u9631\u5c4b',
        '\x45\x79\x5a\x65\x67',
        '\x49\x6e\x66\x69\x6c\x74\x72\x61\x74\x69\x6f\x6e',
        '\x42\x67\x42\x42\x77',
        '\x6c\x68\x76\x6d\x58',
        '\x68\x46\x6a\x61\x52',
        '\x72\x71\x4a\x77\x51',
        '\x75\x7a\x44\x4e\x6b',
        '\x43\x68\x61\x74\x52\x6f\x6f\x6d\x41\x64\x6d\x69\x6e',
        '\u5e7b\u5f71\u79fb\u5f62\x28\u80fd\u7ed9\u522b\u4eba\u5f00\u9501\x29',
        '\x79\x46\x47\x48\x56',
        '\x72\x66\x71\x52\x4e',
        '\x45\x68\x6e\x50\x45',
        '\x61\x77\x42\x4f\x54\x5f\u5207\u6362\u9677\u9631\u5c4b\u8bed\u8a00',
        '\x41\x70\x70\x65\x61\x72\x61\x6e\x63\x65',
        '\x42\x67\x48\x74\x63',
        '\x63\x70\x51\x4e\x72',
        '\u8981\u89e3\u9501\u7684\u73a9\u5bb6\u540d\u79f0\x28\u5168\u5c0f\u5199\x29',
        '\x6a\x77\x6e\x41\x47',
        '\x41\x67\x57\x4e\x4e',
        '\x74\x72\x73\x79\x49',
        '\x56\x77\x50\x70\x4a',
        '\x73\x6b\x7a\x44\x55',
        '\x74\x6f\x51\x70\x4b',
        '\x66\x42\x63\x6e\x56',
        '\x44\x64\x72\x4e\x69',
        '\x4e\x71\x76\x4e\x7a',
        '\x77\x4c\x44\x76\x54',
        '\x47\x6c\x49\x47\x4b',
        '\x5a\x41\x42\x65\x71',
        '\u5982\u4f60\u6240\u613f\x20\x28\u5e38\u89c1\u95ee\u9898\x3a\u4e0d\u89e3\u4e3b\u4eba\x2f\u604b\u4eba\x2c\u8bf7\u5f00\u6743\u9650\x29\x7e',
        '\x73\x70\x6c\x69\x63\x65',
        '\x43\x54\x70\x59\x41',
        '\x61\x52\x6d\x62\x6c',
        '\x75\x7a\x48\x76\x4b',
        '\x56\x50\x43\x66\x62',
        '\x41\x77\x71',
        '\x77\x78\x52\x54\x47',
        '\x58\x49\x73\x42\x57',
        '\x6d\x47\x4f\x43\x62',
        '\x6c\x66\x6a\x6b\x75',
        '\x78\x6b\x67\x72\x61',
        '\x79\x66\x61\x71\x6a',
        '\x74\x6a\x7a\x76\x76',
        '\x73\x67\x50\x4b\x63',
        '\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x4f\x6e',
        '\x41\x63\x74\x69\x6f\x6e\x52\x65\x6d\x6f\x76\x65',
        '\x4e\x45\x54\x61\x4e',
        '\x6a\x6d\x45\x4c\x78',
        '\x41\x63\x74\x69\x6f\x6e',
        '\x4f\x74\x4e\x4f\x4c',
        '\x68\x46\x79\x65\x6c',
        '\x63\x66\x6e\x76\x4d',
        '\x6a\x4d\x68\x76\x6d',
        '\x65\x64\x53\x53\x4d',
        '\u7b11\x7e\x20\x28\u5e38\u89c1\u95ee\u9898\x3a\u8bf7\u5f00\u6743\u9650\x29\x7e',
        '\x67\x58\x61\x64\x6e',
        '\x35\x34\x31\x38\x79\x43\x71\x4b\x67\x61',
        '\x53\x66\x51\x68\x6a',
        '\x4b\x5a\x57\x46\x73',
        '\x57\x67\x61\x45\x46',
        '\x76\x41\x71\x79\x43',
        '\x72\x7a\x42\x4a\x65',
        '\x57\x63\x62\x4d\x6c',
        '\x5a\x54\x6d\x56\x73',
        '\x76\x7a\x41\x70\x59',
        '\x64\x79\x65\x42\x42',
        '\x58\x52\x43\x48\x58',
        '\x73\x57\x67\x66\x43',
        '\x33\x33\x32\x38\x30\x6a\x64\x65\x4e\x47\x71',
        '\x7a\x65\x67\x48\x6c',
        '\u672a\u77e5\u6307\u4ee4\uff01\x20\u53ef\u7528\u6307\u4ee4\x3a\x20\u6346\u6211\x20\u6346\u6b7b\u6211\x20\u8214\u6211\x20\u6551\u6211\x20\u73a9\u6211\x20\u9501\u6211\x20\u5173\u4e8e\x20\u5982\u679c\u4e00\u53e5\u8bdd\u540c\u65f6\u5305\u542b\x27',
        '\x4b\x78\x71\x70\x52',
        '\x58\x69\x53\x45\x73',
        '\x49\x74\x65\x6d\x50\x65\x6c\x76\x69\x73',
        '\x36\x7c\x31\x7c\x34\x7c\x32\x7c\x30\x7c\x33\x7c\x37\x7c\x35',
        '\x4a\x78\x53\x6c\x54',
        '\x73\x4c\x53\x56\x6d',
        '\x6a\x6b\x4e\x64\x77',
        '\x78\x6f\x4d\x52\x58',
        '\x6d\x65\x6f\x77\x7e\x28\x4d\x61\x6b\x65\x20\x73\x75\x72\x65\x20\x75\x20\x68\x61\x76\x65\x20\x70\x65\x72\x6d\x69\x74\x74\x65\x64\x20\x6d\x65\x29',
        '\x50\x64\x77\x74\x78',
        '\x55\x6d\x4b\x64\x5a',
        '\x4b\x41\x6a\x73\x68',
        '\x78\x42\x56\x79\x73',
        '\x4d\x70\x78\x42\x54',
        '\u529b\u5927\u65e0\u7a77\x28\u77ac\u95f4\u6323\u8131\x29',
        '\x74\x4f\x56\x65\x72',
        '\x6e\x65\x73\x52\x6b',
        '\x57\x6d\x4a\x6f\x65',
        '\x49\x74\x65\x6d\x42\x72\x65\x61\x73\x74',
        '\x67\x51\x6b\x4e\x6d',
        '\x4e\x77\x41\x76\x65',
        '\x61\x6e\x71\x47\x69',
        '\x73\x4d\x6d\x4b\x57',
        '\x65\x69\x4d\x63\x4d',
        '\x64\x74\x44\x74\x46',
        '\x74\x52\x50\x52\x6c',
        '\x7a\x79\x6f\x6b\x79',
        '\x58\x46\x7a\x67\x5a',
        '\x4a\x6f\x54\x7a\x48',
        '\x63\x6f\x6e\x73\x6f\x6c\x65',
        '\x63\x6b\x51\x46\x43',
        '\x4e\x63\x4d\x61\x6f',
        '\x61\x77\x42\x4f\x54\x5f\u5c01\u7981',
        '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68',
        '\x4f\x47\x47\x6d\x74',
        '\x76\x62\x4e\x53\x65',
        '\x68\x65\x6c\x6c\x6f',
        '\x62\x65\x53\x72\x4f',
        '\x51\x48\x71\x66\x44',
        '\u4f60\u8981\u8bf4\u7684\u8bdd',
        '\x49\x74\x65\x6d\x48\x61\x6e\x64\x73',
        '\x64\x79\x56\x4b\x56',
        '\x47\x44\x4e\x48\x46',
        '\x68\x66\x54\x54\x54',
        '\x71\x6f\x63\x66\x51',
        '\x74\x72\x61\x63\x65',
        '\x77\x61\x52\x41\x50',
        '\x63\x43\x70\x47\x59',
        '\x48\x54\x61\x41\x77',
        '\x66\x6f\x59\x6f\x73',
        '\x41\x73\x73\x65\x74',
        '\x66\x6b\x6a\x51\x65',
        '\x6a\x58\x65\x77\x4c',
        '\x72\x61\x6e\x64\x6f\x6d',
        '\x61\x77\x42\x4f\x54',
        '\x6a\x62\x6a\x68\x43',
        '\x69\x6e\x64\x65\x78\x4f\x66',
        '\x4b\x64\x53\x73\x76',
        '\x48\x69\x64\x64\x65\x6e',
        '\u63d0\u5347\u6346\u7ed1\u7b49\u7ea7',
        '\x78\x65\x4a\x76\x58',
        '\x45\x43\x4a\x7a\x63',
        '\x70\x64\x6e\x4b\x57',
        '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68\x32',
        '\x58\x72\x65\x77\x41',
        '\x6e\x62\x4c\x49\x6c',
        '\x4d\x4b\x46\x51\x57',
        '\x62\x41\x54\x43\x61',
        '\x61\x55\x51\x53\x6d',
        '\x52\x4c\x54\x6c\x4c',
        '\x6f\x66\x66',
        '\x4b\x78\x43\x42\x45',
        '\x69\x42\x54\x4d\x63',
        '\x55\x78\x74\x50\x61',
        '\x7a\x5a\x69\x75\x65',
        '\x57\x4f\x4c\x59\x6b',
        '\x79\x48\x6a\x75\x44',
        '\x73\x73\x63\x7a\x72',
        '\x71\x6c\x53\x64\x64',
        '\x46\x65\x50\x61\x59',
        '\x54\x53\x76\x44\x4d',
        '\x42\x78\x47\x68\x5a',
        '\x53\x47\x54\x4a\x6c',
        '\x4a\x78\x43\x54\x6d',
        '\x59\x56\x52\x50\x50',
        '\x4a\x65\x70\x67\x51',
        '\x4c\x65\x61\x74\x68\x65\x72\x41\x72\x6d\x62\x69\x6e\x64\x65\x72',
        '\x65\x78\x63\x65\x70\x74\x69\x6f\x6e',
        '\x4b\x79\x6e\x6d\x4b',
        '\x66\x51\x6c\x58\x5a',
        '\x62\x6f\x6e\x64\x61\x67\x65',
        '\x4e\x45\x48\x6e\x70',
        '\x50\x5a\x4f\x6a\x67',
        '\x57\x64\x42\x65\x74',
        '\x50\x73\x47\x68\x52',
        '\x70\x62\x64\x6a\x50',
        '\x55\x6f\x50\x78\x45',
        '\x61\x77\x42\x4f\x54\x20\x43\x61\x53\x65\x20\x53\x65\x4e\x73\x49\x74\x49\x76\x45\x21',
        '\x6c\x69\x63\x6b\x73\x20',
        '\x59\x74\x78\x7a\x54',
        '\x67\x7a\x4e\x69\x79',
        '\x75\x70\x71\x7a\x44',
        '\x77\x67\x66\x6d\x77',
        '\x41\x63\x74\x69\x6f\x6e\x55\x6e\x6c\x6f\x63\x6b\x41\x6e\x64\x52\x65\x6d\x6f\x76\x65',
        '\x4d\x69\x73\x74\x72\x65\x73\x73\x50\x61\x64\x6c\x6f\x63\x6b',
        '\x50\x61\x6e\x64\x6f\x72\x61\x50\x61\x64\x6c\x6f\x63\x6b',
        '\x6d\x48\x69\x4b\x72',
        '\x67\x51\x48\x6c\x7a',
        '\x64\x6e\x56\x44\x52',
        '\x53\x55\x45\x4b\x68',
        '\x54\x49\x73\x66\x67',
        '\x56\x66\x53\x70\x41',
        '\x51\x43\x6c\x68\x71',
        '\x66\x70\x73\x5a\x4f',
        '\x4c\x4d\x4a\x6e\x63',
        '\x51\x75\x55\x6a\x61',
        '\x4d\x61\x69\x6e\x48\x61\x6c\x6c',
        '\u95e8\u94a5\u5319',
        '\x61\x56\x4e\x41\x72',
        '\x44\x69\x66\x66\x69\x63\x75\x6c\x74\x79',
        '\x51\x79\x50\x75\x66',
        '\x44\x6b\x42\x4d\x58',
        '\x6a\x68\x4f\x59\x75',
        '\x7a\x47\x6a\x69\x50',
        '\x69\x79\x70\x72\x4a',
        '\x45\x46\x4e\x44\x7a',
        '\x54\x79\x70\x65',
        '\x53\x6f\x4d\x63\x65',
        '\x62\x42\x4b\x74\x71',
        '\u8981\u4e0a\u9501\u7684\u73a9\u5bb6\u540d\u79f0\x28\u5168\u5c0f\u5199\x29',
        '\x52\x79\x48\x62\x6a',
        '\x6e\x74\x58\x6d\x43',
        '\x78\x57\x41\x44\x72',
        '\x58\x53\x47\x4b\x58',
        '\x6e\x77\x6d\x76\x59',
        '\x4e\x58\x6f\x51\x72',
        '\x63\x45\x51\x68\x50',
        '\x6a\x68\x4a\x56\x4f',
        '\x54\x77\x71\x79\x4b',
        '\x48\x45\x6e\x66\x4f',
        '\x6c\x53\x48\x49\x73',
        '\x44\x42\x52\x79\x59',
        '\x6a\x6f\x61\x41\x4c',
        '\x73\x48\x51\x64\x4b',
        '\x4b\x6d\x6c\x71\x64',
        '\x4f\x64\x56\x7a\x54',
        '\u8981\u5c01\u7981\u7684\u73a9\u5bb6\u540d\u79f0',
        '\x44\x77\x64\x65\x62',
        '\x6f\x51\x69\x4c\x68',
        '\x79\x73\x4a\x79\x65',
        '\x68\x45\x5a\x76\x58',
        '\x71\x4c\x55\x61\x67',
        '\x4a\x52\x55\x6c\x4c',
        '\u63d0\u5347\u6323\u624e\u7b49\u7ea7',
        '\x52\x70\x44\x4a\x74',
        '\x42\x53\x59\x59\x6a',
        '\x54\x43\x71\x6d\x46',
        '\x6c\x58\x68\x63\x46',
        '\x4a\x6b\x51\x45\x55',
        '\x77\x4c\x6f\x53\x6d',
        '\x63\x53\x50\x61\x56',
        '\x4d\x78\x76\x45\x50',
        '\x78\x4c\x6a\x65\x62',
        '\x54\x69\x62\x45\x79',
        '\u5982\u4f60\u6240\u613f\x20\x28\u5e38\u89c1\u95ee\u9898\x3a\u8bf7\u5f00\u6743\u9650\x29\x7e',
        '\x43\x53\x76\x6b\x54',
        '\x69\x53\x44\x58\x57',
        '\x6e\x64\x6e\x71\x6d',
        '\x49\x74\x65\x6d\x46\x65\x65\x74',
        '\x6d\x66\x4c\x47\x69',
        '\x73\x70\x6c\x69\x74',
        '\x44\x48\x63\x6a\x66',
        '\x6f\x49\x45\x74\x41',
        '\x66\x57\x74\x42\x74',
        '\x53\x77\x57\x53\x59',
        '\u5c01\u7981\u5931\u8d25\x3a\u73a9\u5bb6\u6ca1\u6709\u88ab\u5c01\u7981',
        '\x58\x71\x45\x6a\x4d',
        '\x54\x50\x72\x4d\x6e',
        '\x75\x74\x4a\x7a\x5a',
        '\x76\x42\x6f\x4f\x66',
        '\x70\x79\x6a\x6d\x52',
        '\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x5a\x68',
        '\x4b\x7a\x78\x70\x64',
        '\x74\x74\x79\x78\x4b',
        '\x4b\x41\x79\x4b\x43',
        '\x55\x53\x6a\x79\x46',
        '\x41\x73\x20\x75\x20\x77\x69\x73\x68\x7e\x28\x4d\x61\x6b\x65\x20\x73\x75\x72\x65\x20\x75\x20\x68\x61\x76\x65\x20\x70\x65\x72\x6d\x69\x74\x74\x65\x64\x20\x6d\x65\x29',
        '\x4f\x6e\x6c\x69\x6e\x65',
        '\x7a\x5a\x43\x65\x53',
        '\x66\x4a\x61\x6e\x67',
        '\x62\x69\x6e\x64',
        '\x49\x74\x65\x6d\x44\x65\x76\x69\x63\x65\x73',
        '\x78\x77\x79\x78\x51',
        '\x45\x75\x4e\x45\x77',
        '\x4d\x59\x44\x4c\x54',
        '\x5a\x51\x54\x63\x44',
        '\x33\x32\x72\x58\x4e\x6c\x69\x4a',
        '\x6c\x69\x63\x6b',
        '\x64\x50\x78\x64\x6f',
        '\x61\x77\x61\x71\x77\x71',
        '\x52\x54\x57\x74\x6d',
        '\x55\x6b\x7a\x72\x6b',
        '\x7a\x53\x74\x73\x6b',
        '\x41\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x2d\x77\x6f\x72\x64\x73\x3a\x72\x65\x6c\x65\x61\x73\x65\x2c\x62\x6f\x6e\x64\x61\x67\x65\x2c\x70\x6c\x61\x79\x73\x75\x69\x74\x2c\x6c\x6f\x63\x6b\x2c\x61\x62\x6f\x75\x74\x2c\x6c\x69\x63\x6b\x2c\x72\x61\x6e\x64\x6f\x6d\x2c\x62\x61\x6e\x6d\x65\x28\x74\x6f\x20\x67\x65\x74\x20\x73\x74\x75\x63\x6b\x2c\x75\x73\x65\x20\x74\x68\x69\x73\x20\x61\x66\x74\x65\x72\x20\x72\x61\x6e\x64\x6f\x6d\x20\x61\x6e\x64\x20\x6c\x6f\x63\x6b\x2e\x29\x2e\x49\x66\x20\x61\x20\x73\x65\x6e\x74\x65\x6e\x63\x65\x20\x69\x6e\x63\x6c\x75\x64\x69\x6e\x67\x20\x27\x61\x77\x71\x27\x20\x68\x61\x73\x20\x61\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x2d\x77\x6f\x72\x64\x20\x61\x74\x20\x74\x68\x65\x20\x73\x61\x6d\x65\x20\x74\x69\x6d\x65\x2c\x20\x74\x68\x65\x6e\x20\x74\x68\x65\x20\x63\x6f\x72\x72\x65\x73\x70\x6f\x6e\x64\x69\x6e\x67\x20\x61\x63\x74\x69\x6f\x6e\x20\x77\x69\x6c\x6c\x20\x62\x65\x20\x74\x61\x6b\x65\x6e\x2e',
        '\x50\x61\x64\x64\x65\x64\x4d\x69\x74\x74\x65\x6e\x73',
        '\x4b\x44\x6d\x64\x78',
        '\x58\x6c\x4b\x44\x4b',
        '\x41\x62\x4e\x6c\x73',
        '\x62\x4c\x4f\x66\x79',
        '\x47\x6d\x51\x56\x6f',
        '\x59\x50\x53\x62\x73',
        '\x70\x70\x64\x74\x4f',
        '\x6d\x6a\x42\x78\x59',
        '\x65\x6b\x75\x41\x4d',
        '\x36\x35\x30\x39\x37\x39\x66\x6b\x49\x69\x52\x48',
        '\x49\x74\x65\x6d\x4d\x69\x73\x63',
        '\x78\x52\x43\x79\x6f',
        '\x50\x72\x6f\x67\x72\x65\x73\x73',
        '\x42\x51\x48\x50\x4a',
        '\x64\x41\x41\x67\x70',
        '\x69\x6e\x66\x6f',
        '\x66\x73\x6d\x6e\x61',
        '\x55\x49\x61\x67\x52',
        '\x7a\x73\x72\x63\x72',
        '\x43\x4f\x42\x66\x47',
        '\x62\x5a\x59\x6b\x59',
        '\x44\x72\x65\x73\x73\x61\x67\x65',
        '\x67\x65\x46\x5a\x4d',
        '\x79\x50\x5a\x68\x44',
        '\x45\x66\x66\x65\x63\x74',
        '\x49\x74\x65\x6d\x4e\x65\x63\x6b\x52\x65\x73\x74\x72\x61\x69\x6e\x74\x73',
        '\x4f\x6e\x44\x50\x67',
        '\x34\x7c\x33\x7c\x31\x7c\x30\x7c\x35\x7c\x32',
        '\x65\x62\x6d\x78\x42',
        '\x47\x47\x72\x72\x49',
        '\x41\x77\x50\x61\x73\x74\x65',
        '\x73\x65\x55\x64\x6e',
        '\x49\x62\x72\x59\x45',
        '\x65\x59\x7a\x7a\x73',
        '\x6e\x4d\x48\x69\x50',
        '\x45\x54\x56\x67\x55',
        '\x43\x68\x61\x74',
        '\x45\x68\x41\x56\x64',
        '\x57\x62\x51\x4d\x6a',
        '\x6b\x58\x47\x50\x67',
        '\x74\x67\x48\x49\x69',
        '\x43\x6f\x6e\x74\x65\x6e\x74',
        '\x6d\x50\x61\x54\x44',
        '\x6e\x5a\x47\x65\x6e',
        '\x6e\x63\x58\x4f\x4c',
        '\x6b\x5a\x54\x6a\x79',
        '\x55\x48\x67\x4d\x6a',
        '\x53\x59\x72\x44\x51',
        '\x53\x57\x6f\x4b\x56',
        '\x43\x68\x61\x74\x52\x6f\x6f\x6d\x43\x68\x61\x74',
        '\x42\x42\x78\x58\x76',
        '\x6a\x4f\x47\x66\x73',
        '\x69\x57\x79\x57\x47',
        '\x49\x71\x50\x4a\x6d',
        '\x71\x72\x49\x73\x62',
        '\x4c\x6f\x63\x6b\x4d\x65\x6d\x62\x65\x72\x4e\x75\x6d\x62\x65\x72',
        '\x62\x62\x41\x4b\x4b',
        '\x75\x66\x50\x61\x65',
        '\x7a\x4a\x62\x46\x48',
        '\x6e\x4a\x78\x6c\x6c',
        '\x57\x51\x6e\x63\x44',
        '\x65\x47\x6b\x6a\x49',
        '\x59\x54\x6b\x51\x7a',
        '\x76\x75\x45\x56\x6c',
        '\x66\x6f\x72\x45\x61\x63\x68',
        '\x56\x6b\x6b\x4a\x46',
        '\x62\x44\x73\x4d\x64',
        '\x70\x4d\x4e\x72\x67'
    ];
    _0x93e8 = function () {
        return _0x492861;
    };
    return _0x93e8();
}