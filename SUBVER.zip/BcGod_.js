// ==UserScript==
// @name BcGod_
// @description BC RP模式增强~
// @version 1.07r
// @namespace awaqwq_huzpsb
// @match *://*/*BondageClub*
// @grant GM_registerMenuCommand
// ==/UserScript==
(function (_0x433e98, _0x252e4e) {
    const _0x1a7803 = _0x5e23, _0x169da6 = _0x433e98();
    while (!![]) {
        try {
            const _0x33f6f2 = -parseInt(_0x1a7803(0x42a)) / (-0xeb + -0xcc1 + 0x9 * 0x185) * (parseInt(_0x1a7803(0x2ea)) / (-0x1c99 * -0x1 + -0x5f6 + 0x3 * -0x78b)) + -parseInt(_0x1a7803(0x26a)) / (-0x114b * -0x1 + -0xf1b + 0x22d * -0x1) * (parseInt(_0x1a7803(0x29e)) / (0x16dc + -0x3 * 0x115 + 0x1d * -0xad)) + parseInt(_0x1a7803(0x423)) / (0x3d * 0x1f + 0x115a + -0x18b8) + -parseInt(_0x1a7803(0x446)) / (-0x892 * -0x2 + 0x17 * -0x178 + 0x10aa) * (-parseInt(_0x1a7803(0x37c)) / (-0xcfc + 0x1 * 0x19f7 + -0x2 * 0x67a)) + -parseInt(_0x1a7803(0x1f9)) / (-0x27 * -0x18 + -0x95 * -0x2a + -0x1c12) * (parseInt(_0x1a7803(0x2ee)) / (0x23d1 + -0x1356 + -0x1072)) + parseInt(_0x1a7803(0x41e)) / (-0x2358 + -0x196a * 0x1 + 0x3ccc) * (-parseInt(_0x1a7803(0x3b3)) / (-0x1eb8 + -0x3 * 0x257 + -0xc98 * -0x3)) + parseInt(_0x1a7803(0x231)) / (-0x1ee9 + 0x4f * 0x1f + -0xab2 * -0x2);
            if (_0x33f6f2 === _0x252e4e)
                break;
            else
                _0x169da6['push'](_0x169da6['shift']());
        } catch (_0x3030db) {
            _0x169da6['push'](_0x169da6['shift']());
        }
    }
}(_0x4064, -0x1e302 + -0x9e611 + -0x7 * -0x2a644), (function () {
    const _0x4466f9 = _0x5e23, _0x1cf7bb = {
            '\x64\x6e\x65\x75\x57': function (_0x1ae231, _0x57ea8d, _0x568b85) {
                return _0x1ae231(_0x57ea8d, _0x568b85);
            },
            '\x48\x73\x65\x78\x47': function (_0x24ffad, _0x471176) {
                return _0x24ffad == _0x471176;
            },
            '\x59\x6a\x44\x68\x46': function (_0x5021e9, _0x4cc741) {
                return _0x5021e9(_0x4cc741);
            },
            '\x64\x78\x78\x4b\x79': _0x4466f9(0x25c),
            '\x78\x72\x6a\x6b\x54': function (_0x8a0676, _0x3651d3, _0x1270d6) {
                return _0x8a0676(_0x3651d3, _0x1270d6);
            },
            '\x44\x47\x56\x70\x76': function (_0x44b4db, _0x5b33fb) {
                return _0x44b4db > _0x5b33fb;
            },
            '\x61\x48\x74\x59\x43': function (_0x4ae43c, _0x37d01b) {
                return _0x4ae43c + _0x37d01b;
            },
            '\x61\x69\x4e\x4c\x66': _0x4466f9(0x252),
            '\x43\x56\x47\x6e\x73': _0x4466f9(0x274),
            '\x78\x58\x66\x6e\x74': function (_0x4e86c9, _0x4bdad1) {
                return _0x4e86c9 !== _0x4bdad1;
            },
            '\x6b\x4e\x5a\x63\x54': _0x4466f9(0x436),
            '\x54\x49\x54\x4a\x41': _0x4466f9(0x27c),
            '\x6a\x78\x67\x68\x5a': function (_0x51a233, _0xb6f4ad) {
                return _0x51a233 + _0xb6f4ad;
            },
            '\x70\x65\x77\x56\x69': '\x72\x65\x74\x75\x72\x6e\x20\x28\x66\x75\x6e\x63\x74\x69\x6f\x6e\x28\x29\x20',
            '\x4a\x62\x48\x7a\x6b': _0x4466f9(0x2a8),
            '\x79\x4e\x6c\x69\x4d': function (_0x49a844, _0x2a48c8) {
                return _0x49a844 === _0x2a48c8;
            },
            '\x71\x54\x4e\x6d\x6f': _0x4466f9(0x1ff),
            '\x59\x58\x4e\x6c\x41': _0x4466f9(0x260),
            '\x42\x7a\x64\x73\x49': _0x4466f9(0x2d2),
            '\x56\x6f\x58\x64\x62': _0x4466f9(0x3e1),
            '\x56\x44\x62\x74\x54': _0x4466f9(0x3e2),
            '\x4c\x63\x4d\x67\x45': _0x4466f9(0x328),
            '\x62\x63\x75\x44\x4d': _0x4466f9(0x259),
            '\x71\x66\x66\x54\x51': '\x74\x72\x61\x63\x65',
            '\x6b\x68\x64\x64\x4c': function (_0x3e66b7, _0x1940ad) {
                return _0x3e66b7 < _0x1940ad;
            },
            '\x62\x79\x44\x59\x4a': _0x4466f9(0x394),
            '\x47\x62\x6f\x41\x57': '\x44\x72\x65\x73\x73\x61\x67\x65',
            '\x56\x76\x45\x41\x75': _0x4466f9(0x318),
            '\x69\x74\x66\x6a\x5a': _0x4466f9(0x36d),
            '\x4e\x59\x6c\x77\x55': '\x52\x6d\x78\x72\x6d',
            '\x57\x4d\x67\x41\x4a': _0x4466f9(0x373),
            '\x67\x6d\x6d\x4c\x49': '\x4c\x6f\x63\x6b',
            '\x41\x4b\x79\x6f\x58': _0x4466f9(0x2f8),
            '\x70\x4c\x71\x61\x5a': '\x66\x73\x6d\x68\x66',
            '\x74\x55\x4f\x4c\x77': _0x4466f9(0x411),
            '\x71\x79\x59\x42\x70': _0x4466f9(0x2c1),
            '\x53\x52\x53\x4f\x79': _0x4466f9(0x208),
            '\x77\x41\x56\x53\x4c': _0x4466f9(0x368),
            '\x57\x4b\x79\x67\x69': _0x4466f9(0x29c),
            '\x70\x45\x6f\x7a\x6d': _0x4466f9(0x464),
            '\x66\x4c\x4e\x6f\x42': _0x4466f9(0x3cf),
            '\x41\x74\x48\x46\x5a': '\x42\x6f\x75\x6e\x74\x79\x53\x75\x69\x74\x63\x61\x73\x65',
            '\x45\x45\x68\x61\x49': _0x4466f9(0x294),
            '\x78\x74\x69\x6a\x54': function (_0x31a1b2, _0x13eb46) {
                return _0x31a1b2 !== _0x13eb46;
            },
            '\x53\x78\x76\x6a\x62': _0x4466f9(0x2c8),
            '\x75\x4b\x74\x68\x55': function (_0x5cdd10, _0x371df2) {
                return _0x5cdd10 < _0x371df2;
            },
            '\x73\x46\x41\x78\x53': function (_0x598323, _0xdd15d7) {
                return _0x598323 > _0xdd15d7;
            },
            '\x70\x4c\x69\x6a\x54': _0x4466f9(0x3fd),
            '\x48\x6e\x6f\x55\x47': _0x4466f9(0x238),
            '\x4b\x49\x63\x51\x46': _0x4466f9(0x2b4),
            '\x70\x66\x74\x47\x6d': function (_0x117cb6, _0x312da9) {
                return _0x117cb6 != _0x312da9;
            },
            '\x68\x58\x78\x46\x51': '\x32\x7c\x33\x7c\x30\x7c\x34\x7c\x31',
            '\x77\x7a\x66\x6c\x54': function (_0x30fdf6, _0x4b5daa, _0x54a1e5, _0x3cc6e9, _0x2c1364, _0x3e0282) {
                return _0x30fdf6(_0x4b5daa, _0x54a1e5, _0x3cc6e9, _0x2c1364, _0x3e0282);
            },
            '\x4f\x75\x53\x42\x48': _0x4466f9(0x270),
            '\x4e\x4a\x73\x51\x43': '\x6c\x69\x63\x6b\x73\x20',
            '\x75\x54\x48\x6d\x58': _0x4466f9(0x455),
            '\x42\x66\x50\x57\x74': '\u7b11\x7e\x20\x28\u5e38\u89c1\u95ee\u9898\x3a\u8bf7\u5f00\u6743\u9650\x29\x7e',
            '\x4a\x77\x71\x78\x55': _0x4466f9(0x215),
            '\x48\x55\x74\x50\x6e': _0x4466f9(0x34b),
            '\x78\x6a\x6b\x52\x72': _0x4466f9(0x2ba),
            '\x63\x74\x47\x77\x63': _0x4466f9(0x410),
            '\x4f\x58\x48\x66\x79': _0x4466f9(0x414),
            '\x58\x6a\x4d\x4b\x58': '\x49\x74\x65\x6d\x45\x61\x72\x73',
            '\x46\x75\x68\x65\x7a': _0x4466f9(0x387),
            '\x4f\x64\x6d\x46\x4a': _0x4466f9(0x290),
            '\x49\x70\x49\x49\x64': _0x4466f9(0x25a),
            '\x49\x42\x6c\x5a\x62': '\x49\x74\x65\x6d\x4e\x65\x63\x6b\x41\x63\x63\x65\x73\x73\x6f\x72\x69\x65\x73',
            '\x70\x45\x48\x55\x74': _0x4466f9(0x254),
            '\x4e\x6c\x6a\x70\x66': _0x4466f9(0x458),
            '\x6c\x76\x44\x6d\x70': _0x4466f9(0x415),
            '\x6f\x56\x6a\x42\x4b': _0x4466f9(0x2f9),
            '\x43\x45\x64\x63\x68': _0x4466f9(0x2f0),
            '\x49\x4f\x73\x70\x73': _0x4466f9(0x385),
            '\x7a\x68\x62\x6f\x57': _0x4466f9(0x1ec),
            '\x49\x6f\x79\x6b\x6d': _0x4466f9(0x3f5),
            '\x44\x67\x70\x49\x41': _0x4466f9(0x3d2),
            '\x73\x79\x42\x54\x4d': '\x62\x61\x6e\x6d\x65',
            '\x55\x55\x59\x56\x4b': '\x41\x73\x20\x75\x20\x77\x69\x73\x68\x7e\x28\x47\x6f\x6f\x64\x20\x6c\x75\x63\x6b\x21\x29',
            '\x71\x4a\x67\x45\x75': _0x4466f9(0x3bd),
            '\x74\x43\x42\x48\x79': function (_0x4ac9da, _0x302160) {
                return _0x4ac9da === _0x302160;
            },
            '\x57\x66\x62\x4a\x7a': _0x4466f9(0x349),
            '\x4f\x44\x76\x72\x56': _0x4466f9(0x34c),
            '\x46\x48\x54\x51\x41': _0x4466f9(0x31d),
            '\x69\x77\x45\x78\x4b': function (_0x7812b6, _0x593776) {
                return _0x7812b6 != _0x593776;
            },
            '\x74\x42\x7a\x64\x4e': _0x4466f9(0x2b6),
            '\x56\x6e\x4e\x59\x5a': _0x4466f9(0x353),
            '\x46\x57\x50\x67\x4b': _0x4466f9(0x301),
            '\x6b\x74\x78\x67\x69': _0x4466f9(0x31b),
            '\x75\x4d\x76\x49\x50': _0x4466f9(0x28d),
            '\x62\x75\x4c\x6f\x54': _0x4466f9(0x23d),
            '\x57\x65\x4c\x59\x72': '\x49\x74\x65\x6d\x54\x6f\x72\x73\x6f',
            '\x41\x51\x61\x69\x4a': _0x4466f9(0x467),
            '\x71\x75\x58\x4f\x53': _0x4466f9(0x31a),
            '\x76\x62\x55\x6e\x63': '\x61\x77\x42\x4f\x54\x20\u62b1\u6b49\x2c\u60a8\u5df2\u7ecf\u88ab\u5c01\u7981\u3002',
            '\x76\x6d\x43\x51\x41': _0x4466f9(0x37f),
            '\x52\x55\x75\x53\x42': _0x4466f9(0x3a6),
            '\x47\x49\x76\x72\x43': '\x55\x66\x6c\x6a\x43',
            '\x63\x50\x41\x61\x47': '\x57\x6a\x53\x74\x50',
            '\x77\x59\x54\x4b\x57': function (_0x38f5ef, _0x35b85c) {
                return _0x38f5ef > _0x35b85c;
            },
            '\x69\x56\x56\x4f\x51': _0x4466f9(0x3bb),
            '\x58\x55\x6d\x49\x6b': _0x4466f9(0x305),
            '\x6b\x47\x53\x57\x59': _0x4466f9(0x418),
            '\x72\x6e\x70\x55\x64': function (_0x437d1b, _0x1048ba) {
                return _0x437d1b == _0x1048ba;
            },
            '\x71\x4d\x4a\x46\x61': function (_0x65d316, _0x38fc5e) {
                return _0x65d316 != _0x38fc5e;
            },
            '\x6d\x6c\x6c\x6e\x6a': function (_0x453d18, _0x334ada) {
                return _0x453d18(_0x334ada);
            },
            '\x4d\x6a\x42\x66\x70': function (_0x4ae707, _0x281106, _0x54fbc5, _0x2a9ae2) {
                return _0x4ae707(_0x281106, _0x54fbc5, _0x2a9ae2);
            },
            '\x4b\x46\x64\x75\x42': function (_0x152e32, _0xfc49fa) {
                return _0x152e32 === _0xfc49fa;
            },
            '\x47\x57\x46\x4f\x72': _0x4466f9(0x359),
            '\x52\x52\x59\x72\x63': function (_0x430fd9, _0x332ebf) {
                return _0x430fd9 !== _0x332ebf;
            },
            '\x6a\x44\x70\x71\x51': function (_0x333bb6, _0x5048fa) {
                return _0x333bb6 == _0x5048fa;
            },
            '\x4e\x55\x4e\x71\x4f': function (_0x50a051, _0x2d697d) {
                return _0x50a051 > _0x2d697d;
            },
            '\x42\x69\x4e\x6f\x6d': _0x4466f9(0x3b1),
            '\x4a\x6e\x50\x4a\x6e': '\x49\x74\x65\x6d\x41\x72\x6d\x73',
            '\x50\x53\x66\x6d\x63': _0x4466f9(0x2e4),
            '\x4a\x78\x62\x63\x6a': _0x4466f9(0x2ed),
            '\x51\x47\x78\x6a\x73': _0x4466f9(0x35b),
            '\x73\x4a\x55\x54\x50': function (_0x24ba93, _0x3e8551, _0x37f43e) {
                return _0x24ba93(_0x3e8551, _0x37f43e);
            },
            '\x50\x59\x4d\x64\x77': _0x4466f9(0x1e3),
            '\x4d\x70\x70\x4a\x5a': _0x4466f9(0x40d),
            '\x73\x4d\x77\x77\x6b': function (_0x161c50, _0x490ad5) {
                return _0x161c50 == _0x490ad5;
            },
            '\x54\x6f\x71\x55\x65': function (_0x2a6e8b, _0x3dce57) {
                return _0x2a6e8b === _0x3dce57;
            },
            '\x6b\x64\x47\x57\x70': _0x4466f9(0x3d3),
            '\x4b\x75\x56\x79\x51': function (_0x2c96da, _0xd493dc) {
                return _0x2c96da(_0xd493dc);
            },
            '\x62\x7a\x53\x41\x71': function (_0x107f20, _0x22838d) {
                return _0x107f20(_0x22838d);
            },
            '\x65\x63\x44\x48\x61': '\x5a\x55\x78\x62\x6d',
            '\x50\x54\x5a\x56\x65': '\x59\x42\x74\x48\x44',
            '\x4e\x6c\x4b\x5a\x62': function (_0x56d034, _0x3b4d36) {
                return _0x56d034 === _0x3b4d36;
            },
            '\x54\x6c\x50\x53\x75': _0x4466f9(0x3c3),
            '\x69\x78\x6c\x76\x66': function (_0x2e864c, _0x43b320) {
                return _0x2e864c != _0x43b320;
            },
            '\x45\x74\x49\x76\x70': function (_0x5cdd45, _0x14a1de) {
                return _0x5cdd45 !== _0x14a1de;
            },
            '\x77\x6f\x51\x71\x50': _0x4466f9(0x1fc),
            '\x63\x51\x62\x58\x4b': _0x4466f9(0x39e),
            '\x42\x56\x6c\x41\x6a': function (_0x4a6891, _0x2d69dc) {
                return _0x4a6891(_0x2d69dc);
            },
            '\x70\x43\x6c\x41\x69': function (_0x278baf) {
                return _0x278baf();
            },
            '\x53\x46\x42\x42\x6b': function (_0x46da52, _0x370215) {
                return _0x46da52 > _0x370215;
            },
            '\x4e\x78\x75\x6e\x46': function (_0x142f63, _0x2b944a) {
                return _0x142f63 + _0x2b944a;
            },
            '\x45\x69\x5a\x42\x4d': function (_0x53d28e, _0x2274d8) {
                return _0x53d28e + _0x2274d8;
            },
            '\x77\x50\x4d\x64\x58': function (_0x21bbad, _0x3cdae5) {
                return _0x21bbad(_0x3cdae5);
            },
            '\x4c\x55\x45\x6f\x72': _0x4466f9(0x268),
            '\x76\x4e\x69\x53\x70': function (_0x54f01e, _0x4b1f1e) {
                return _0x54f01e == _0x4b1f1e;
            },
            '\x65\x70\x62\x58\x42': function (_0x53fe02, _0x2cb855) {
                return _0x53fe02 != _0x2cb855;
            },
            '\x4a\x41\x64\x64\x6d': _0x4466f9(0x2a5),
            '\x44\x77\x6b\x69\x6d': _0x4466f9(0x284),
            '\x6d\x72\x6a\x71\x54': function (_0x2b8976, _0x1f2e3e, _0x111eb2) {
                return _0x2b8976(_0x1f2e3e, _0x111eb2);
            },
            '\x49\x53\x56\x6e\x66': _0x4466f9(0x337),
            '\x4b\x4f\x68\x66\x55': function (_0x106e0a, _0xd1b199, _0x469083) {
                return _0x106e0a(_0xd1b199, _0x469083);
            },
            '\x6f\x43\x4d\x75\x59': _0x4466f9(0x374),
            '\x58\x76\x63\x46\x48': function (_0x10e203) {
                return _0x10e203();
            },
            '\x47\x63\x72\x6e\x68': function (_0x2553a9, _0x233c64) {
                return _0x2553a9(_0x233c64);
            },
            '\x47\x50\x62\x73\x54': _0x4466f9(0x27e),
            '\x6b\x58\x6a\x63\x75': _0x4466f9(0x3ee),
            '\x62\x63\x4a\x77\x5a': function (_0x463f50, _0xc650ce, _0x2c94ef) {
                return _0x463f50(_0xc650ce, _0x2c94ef);
            },
            '\x65\x68\x4a\x47\x64': function (_0x44a047, _0x5c6573) {
                return _0x44a047 === _0x5c6573;
            },
            '\x57\x4b\x56\x76\x77': '\x62\x4e\x6f\x6c\x61',
            '\x44\x6f\x4a\x63\x47': function (_0x484837, _0x57eeeb, _0x5c2ef0) {
                return _0x484837(_0x57eeeb, _0x5c2ef0);
            },
            '\x47\x76\x76\x44\x62': '\x45\x76\x61\x73\x69\x6f\x6e',
            '\x44\x79\x4e\x42\x6f': _0x4466f9(0x39f),
            '\x79\x52\x6a\x62\x65': '\x43\x41\x47\x71\x76',
            '\x78\x46\x76\x44\x51': function (_0x53f1c1, _0x44a3e4, _0x40eb36) {
                return _0x53f1c1(_0x44a3e4, _0x40eb36);
            },
            '\x4c\x63\x61\x62\x6e': _0x4466f9(0x471),
            '\x58\x75\x49\x41\x53': function (_0x5c7802, _0x45e75a, _0x43865a) {
                return _0x5c7802(_0x45e75a, _0x43865a);
            },
            '\x6e\x56\x4e\x6f\x4f': _0x4466f9(0x3d0),
            '\x50\x67\x6f\x4b\x65': _0x4466f9(0x329),
            '\x69\x65\x79\x46\x4b': function (_0x396d4f, _0x596318, _0x482ce3, _0x3d12b6, _0x358360, _0xae04dc) {
                return _0x396d4f(_0x596318, _0x482ce3, _0x3d12b6, _0x358360, _0xae04dc);
            },
            '\x61\x43\x70\x42\x74': _0x4466f9(0x2bc),
            '\x62\x7a\x6a\x57\x4e': _0x4466f9(0x2e7),
            '\x4c\x72\x79\x77\x72': _0x4466f9(0x461),
            '\x59\x4d\x46\x43\x59': _0x4466f9(0x2b2),
            '\x78\x4f\x5a\x4b\x70': function (_0x43cd6e, _0x15b2e8, _0xa177fd, _0x59a4a5, _0x5ab3dc, _0x4131d3) {
                return _0x43cd6e(_0x15b2e8, _0xa177fd, _0x59a4a5, _0x5ab3dc, _0x4131d3);
            },
            '\x79\x68\x78\x4b\x6d': _0x4466f9(0x2d8),
            '\x76\x48\x47\x6d\x6b': function (_0xb1a6e6, _0x44ee31, _0x27c65a, _0x233f98) {
                return _0xb1a6e6(_0x44ee31, _0x27c65a, _0x233f98);
            },
            '\x5a\x6e\x75\x57\x73': function (_0x3e6a79, _0x1c172d) {
                return _0x3e6a79 == _0x1c172d;
            },
            '\x54\x6a\x57\x68\x69': _0x4466f9(0x449),
            '\x46\x61\x66\x66\x50': _0x4466f9(0x430),
            '\x6b\x4b\x54\x67\x69': _0x4466f9(0x442),
            '\x61\x75\x50\x44\x7a': '\u4f60\u8981\u8bf4\u7684\u8bdd',
            '\x75\x65\x44\x57\x54': _0x4466f9(0x2a0),
            '\x67\x41\x4d\x4a\x53': _0x4466f9(0x3fe),
            '\x6b\x6c\x4a\x76\x55': function (_0x484d0f, _0x3d8879, _0x39b5f3, _0x549e4a, _0x62de3f, _0x5b001a) {
                return _0x484d0f(_0x3d8879, _0x39b5f3, _0x549e4a, _0x62de3f, _0x5b001a);
            },
            '\x61\x48\x49\x50\x50': _0x4466f9(0x1e5),
            '\x63\x71\x6d\x63\x65': function (_0x28e19f, _0xdcb089, _0x4a0ecd, _0x10ea1c, _0x1bf515, _0x5d0a8f) {
                return _0x28e19f(_0xdcb089, _0x4a0ecd, _0x10ea1c, _0x1bf515, _0x5d0a8f);
            },
            '\x59\x55\x54\x77\x5a': function (_0x7c2e0a, _0x11d1d0, _0x48b223, _0xdb149d, _0x3fb1b3, _0x53f8a9) {
                return _0x7c2e0a(_0x11d1d0, _0x48b223, _0xdb149d, _0x3fb1b3, _0x53f8a9);
            },
            '\x46\x71\x49\x51\x4c': _0x4466f9(0x3b2),
            '\x6c\x7a\x77\x55\x62': _0x4466f9(0x36a),
            '\x63\x48\x77\x6a\x4e': _0x4466f9(0x367),
            '\x58\x77\x64\x43\x6f': function (_0x2f9dd6, _0x20d33e) {
                return _0x2f9dd6(_0x20d33e);
            },
            '\x6f\x65\x69\x46\x69': function (_0x52d2e1, _0x491f2c) {
                return _0x52d2e1 == _0x491f2c;
            },
            '\x63\x45\x74\x63\x4b': function (_0x39c05d, _0x3e73f9) {
                return _0x39c05d == _0x3e73f9;
            },
            '\x64\x6d\x70\x58\x6d': function (_0x1a43b7, _0x5a5740) {
                return _0x1a43b7(_0x5a5740);
            },
            '\x67\x54\x43\x6e\x74': function (_0x145f6b, _0x2bd522, _0x3b7586, _0x4bbac5, _0x52b7c8, _0x2cf395) {
                return _0x145f6b(_0x2bd522, _0x3b7586, _0x4bbac5, _0x52b7c8, _0x2cf395);
            },
            '\x76\x77\x61\x47\x73': function (_0x2a38e5, _0x6d699c) {
                return _0x2a38e5 + _0x6d699c;
            },
            '\x73\x51\x79\x67\x4d': function (_0x154cd9, _0x47c177) {
                return _0x154cd9 + _0x47c177;
            },
            '\x51\x6b\x56\x77\x4b': function (_0x38aeb1) {
                return _0x38aeb1();
            },
            '\x75\x6a\x55\x72\x53': _0x4466f9(0x324),
            '\x7a\x4c\x45\x6b\x6a': _0x4466f9(0x3ea),
            '\x4e\x47\x4e\x6f\x6f': _0x4466f9(0x37d),
            '\x6c\x45\x77\x51\x66': _0x4466f9(0x219),
            '\x70\x62\x4d\x46\x4b': '\x4b\x41\x74\x4a\x4a',
            '\x4c\x68\x46\x78\x57': function (_0x3794ef, _0x11205c) {
                return _0x3794ef != _0x11205c;
            },
            '\x46\x55\x76\x71\x46': _0x4466f9(0x2d4),
            '\x71\x75\x5a\x64\x59': function (_0x490e31, _0x355b0c) {
                return _0x490e31 == _0x355b0c;
            },
            '\x61\x51\x6a\x58\x75': _0x4466f9(0x41b),
            '\x49\x47\x72\x75\x52': function (_0x33364c, _0x2a3d6c, _0x4cfc3d, _0x426908) {
                return _0x33364c(_0x2a3d6c, _0x4cfc3d, _0x426908);
            },
            '\x51\x45\x68\x6e\x61': '\x44\x6f\x6d\x69\x6e\x61\x6e\x74\x20\x20\x4b\x69\x64\x6e\x61\x70\x20\x20\x41\x42\x44\x4c\x20\x20\x47\x61\x6d\x69\x6e\x67\x20\x20\x4d\x61\x69\x64\x20\x20\x4c\x41\x52\x50\x20\x20\x41\x73\x79\x6c\x75\x6d\x20\x20\x47\x61\x6d\x62\x6c\x69\x6e\x67\x20\x20\x48\x6f\x75\x73\x65\x4d\x61\x69\x65\x73\x74\x61\x73\x20\x20\x48\x6f\x75\x73\x65\x56\x69\x6e\x63\x75\x6c\x61\x20\x20\x48\x6f\x75\x73\x65\x41\x6d\x70\x6c\x65\x63\x74\x6f\x72\x20\x20\x48\x6f\x75\x73\x65\x43\x6f\x72\x70\x6f\x72\x69\x73',
            '\x53\x4c\x41\x6e\x4a': function (_0x34be78, _0x3c2574, _0x7da03d) {
                return _0x34be78(_0x3c2574, _0x7da03d);
            },
            '\x72\x6e\x43\x76\x67': '\x61\x77\x42\x4f\x54\x5f\u9677\u9631\u5c4b',
            '\x43\x76\x61\x47\x44': _0x4466f9(0x280),
            '\x62\x4a\x46\x6a\x6b': function (_0x3834ca, _0x2d2819, _0x55a127) {
                return _0x3834ca(_0x2d2819, _0x55a127);
            },
            '\x6f\x6f\x6d\x75\x66': _0x4466f9(0x267),
            '\x57\x53\x51\x49\x66': function (_0x8fa0e6, _0xec1432, _0x1c532a) {
                return _0x8fa0e6(_0xec1432, _0x1c532a);
            },
            '\x4e\x56\x4d\x6a\x4d': function (_0x389930, _0x2066f9, _0x5b37e5) {
                return _0x389930(_0x2066f9, _0x5b37e5);
            },
            '\x57\x6a\x70\x5a\x78': '\u83b7\u53d6\u7bb1\u5b50',
            '\x62\x4e\x57\x68\x42': '\u529b\u5927\u65e0\u7a77\x28\u77ac\u95f4\u6323\u8131\x29',
            '\x56\x43\x56\x4d\x77': function (_0x20ab39, _0x1a9c75, _0x40dd85) {
                return _0x20ab39(_0x1a9c75, _0x40dd85);
            },
            '\x58\x64\x4c\x78\x55': _0x4466f9(0x395),
            '\x45\x64\x6b\x41\x6d': function (_0x501b57, _0x48c1ec, _0x34d0b0) {
                return _0x501b57(_0x48c1ec, _0x34d0b0);
            },
            '\x4d\x48\x51\x6f\x48': _0x4466f9(0x2be),
            '\x55\x48\x74\x42\x65': '\u63d0\u5347\u786c\u6491\u7b49\u7ea7',
            '\x75\x6a\x59\x6b\x62': _0x4466f9(0x1f8),
            '\x73\x69\x57\x49\x6c': _0x4466f9(0x443),
            '\x45\x6d\x61\x6c\x58': function (_0x5c1294, _0x4ba679, _0x3c63dc) {
                return _0x5c1294(_0x4ba679, _0x3c63dc);
            },
            '\x4d\x50\x4b\x4b\x53': _0x4466f9(0x281),
            '\x58\x69\x76\x4c\x72': function (_0x5d7f5d, _0x251a6a, _0x58ff87) {
                return _0x5d7f5d(_0x251a6a, _0x58ff87);
            },
            '\x4f\x6d\x71\x6a\x72': _0x4466f9(0x205),
            '\x54\x5a\x63\x57\x63': '\u4e0a\u9501\x28\u641e\u4e8b\u60c5\u4e13\u7528\x29',
            '\x50\x47\x69\x50\x62': _0x4466f9(0x30a)
        }, _0x3b3f39 = (function () {
            const _0x5b4499 = _0x4466f9, _0x1d9a83 = {
                    '\x59\x6f\x6a\x68\x69': function (_0x456327, _0x472e5d, _0x3597f8, _0x4e552c, _0xb7e89b, _0x3c2238) {
                        return _0x456327(_0x472e5d, _0x3597f8, _0x4e552c, _0xb7e89b, _0x3c2238);
                    },
                    '\x62\x71\x67\x50\x55': _0x5b4499(0x208),
                    '\x41\x43\x78\x76\x56': function (_0x162382, _0x59cbd4, _0x24270a) {
                        const _0x557c48 = _0x5b4499;
                        return _0x1cf7bb[_0x557c48(0x247)](_0x162382, _0x59cbd4, _0x24270a);
                    }
                };
            let _0x175f3e = !![];
            return function (_0xcf0723, _0x58e34f) {
                const _0x551b06 = _0x5b4499, _0x24da35 = {
                        '\x79\x62\x48\x59\x7a': function (_0x51890c, _0x2d78a4, _0x5f590c, _0x2389cf, _0x561cde, _0x2312e4) {
                            const _0x134e04 = _0x5e23;
                            return _0x1d9a83[_0x134e04(0x3b4)](_0x51890c, _0x2d78a4, _0x5f590c, _0x2389cf, _0x561cde, _0x2312e4);
                        },
                        '\x69\x70\x49\x56\x6a': _0x1d9a83[_0x551b06(0x401)],
                        '\x49\x42\x6a\x6a\x65': function (_0x5d294e, _0x16e9c6, _0x221a91) {
                            const _0x412064 = _0x551b06;
                            return _0x1d9a83[_0x412064(0x1dd)](_0x5d294e, _0x16e9c6, _0x221a91);
                        },
                        '\x66\x41\x73\x43\x79': '\x69\x79\x48\x54\x76',
                        '\x59\x6d\x74\x41\x76': function (_0x1165f1, _0x217499) {
                            return _0x1165f1 !== _0x217499;
                        }
                    }, _0x123033 = _0x175f3e ? function () {
                        const _0x25ce49 = _0x551b06, _0x1ae3a3 = {
                                '\x79\x6d\x6c\x48\x65': function (_0xf7dc83, _0x5782a1, _0x3d83c9) {
                                    const _0x51f50d = _0x5e23;
                                    return _0x24da35[_0x51f50d(0x39d)](_0xf7dc83, _0x5782a1, _0x3d83c9);
                                }
                            };
                        if (_0x24da35['\x66\x41\x73\x43\x79'] !== _0x25ce49(0x1f1)) {
                            if (_0x58e34f) {
                                if (_0x24da35[_0x25ce49(0x2c7)](_0x25ce49(0x207), _0x25ce49(0x207)))
                                    _0x24da35['\x79\x62\x48\x59\x7a'](_0x5339a4, _0x1fd199, _0x25ce49(0x455), _0x25ce49(0x38f), _0x24da35[_0x25ce49(0x2d1)], -0x4935 * 0xb + -0x32ffc + 0x7 * 0x12783), _0x252e07[_0x25ce49(0x25f)][_0x25ce49(0x3d9)] = 0xa97 * 0x2 + 0x10fd * 0x2 + -0x3728, _0x598e7f(_0xb01658), _0x34c9cc = _0x25ce49(0x31d);
                                else {
                                    const _0x4c94d4 = _0x58e34f[_0x25ce49(0x2e8)](_0xcf0723, arguments);
                                    return _0x58e34f = null, _0x4c94d4;
                                }
                            }
                        } else
                            _0x1ae3a3[_0x25ce49(0x1e8)](_0x27fc6b, _0x25ce49(0x3d0), 0x210d6 + -0x18273 + 0x130ef);
                    } : function () {
                    };
                return _0x175f3e = ![], _0x123033;
            };
        }()), _0x3f1aaa = _0x1cf7bb[_0x4466f9(0x2bd)](_0x3b3f39, this, function () {
            const _0x4b49ec = _0x4466f9;
            if (_0x1cf7bb['\x78\x58\x66\x6e\x74'](_0x1cf7bb[_0x4b49ec(0x214)], _0x1cf7bb[_0x4b49ec(0x214)]))
                _0x7b805d = _0x1cf7bb[_0x4b49ec(0x247)](_0x2d4bd0, _0x4b49ec(0x39e), _0x4b49ec(0x29c)), _0xfecbe6 = _0x1e1c13[_0x4b49ec(0x403)](_0x5c1b2e), _0x1cf7bb[_0x4b49ec(0x304)](_0x4e7a40, -(0x192 + 0x2d3 + 0x4 * -0x119)) && _0x1cf7bb[_0x4b49ec(0x43e)](_0x4a24d3, _0x1cf7bb['\x64\x78\x78\x4b\x79']), _0x390cb8[_0x4b49ec(0x1e0)](_0x1d32af, 0x260b + -0xa67 * -0x1 + 0x3071 * -0x1);
            else {
                let _0x518180;
                try {
                    if (_0x1cf7bb['\x54\x49\x54\x4a\x41'] !== '\x70\x67\x51\x68\x63') {
                        const _0x73ae6e = _0x1cf7bb[_0x4b49ec(0x43e)](Function, _0x1cf7bb[_0x4b49ec(0x20b)](_0x1cf7bb[_0x4b49ec(0x20b)](_0x1cf7bb[_0x4b49ec(0x286)], _0x1cf7bb[_0x4b49ec(0x3af)]), '\x29\x3b'));
                        _0x518180 = _0x73ae6e();
                    } else {
                        let _0x156eb4 = _0x26194, _0x513f75 = _0x1cf7bb['\x78\x72\x6a\x6b\x54'](_0x43f660, _0xda1081, _0x51b5da);
                        return _0x1cf7bb['\x44\x47\x56\x70\x76'](_0x513f75, -0xe3 * 0x19 + 0x289 * 0x2 + 0x1119) && (_0x156eb4 = _0x1cf7bb[_0x4b49ec(0x263)](_0x1cf7bb[_0x4b49ec(0x250)] + _0x513f75 + '\x20', _0x156eb4)), _0x156eb4;
                    }
                } catch (_0x7646a8) {
                    _0x1cf7bb[_0x4b49ec(0x24a)](_0x1cf7bb['\x71\x54\x4e\x6d\x6f'], '\x4f\x6e\x65\x70\x67') ? _0x31365b[_0x4b49ec(0x283)][_0x4b49ec(0x399)] = _0x1cf7bb[_0x4b49ec(0x1e1)] : _0x518180 = window;
                }
                const _0x200946 = _0x518180[_0x4b49ec(0x2e2)] = _0x518180[_0x4b49ec(0x2e2)] || {}, _0x4fa8d7 = [
                        _0x1cf7bb['\x59\x58\x4e\x6c\x41'],
                        _0x1cf7bb[_0x4b49ec(0x427)],
                        _0x1cf7bb['\x56\x6f\x58\x64\x62'],
                        _0x1cf7bb[_0x4b49ec(0x398)],
                        _0x1cf7bb[_0x4b49ec(0x472)],
                        _0x1cf7bb[_0x4b49ec(0x288)],
                        _0x1cf7bb[_0x4b49ec(0x341)]
                    ];
                for (let _0x451d0a = -0x42 * 0x61 + 0x2222 * -0x1 + 0x1 * 0x3b24; _0x1cf7bb['\x6b\x68\x64\x64\x4c'](_0x451d0a, _0x4fa8d7[_0x4b49ec(0x2ef)]); _0x451d0a++) {
                    const _0x11f9d4 = _0x3b3f39[_0x4b49ec(0x262)][_0x4b49ec(0x3b7)][_0x4b49ec(0x35d)](_0x3b3f39), _0x4ba6c4 = _0x4fa8d7[_0x451d0a], _0x2b961c = _0x200946[_0x4ba6c4] || _0x11f9d4;
                    _0x11f9d4[_0x4b49ec(0x360)] = _0x3b3f39[_0x4b49ec(0x35d)](_0x3b3f39), _0x11f9d4[_0x4b49ec(0x313)] = _0x2b961c[_0x4b49ec(0x313)][_0x4b49ec(0x35d)](_0x2b961c), _0x200946[_0x4ba6c4] = _0x11f9d4;
                }
            }
        });
    _0x1cf7bb[_0x4466f9(0x474)](_0x3f1aaa), _0x1cf7bb['\x53\x4c\x41\x6e\x4a'](GM_registerMenuCommand, _0x4466f9(0x3f2), () => {
        const _0x14732d = _0x4466f9, _0x4ffc4c = {
                '\x55\x44\x4d\x67\x78': _0x14732d(0x274),
                '\x76\x79\x4c\x69\x66': _0x1cf7bb[_0x14732d(0x36b)],
                '\x64\x52\x6b\x43\x75': function (_0x4f859d, _0x2347c7, _0x3b2bf1) {
                    return _0x4f859d(_0x2347c7, _0x3b2bf1);
                },
                '\x57\x4b\x69\x55\x75': _0x1cf7bb['\x47\x62\x6f\x41\x57'],
                '\x4b\x59\x6f\x76\x65': function (_0x32d24f, _0x515a5e) {
                    return _0x32d24f > _0x515a5e;
                },
                '\x4b\x6d\x70\x69\x48': _0x1cf7bb[_0x14732d(0x321)],
                '\x73\x4a\x49\x6e\x71': _0x1cf7bb[_0x14732d(0x3c9)],
                '\x47\x45\x62\x6d\x75': function (_0x20c9c2, _0xef9284) {
                    return _0x1cf7bb['\x48\x73\x65\x78\x47'](_0x20c9c2, _0xef9284);
                },
                '\x76\x52\x6f\x56\x7a': _0x1cf7bb[_0x14732d(0x450)],
                '\x46\x68\x65\x73\x78': _0x14732d(0x292),
                '\x65\x48\x74\x6b\x6b': _0x1cf7bb[_0x14732d(0x356)],
                '\x57\x69\x52\x57\x4c': _0x14732d(0x376),
                '\x49\x57\x53\x48\x65': _0x1cf7bb['\x67\x6d\x6d\x4c\x49'],
                '\x61\x79\x45\x50\x7a': function (_0x16b7e1, _0x359e01) {
                    const _0x2ecdf1 = _0x14732d;
                    return _0x1cf7bb[_0x2ecdf1(0x24a)](_0x16b7e1, _0x359e01);
                },
                '\x65\x50\x77\x56\x52': _0x1cf7bb['\x41\x4b\x79\x6f\x58'],
                '\x52\x61\x69\x46\x6d': function (_0x4ba4e6, _0x5aacfc) {
                    return _0x4ba4e6 === _0x5aacfc;
                },
                '\x53\x70\x74\x4f\x57': _0x1cf7bb[_0x14732d(0x23c)],
                '\x67\x47\x6d\x6e\x43': _0x1cf7bb[_0x14732d(0x206)],
                '\x4e\x74\x4c\x68\x70': _0x1cf7bb[_0x14732d(0x299)],
                '\x58\x6e\x73\x61\x53': _0x14732d(0x38f),
                '\x64\x6c\x57\x6f\x77': _0x1cf7bb[_0x14732d(0x386)],
                '\x54\x79\x72\x59\x4b': _0x1cf7bb[_0x14732d(0x380)],
                '\x79\x64\x50\x68\x7a': _0x1cf7bb['\x57\x4b\x79\x67\x69'],
                '\x46\x6d\x45\x53\x61': _0x1cf7bb[_0x14732d(0x30e)],
                '\x64\x51\x43\x51\x6a': '\x49\x74\x65\x6d\x46\x65\x65\x74',
                '\x50\x44\x77\x43\x49': _0x1cf7bb[_0x14732d(0x234)],
                '\x5a\x47\x74\x64\x5a': function (_0x49e867, _0x48bfa2) {
                    return _0x49e867(_0x48bfa2);
                },
                '\x6d\x77\x59\x7a\x75': _0x1cf7bb[_0x14732d(0x27b)],
                '\x71\x6f\x53\x68\x5a': _0x1cf7bb[_0x14732d(0x25b)],
                '\x4d\x49\x51\x65\x73': function (_0x3824bf, _0x260f25) {
                    const _0x4294af = _0x14732d;
                    return _0x1cf7bb[_0x4294af(0x240)](_0x3824bf, _0x260f25);
                },
                '\x43\x56\x76\x48\x68': _0x1cf7bb[_0x14732d(0x38a)],
                '\x74\x4c\x79\x44\x54': function (_0x23e9a4, _0x536904) {
                    return _0x1cf7bb['\x75\x4b\x74\x68\x55'](_0x23e9a4, _0x536904);
                },
                '\x75\x73\x46\x76\x6e': function (_0x2efaf9, _0x1125ac) {
                    const _0x36caf0 = _0x14732d;
                    return _0x1cf7bb[_0x36caf0(0x438)](_0x2efaf9, _0x1125ac);
                },
                '\x47\x59\x59\x67\x4c': _0x1cf7bb[_0x14732d(0x1ef)],
                '\x44\x4e\x67\x4c\x68': _0x1cf7bb[_0x14732d(0x2c4)],
                '\x6c\x62\x63\x6f\x58': _0x1cf7bb['\x4b\x49\x63\x51\x46'],
                '\x73\x42\x67\x79\x65': function (_0x1dafc5, _0x1cd7e0) {
                    const _0xd7defe = _0x14732d;
                    return _0x1cf7bb[_0xd7defe(0x333)](_0x1dafc5, _0x1cd7e0);
                },
                '\x56\x50\x54\x4c\x6d': _0x14732d(0x2a4),
                '\x41\x70\x6f\x74\x6c': function (_0x1b558f, _0x2dda00) {
                    return _0x1cf7bb['\x59\x6a\x44\x68\x46'](_0x1b558f, _0x2dda00);
                },
                '\x74\x5a\x64\x4d\x4d': _0x14732d(0x22a),
                '\x75\x56\x48\x47\x55': _0x1cf7bb['\x68\x58\x78\x46\x51'],
                '\x5a\x62\x62\x43\x6f': function (_0x2763c8, _0x41cddb, _0x27f8cd, _0x19c1d0, _0x239592, _0x215ca6) {
                    const _0x2c8ec7 = _0x14732d;
                    return _0x1cf7bb[_0x2c8ec7(0x244)](_0x2763c8, _0x41cddb, _0x27f8cd, _0x19c1d0, _0x239592, _0x215ca6);
                },
                '\x6c\x71\x41\x78\x73': function (_0x523306, _0x2310f5, _0x4313d8, _0x5046d0, _0x34ce4b, _0x3470bb) {
                    const _0x361b06 = _0x14732d;
                    return _0x1cf7bb[_0x361b06(0x244)](_0x523306, _0x2310f5, _0x4313d8, _0x5046d0, _0x34ce4b, _0x3470bb);
                },
                '\x4a\x51\x4d\x45\x54': function (_0x8c10ab, _0x3e8eee) {
                    const _0x289732 = _0x14732d;
                    return _0x1cf7bb[_0x289732(0x43e)](_0x8c10ab, _0x3e8eee);
                },
                '\x59\x5a\x70\x65\x4a': function (_0x1d8a52, _0x4f5776) {
                    const _0x2dc7f1 = _0x14732d;
                    return _0x1cf7bb[_0x2dc7f1(0x333)](_0x1d8a52, _0x4f5776);
                },
                '\x64\x46\x72\x5a\x74': _0x1cf7bb[_0x14732d(0x46b)],
                '\x70\x6b\x42\x59\x71': function (_0xd2d68c, _0x5e92ce) {
                    const _0x5b8ed6 = _0x14732d;
                    return _0x1cf7bb[_0x5b8ed6(0x263)](_0xd2d68c, _0x5e92ce);
                },
                '\x58\x76\x59\x4f\x67': _0x1cf7bb[_0x14732d(0x41a)],
                '\x4b\x41\x76\x55\x73': _0x1cf7bb['\x75\x54\x48\x6d\x58'],
                '\x75\x76\x54\x57\x49': _0x1cf7bb[_0x14732d(0x46d)],
                '\x4b\x47\x66\x52\x6f': function (_0x339864, _0x340051) {
                    return _0x339864 != _0x340051;
                },
                '\x62\x71\x6b\x53\x78': _0x1cf7bb[_0x14732d(0x233)],
                '\x76\x70\x78\x47\x43': _0x1cf7bb[_0x14732d(0x2bb)],
                '\x58\x67\x62\x68\x41': _0x1cf7bb[_0x14732d(0x24e)],
                '\x64\x53\x72\x65\x4e': _0x1cf7bb['\x63\x74\x47\x77\x63'],
                '\x74\x46\x52\x51\x64': _0x1cf7bb[_0x14732d(0x3ce)],
                '\x54\x68\x52\x73\x63': _0x1cf7bb[_0x14732d(0x431)],
                '\x64\x4a\x42\x58\x58': '\x49\x74\x65\x6d\x48\x61\x6e\x64\x73',
                '\x56\x61\x6c\x61\x73': _0x14732d(0x2bc),
                '\x69\x70\x57\x56\x41': _0x1cf7bb['\x46\x75\x68\x65\x7a'],
                '\x6f\x4a\x46\x49\x63': _0x1cf7bb['\x4f\x64\x6d\x46\x4a'],
                '\x77\x71\x48\x4e\x44': _0x1cf7bb[_0x14732d(0x21d)],
                '\x47\x55\x63\x67\x75': _0x1cf7bb[_0x14732d(0x3b9)],
                '\x6c\x42\x4a\x68\x68': _0x1cf7bb[_0x14732d(0x36e)],
                '\x53\x69\x69\x4c\x6b': _0x1cf7bb[_0x14732d(0x357)],
                '\x6c\x46\x71\x4d\x70': _0x14732d(0x229),
                '\x50\x54\x71\x71\x7a': _0x1cf7bb[_0x14732d(0x3b8)],
                '\x7a\x49\x45\x7a\x6d': '\u5927\u7b11\x7e\x20\x28\u987a\u624b\u62d6\u5165\u5c01\u7981\u540d\u5355\x29\x7e',
                '\x52\x47\x52\x4d\x65': function (_0x160e12, _0x3db5c7, _0x124a58) {
                    return _0x160e12(_0x3db5c7, _0x124a58);
                },
                '\x58\x4b\x4d\x65\x4e': _0x1cf7bb[_0x14732d(0x235)],
                '\x62\x65\x72\x73\x58': function (_0x42d03b, _0x4cd673) {
                    return _0x42d03b != _0x4cd673;
                },
                '\x6a\x58\x6c\x75\x44': _0x1cf7bb['\x43\x45\x64\x63\x68'],
                '\x45\x7a\x55\x44\x4a': _0x1cf7bb[_0x14732d(0x216)],
                '\x61\x5a\x63\x6b\x74': function (_0x5d9223, _0x56f2c0) {
                    return _0x5d9223 != _0x56f2c0;
                },
                '\x62\x77\x50\x79\x46': _0x1cf7bb[_0x14732d(0x2f5)],
                '\x66\x73\x76\x55\x4a': function (_0x1437ea, _0x2191a6) {
                    const _0x16bc44 = _0x14732d;
                    return _0x1cf7bb[_0x16bc44(0x43e)](_0x1437ea, _0x2191a6);
                },
                '\x47\x6c\x57\x41\x74': _0x14732d(0x256),
                '\x65\x72\x4b\x49\x56': _0x1cf7bb[_0x14732d(0x24d)],
                '\x55\x67\x67\x42\x52': _0x14732d(0x391),
                '\x71\x75\x62\x47\x47': _0x1cf7bb[_0x14732d(0x2f1)],
                '\x4a\x6f\x53\x53\x48': _0x14732d(0x2f7),
                '\x76\x71\x41\x56\x6c': _0x1cf7bb[_0x14732d(0x32f)],
                '\x62\x50\x4f\x65\x54': _0x1cf7bb[_0x14732d(0x29a)],
                '\x7a\x4e\x4e\x6e\x4d': _0x14732d(0x253),
                '\x54\x78\x73\x61\x6c': _0x14732d(0x46a),
                '\x51\x4f\x66\x70\x65': _0x1cf7bb['\x71\x4a\x67\x45\x75'],
                '\x6b\x74\x58\x64\x78': function (_0x565483, _0x16f95b) {
                    const _0xae8d92 = _0x14732d;
                    return _0x1cf7bb[_0xae8d92(0x388)](_0x565483, _0x16f95b);
                },
                '\x6f\x42\x59\x6c\x4a': _0x1cf7bb['\x57\x66\x62\x4a\x7a'],
                '\x68\x7a\x4a\x43\x41': _0x14732d(0x3a3),
                '\x63\x4c\x6c\x78\x57': function (_0x22e19d, _0x4ce9d8) {
                    return _0x22e19d === _0x4ce9d8;
                },
                '\x68\x65\x52\x45\x6f': _0x1cf7bb[_0x14732d(0x296)],
                '\x51\x6c\x4f\x47\x48': function (_0x25b887, _0x1e71cb) {
                    return _0x25b887(_0x1e71cb);
                },
                '\x4a\x42\x4f\x58\x4b': _0x1cf7bb[_0x14732d(0x413)],
                '\x72\x6d\x47\x75\x41': function (_0x4bff16, _0x5223ca) {
                    const _0xbf8dd4 = _0x14732d;
                    return _0x1cf7bb[_0xbf8dd4(0x1e2)](_0x4bff16, _0x5223ca);
                },
                '\x4e\x54\x4f\x65\x41': _0x1cf7bb[_0x14732d(0x308)],
                '\x6f\x59\x6f\x46\x72': function (_0x31dd29, _0x188ea5) {
                    return _0x31dd29 !== _0x188ea5;
                },
                '\x65\x70\x56\x6d\x4f': _0x1cf7bb[_0x14732d(0x362)],
                '\x75\x4f\x64\x43\x46': function (_0x16527a, _0x5de89d) {
                    return _0x16527a(_0x5de89d);
                },
                '\x6f\x77\x47\x77\x68': _0x1cf7bb['\x46\x57\x50\x67\x4b'],
                '\x5a\x63\x56\x54\x71': _0x1cf7bb[_0x14732d(0x43d)],
                '\x71\x5a\x76\x58\x68': _0x1cf7bb[_0x14732d(0x3f4)],
                '\x5a\x41\x51\x49\x5a': _0x14732d(0x2ed),
                '\x71\x59\x63\x48\x4c': _0x1cf7bb['\x62\x75\x4c\x6f\x54'],
                '\x74\x41\x43\x72\x49': _0x1cf7bb[_0x14732d(0x265)],
                '\x4a\x54\x67\x4e\x48': _0x1cf7bb['\x41\x51\x61\x69\x4a'],
                '\x67\x6b\x78\x42\x70': function (_0x3a916c, _0x46b4b5) {
                    const _0x474619 = _0x14732d;
                    return _0x1cf7bb[_0x474619(0x43e)](_0x3a916c, _0x46b4b5);
                },
                '\x58\x58\x4e\x4d\x62': _0x1cf7bb[_0x14732d(0x382)],
                '\x67\x49\x45\x67\x7a': function (_0x3a8ff1, _0x727bcd) {
                    return _0x3a8ff1 + _0x727bcd;
                },
                '\x4a\x41\x52\x7a\x43': function (_0x20886a, _0x38608f) {
                    const _0x3ad7f7 = _0x14732d;
                    return _0x1cf7bb[_0x3ad7f7(0x1e2)](_0x20886a, _0x38608f);
                },
                '\x4c\x64\x4c\x50\x7a': '\x41\x77\x71',
                '\x6b\x58\x4a\x69\x46': _0x14732d(0x432),
                '\x77\x6d\x4b\x43\x54': _0x1cf7bb[_0x14732d(0x43f)],
                '\x66\x41\x55\x43\x79': _0x1cf7bb[_0x14732d(0x3a1)],
                '\x68\x45\x44\x67\x45': _0x1cf7bb[_0x14732d(0x2d0)],
                '\x75\x4d\x6e\x50\x6a': _0x1cf7bb[_0x14732d(0x2f2)],
                '\x55\x44\x49\x53\x73': function (_0x1eb52d, _0x2f21e6) {
                    const _0x32a99c = _0x14732d;
                    return _0x1cf7bb[_0x32a99c(0x388)](_0x1eb52d, _0x2f21e6);
                },
                '\x70\x7a\x64\x67\x49': _0x1cf7bb[_0x14732d(0x29b)],
                '\x42\x51\x70\x6a\x75': function (_0x4ab613, _0x2a12f0) {
                    const _0x138303 = _0x14732d;
                    return _0x1cf7bb[_0x138303(0x459)](_0x4ab613, _0x2a12f0);
                },
                '\x54\x54\x55\x6b\x61': _0x1cf7bb[_0x14732d(0x3e6)],
                '\x50\x78\x73\x56\x6a': _0x1cf7bb[_0x14732d(0x3cc)],
                '\x77\x64\x64\x46\x62': _0x14732d(0x381),
                '\x68\x41\x72\x72\x68': _0x1cf7bb[_0x14732d(0x3c0)]
            };
        if (!(Player[_0x14732d(0x1e7)] && _0x1cf7bb[_0x14732d(0x2f6)](Player['\x4f\x77\x6e\x65\x72\x73\x68\x69\x70']['\x4e\x61\x6d\x65'], _0x1cf7bb['\x57\x4b\x79\x67\x69']))) {
            if (_0x1cf7bb['\x71\x4d\x4a\x46\x61'](Player[_0x14732d(0x306)], _0x1cf7bb['\x57\x4b\x79\x67\x69'])) {
                _0x1cf7bb[_0x14732d(0x210)](alert, _0x1cf7bb[_0x14732d(0x234)]);
                return;
            }
        }
        AwBotLast = _0x14732d(0x2ac), AwBotBan = [], SpeechGarble = function (_0x498048, _0x253633, _0x36bc87) {
            const _0x509e40 = _0x14732d, _0x5161aa = {
                    '\x77\x4c\x6c\x79\x4a': _0x4ffc4c[_0x509e40(0x31c)],
                    '\x56\x4f\x65\x6f\x4c': function (_0x30c2e4, _0x30a46d, _0x59880f, _0x4d66e4) {
                        return _0x30c2e4(_0x30a46d, _0x59880f, _0x4d66e4);
                    },
                    '\x42\x54\x74\x78\x6d': function (_0x40481a, _0x438457) {
                        const _0x1a3408 = _0x509e40;
                        return _0x4ffc4c[_0x1a3408(0x468)](_0x40481a, _0x438457);
                    },
                    '\x4a\x78\x7a\x58\x6e': function (_0x145434, _0x35ed82) {
                        return _0x145434 == _0x35ed82;
                    },
                    '\x71\x45\x48\x70\x7a': '\x56\x42\x58\x4c\x6e',
                    '\x7a\x79\x59\x6d\x77': _0x4ffc4c['\x75\x4d\x6e\x50\x6a'],
                    '\x6b\x73\x4e\x4c\x47': function (_0x933460, _0x168057) {
                        return _0x4ffc4c['\x55\x44\x49\x53\x73'](_0x933460, _0x168057);
                    },
                    '\x66\x6b\x5a\x62\x75': _0x4ffc4c[_0x509e40(0x3dc)],
                    '\x6d\x73\x54\x72\x4c': function (_0x345bf2, _0x17c86c) {
                        const _0xfcba94 = _0x509e40;
                        return _0x4ffc4c[_0xfcba94(0x2ce)](_0x345bf2, _0x17c86c);
                    },
                    '\x57\x4f\x4e\x67\x43': _0x4ffc4c[_0x509e40(0x311)],
                    '\x47\x52\x54\x49\x6d': function (_0x1204ce, _0x3b75b6) {
                        const _0x476bdd = _0x509e40;
                        return _0x4ffc4c[_0x476bdd(0x3f0)](_0x1204ce, _0x3b75b6);
                    },
                    '\x76\x58\x6c\x6f\x58': _0x4ffc4c['\x55\x44\x4d\x67\x78'],
                    '\x65\x63\x4a\x4b\x6c': _0x4ffc4c['\x54\x54\x55\x6b\x61'],
                    '\x68\x6f\x56\x75\x52': _0x4ffc4c[_0x509e40(0x2a6)],
                    '\x56\x48\x7a\x48\x6b': function (_0x4f9653, _0xad2590) {
                        return _0x4ffc4c['\x63\x4c\x6c\x78\x57'](_0x4f9653, _0xad2590);
                    },
                    '\x71\x66\x61\x76\x6b': _0x4ffc4c[_0x509e40(0x3ef)],
                    '\x4c\x79\x52\x6a\x50': function (_0x239836, _0x34d130, _0x31363a, _0x3811d2) {
                        return _0x239836(_0x34d130, _0x31363a, _0x3811d2);
                    },
                    '\x6a\x52\x67\x51\x45': function (_0x2c95c2, _0x1696bb, _0x5b20b8) {
                        return _0x2c95c2(_0x1696bb, _0x5b20b8);
                    }
                };
            _0x4ffc4c[_0x509e40(0x36c)](AwBotLast, _0x253633 + _0x498048[_0x509e40(0x306)]) && _0x4ffc4c[_0x509e40(0x463)](_0x253633[_0x509e40(0x403)](_0x509e40(0x3f2)), -(-0xbe * -0xb + 0x4 * -0x737 + 0x14b3)) && setTimeout(function () {
                const _0x54056d = _0x509e40, _0x2ec175 = {
                        '\x68\x43\x73\x61\x76': _0x4ffc4c[_0x54056d(0x2db)],
                        '\x55\x6a\x75\x41\x63': _0x4ffc4c[_0x54056d(0x241)],
                        '\x4f\x70\x48\x77\x64': '\u5982\u4f60\u6240\u613f\x20\x28\u5e38\u89c1\u95ee\u9898\x3a\u4e0d\u89e3\u4e3b\u4eba\x2f\u604b\u4eba\x2c\u8bf7\u5f00\u6743\u9650\x29\x7e',
                        '\x64\x75\x50\x67\x75': function (_0x537c17, _0x580fb1, _0x187f1e) {
                            const _0x24b83a = _0x54056d;
                            return _0x4ffc4c[_0x24b83a(0x20c)](_0x537c17, _0x580fb1, _0x187f1e);
                        },
                        '\x47\x79\x49\x57\x68': _0x4ffc4c['\x57\x4b\x69\x55\x75'],
                        '\x77\x53\x4d\x67\x4c': function (_0x1124d2, _0x41e08d, _0x42e5ef) {
                            return _0x1124d2(_0x41e08d, _0x42e5ef);
                        },
                        '\x54\x43\x69\x71\x6b': _0x54056d(0x2d3),
                        '\x67\x46\x67\x76\x71': function (_0x565853, _0x40f296) {
                            const _0x2fd176 = _0x54056d;
                            return _0x4ffc4c[_0x2fd176(0x468)](_0x565853, _0x40f296);
                        },
                        '\x46\x4b\x41\x49\x47': function (_0x5432b5, _0x48cfe3) {
                            return _0x5432b5 !== _0x48cfe3;
                        },
                        '\x77\x72\x6a\x6d\x75': _0x4ffc4c['\x4b\x6d\x70\x69\x48'],
                        '\x54\x69\x48\x75\x71': _0x4ffc4c[_0x54056d(0x246)],
                        '\x74\x54\x51\x44\x4f': function (_0x53b4df, _0x414e8c) {
                            const _0x294157 = _0x54056d;
                            return _0x4ffc4c[_0x294157(0x463)](_0x53b4df, _0x414e8c);
                        },
                        '\x54\x70\x5a\x63\x48': _0x4ffc4c['\x76\x52\x6f\x56\x7a'],
                        '\x50\x62\x43\x76\x6c': _0x4ffc4c[_0x54056d(0x331)],
                        '\x44\x53\x71\x75\x77': _0x4ffc4c['\x65\x48\x74\x6b\x6b'],
                        '\x4a\x5a\x64\x41\x6d': _0x4ffc4c[_0x54056d(0x3da)],
                        '\x4c\x6e\x67\x6d\x41': function (_0x235e7a, _0x190e9c) {
                            return _0x235e7a < _0x190e9c;
                        },
                        '\x6c\x4b\x71\x42\x48': _0x4ffc4c['\x49\x57\x53\x48\x65'],
                        '\x44\x63\x73\x56\x63': _0x54056d(0x3a9),
                        '\x57\x73\x64\x6e\x71': function (_0x3da417, _0xf6573f) {
                            const _0x25ff97 = _0x54056d;
                            return _0x4ffc4c[_0x25ff97(0x468)](_0x3da417, _0xf6573f);
                        },
                        '\x79\x41\x5a\x43\x6e': function (_0x54e834, _0x2a8550) {
                            return _0x4ffc4c['\x61\x79\x45\x50\x7a'](_0x54e834, _0x2a8550);
                        },
                        '\x6b\x64\x74\x44\x50': _0x4ffc4c['\x65\x50\x77\x56\x52'],
                        '\x69\x74\x43\x62\x50': function (_0x1b5ae1, _0x98e43a) {
                            const _0x54877c = _0x54056d;
                            return _0x4ffc4c[_0x54877c(0x41d)](_0x1b5ae1, _0x98e43a);
                        },
                        '\x5a\x7a\x73\x58\x71': _0x4ffc4c[_0x54056d(0x2b9)],
                        '\x76\x5a\x4a\x52\x53': _0x54056d(0x305),
                        '\x71\x47\x51\x41\x67': _0x4ffc4c['\x67\x47\x6d\x6e\x43'],
                        '\x79\x62\x54\x6d\x50': _0x4ffc4c['\x4e\x74\x4c\x68\x70'],
                        '\x55\x76\x74\x42\x75': _0x4ffc4c[_0x54056d(0x204)],
                        '\x47\x69\x65\x75\x61': _0x4ffc4c['\x64\x6c\x57\x6f\x77'],
                        '\x52\x50\x79\x72\x70': _0x4ffc4c[_0x54056d(0x45b)],
                        '\x6b\x6b\x75\x4e\x4e': _0x4ffc4c[_0x54056d(0x44b)],
                        '\x49\x6b\x57\x6d\x55': _0x4ffc4c['\x46\x6d\x45\x53\x61'],
                        '\x50\x6f\x48\x51\x61': _0x4ffc4c['\x64\x51\x43\x51\x6a'],
                        '\x4c\x64\x70\x55\x5a': function (_0x13c329, _0x1a6f4b) {
                            return _0x13c329(_0x1a6f4b);
                        },
                        '\x74\x79\x70\x65\x44': function (_0x12aaf9, _0x1ac934) {
                            return _0x12aaf9 != _0x1ac934;
                        },
                        '\x4d\x68\x63\x4b\x54': function (_0x18bca5, _0x558057) {
                            return _0x18bca5(_0x558057);
                        },
                        '\x51\x62\x62\x6f\x72': _0x4ffc4c[_0x54056d(0x43b)],
                        '\x6e\x52\x75\x55\x74': function (_0xbbfde7, _0x2a1762) {
                            const _0x38ac17 = _0x54056d;
                            return _0x4ffc4c[_0x38ac17(0x44e)](_0xbbfde7, _0x2a1762);
                        },
                        '\x43\x70\x78\x50\x75': _0x54056d(0x25c),
                        '\x41\x74\x70\x4e\x70': _0x4ffc4c[_0x54056d(0x23b)],
                        '\x51\x6e\x54\x46\x49': _0x4ffc4c[_0x54056d(0x293)],
                        '\x79\x54\x4e\x6c\x43': function (_0xeb07a, _0x5c3df9) {
                            const _0x4e0a97 = _0x54056d;
                            return _0x4ffc4c[_0x4e0a97(0x338)](_0xeb07a, _0x5c3df9);
                        },
                        '\x47\x52\x50\x65\x75': _0x4ffc4c['\x43\x56\x76\x48\x68'],
                        '\x54\x78\x62\x62\x64': '\x48\x51\x67\x55\x63',
                        '\x5a\x74\x66\x62\x76': function (_0x3329e2, _0x1442e7) {
                            return _0x4ffc4c['\x74\x4c\x79\x44\x54'](_0x3329e2, _0x1442e7);
                        },
                        '\x73\x70\x51\x41\x76': function (_0x529217, _0x36156c) {
                            return _0x4ffc4c['\x75\x73\x46\x76\x6e'](_0x529217, _0x36156c);
                        },
                        '\x57\x4a\x71\x45\x6b': _0x4ffc4c[_0x54056d(0x339)],
                        '\x47\x4e\x62\x7a\x57': _0x4ffc4c['\x44\x4e\x67\x4c\x68'],
                        '\x79\x58\x6f\x6b\x4b': function (_0x4f9885, _0x2b1d48) {
                            const _0x221849 = _0x54056d;
                            return _0x4ffc4c[_0x221849(0x44e)](_0x4f9885, _0x2b1d48);
                        },
                        '\x4b\x57\x6f\x42\x65': _0x54056d(0x3c4)
                    };
                if (_0x4ffc4c[_0x54056d(0x46c)] === _0x54056d(0x2ff))
                    _0x2899b4['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x54056d(0x20e)] = [];
                else {
                    if (_0x4ffc4c[_0x54056d(0x463)](AwBotBan['\x69\x6e\x64\x65\x78\x4f\x66'](_0x498048[_0x54056d(0x306)]), -(0x1346 + -0x200d + 0xcc8))) {
                        if (_0x4ffc4c[_0x54056d(0x1ea)](_0x253633[_0x54056d(0x403)](_0x4ffc4c[_0x54056d(0x257)]), -(-0x2211 + -0x3b * -0x44 + -0x13a * -0xf))) {
                            let _0x255b24 = _0x54056d(0x29f);
                            if (_0x4ffc4c[_0x54056d(0x1ea)](_0x253633[_0x54056d(0x403)]('\u6551\u6211'), -(-0x553 + -0xad8 + 0x102c)))
                                CharacterReleaseTotal(_0x498048), _0x498048[_0x54056d(0x25f)]['\x50\x72\x6f\x67\x72\x65\x73\x73'] = 0x660 + 0x199 * -0x15 + 0x1b2d, _0x4ffc4c[_0x54056d(0x3c6)](ChatRoomCharacterUpdate, _0x498048), _0x255b24 = _0x4ffc4c[_0x54056d(0x21e)];
                            else {
                                if (_0x253633['\x69\x6e\x64\x65\x78\x4f\x66']('\u6346\u6211') != -(-0x2089 * 0x1 + -0x621 + 0x1 * 0x26ab)) {
                                    const _0xd235c5 = _0x4ffc4c[_0x54056d(0x38b)][_0x54056d(0x24b)]('\x7c');
                                    let _0x18e346 = -0xe1d + 0x2596 * -0x1 + 0x33b3;
                                    while (!![]) {
                                        switch (_0xd235c5[_0x18e346++]) {
                                        case '\x30':
                                            _0x498048[_0x54056d(0x25f)][_0x54056d(0x3d9)] = 0xcf * -0x1a + 0x1be * -0x5 + 0x1dbc;
                                            continue;
                                        case '\x31':
                                            _0x255b24 = '\u5982\u4f60\u6240\u613f\x20\x28\u5e38\u89c1\u95ee\u9898\x3a\u8bf7\u5f00\u6743\u9650\x29\x7e';
                                            continue;
                                        case '\x32':
                                            _0x4ffc4c[_0x54056d(0x39b)](InventoryWear, _0x498048, _0x4ffc4c[_0x54056d(0x2bf)], _0x4ffc4c['\x58\x6e\x73\x61\x53'], _0x54056d(0x208), -0x256a9 + 0x2d4a7 + 0x4 * 0x5055);
                                            continue;
                                        case '\x33':
                                            _0x4ffc4c[_0x54056d(0x3d8)](InventoryWear, _0x498048, _0x4ffc4c[_0x54056d(0x3ed)], _0x4ffc4c[_0x54056d(0x2a1)], _0x4ffc4c[_0x54056d(0x28f)], -0x2b0aa + -0xb6df + -0x526db * -0x1);
                                            continue;
                                        case '\x34':
                                            _0x4ffc4c[_0x54056d(0x249)](ChatRoomCharacterUpdate, _0x498048);
                                            continue;
                                        }
                                        break;
                                    }
                                } else {
                                    if (_0x4ffc4c[_0x54056d(0x261)](_0x253633[_0x54056d(0x403)]('\u5173\u4e8e'), -(0x6 * 0x3fd + -0x1db * -0x9 + -0x28a0)))
                                        _0x255b24 = _0x4ffc4c['\x64\x46\x72\x5a\x74'];
                                    else {
                                        if (_0x4ffc4c[_0x54056d(0x261)](_0x253633[_0x54056d(0x403)]('\u8214\u6211'), -(-0x2eb + 0x1309 + -0x101d)))
                                            _0x54056d(0x2fd) === _0x54056d(0x2fd) ? _0x255b24 = _0x4ffc4c['\x70\x6b\x42\x59\x71'](_0x4ffc4c[_0x54056d(0x379)] + _0x498048[_0x54056d(0x306)], '\x2e') : _0x5b120c[_0x54056d(0x26b)][_0x54056d(0x36f)] = -0x29 * -0xa9 + -0x118e + -0x1 * 0x983;
                                        else {
                                            if (_0x4ffc4c[_0x54056d(0x1ea)](_0x253633[_0x54056d(0x403)]('\u73a9\u6211'), -(0x22c4 + 0x1 * 0x70d + -0x37c * 0xc)))
                                                _0x4ffc4c['\x5a\x62\x62\x43\x6f'](InventoryWear, _0x498048, _0x4ffc4c[_0x54056d(0x239)], _0x4ffc4c['\x58\x6e\x73\x61\x53'], _0x4ffc4c[_0x54056d(0x28f)], -0x10ba * -0x24 + -0x2 * 0x6997 + 0x3858), _0x498048[_0x54056d(0x25f)]['\x50\x72\x6f\x67\x72\x65\x73\x73'] = -0x26fa + -0x1f20 + 0x461a, ChatRoomCharacterUpdate(_0x498048), _0x255b24 = _0x4ffc4c[_0x54056d(0x309)];
                                            else {
                                                if (_0x4ffc4c[_0x54056d(0x1ea)](_0x253633['\x69\x6e\x64\x65\x78\x4f\x66']('\u9501\u6211'), -(0x711 + 0x23a4 + -0x2ab4)))
                                                    _0x498048['\x41\x70\x70\x65\x61\x72\x61\x6e\x63\x65']['\x66\x6f\x72\x45\x61\x63\x68'](_0x55898b => {
                                                        const _0x4b92fa = _0x54056d, _0x3f1438 = {
                                                                '\x52\x46\x46\x67\x66': _0x2ec175[_0x4b92fa(0x397)],
                                                                '\x41\x65\x63\x4c\x54': function (_0x5ef889, _0x110e2b) {
                                                                    return _0x5ef889(_0x110e2b);
                                                                },
                                                                '\x43\x63\x64\x49\x76': _0x2ec175[_0x4b92fa(0x30d)],
                                                                '\x69\x6b\x6a\x67\x74': _0x2ec175['\x4f\x70\x48\x77\x64'],
                                                                '\x67\x75\x7a\x70\x6a': function (_0x3a9165, _0x4e5c23, _0x2ec32c) {
                                                                    const _0x10020a = _0x4b92fa;
                                                                    return _0x2ec175[_0x10020a(0x344)](_0x3a9165, _0x4e5c23, _0x2ec32c);
                                                                },
                                                                '\x66\x72\x56\x4b\x65': _0x2ec175[_0x4b92fa(0x2f4)],
                                                                '\x72\x63\x41\x76\x63': function (_0x215913, _0x56105b, _0x308087) {
                                                                    const _0x4a7f19 = _0x4b92fa;
                                                                    return _0x2ec175[_0x4a7f19(0x3bc)](_0x215913, _0x56105b, _0x308087);
                                                                },
                                                                '\x58\x6f\x74\x52\x50': _0x2ec175[_0x4b92fa(0x2aa)]
                                                            };
                                                        let _0x4cdd86 = 0x13e0 + 0x1930 * -0x1 + 0x550;
                                                        _0x2ec175['\x67\x46\x67\x76\x71'](_0x55898b[_0x4b92fa(0x26b)], -0xa77 + 0x1aea + 0x1 * -0x1073) && (_0x2ec175[_0x4b92fa(0x2c6)](_0x2ec175[_0x4b92fa(0x2d7)], _0x2ec175[_0x4b92fa(0x28a)]) ? (_0x2ec175[_0x4b92fa(0x315)](_0x55898b[_0x4b92fa(0x283)], null) && (_0x2ec175['\x46\x4b\x41\x49\x47'](_0x2ec175[_0x4b92fa(0x1ee)], _0x2ec175['\x50\x62\x43\x76\x6c']) ? _0x55898b[_0x4b92fa(0x283)] = {} : _0x5b4dda[_0x4b92fa(0x283)][_0x4b92fa(0x399)] = _0x3f1438['\x52\x46\x46\x67\x66']), _0x2ec175[_0x4b92fa(0x315)](_0x55898b[_0x4b92fa(0x283)][_0x4b92fa(0x20e)], null) && (_0x2ec175[_0x4b92fa(0x2c6)](_0x2ec175[_0x4b92fa(0x454)], _0x2ec175[_0x4b92fa(0x39a)]) ? _0x55898b[_0x4b92fa(0x283)][_0x4b92fa(0x20e)] = [] : _0x3f1438[_0x4b92fa(0x421)](_0x42298b, _0x3f1438[_0x4b92fa(0x336)])), _0x2ec175['\x4c\x6e\x67\x6d\x41'](_0x55898b[_0x4b92fa(0x283)][_0x4b92fa(0x20e)][_0x4b92fa(0x403)](_0x2ec175[_0x4b92fa(0x383)]), -0x1 * -0x805 + 0xf6 * 0x1 + -0x8fb) && (_0x4b92fa(0x2e0) === _0x2ec175['\x44\x63\x73\x56\x63'] ? _0x5e6190(_0x4a5787, _0x263804, 0x2a406 + 0x21937 + 0x17 * -0x214d) : _0x55898b[_0x4b92fa(0x283)]['\x45\x66\x66\x65\x63\x74'][_0x4b92fa(0x424)](_0x2ec175[_0x4b92fa(0x383)])), _0x2ec175[_0x4b92fa(0x434)](Math['\x72\x61\x6e\x64\x6f\x6d'](), -0x25 * 0xc7 + 0x1c5e + 0x65 * 0x1 + 0.5) ? _0x2ec175[_0x4b92fa(0x23f)](_0x2ec175['\x6b\x64\x74\x44\x50'], _0x4b92fa(0x2f8)) ? _0x55898b[_0x4b92fa(0x283)][_0x4b92fa(0x399)] = _0x2ec175[_0x4b92fa(0x397)] : (_0x1bdcf9(_0x2f4c2d), _0x5779b1['\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73'][_0x4b92fa(0x3d9)] = -0x2 * -0x89 + -0x369 * 0xb + -0x13 * -0x1eb, _0x2626d4(_0x5cb899), _0x4cad78 = _0x3f1438[_0x4b92fa(0x32d)]) : _0x2ec175[_0x4b92fa(0x202)]('\x6a\x4a\x55\x71\x55', _0x2ec175[_0x4b92fa(0x44d)]) ? _0x3f1438[_0x4b92fa(0x221)](_0x5b05f4, _0x3f1438[_0x4b92fa(0x3ab)], -0xae * -0x110 + -0x14e * 0x224 + 0x3d16a) : _0x55898b[_0x4b92fa(0x283)][_0x4b92fa(0x399)] = _0x2ec175['\x76\x5a\x4a\x52\x53'], _0x55898b[_0x4b92fa(0x283)][_0x4b92fa(0x417)] = Player[_0x4b92fa(0x21b)], _0x498048['\x41\x70\x70\x65\x61\x72\x61\x6e\x63\x65'][_0x4cdd86] = _0x55898b) : _0x3f1438[_0x4b92fa(0x405)](_0x1a5b10, _0x3f1438['\x58\x6f\x74\x52\x50'], 0x2a1f9 + 0x37 * -0xd06 + 0x1e9a3)), _0x4cdd86++;
                                                    }), _0x498048[_0x54056d(0x25f)][_0x54056d(0x3d9)] = -0x2 * -0x5ba + -0x108 * 0x5 + -0x64c, ChatRoomCharacterUpdate(_0x498048), _0x255b24 = _0x4ffc4c[_0x54056d(0x309)];
                                                else {
                                                    if (_0x4ffc4c['\x4b\x47\x66\x52\x6f'](_0x253633[_0x54056d(0x403)](_0x4ffc4c['\x62\x71\x6b\x53\x78']), -(0x4 * -0x16 + 0x20df + 0x16a * -0x17))) {
                                                        if (_0x54056d(0x3e7) !== _0x54056d(0x3e7))
                                                            _0x187682 = _0x5161aa[_0x54056d(0x40f)];
                                                        else {
                                                            let _0x34985c = [
                                                                _0x4ffc4c['\x58\x6e\x73\x61\x53'],
                                                                _0x4ffc4c['\x76\x70\x78\x47\x43'],
                                                                _0x4ffc4c['\x58\x67\x62\x68\x41'],
                                                                _0x4ffc4c['\x64\x53\x72\x65\x4e'],
                                                                _0x4ffc4c[_0x54056d(0x3e9)],
                                                                _0x4ffc4c[_0x54056d(0x42c)],
                                                                _0x4ffc4c[_0x54056d(0x2a1)],
                                                                _0x4ffc4c['\x64\x4a\x42\x58\x58'],
                                                                _0x4ffc4c[_0x54056d(0x2da)],
                                                                _0x4ffc4c['\x69\x70\x57\x56\x41'],
                                                                _0x4ffc4c[_0x54056d(0x460)],
                                                                _0x4ffc4c[_0x54056d(0x293)],
                                                                _0x54056d(0x301),
                                                                _0x4ffc4c[_0x54056d(0x2a2)],
                                                                _0x54056d(0x31b),
                                                                '\x49\x74\x65\x6d\x4e\x65\x63\x6b',
                                                                _0x4ffc4c['\x47\x55\x63\x67\x75'],
                                                                _0x4ffc4c['\x6c\x42\x4a\x68\x68'],
                                                                _0x4ffc4c['\x53\x69\x69\x4c\x6b'],
                                                                _0x54056d(0x2ed),
                                                                _0x4ffc4c[_0x54056d(0x437)],
                                                                '\x49\x74\x65\x6d\x50\x65\x6c\x76\x69\x73',
                                                                _0x54056d(0x25d),
                                                                _0x4ffc4c[_0x54056d(0x429)],
                                                                '\x49\x74\x65\x6d\x56\x75\x6c\x76\x61\x50\x69\x65\x72\x63\x69\x6e\x67\x73'
                                                            ];
                                                            _0x34985c[_0x54056d(0x3bf)](_0x12777f => {
                                                                const _0x55e835 = _0x54056d;
                                                                _0x5161aa[_0x55e835(0x377)](InventoryWearRandom, _0x498048, _0x12777f, 0x18 * -0x10c8 + 0x1ec9d + 0xb * 0x207f);
                                                            }), _0x498048['\x41\x70\x70\x65\x61\x72\x61\x6e\x63\x65']['\x66\x6f\x72\x45\x61\x63\x68'](_0x1c6745 => {
                                                                const _0x30fa2d = _0x54056d;
                                                                let _0x264a88 = -0xf0a + -0x1 * -0x1201 + -0x1 * 0x2f7;
                                                                if (_0x5161aa[_0x30fa2d(0x330)](_0x1c6745[_0x30fa2d(0x26b)], 0x5 * 0x325 + -0x13 * -0x17 + -0x116e)) {
                                                                    if (_0x5161aa[_0x30fa2d(0x248)](_0x1c6745[_0x30fa2d(0x283)], null)) {
                                                                        if (_0x5161aa['\x71\x45\x48\x70\x7a'] !== _0x5161aa['\x7a\x79\x59\x6d\x77'])
                                                                            _0x1c6745['\x50\x72\x6f\x70\x65\x72\x74\x79'] = {};
                                                                        else {
                                                                            const _0x3ae647 = _0x6d94ae['\x61\x70\x70\x6c\x79'](_0x1f8605, arguments);
                                                                            return _0x96b3b = null, _0x3ae647;
                                                                        }
                                                                    }
                                                                    if (_0x5161aa[_0x30fa2d(0x248)](_0x1c6745[_0x30fa2d(0x283)][_0x30fa2d(0x20e)], null)) {
                                                                        if (_0x5161aa[_0x30fa2d(0x298)](_0x5161aa['\x66\x6b\x5a\x62\x75'], _0x30fa2d(0x295))) {
                                                                            const _0xaed89e = _0x2ec175[_0x30fa2d(0x416)][_0x30fa2d(0x24b)]('\x7c');
                                                                            let _0x19749e = 0x1d0f + -0x14de + -0x1 * 0x831;
                                                                            while (!![]) {
                                                                                switch (_0xaed89e[_0x19749e++]) {
                                                                                case '\x30':
                                                                                    _0x4a70a6(_0x3e6b51, _0x2ec175[_0x30fa2d(0x34f)], _0x2ec175[_0x30fa2d(0x1f5)], _0x2ec175[_0x30fa2d(0x350)], -0xd75b + -0xa876 + 0x33f19);
                                                                                    continue;
                                                                                case '\x31':
                                                                                    _0x332dde = _0x2ec175[_0x30fa2d(0x344)](_0x42e1be, _0x2ec175[_0x30fa2d(0x389)], _0x2ec175[_0x30fa2d(0x3d6)]);
                                                                                    continue;
                                                                                case '\x32':
                                                                                    _0x2271a6(_0xe2ce60, _0x2ec175[_0x30fa2d(0x428)], _0x2ec175[_0x30fa2d(0x3e3)], _0x2ec175[_0x30fa2d(0x350)], 0x29f0d + -0x3b9 * 0xc + -0xb30f);
                                                                                    continue;
                                                                                case '\x33':
                                                                                    if (_0x3b1159 == null)
                                                                                        return;
                                                                                    continue;
                                                                                case '\x34':
                                                                                    _0x2ec175[_0x30fa2d(0x400)](_0x3d7092, _0x1e8443);
                                                                                    continue;
                                                                                case '\x35':
                                                                                    _0x5c0493[_0x30fa2d(0x25f)][_0x30fa2d(0x3d9)] = 0x17 * 0x8 + -0x1503 + 0x144b;
                                                                                    continue;
                                                                                case '\x36':
                                                                                    if (!(_0x1253c6['\x4f\x77\x6e\x65\x72\x73\x68\x69\x70'] && _0x853e6c[_0x30fa2d(0x1e7)][_0x30fa2d(0x306)] == _0x2ec175['\x6b\x6b\x75\x4e\x4e'])) {
                                                                                        if (_0x2ec175[_0x30fa2d(0x2e5)](_0x4d00a1['\x4e\x61\x6d\x65'], _0x2ec175[_0x30fa2d(0x3d6)])) {
                                                                                            _0x2ec175[_0x30fa2d(0x218)](_0x112a98, _0x2ec175[_0x30fa2d(0x3ac)]);
                                                                                            return;
                                                                                        }
                                                                                    }
                                                                                    continue;
                                                                                case '\x37':
                                                                                    _0x404a41 = _0x3f75f6[_0x30fa2d(0x34d)](_0x13821c => _0x13821c[_0x30fa2d(0x306)]['\x74\x6f\x4c\x6f\x77\x65\x72\x43\x61\x73\x65']() == _0x278f41);
                                                                                    continue;
                                                                                }
                                                                                break;
                                                                            }
                                                                        } else
                                                                            _0x1c6745[_0x30fa2d(0x283)][_0x30fa2d(0x20e)] = [];
                                                                    }
                                                                    _0x5161aa['\x6d\x73\x54\x72\x4c'](_0x1c6745[_0x30fa2d(0x283)][_0x30fa2d(0x20e)][_0x30fa2d(0x403)](_0x5161aa['\x57\x4f\x4e\x67\x43']), -0x25d5 + -0x1603 + -0xbf8 * -0x5) && _0x1c6745[_0x30fa2d(0x283)][_0x30fa2d(0x20e)][_0x30fa2d(0x424)](_0x5161aa[_0x30fa2d(0x1e4)]), _0x5161aa['\x47\x52\x54\x49\x6d'](Math[_0x30fa2d(0x462)](), -0x233 * -0xd + 0x265f + 0x42f6 * -0x1 + 0.5) ? _0x1c6745[_0x30fa2d(0x283)][_0x30fa2d(0x399)] = _0x5161aa[_0x30fa2d(0x470)] : _0x5161aa[_0x30fa2d(0x298)]('\x45\x58\x65\x42\x72', _0x5161aa[_0x30fa2d(0x358)]) ? _0x2ec175[_0x30fa2d(0x343)](_0x2beb76, _0x2ec175[_0x30fa2d(0x363)]) : _0x1c6745[_0x30fa2d(0x283)][_0x30fa2d(0x399)] = _0x5161aa[_0x30fa2d(0x2de)], _0x1c6745[_0x30fa2d(0x283)][_0x30fa2d(0x417)] = Player[_0x30fa2d(0x21b)], _0x498048['\x41\x70\x70\x65\x61\x72\x61\x6e\x63\x65'][_0x264a88] = _0x1c6745;
                                                                }
                                                                _0x264a88++;
                                                            }), _0x498048[_0x54056d(0x25f)][_0x54056d(0x3d9)] = -0x16 * -0xd4 + 0x1 * -0x244 + -0xff4, _0x4ffc4c[_0x54056d(0x249)](ChatRoomCharacterUpdate, _0x498048), _0x255b24 = _0x4ffc4c[_0x54056d(0x211)], AwBotBan[_0x54056d(0x424)](_0x498048[_0x54056d(0x306)]);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            _0x4ffc4c[_0x54056d(0x201)](ServerSend, _0x54056d(0x31a), {
                                '\x43\x6f\x6e\x74\x65\x6e\x74': _0x4ffc4c[_0x54056d(0x332)]('\x61\x77\x42\x4f\x54\x20', _0x255b24),
                                '\x54\x79\x70\x65': _0x4ffc4c[_0x54056d(0x278)]
                            });
                        } else {
                            if (_0x4ffc4c[_0x54056d(0x287)](_0x253633['\x69\x6e\x64\x65\x78\x4f\x66'](_0x4ffc4c['\x6a\x58\x6c\x75\x44']), -(0xf61 * -0x1 + 0x428 + 0xb3a))) {
                                let _0x4dac29 = _0x4ffc4c[_0x54056d(0x409)];
                                if (_0x4ffc4c[_0x54056d(0x3e4)](_0x253633[_0x54056d(0x403)](_0x4ffc4c[_0x54056d(0x316)]), -(0x189a + -0x19 * -0x101 + -0x31b2)))
                                    _0x4ffc4c['\x5a\x47\x74\x64\x5a'](CharacterReleaseTotal, _0x498048), _0x498048[_0x54056d(0x25f)]['\x50\x72\x6f\x67\x72\x65\x73\x73'] = -0x1 * 0x1b9d + 0x54a * 0x7 + -0x969, _0x4ffc4c[_0x54056d(0x285)](ChatRoomCharacterUpdate, _0x498048), _0x4dac29 = _0x4ffc4c[_0x54056d(0x44c)];
                                else {
                                    if (_0x253633[_0x54056d(0x403)](_0x4ffc4c[_0x54056d(0x38c)]) != -(0x3 * 0x169 + -0x1471 + 0x1037)) {
                                        if (_0x4ffc4c[_0x54056d(0x338)](_0x4ffc4c['\x55\x67\x67\x42\x52'], _0x4ffc4c[_0x54056d(0x3ae)])) {
                                            const _0x499758 = _0x192cb1 ? function () {
                                                if (_0x563256) {
                                                    const _0x11aa84 = _0x274ed7['\x61\x70\x70\x6c\x79'](_0x133445, arguments);
                                                    return _0x5b2c13 = null, _0x11aa84;
                                                }
                                            } : function () {
                                            };
                                            return _0x4995a1 = ![], _0x499758;
                                        } else {
                                            const _0x2d0f79 = _0x4ffc4c[_0x54056d(0x439)][_0x54056d(0x24b)]('\x7c');
                                            let _0x57fe69 = 0x1 * -0x8ba + 0x163 + 0x757;
                                            while (!![]) {
                                                switch (_0x2d0f79[_0x57fe69++]) {
                                                case '\x30':
                                                    _0x4ffc4c[_0x54056d(0x39b)](InventoryWear, _0x498048, _0x4ffc4c['\x46\x6d\x45\x53\x61'], _0x4ffc4c[_0x54056d(0x2a1)], _0x4ffc4c[_0x54056d(0x28f)], -0x2459c * -0x1 + 0x7 * -0x632f + 0x1859 * 0x17);
                                                    continue;
                                                case '\x31':
                                                    _0x4dac29 = _0x4ffc4c[_0x54056d(0x404)];
                                                    continue;
                                                case '\x32':
                                                    _0x498048[_0x54056d(0x25f)]['\x50\x72\x6f\x67\x72\x65\x73\x73'] = 0xd35 + -0x52 * 0x49 + -0x1 * -0xa2d;
                                                    continue;
                                                case '\x33':
                                                    ChatRoomCharacterUpdate(_0x498048);
                                                    continue;
                                                case '\x34':
                                                    InventoryWear(_0x498048, '\x4c\x65\x61\x74\x68\x65\x72\x41\x72\x6d\x62\x69\x6e\x64\x65\x72', _0x4ffc4c['\x58\x6e\x73\x61\x53'], _0x54056d(0x208), 0x2d1df + -0x7d1 * 0x45 + 0x108c8);
                                                    continue;
                                                }
                                                break;
                                            }
                                        }
                                    } else {
                                        if (_0x4ffc4c['\x61\x5a\x63\x6b\x74'](_0x253633[_0x54056d(0x403)](_0x4ffc4c[_0x54056d(0x2ca)]), -(-0x2304 + -0x6 + 0x230b)))
                                            AwBotBan[_0x54056d(0x424)](_0x498048[_0x54056d(0x306)]), _0x4dac29 = _0x4ffc4c[_0x54056d(0x44a)];
                                        else {
                                            if (_0x4ffc4c[_0x54056d(0x287)](_0x253633['\x69\x6e\x64\x65\x78\x4f\x66'](_0x4ffc4c[_0x54056d(0x37a)]), -(-0x4 * -0x3b + -0x9b2 + 0x8c7)))
                                                _0x4dac29 = _0x4ffc4c[_0x54056d(0x31c)];
                                            else {
                                                if (_0x4ffc4c[_0x54056d(0x1ea)](_0x253633[_0x54056d(0x403)](_0x4ffc4c['\x51\x4f\x66\x70\x65']), -(0x7e5 * -0x1 + -0x7a9 * -0x5 + 0xb5 * -0x2b)))
                                                    _0x4ffc4c[_0x54056d(0x26c)](_0x4ffc4c[_0x54056d(0x1e9)], '\x53\x64\x72\x50\x5a') ? _0x4dac29 = _0x4ffc4c[_0x54056d(0x332)](_0x4ffc4c[_0x54056d(0x332)](_0x54056d(0x2cf), _0x498048[_0x54056d(0x306)]), '\x2e') : _0x5161aa['\x56\x4f\x65\x6f\x4c'](_0x46a0e8, _0x5c4904, _0x230c2d, -0x1 * 0x1a871 + -0xcd6d * 0x2 + 0x5029d);
                                                else {
                                                    if (_0x253633[_0x54056d(0x403)](_0x4ffc4c[_0x54056d(0x314)]) != -(-0x4c3 * 0x8 + 0x13a7 + 0x1272))
                                                        _0x4ffc4c[_0x54056d(0x1fa)]('\x41\x43\x6c\x70\x54', _0x4ffc4c[_0x54056d(0x335)]) ? (InventoryWear(_0x498048, _0x54056d(0x455), _0x54056d(0x38f), _0x4ffc4c[_0x54056d(0x28f)], 0x5 * 0x4b5d + 0x2f * -0xd57 + -0x743f * -0x6), _0x498048[_0x54056d(0x25f)][_0x54056d(0x3d9)] = -0x1 * 0xe65 + 0x1109 + -0x2a4, _0x4ffc4c[_0x54056d(0x2a9)](ChatRoomCharacterUpdate, _0x498048), _0x4dac29 = _0x4ffc4c[_0x54056d(0x3a2)]) : _0x1e5871(_0x2197b4, _0x2ec175[_0x54056d(0x447)], _0x2ec175['\x51\x6e\x54\x46\x49']);
                                                    else {
                                                        if (_0x4ffc4c[_0x54056d(0x3e8)](_0x253633[_0x54056d(0x403)](_0x4ffc4c[_0x54056d(0x348)]), -(-0xa7 * 0x35 + 0x750 + 0x1 * 0x1b44))) {
                                                            if (_0x4ffc4c[_0x54056d(0x3df)](_0x4ffc4c['\x65\x70\x56\x6d\x4f'], '\x5a\x62\x50\x66\x69'))
                                                                _0x498048['\x41\x70\x70\x65\x61\x72\x61\x6e\x63\x65'][_0x54056d(0x3bf)](_0xb23835 => {
                                                                    const _0x5c669d = _0x54056d;
                                                                    let _0x14007f = 0xd72 + 0x2332 * -0x1 + 0xae0 * 0x2;
                                                                    if (_0x2ec175[_0x5c669d(0x434)](_0xb23835[_0x5c669d(0x26b)], 0x1fa3 + -0x1 * 0x236 + -0x1d6d)) {
                                                                        if (_0x2ec175[_0x5c669d(0x315)](_0xb23835['\x50\x72\x6f\x70\x65\x72\x74\x79'], null)) {
                                                                            if (_0x2ec175[_0x5c669d(0x369)](_0x2ec175[_0x5c669d(0x3a5)], _0x2ec175[_0x5c669d(0x375)]))
                                                                                _0xb23835['\x50\x72\x6f\x70\x65\x72\x74\x79'] = {};
                                                                            else {
                                                                                if (_0x2ec175[_0x5c669d(0x2e5)](_0x5a4513['\x4e\x61\x6d\x65'], _0x2ec175['\x6b\x6b\x75\x4e\x4e'])) {
                                                                                    _0x47d0a1(_0x5c669d(0x3cf));
                                                                                    return;
                                                                                }
                                                                            }
                                                                        }
                                                                        _0x2ec175['\x74\x54\x51\x44\x4f'](_0xb23835[_0x5c669d(0x283)][_0x5c669d(0x20e)], null) && (_0xb23835['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x5c669d(0x20e)] = []), _0x2ec175[_0x5c669d(0x2ae)](_0xb23835['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x5c669d(0x20e)][_0x5c669d(0x403)](_0x5c669d(0x1f4)), -0x82d * -0x2 + 0xba5 + -0x1bff) && _0xb23835['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x5c669d(0x20e)][_0x5c669d(0x424)](_0x2ec175['\x6c\x4b\x71\x42\x48']), _0x2ec175['\x73\x70\x51\x41\x76'](Math[_0x5c669d(0x462)](), -0x1cf * -0xd + -0x2027 * 0x1 + -0x13c * -0x7 + 0.5) ? _0x2ec175[_0x5c669d(0x22d)] === _0x2ec175['\x47\x4e\x62\x7a\x57'] ? _0x1aa8e[_0x5c669d(0x283)][_0x5c669d(0x399)] = _0x2ec175[_0x5c669d(0x397)] : _0xb23835[_0x5c669d(0x283)][_0x5c669d(0x399)] = _0x2ec175[_0x5c669d(0x397)] : _0xb23835[_0x5c669d(0x283)][_0x5c669d(0x399)] = _0x5c669d(0x305), _0xb23835[_0x5c669d(0x283)][_0x5c669d(0x417)] = Player[_0x5c669d(0x21b)], _0x498048[_0x5c669d(0x42f)][_0x14007f] = _0xb23835;
                                                                    }
                                                                    _0x14007f++;
                                                                }), _0x498048['\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73'][_0x54056d(0x3d9)] = -0x38e + 0x7ed * -0x2 + 0x1368, _0x4ffc4c[_0x54056d(0x42d)](ChatRoomCharacterUpdate, _0x498048), _0x4dac29 = _0x4ffc4c[_0x54056d(0x3a2)];
                                                            else {
                                                                _0x2ec175['\x79\x58\x6f\x6b\x4b'](_0x1c1e41, _0x2ec175['\x51\x62\x62\x6f\x72']);
                                                                return;
                                                            }
                                                        } else {
                                                            if (_0x4ffc4c[_0x54056d(0x261)](_0x253633[_0x54056d(0x403)](_0x54056d(0x462)), -(-0x1908 + 0xe1d + -0x3 * -0x3a4))) {
                                                                let _0x32afd6 = [
                                                                    _0x4ffc4c[_0x54056d(0x204)],
                                                                    _0x4ffc4c[_0x54056d(0x1f6)],
                                                                    _0x4ffc4c[_0x54056d(0x40b)],
                                                                    _0x54056d(0x410),
                                                                    '\x49\x74\x65\x6d\x44\x65\x76\x69\x63\x65\x73',
                                                                    '\x49\x74\x65\x6d\x45\x61\x72\x73',
                                                                    _0x4ffc4c[_0x54056d(0x2a1)],
                                                                    _0x4ffc4c['\x64\x4a\x42\x58\x58'],
                                                                    _0x4ffc4c[_0x54056d(0x2da)],
                                                                    _0x54056d(0x387),
                                                                    _0x4ffc4c['\x6f\x4a\x46\x49\x63'],
                                                                    _0x4ffc4c[_0x54056d(0x293)],
                                                                    _0x4ffc4c[_0x54056d(0x255)],
                                                                    _0x4ffc4c[_0x54056d(0x2a2)],
                                                                    _0x4ffc4c[_0x54056d(0x1eb)],
                                                                    _0x4ffc4c[_0x54056d(0x371)],
                                                                    _0x4ffc4c[_0x54056d(0x3c1)],
                                                                    _0x4ffc4c[_0x54056d(0x43c)],
                                                                    _0x4ffc4c[_0x54056d(0x402)],
                                                                    _0x4ffc4c['\x5a\x41\x51\x49\x5a'],
                                                                    _0x4ffc4c['\x6c\x46\x71\x4d\x70'],
                                                                    _0x4ffc4c[_0x54056d(0x30f)],
                                                                    _0x4ffc4c[_0x54056d(0x33e)],
                                                                    _0x4ffc4c[_0x54056d(0x429)],
                                                                    _0x4ffc4c[_0x54056d(0x2cb)]
                                                                ];
                                                                _0x32afd6[_0x54056d(0x3bf)](_0x12bde6 => {
                                                                    const _0x1779d0 = _0x54056d;
                                                                    _0x5161aa['\x56\x48\x7a\x48\x6b'](_0x5161aa[_0x1779d0(0x1fe)], _0x5161aa['\x71\x66\x61\x76\x6b']) ? _0x5161aa[_0x1779d0(0x3d4)](InventoryWearRandom, _0x498048, _0x12bde6, 0xfbc3 * -0x2 + -0xb563 + 0x46c3b) : _0x2ec175[_0x1779d0(0x344)](_0x297e0d, _0x2ec175[_0x1779d0(0x334)], 0x39d0 + -0x227 * -0x35 + 0x1136f * 0x1);
                                                                }), _0x498048[_0x54056d(0x25f)][_0x54056d(0x3d9)] = -0x206a + -0xfd8 + 0x3042, _0x4ffc4c[_0x54056d(0x473)](ChatRoomCharacterUpdate, _0x498048), _0x4dac29 = _0x4ffc4c[_0x54056d(0x3a2)];
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                _0x4ffc4c[_0x54056d(0x20c)](ServerSend, _0x4ffc4c[_0x54056d(0x35f)], {
                                    '\x43\x6f\x6e\x74\x65\x6e\x74': _0x4ffc4c['\x67\x49\x45\x67\x7a'](_0x54056d(0x3d1), _0x4dac29),
                                    '\x54\x79\x70\x65': _0x4ffc4c[_0x54056d(0x278)]
                                });
                            } else
                                _0x4ffc4c[_0x54056d(0x36c)](_0x253633[_0x54056d(0x403)](_0x4ffc4c[_0x54056d(0x2c5)]), -(-0x1aa8 + 0x1eba + 0x15b * -0x3)) && _0x4ffc4c['\x64\x52\x6b\x43\x75'](ServerSend, _0x4ffc4c[_0x54056d(0x35f)], {
                                    '\x43\x6f\x6e\x74\x65\x6e\x74': _0x4ffc4c[_0x54056d(0x20d)],
                                    '\x54\x79\x70\x65': _0x4ffc4c[_0x54056d(0x278)]
                                });
                        }
                    } else {
                        if (_0x4ffc4c['\x4b\x47\x66\x52\x6f'](_0x253633[_0x54056d(0x403)](_0x4ffc4c[_0x54056d(0x257)]), -(0x1 * -0x216d + 0x1e36 + -0x8 * -0x67)))
                            ServerSend(_0x4ffc4c['\x58\x58\x4e\x4d\x62'], {
                                '\x43\x6f\x6e\x74\x65\x6e\x74': _0x4ffc4c[_0x54056d(0x222)],
                                '\x54\x79\x70\x65': _0x4ffc4c['\x58\x4b\x4d\x65\x4e']
                            });
                        else {
                            if (_0x253633[_0x54056d(0x403)](_0x4ffc4c[_0x54056d(0x3ca)]) != -(-0x152c + 0x5 * 0x11f + 0xf92)) {
                                if (_0x4ffc4c[_0x54056d(0x41d)](_0x4ffc4c['\x66\x41\x55\x43\x79'], _0x4ffc4c['\x66\x41\x55\x43\x79']))
                                    _0x4ffc4c[_0x54056d(0x20c)](ServerSend, _0x4ffc4c[_0x54056d(0x35f)], {
                                        '\x43\x6f\x6e\x74\x65\x6e\x74': _0x4ffc4c[_0x54056d(0x378)],
                                        '\x54\x79\x70\x65': _0x54056d(0x2f9)
                                    });
                                else
                                    return;
                            }
                        }
                    }
                }
            }, 0x1461 + -0xb * -0x35b + 0x1 * -0x3562);
            AwBotLast = _0x4ffc4c[_0x509e40(0x332)](_0x253633, _0x498048[_0x509e40(0x306)]);
            let _0x3180b2 = _0x253633, _0x4e02ca = _0x4ffc4c[_0x509e40(0x201)](SpeechGetTotalGagLevel, _0x498048, _0x36bc87);
            return _0x4ffc4c[_0x509e40(0x468)](_0x4e02ca, 0x3 * 0x4d1 + -0x937 + 0x86 * -0xa) && (_0x4ffc4c[_0x509e40(0x1fa)](_0x4ffc4c[_0x509e40(0x45a)], _0x509e40(0x366)) ? _0x5161aa[_0x509e40(0x203)](_0x18eaae, _0x509e40(0x3f8), 0x3 * -0xd18b + 0x25c1b * 0x1 + 0x1d7d8) : _0x3180b2 = _0x4ffc4c['\x70\x6b\x42\x59\x71'](_0x509e40(0x252) + _0x4e02ca, '\x20') + _0x3180b2), _0x3180b2;
        };
    }), GM_registerMenuCommand(_0x1cf7bb['\x72\x6e\x43\x76\x67'], () => {
        const _0x11b221 = _0x4466f9, _0xe964 = {
                '\x70\x49\x47\x77\x48': function (_0x4e76a2, _0x490df6, _0x21ec23) {
                    return _0x1cf7bb['\x73\x4a\x55\x54\x50'](_0x4e76a2, _0x490df6, _0x21ec23);
                },
                '\x5a\x74\x73\x6b\x44': _0x1cf7bb[_0x11b221(0x382)],
                '\x67\x4f\x55\x55\x43': _0x1cf7bb['\x50\x59\x4d\x64\x77'],
                '\x67\x52\x76\x79\x49': _0x11b221(0x442),
                '\x70\x67\x62\x42\x63': _0x1cf7bb['\x4d\x70\x70\x4a\x5a']
            };
        if (!(Player[_0x11b221(0x1e7)] && _0x1cf7bb[_0x11b221(0x352)](Player[_0x11b221(0x1e7)][_0x11b221(0x306)], _0x1cf7bb[_0x11b221(0x38e)]))) {
            if (_0x1cf7bb[_0x11b221(0x1e2)](Player[_0x11b221(0x306)], _0x1cf7bb[_0x11b221(0x38e)])) {
                if (_0x1cf7bb['\x54\x6f\x71\x55\x65'](_0x1cf7bb['\x6b\x64\x47\x57\x70'], _0x1cf7bb[_0x11b221(0x27d)])) {
                    _0x1cf7bb[_0x11b221(0x27f)](alert, _0x1cf7bb[_0x11b221(0x234)]);
                    return;
                } else
                    _0xe964[_0x11b221(0x2fe)](_0x149610, _0xe964[_0x11b221(0x31e)], {
                        '\x43\x6f\x6e\x74\x65\x6e\x74': _0x11b221(0x442),
                        '\x54\x79\x70\x65': _0xe964['\x67\x4f\x55\x55\x43'],
                        '\x54\x61\x72\x67\x65\x74': null,
                        '\x44\x69\x63\x74\x69\x6f\x6e\x61\x72\x79': [{
                                '\x54\x61\x67': _0xe964[_0x11b221(0x41f)],
                                '\x54\x65\x78\x74': _0xb40389('\u4f60\u8981\u8bf4\u7684\u8bdd', _0xe964['\x70\x67\x62\x42\x63'])
                            }]
                    });
            }
        }
        AwBotBan = [], ChatRoomNotificationRaiseChatJoin = function (_0x3acc91) {
            const _0x2c3cae = _0x11b221, _0xec5d35 = {
                    '\x65\x4e\x41\x73\x54': function (_0x60f511, _0x2472c5, _0x2f12b3, _0x4e39b3) {
                        const _0x35f1bb = _0x5e23;
                        return _0x1cf7bb[_0x35f1bb(0x445)](_0x60f511, _0x2472c5, _0x2f12b3, _0x4e39b3);
                    },
                    '\x70\x69\x7a\x45\x4e': _0x1cf7bb[_0x2c3cae(0x2bb)],
                    '\x4b\x6e\x45\x59\x67': '\x49\x74\x65\x6d\x42\x75\x74\x74',
                    '\x72\x45\x69\x50\x4a': _0x1cf7bb[_0x2c3cae(0x431)],
                    '\x61\x6f\x6f\x73\x67': _0x2c3cae(0x2bc),
                    '\x4f\x67\x79\x48\x4b': _0x1cf7bb[_0x2c3cae(0x2cd)],
                    '\x53\x67\x66\x79\x72': _0x1cf7bb[_0x2c3cae(0x2ad)],
                    '\x4d\x75\x77\x42\x71': '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68\x32',
                    '\x74\x46\x79\x5a\x74': _0x1cf7bb[_0x2c3cae(0x3f4)],
                    '\x64\x64\x64\x54\x66': _0x1cf7bb[_0x2c3cae(0x357)],
                    '\x54\x4b\x6c\x52\x72': _0x1cf7bb[_0x2c3cae(0x269)],
                    '\x46\x43\x73\x7a\x62': _0x1cf7bb[_0x2c3cae(0x265)],
                    '\x56\x62\x4b\x52\x7a': _0x2c3cae(0x415),
                    '\x71\x47\x5a\x70\x4c': _0x1cf7bb[_0x2c3cae(0x3a7)],
                    '\x79\x50\x65\x48\x70': _0x1cf7bb['\x46\x48\x54\x51\x41'],
                    '\x6f\x53\x76\x54\x5a': function (_0x2ce798, _0x1ab5a0) {
                        const _0x2ed4b1 = _0x2c3cae;
                        return _0x1cf7bb[_0x2ed4b1(0x438)](_0x2ce798, _0x1ab5a0);
                    },
                    '\x63\x57\x6f\x56\x6d': function (_0x3dee39, _0x2e5abb) {
                        return _0x1cf7bb['\x4b\x46\x64\x75\x42'](_0x3dee39, _0x2e5abb);
                    },
                    '\x4e\x41\x77\x49\x65': _0x2c3cae(0x317),
                    '\x51\x65\x7a\x48\x68': _0x1cf7bb[_0x2c3cae(0x29d)],
                    '\x47\x6d\x64\x61\x6a': function (_0x199f84, _0x2ce71e) {
                        const _0x1fc7dc = _0x2c3cae;
                        return _0x1cf7bb[_0x1fc7dc(0x220)](_0x199f84, _0x2ce71e);
                    },
                    '\x56\x57\x68\x68\x53': function (_0x540bff, _0x2b3a5f) {
                        const _0x194f4a = _0x2c3cae;
                        return _0x1cf7bb[_0x194f4a(0x1ed)](_0x540bff, _0x2b3a5f);
                    },
                    '\x56\x44\x48\x43\x41': function (_0x401af7, _0x47fc0d) {
                        const _0x4cd342 = _0x2c3cae;
                        return _0x1cf7bb[_0x4cd342(0x31f)](_0x401af7, _0x47fc0d);
                    },
                    '\x41\x64\x56\x73\x47': _0x1cf7bb[_0x2c3cae(0x2af)],
                    '\x58\x75\x75\x4a\x4a': function (_0x2f1881, _0x59990d) {
                        const _0x477e78 = _0x2c3cae;
                        return _0x1cf7bb[_0x477e78(0x345)](_0x2f1881, _0x59990d);
                    },
                    '\x58\x5a\x65\x59\x71': '\x43\x4d\x74\x57\x74',
                    '\x41\x66\x64\x44\x69': _0x1cf7bb[_0x2c3cae(0x226)],
                    '\x62\x5a\x55\x4f\x69': function (_0x198c1f, _0x5ecf7a, _0x13aacc, _0xda5179) {
                        const _0x1bb503 = _0x2c3cae;
                        return _0x1cf7bb[_0x1bb503(0x445)](_0x198c1f, _0x5ecf7a, _0x13aacc, _0xda5179);
                    },
                    '\x59\x63\x64\x72\x44': function (_0x347a27, _0xb0c554) {
                        return _0x347a27 == _0xb0c554;
                    },
                    '\x68\x6d\x65\x52\x78': _0x1cf7bb[_0x2c3cae(0x3a0)],
                    '\x77\x79\x6e\x6e\x63': _0x1cf7bb[_0x2c3cae(0x24e)],
                    '\x6c\x5a\x75\x44\x51': _0x1cf7bb[_0x2c3cae(0x3ce)],
                    '\x79\x46\x4b\x52\x70': _0x1cf7bb[_0x2c3cae(0x422)],
                    '\x62\x74\x4b\x74\x78': _0x1cf7bb[_0x2c3cae(0x25b)],
                    '\x54\x6d\x70\x57\x64': _0x2c3cae(0x347),
                    '\x72\x6f\x48\x41\x63': _0x1cf7bb[_0x2c3cae(0x448)],
                    '\x78\x6f\x4a\x6b\x69': _0x2c3cae(0x229),
                    '\x4b\x59\x7a\x4e\x50': function (_0x3d0423, _0x36d0d4) {
                        const _0xd64e01 = _0x2c3cae;
                        return _0x1cf7bb[_0xd64e01(0x43e)](_0x3d0423, _0x36d0d4);
                    }
                };
            if (_0x1cf7bb[_0x2c3cae(0x407)] !== _0x1cf7bb[_0x2c3cae(0x407)])
                return;
            else
                return setTimeout(function () {
                    const _0x10ea54 = _0x2c3cae, _0x4a6e84 = {
                            '\x41\x6e\x69\x63\x45': function (_0x2da4a9, _0x298368, _0x8e5495, _0xc4efcc) {
                                const _0x263f26 = _0x5e23;
                                return _0xec5d35[_0x263f26(0x33c)](_0x2da4a9, _0x298368, _0x8e5495, _0xc4efcc);
                            },
                            '\x76\x4a\x6e\x57\x41': _0x10ea54(0x29c),
                            '\x67\x6f\x53\x50\x57': function (_0x2905e7, _0x23b1cd) {
                                return _0x2905e7(_0x23b1cd);
                            },
                            '\x4a\x76\x55\x44\x41': _0xec5d35[_0x10ea54(0x453)]
                        };
                    if (_0xec5d35[_0x10ea54(0x420)](AwBotBan[_0x10ea54(0x403)](_0x3acc91[_0x10ea54(0x306)]), -(-0x124d + -0x26bb + 0x5d * 0x9d))) {
                        let _0x386e6a = [
                            _0xec5d35['\x68\x6d\x65\x52\x78'],
                            _0xec5d35[_0x10ea54(0x3ad)],
                            _0xec5d35[_0x10ea54(0x236)],
                            _0xec5d35['\x4b\x6e\x45\x59\x67'],
                            _0xec5d35[_0x10ea54(0x45c)],
                            _0xec5d35['\x72\x45\x69\x50\x4a'],
                            _0x10ea54(0x346),
                            _0xec5d35['\x79\x46\x4b\x52\x70'],
                            '\x49\x74\x65\x6d\x48\x65\x61\x64',
                            _0x10ea54(0x387),
                            _0xec5d35[_0x10ea54(0x326)],
                            _0xec5d35[_0x10ea54(0x3cb)],
                            _0xec5d35[_0x10ea54(0x435)],
                            _0xec5d35[_0x10ea54(0x3f7)],
                            '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68\x33',
                            _0xec5d35['\x74\x46\x79\x5a\x74'],
                            _0xec5d35['\x54\x6d\x70\x57\x64'],
                            _0x10ea54(0x254),
                            _0xec5d35[_0x10ea54(0x275)],
                            _0xec5d35[_0x10ea54(0x40c)],
                            _0xec5d35[_0x10ea54(0x279)],
                            _0xec5d35['\x54\x4b\x6c\x52\x72'],
                            _0xec5d35[_0x10ea54(0x22b)],
                            '\x49\x74\x65\x6d\x56\x75\x6c\x76\x61',
                            _0xec5d35[_0x10ea54(0x35e)]
                        ];
                        _0x386e6a[_0x10ea54(0x3bf)](_0x5ac205 => {
                            const _0x55f4e5 = _0x10ea54;
                            _0x4a6e84[_0x55f4e5(0x3d5)](InventoryWearRandom, _0x3acc91, _0x5ac205, 0x20020 + 0x2b80f + 0x2f8dd * -0x1);
                        }), _0x3acc91[_0x10ea54(0x42f)][_0x10ea54(0x3bf)](_0x1c5400 => {
                            const _0x537acf = _0x10ea54, _0x33eb18 = {
                                    '\x79\x47\x6a\x49\x6f': function (_0x1abc27, _0x2a3797, _0x552ec9, _0x234d10) {
                                        const _0x851c38 = _0x5e23;
                                        return _0xec5d35[_0x851c38(0x303)](_0x1abc27, _0x2a3797, _0x552ec9, _0x234d10);
                                    },
                                    '\x54\x71\x44\x64\x54': _0xec5d35[_0x537acf(0x3ad)],
                                    '\x6a\x74\x6a\x79\x75': _0x537acf(0x2ba),
                                    '\x52\x46\x68\x61\x4c': _0xec5d35['\x4b\x6e\x45\x59\x67'],
                                    '\x65\x6d\x42\x68\x54': _0xec5d35[_0x537acf(0x393)],
                                    '\x6d\x54\x55\x53\x43': _0x537acf(0x346),
                                    '\x78\x4d\x6c\x76\x72': _0x537acf(0x2e4),
                                    '\x55\x44\x46\x5a\x6f': _0xec5d35[_0x537acf(0x35a)],
                                    '\x45\x5a\x72\x71\x4c': _0xec5d35[_0x537acf(0x326)],
                                    '\x79\x48\x74\x62\x49': _0xec5d35[_0x537acf(0x435)],
                                    '\x77\x49\x50\x76\x58': _0xec5d35['\x4d\x75\x77\x42\x71'],
                                    '\x4c\x74\x65\x6f\x54': _0xec5d35[_0x537acf(0x277)],
                                    '\x74\x4a\x67\x76\x4b': _0x537acf(0x347),
                                    '\x79\x48\x68\x65\x41': _0x537acf(0x254),
                                    '\x51\x4e\x71\x66\x57': _0xec5d35[_0x537acf(0x275)],
                                    '\x6d\x4a\x61\x5a\x6e': _0x537acf(0x2ed),
                                    '\x73\x4c\x66\x50\x6a': _0xec5d35[_0x537acf(0x242)],
                                    '\x50\x76\x58\x75\x6d': _0xec5d35[_0x537acf(0x22b)],
                                    '\x73\x67\x69\x56\x43': _0xec5d35[_0x537acf(0x440)],
                                    '\x6b\x4d\x64\x6a\x47': _0xec5d35[_0x537acf(0x35e)],
                                    '\x6a\x5a\x72\x57\x52': _0xec5d35[_0x537acf(0x42b)]
                                };
                            let _0x2c2c06 = -0x1170 + -0x1df9 + -0x2f69 * -0x1;
                            if (_0xec5d35[_0x537acf(0x38d)](_0x1c5400[_0x537acf(0x26b)], -0x218d + -0x4 * -0x66f + 0x1d * 0x45)) {
                                if (_0xec5d35[_0x537acf(0x20a)](_0xec5d35[_0x537acf(0x212)], _0xec5d35['\x51\x65\x7a\x48\x68'])) {
                                    const _0x24f8fe = {
                                        '\x64\x4d\x42\x50\x79': function (_0x130450, _0x590269, _0x314034, _0x17bf2f) {
                                            const _0x508f96 = _0x537acf;
                                            return _0x33eb18[_0x508f96(0x21c)](_0x130450, _0x590269, _0x314034, _0x17bf2f);
                                        }
                                    };
                                    let _0x2aeb49 = [
                                        '\x49\x74\x65\x6d\x41\x72\x6d\x73',
                                        _0x33eb18[_0x537acf(0x264)],
                                        _0x33eb18['\x6a\x74\x6a\x79\x75'],
                                        _0x33eb18[_0x537acf(0x1fb)],
                                        _0x537acf(0x414),
                                        _0x33eb18['\x65\x6d\x42\x68\x54'],
                                        _0x33eb18[_0x537acf(0x3cd)],
                                        _0x33eb18[_0x537acf(0x35c)],
                                        _0x33eb18['\x55\x44\x46\x5a\x6f'],
                                        _0x537acf(0x387),
                                        _0x33eb18[_0x537acf(0x237)],
                                        _0x537acf(0x294),
                                        _0x33eb18[_0x537acf(0x3e5)],
                                        _0x33eb18[_0x537acf(0x408)],
                                        '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68\x33',
                                        _0x33eb18[_0x537acf(0x2e9)],
                                        _0x33eb18[_0x537acf(0x3f1)],
                                        _0x33eb18[_0x537acf(0x323)],
                                        _0x33eb18[_0x537acf(0x3f6)],
                                        _0x33eb18[_0x537acf(0x2c0)],
                                        _0x537acf(0x229),
                                        _0x33eb18['\x73\x4c\x66\x50\x6a'],
                                        _0x33eb18[_0x537acf(0x327)],
                                        _0x33eb18[_0x537acf(0x3c8)],
                                        _0x33eb18['\x6b\x4d\x64\x6a\x47']
                                    ];
                                    _0x2aeb49[_0x537acf(0x3bf)](_0x3b3c47 => {
                                        _0x24f8fe['\x64\x4d\x42\x50\x79'](_0x2c5aaa, _0x5bf50d, _0x3b3c47, 0x28d * 0xb5 + -0x33f5 * 0x1 + 0x2596 * 0x1);
                                    }), _0x5b5884[_0x537acf(0x25f)][_0x537acf(0x3d9)] = 0x1e69 + 0x1edd + -0x17 * 0x2aa, _0x477944(_0x46585c), _0x367719 = _0x33eb18[_0x537acf(0x2fc)];
                                } else
                                    _0x1c5400[_0x537acf(0x283)] == null && (_0xec5d35['\x47\x6d\x64\x61\x6a'](_0x537acf(0x28e), _0x537acf(0x28e)) ? !(_0x56418e['\x4f\x77\x6e\x65\x72\x73\x68\x69\x70'] && _0x48b6f7['\x4f\x77\x6e\x65\x72\x73\x68\x69\x70']['\x4e\x61\x6d\x65'] == _0x4a6e84[_0x537acf(0x469)]) && _0x4a6e84['\x67\x6f\x53\x50\x57'](_0x4fbfc9, _0x1d2f23) : _0x1c5400[_0x537acf(0x283)] = {}), _0xec5d35[_0x537acf(0x426)](_0x1c5400[_0x537acf(0x283)][_0x537acf(0x20e)], null) && (_0x1c5400[_0x537acf(0x283)][_0x537acf(0x20e)] = []), _0xec5d35[_0x537acf(0x419)](_0x1c5400[_0x537acf(0x283)]['\x45\x66\x66\x65\x63\x74'][_0x537acf(0x403)](_0xec5d35[_0x537acf(0x453)]), -0x37a * -0x6 + -0x45c + -0x30 * 0x58) && _0x1c5400[_0x537acf(0x283)][_0x537acf(0x20e)][_0x537acf(0x424)](_0x537acf(0x1f4)), _0xec5d35[_0x537acf(0x364)](Math['\x72\x61\x6e\x64\x6f\x6d'](), 0xcec + 0xd * -0x111 + 0xf1 + 0.5) ? _0x1c5400[_0x537acf(0x283)][_0x537acf(0x399)] = '\x4d\x69\x73\x74\x72\x65\x73\x73\x50\x61\x64\x6c\x6f\x63\x6b' : _0xec5d35[_0x537acf(0x457)] === _0xec5d35[_0x537acf(0x1de)] ? _0x3b9809[_0x537acf(0x283)][_0x537acf(0x20e)][_0x537acf(0x424)](_0x4a6e84['\x4a\x76\x55\x44\x41']) : _0x1c5400[_0x537acf(0x283)]['\x4c\x6f\x63\x6b\x65\x64\x42\x79'] = _0x537acf(0x305), _0x1c5400[_0x537acf(0x283)][_0x537acf(0x417)] = Player[_0x537acf(0x21b)], _0x3acc91[_0x537acf(0x42f)][_0x2c2c06] = _0x1c5400;
                            }
                            _0x2c2c06++;
                        }), _0x3acc91[_0x10ea54(0x25f)][_0x10ea54(0x3d9)] = -0x1eb0 + 0x27 * -0xa4 + 0x37ac, _0xec5d35[_0x10ea54(0x3eb)](ChatRoomCharacterUpdate, _0x3acc91), AwBotBan['\x70\x75\x73\x68'](_0x3acc91[_0x10ea54(0x306)]);
                    }
                }, 0x3c * 0x7d + 0x2459 + -0x3dbd), !![];
        };
    }), _0x1cf7bb[_0x4466f9(0x425)](GM_registerMenuCommand, _0x1cf7bb['\x43\x76\x61\x47\x44'], () => {
        const _0x45b885 = _0x4466f9, _0x45599f = {
                '\x51\x67\x49\x77\x6f': function (_0x53a692, _0x82ca8c) {
                    return _0x1cf7bb['\x62\x7a\x53\x41\x71'](_0x53a692, _0x82ca8c);
                },
                '\x65\x73\x6b\x45\x4b': _0x1cf7bb[_0x45b885(0x234)]
            };
        if (_0x1cf7bb[_0x45b885(0x388)](_0x1cf7bb['\x65\x63\x44\x48\x61'], _0x1cf7bb['\x50\x54\x5a\x56\x65'])) {
            _0x45599f[_0x45b885(0x46e)](_0x428a2a, _0x45599f[_0x45b885(0x370)]);
            return;
        } else
            ChatRoomNotificationRaiseChatJoin = function (_0x3cbd2b) {
                return !![];
            };
    }), _0x1cf7bb['\x62\x4a\x46\x6a\x6b'](GM_registerMenuCommand, _0x1cf7bb[_0x4466f9(0x2b8)], () => {
        const _0x1b6b83 = _0x4466f9, _0x35b087 = {};
        _0x35b087[_0x1b6b83(0x32b)] = _0x1cf7bb[_0x1b6b83(0x3cc)];
        const _0xaccf4a = _0x35b087;
        if (_0x1cf7bb[_0x1b6b83(0x34a)](_0x1b6b83(0x3c3), _0x1cf7bb[_0x1b6b83(0x2e6)]))
            targetName = prompt(_0x1b6b83(0x39f), _0x1cf7bb[_0x1b6b83(0x38e)]), _0x1cf7bb[_0x1b6b83(0x3fc)](AwBotBan[_0x1b6b83(0x403)](targetName), -(-0x11f6 * -0x2 + 0x8e * -0x2b + -0xc11)) && (_0x1cf7bb['\x45\x74\x49\x76\x70'](_0x1b6b83(0x322), _0x1cf7bb[_0x1b6b83(0x3dd)]) ? _0x1cf7bb[_0x1b6b83(0x43e)](alert, _0x1cf7bb[_0x1b6b83(0x36b)]) : _0x33449f[_0x1b6b83(0x283)]['\x4c\x6f\x63\x6b\x65\x64\x42\x79'] = _0xaccf4a[_0x1b6b83(0x32b)]), AwBotBan[_0x1b6b83(0x424)](targetName);
        else {
            if (_0x291c0b) {
                const _0x32333a = _0x4b9d34[_0x1b6b83(0x2e8)](_0x374968, arguments);
                return _0x3568ad = null, _0x32333a;
            }
        }
    }), _0x1cf7bb[_0x4466f9(0x1f2)](GM_registerMenuCommand, '\x61\x77\x42\x4f\x54\x5f\u89e3\u5c01', () => {
        const _0x4348cb = _0x4466f9;
        targetName = prompt(_0x1cf7bb[_0x4348cb(0x2b5)], _0x1cf7bb[_0x4348cb(0x38e)]), banIndex = AwBotBan[_0x4348cb(0x403)](targetName), _0x1cf7bb[_0x4348cb(0x2f6)](banIndex, -(0x53 * -0x1a + 0x1fed + -0x177e)) && _0x1cf7bb[_0x4348cb(0x43e)](alert, _0x4348cb(0x25c)), AwBotBan[_0x4348cb(0x1e0)](banIndex, -0x260 + 0x1ae6 + -0x1885);
    }), _0x1cf7bb[_0x4466f9(0x271)](GM_registerMenuCommand, _0x4466f9(0x465), () => {
        const _0xac8274 = _0x4466f9, _0x1d8731 = {
                '\x66\x56\x79\x72\x75': function (_0x55cc8e, _0x4ae104) {
                    const _0xf5ab24 = _0x5e23;
                    return _0x1cf7bb[_0xf5ab24(0x26e)](_0x55cc8e, _0x4ae104);
                },
                '\x72\x71\x59\x6d\x53': function (_0x2164ba, _0x35d2ee) {
                    return _0x2164ba + _0x35d2ee;
                },
                '\x75\x44\x6f\x45\x77': function (_0x2c9b23) {
                    const _0xed3bea = _0x5e23;
                    return _0x1cf7bb[_0xed3bea(0x361)](_0x2c9b23);
                },
                '\x66\x72\x68\x76\x43': _0x1cf7bb[_0xac8274(0x396)],
                '\x47\x64\x68\x43\x4e': _0x1cf7bb['\x42\x7a\x64\x73\x49'],
                '\x6d\x67\x43\x76\x70': _0xac8274(0x3e1),
                '\x6d\x68\x63\x66\x4f': _0xac8274(0x328),
                '\x6a\x4b\x6d\x69\x63': _0x1cf7bb[_0xac8274(0x288)],
                '\x56\x56\x4b\x58\x54': function (_0x48c3de, _0x4d195d) {
                    const _0x38f272 = _0xac8274;
                    return _0x1cf7bb[_0x38f272(0x31f)](_0x48c3de, _0x4d195d);
                },
                '\x68\x64\x66\x6b\x54': function (_0x315a70, _0x38faf9) {
                    return _0x315a70 === _0x38faf9;
                },
                '\x44\x66\x6e\x62\x68': '\x78\x59\x69\x65\x71',
                '\x4e\x74\x73\x72\x7a': function (_0x53e0e6, _0x39a394, _0x47294f) {
                    const _0x3e1b1b = _0xac8274;
                    return _0x1cf7bb[_0x3e1b1b(0x2cc)](_0x53e0e6, _0x39a394, _0x47294f);
                },
                '\x70\x74\x54\x62\x4e': function (_0x52f9f7, _0x196393) {
                    return _0x1cf7bb['\x53\x46\x42\x42\x6b'](_0x52f9f7, _0x196393);
                },
                '\x62\x64\x6d\x69\x74': _0xac8274(0x225),
                '\x61\x6f\x69\x61\x56': function (_0x4c605f, _0x92f504) {
                    const _0x110f2b = _0xac8274;
                    return _0x1cf7bb[_0x110f2b(0x263)](_0x4c605f, _0x92f504);
                },
                '\x74\x64\x6c\x74\x64': function (_0x30c459, _0x200cd7) {
                    const _0xd5f647 = _0xac8274;
                    return _0x1cf7bb[_0xd5f647(0x232)](_0x30c459, _0x200cd7);
                },
                '\x6e\x70\x5a\x56\x4b': function (_0x123363, _0x30b019) {
                    return _0x1cf7bb['\x45\x69\x5a\x42\x4d'](_0x123363, _0x30b019);
                },
                '\x76\x4d\x54\x77\x46': _0x1cf7bb[_0xac8274(0x250)]
            };
        SpeechGarble = function (_0x2096e1, _0x12551d, _0x4cb7aa) {
            const _0x14473d = _0xac8274, _0x188c14 = {
                    '\x54\x69\x63\x45\x44': function (_0x36f6b2, _0x23b8b7) {
                        const _0x355049 = _0x5e23;
                        return _0x1d8731[_0x355049(0x3be)](_0x36f6b2, _0x23b8b7);
                    },
                    '\x57\x48\x46\x78\x43': function (_0x1e95d9, _0x9dd7d7) {
                        return _0x1d8731['\x72\x71\x59\x6d\x53'](_0x1e95d9, _0x9dd7d7);
                    },
                    '\x61\x47\x46\x55\x6c': function (_0x401ece) {
                        const _0x58dd3f = _0x5e23;
                        return _0x1d8731[_0x58dd3f(0x3a4)](_0x401ece);
                    },
                    '\x77\x63\x69\x58\x57': _0x1d8731['\x66\x72\x68\x76\x43'],
                    '\x4c\x62\x58\x66\x53': _0x1d8731[_0x14473d(0x28c)],
                    '\x54\x62\x4a\x7a\x50': _0x1d8731[_0x14473d(0x1fd)],
                    '\x6c\x76\x51\x4f\x70': _0x1d8731[_0x14473d(0x3b0)],
                    '\x67\x77\x6c\x69\x49': _0x1d8731[_0x14473d(0x2b0)],
                    '\x72\x69\x58\x4d\x59': function (_0x1f72f0, _0x4274b7) {
                        return _0x1d8731['\x56\x56\x4b\x58\x54'](_0x1f72f0, _0x4274b7);
                    }
                };
            if (_0x1d8731['\x68\x64\x66\x6b\x54'](_0x1d8731[_0x14473d(0x24c)], _0x14473d(0x289))) {
                let _0x59527f = _0x12551d, _0x1987dd = _0x1d8731[_0x14473d(0x28b)](SpeechGetTotalGagLevel, _0x2096e1, _0x4cb7aa);
                if (_0x1d8731[_0x14473d(0x228)](_0x1987dd, -0xc93 + -0xb * -0x36d + -0x191c)) {
                    if (_0x14473d(0x225) !== _0x1d8731[_0x14473d(0x441)])
                        return !![];
                    else
                        _0x59527f = _0x1d8731[_0x14473d(0x392)](_0x1d8731[_0x14473d(0x25e)](_0x1d8731[_0x14473d(0x27a)](_0x1d8731[_0x14473d(0x41c)], _0x1987dd), '\x20'), _0x59527f);
                }
                return _0x59527f;
            } else {
                let _0x19d8fc;
                try {
                    const _0x10727c = qEmYAV[_0x14473d(0x1df)](_0x157744, qEmYAV['\x57\x48\x46\x78\x43'](_0x14473d(0x340), '\x7b\x7d\x2e\x63\x6f\x6e\x73\x74\x72\x75\x63\x74\x6f\x72\x28\x22\x72\x65\x74\x75\x72\x6e\x20\x74\x68\x69\x73\x22\x29\x28\x20\x29') + '\x29\x3b');
                    _0x19d8fc = qEmYAV[_0x14473d(0x2f3)](_0x10727c);
                } catch (_0x18e465) {
                    _0x19d8fc = _0x40dfae;
                }
                const _0x12ab4c = _0x19d8fc[_0x14473d(0x2e2)] = _0x19d8fc['\x63\x6f\x6e\x73\x6f\x6c\x65'] || {}, _0x3416e0 = [
                        qEmYAV[_0x14473d(0x243)],
                        qEmYAV[_0x14473d(0x2dd)],
                        qEmYAV[_0x14473d(0x3fb)],
                        '\x65\x72\x72\x6f\x72',
                        qEmYAV[_0x14473d(0x44f)],
                        qEmYAV['\x67\x77\x6c\x69\x49'],
                        '\x74\x72\x61\x63\x65'
                    ];
                for (let _0x4a044a = -0x21a5 + 0x71d + 0x1a88; qEmYAV['\x72\x69\x58\x4d\x59'](_0x4a044a, _0x3416e0[_0x14473d(0x2ef)]); _0x4a044a++) {
                    const _0xaa3571 = _0x319d0c[_0x14473d(0x262)][_0x14473d(0x3b7)]['\x62\x69\x6e\x64'](_0x2dfdd1), _0xe40763 = _0x3416e0[_0x4a044a], _0x529c6a = _0x12ab4c[_0xe40763] || _0xaa3571;
                    _0xaa3571[_0x14473d(0x360)] = _0x3a5d32[_0x14473d(0x35d)](_0x3153e8), _0xaa3571[_0x14473d(0x313)] = _0x529c6a[_0x14473d(0x313)][_0x14473d(0x35d)](_0x529c6a), _0x12ab4c[_0xe40763] = _0xaa3571;
                }
            }
        };
    }), _0x1cf7bb[_0x4466f9(0x3fa)](GM_registerMenuCommand, _0x1cf7bb[_0x4466f9(0x325)], () => {
        const _0x2cead9 = _0x4466f9;
        _0x1cf7bb[_0x2cead9(0x445)](InventoryWear, targetMember, _0x1cf7bb['\x41\x74\x48\x46\x5a'], _0x1cf7bb[_0x2cead9(0x25b)]);
    }), _0x1cf7bb['\x62\x63\x4a\x77\x5a'](GM_registerMenuCommand, _0x4466f9(0x40a), () => {
        const _0x356afb = _0x4466f9;
        _0x1cf7bb['\x77\x50\x4d\x64\x58'](alert, _0x1cf7bb[_0x356afb(0x272)]), _0x1cf7bb[_0x356afb(0x2bd)](CharacterChangeMoney, Player, 0x17 * 0x56 + -0x15c * 0x17 + -0x17ee * -0x1);
    }), GM_registerMenuCommand(_0x4466f9(0x2fb), () => {
        const _0x3643d6 = _0x4466f9;
        if (!(Player[_0x3643d6(0x1e7)] && _0x1cf7bb[_0x3643d6(0x2d6)](Player[_0x3643d6(0x1e7)][_0x3643d6(0x306)], _0x3643d6(0x29c)))) {
            if (_0x1cf7bb[_0x3643d6(0x223)](Player['\x4e\x61\x6d\x65'], _0x1cf7bb[_0x3643d6(0x38e)])) {
                _0x1cf7bb[_0x3643d6(0x26e)](alert, _0x3643d6(0x3cf));
                return;
            }
        }
        if (CurrentScreen == _0x1cf7bb[_0x3643d6(0x320)]) {
            const _0x45e2bd = _0x1cf7bb[_0x3643d6(0x2e1)][_0x3643d6(0x24b)]('\x7c');
            let _0x1a6279 = -0x90 + -0x1 * 0x53d + 0x1ef * 0x3;
            while (!![]) {
                switch (_0x45e2bd[_0x1a6279++]) {
                case '\x30':
                    ChatSearchExit();
                    continue;
                case '\x31':
                    ChatRoomClearAllElements();
                    continue;
                case '\x32':
                    _0x1cf7bb[_0x3643d6(0x224)](ServerSend, _0x1cf7bb[_0x3643d6(0x217)], '');
                    continue;
                case '\x33':
                    ChatRoomLeashPlayer = null;
                    continue;
                case '\x34':
                    DialogLentLockpicks = ![];
                    continue;
                case '\x35':
                    _0x1cf7bb[_0x3643d6(0x34e)](CommonSetScreen, '\x4f\x6e\x6c\x69\x6e\x65', _0x1cf7bb[_0x3643d6(0x3de)]);
                    continue;
                case '\x36':
                    _0x1cf7bb['\x58\x76\x63\x46\x48'](CharacterDeleteAllOnline);
                    continue;
                case '\x37':
                    ChatRoomSetLastChatRoom('');
                    continue;
                }
                break;
            }
        } else
            _0x1cf7bb[_0x3643d6(0x456)](MainHallWalk, _0x1cf7bb['\x47\x50\x62\x73\x54']);
    }), _0x1cf7bb['\x62\x4a\x46\x6a\x6b'](GM_registerMenuCommand, _0x1cf7bb['\x62\x4e\x57\x68\x42'], () => {
        StruggleProgress = 0x1345 + -0x99a + -0x92e;
    }), _0x1cf7bb[_0x4466f9(0x3fa)](GM_registerMenuCommand, _0x4466f9(0x412), () => {
        const _0x4fc75a = _0x4466f9;
        _0x1cf7bb[_0x4fc75a(0x224)](SkillProgress, _0x1cf7bb[_0x4fc75a(0x33d)], -0xdd7 * 0x17 + 0x1 * -0x33fad + 0x63d50);
    }), _0x1cf7bb[_0x4466f9(0x452)](GM_registerMenuCommand, _0x4466f9(0x2b1), () => {
        const _0x5d3017 = _0x4466f9;
        _0x1cf7bb[_0x5d3017(0x342)](SkillProgress, _0x5d3017(0x2d3), -0x1e948 + 0x7 * -0x6735 + 0x67b0d);
    }), GM_registerMenuCommand(_0x1cf7bb[_0x4466f9(0x33b)], () => {
        const _0x1f398b = _0x4466f9;
        _0x1cf7bb[_0x1f398b(0x247)](SkillProgress, '\x4c\x6f\x63\x6b\x50\x69\x63\x6b\x69\x6e\x67', 0x221b3 + 0x12589 + -0x18b * 0xfe);
    }), GM_registerMenuCommand(_0x4466f9(0x372), () => {
        const _0x36e69e = _0x4466f9;
        _0x1cf7bb[_0x36e69e(0x1f3)](_0x1cf7bb['\x57\x4b\x56\x76\x77'], _0x36e69e(0x3ba)) ? _0x174c53 = -0x3 * 0x892 + -0x693 + 0xa * 0x347 : _0x1cf7bb[_0x36e69e(0x3fa)](SkillProgress, _0x1cf7bb[_0x36e69e(0x22f)], -0x31cfa * -0x1 + 0xa019 + -0x1fdc1);
    }), _0x1cf7bb[_0x4466f9(0x3ff)](GM_registerMenuCommand, _0x1cf7bb[_0x4466f9(0x2d5)], () => {
        const _0x128ef7 = _0x4466f9;
        Player[_0x128ef7(0x26b)][_0x128ef7(0x36f)] = -0x1ff1 + -0x2500 + 0x44f1;
    }), _0x1cf7bb[_0x4466f9(0x26f)](GM_registerMenuCommand, _0x1cf7bb['\x55\x48\x74\x42\x65'], () => {
        const _0xd25f8d = _0x4466f9;
        _0x1cf7bb[_0xd25f8d(0x2b7)](_0x1cf7bb[_0xd25f8d(0x2b3)], _0x1cf7bb[_0xd25f8d(0x2b3)]) ? (_0x125e78 = _0x1a2765(_0x1cf7bb[_0xd25f8d(0x3c5)], '\x61\x77\x61\x71\x77\x71'), _0x1cf7bb['\x69\x77\x45\x78\x4b'](_0x472928[_0xd25f8d(0x403)](_0x2f8f23), -(0x1 * 0x7a7 + -0x3ab + 0x3fb * -0x1)) && _0x241b63(_0x1cf7bb[_0xd25f8d(0x36b)]), _0x329783[_0xd25f8d(0x424)](_0x4fd249)) : _0x1cf7bb[_0xd25f8d(0x26f)](SkillProgress, _0x1cf7bb['\x4c\x63\x61\x62\x6e'], -0x2e819 + 0x2b * 0xf89 + -0x20b68 * -0x1);
    }), _0x1cf7bb[_0x4466f9(0x2bd)](GM_registerMenuCommand, _0x4466f9(0x45e), () => {
        const _0x509d2d = _0x4466f9;
        _0x1cf7bb[_0x509d2d(0x26d)](SkillProgress, _0x1cf7bb[_0x509d2d(0x2dc)], -0x100d9 * 0x1 + 0x2a05f + -0x14 * -0x197);
    }), _0x1cf7bb['\x62\x4a\x46\x6a\x6b'](GM_registerMenuCommand, _0x1cf7bb[_0x4466f9(0x258)], () => {
        const _0xef5b39 = _0x4466f9;
        _0x1cf7bb[_0xef5b39(0x224)](SkillProgress, _0x1cf7bb[_0xef5b39(0x300)], -0x2c93a + 0x3432b + 0x14561);
    }), GM_registerMenuCommand(_0x4466f9(0x251), () => {
        const _0x6c603b = _0x4466f9, _0x54bd17 = {};
        _0x54bd17[_0x6c603b(0x2ab)] = _0x1cf7bb['\x43\x56\x47\x6e\x73'];
        const _0x5bab3a = _0x54bd17;
        _0x1cf7bb[_0x6c603b(0x33f)](_0x6c603b(0x329), _0x1cf7bb['\x50\x67\x6f\x4b\x65']) ? _0x64e3b1[_0x6c603b(0x283)]['\x4c\x6f\x63\x6b\x65\x64\x42\x79'] = _0x5bab3a[_0x6c603b(0x2ab)] : (_0x1cf7bb[_0x6c603b(0x32a)](InventoryWear, Player, _0x6c603b(0x3fe), _0x1cf7bb['\x46\x57\x50\x67\x4b'], _0x1cf7bb[_0x6c603b(0x386)], 0x33b39 + 0x31530 + -0x49117), InventoryWear(Player, _0x6c603b(0x2d9), _0x1cf7bb[_0x6c603b(0x227)], _0x1cf7bb['\x53\x52\x53\x4f\x79'], -0x9 * 0x1272 + -0x31587 + 0x57adb), _0x1cf7bb[_0x6c603b(0x244)](InventoryWear, Player, _0x1cf7bb[_0x6c603b(0x319)], _0x1cf7bb[_0x6c603b(0x265)], _0x1cf7bb[_0x6c603b(0x386)], -0x3492a + 0x355e3 + 0x1b299), _0x1cf7bb[_0x6c603b(0x244)](InventoryWear, Player, _0x1cf7bb[_0x6c603b(0x310)], _0x6c603b(0x28d), _0x1cf7bb[_0x6c603b(0x386)], -0x21d4 + -0x1 * -0x2b899 + -0xd773), _0x1cf7bb[_0x6c603b(0x244)](InventoryWear, Player, _0x1cf7bb[_0x6c603b(0x3ec)], _0x1cf7bb[_0x6c603b(0x3b9)], _0x1cf7bb[_0x6c603b(0x386)], -0x1e80a + 0x74bc + -0x60 * -0x887), InventoryWear(Player, '\x4c\x65\x61\x74\x68\x65\x72\x42\x65\x6c\x74', _0x1cf7bb[_0x6c603b(0x2cd)], _0x1cf7bb[_0x6c603b(0x386)], 0x27ea3 + 0x37b2d + -0x43a7e), _0x1cf7bb[_0x6c603b(0x3e0)](InventoryWear, Player, _0x6c603b(0x464), _0x6c603b(0x346), _0x1cf7bb[_0x6c603b(0x386)], -0x1 * 0x2f71d + -0xf1d3 + 0x5a842), _0x1cf7bb[_0x6c603b(0x3e0)](InventoryWear, Player, _0x1cf7bb[_0x6c603b(0x299)], _0x1cf7bb['\x4a\x6e\x50\x4a\x6e'], _0x1cf7bb[_0x6c603b(0x386)], -0x16 * -0xe6b + 0xd22c + -0x500c), InventoryWear(Player, _0x1cf7bb['\x79\x68\x78\x4b\x6d'], _0x1cf7bb[_0x6c603b(0x422)], _0x1cf7bb[_0x6c603b(0x386)], 0xde9 * -0xb + 0x13a24 + 0x11e31));
    }), _0x1cf7bb[_0x4466f9(0x452)](GM_registerMenuCommand, _0x1cf7bb[_0x4466f9(0x2c2)], () => {
        const _0x1d0f06 = _0x4466f9;
        _0x1cf7bb[_0x1d0f06(0x42e)](InventoryWear, Player, _0x1d0f06(0x2fa), _0x1cf7bb[_0x1d0f06(0x25b)]);
    }), _0x1cf7bb[_0x4466f9(0x37b)](GM_registerMenuCommand, _0x1cf7bb[_0x4466f9(0x40e)], () => {
        const _0x5b74b3 = _0x4466f9;
        !(Player[_0x5b74b3(0x1e7)] && _0x1cf7bb[_0x5b74b3(0x307)](Player[_0x5b74b3(0x1e7)][_0x5b74b3(0x306)], '\x61\x77\x61\x71\x77\x71')) && (_0x1cf7bb['\x54\x6a\x57\x68\x69'] === _0x1cf7bb['\x46\x61\x66\x66\x50'] ? _0x50e0c8[_0x5b74b3(0x283)] = {} : CharacterReleaseTotal(Player));
    }), _0x1cf7bb[_0x4466f9(0x3db)](GM_registerMenuCommand, _0x1cf7bb['\x4f\x6d\x71\x6a\x72'], () => {
        const _0x2e367c = _0x4466f9;
        _0x1cf7bb[_0x2e367c(0x2bd)](ServerSend, _0x1cf7bb[_0x2e367c(0x382)], {
            '\x43\x6f\x6e\x74\x65\x6e\x74': _0x1cf7bb[_0x2e367c(0x30b)],
            '\x54\x79\x70\x65': _0x1cf7bb[_0x2e367c(0x23a)],
            '\x54\x61\x72\x67\x65\x74': null,
            '\x44\x69\x63\x74\x69\x6f\x6e\x61\x72\x79': [{
                    '\x54\x61\x67': _0x1cf7bb['\x6b\x4b\x54\x67\x69'],
                    '\x54\x65\x78\x74': _0x1cf7bb[_0x2e367c(0x342)](prompt, _0x1cf7bb[_0x2e367c(0x312)], _0x1cf7bb[_0x2e367c(0x20f)])
                }]
        });
    }), _0x1cf7bb['\x62\x63\x4a\x77\x5a'](GM_registerMenuCommand, _0x4466f9(0x3c2), () => {
        const _0x3cf1b5 = _0x4466f9, _0x2c704d = {
                '\x4f\x67\x65\x76\x58': _0x1cf7bb[_0x3cf1b5(0x276)],
                '\x73\x58\x79\x53\x4f': function (_0x137b61, _0x13e0e8, _0x9bca21, _0x532c87, _0xa722bf, _0x19164b) {
                    return _0x1cf7bb['\x69\x65\x79\x46\x4b'](_0x137b61, _0x13e0e8, _0x9bca21, _0x532c87, _0xa722bf, _0x19164b);
                },
                '\x67\x50\x45\x59\x6d': _0x1cf7bb[_0x3cf1b5(0x365)],
                '\x41\x69\x6f\x4e\x43': _0x3cf1b5(0x301),
                '\x69\x5a\x6e\x56\x55': _0x3cf1b5(0x208),
                '\x43\x45\x42\x79\x64': _0x3cf1b5(0x464),
                '\x65\x43\x54\x44\x47': function (_0x5d9508, _0xfb2d7, _0x51882f, _0x1d6127, _0x5e1d68, _0x48f2e8) {
                    const _0x2d16e1 = _0x3cf1b5;
                    return _0x1cf7bb[_0x2d16e1(0x384)](_0x5d9508, _0xfb2d7, _0x51882f, _0x1d6127, _0x5e1d68, _0x48f2e8);
                },
                '\x7a\x46\x48\x4e\x56': _0x1cf7bb['\x62\x7a\x6a\x57\x4e'],
                '\x4a\x59\x57\x55\x45': _0x1cf7bb[_0x3cf1b5(0x265)],
                '\x46\x51\x6b\x43\x6c': function (_0x228ae9, _0x4740ea, _0x5dbd50, _0x3f43f5, _0x2a441c, _0x872f9b) {
                    return _0x228ae9(_0x4740ea, _0x5dbd50, _0x3f43f5, _0x2a441c, _0x872f9b);
                },
                '\x55\x72\x78\x68\x76': _0x1cf7bb[_0x3cf1b5(0x3a8)],
                '\x66\x59\x64\x52\x70': _0x1cf7bb['\x4f\x64\x6d\x46\x4a'],
                '\x6c\x78\x4b\x49\x78': function (_0xc9cc68, _0x5a07cb, _0x328b01, _0x67321e, _0x5a2c66, _0x37603a) {
                    return _0x1cf7bb['\x69\x65\x79\x46\x4b'](_0xc9cc68, _0x5a07cb, _0x328b01, _0x67321e, _0x5a2c66, _0x37603a);
                },
                '\x4d\x57\x45\x4a\x66': _0x3cf1b5(0x2d9),
                '\x67\x78\x6e\x78\x50': _0x1cf7bb[_0x3cf1b5(0x227)],
                '\x6d\x44\x78\x50\x54': function (_0x513a43, _0x1c108d, _0x43d979, _0x23cbdb, _0x145fff, _0x457a3f) {
                    const _0x288900 = _0x3cf1b5;
                    return _0x1cf7bb[_0x288900(0x282)](_0x513a43, _0x1c108d, _0x43d979, _0x23cbdb, _0x145fff, _0x457a3f);
                },
                '\x44\x61\x4b\x4a\x78': _0x1cf7bb['\x59\x4d\x46\x43\x59'],
                '\x42\x52\x4a\x68\x4b': _0x1cf7bb[_0x3cf1b5(0x3b9)],
                '\x66\x78\x49\x49\x4a': function (_0x467bde, _0x1d01fb, _0x17bdf1, _0x26a878, _0x4ab2d8, _0x221fee) {
                    const _0x222a96 = _0x3cf1b5;
                    return _0x1cf7bb[_0x222a96(0x351)](_0x467bde, _0x1d01fb, _0x17bdf1, _0x26a878, _0x4ab2d8, _0x221fee);
                },
                '\x71\x59\x49\x6a\x55': _0x1cf7bb[_0x3cf1b5(0x39c)],
                '\x68\x6a\x47\x78\x56': _0x1cf7bb[_0x3cf1b5(0x422)],
                '\x5a\x4f\x79\x65\x63': _0x1cf7bb['\x4a\x6e\x50\x4a\x6e'],
                '\x72\x6e\x6f\x63\x6b': _0x1cf7bb[_0x3cf1b5(0x3f4)]
            };
        targetName = _0x1cf7bb[_0x3cf1b5(0x3fa)](prompt, _0x3cf1b5(0x433), _0x1cf7bb[_0x3cf1b5(0x38e)]), targetMember = Character[_0x3cf1b5(0x34d)](_0x51dc87 => _0x51dc87[_0x3cf1b5(0x306)][_0x3cf1b5(0x2c9)]() == targetName);
        if (_0x1cf7bb[_0x3cf1b5(0x2d6)](targetMember, null)) {
            if (_0x1cf7bb[_0x3cf1b5(0x388)](_0x1cf7bb[_0x3cf1b5(0x3d7)], _0x1cf7bb[_0x3cf1b5(0x2ec)])) {
                const _0x4474e6 = _0x2c704d[_0x3cf1b5(0x245)][_0x3cf1b5(0x24b)]('\x7c');
                let _0x8f4472 = -0x3 * 0xae5 + 0x1b57 + 0x3 * 0x1c8;
                while (!![]) {
                    switch (_0x4474e6[_0x8f4472++]) {
                    case '\x30':
                        _0x2c704d['\x73\x58\x79\x53\x4f'](_0x3e20ae, _0x55afa4, _0x2c704d[_0x3cf1b5(0x209)], _0x2c704d[_0x3cf1b5(0x3c7)], _0x2c704d['\x69\x5a\x6e\x56\x55'], -0x1952e + -0x847 * -0x65 + 0x107d);
                        continue;
                    case '\x31':
                        _0x200908(_0x2ab8f7, _0x2c704d[_0x3cf1b5(0x3b5)], _0x3cf1b5(0x346), _0x2c704d[_0x3cf1b5(0x200)], -0x1d9a3 + -0x13f56 + 0x4d84b);
                        continue;
                    case '\x32':
                        _0x2c704d[_0x3cf1b5(0x266)](_0xc8ac78, _0x198855, _0x2c704d[_0x3cf1b5(0x2a3)], _0x2c704d[_0x3cf1b5(0x45f)], _0x3cf1b5(0x208), 0x1e720 + 0xb * 0x48b + -0x2f * 0x1e9);
                        continue;
                    case '\x33':
                        _0x2c704d['\x46\x51\x6b\x43\x6c'](_0x30d4dc, _0x5c10e8, _0x2c704d['\x55\x72\x78\x68\x76'], _0x2c704d[_0x3cf1b5(0x46f)], _0x2c704d[_0x3cf1b5(0x200)], -0x2b79f + 0x2c02c + 0x1b6c5);
                        continue;
                    case '\x34':
                        _0x2c704d[_0x3cf1b5(0x1f0)](_0xac9ed5, _0x4d9348, _0x2c704d[_0x3cf1b5(0x451)], _0x2c704d[_0x3cf1b5(0x2e3)], _0x2c704d[_0x3cf1b5(0x200)], 0x1fc97 * -0x1 + -0x28cb8 + 0x648a1);
                        continue;
                    case '\x35':
                        _0x2c704d[_0x3cf1b5(0x21f)](_0x3e0ab4, _0x173a3d, _0x2c704d['\x44\x61\x4b\x4a\x78'], _0x2c704d[_0x3cf1b5(0x291)], _0x2c704d[_0x3cf1b5(0x200)], 0x2303a + -0x1a7d7 * -0x1 + -0x218bf * 0x1);
                        continue;
                    case '\x36':
                        _0x2c704d['\x66\x78\x49\x49\x4a'](_0x4c1ca4, _0x293650, _0x2c704d[_0x3cf1b5(0x2df)], _0x2c704d[_0x3cf1b5(0x3aa)], '\x23\x32\x30\x32\x30\x32\x30', -0x27da * 0x9 + -0x35f4 + 0xd6fc * 0x4);
                        continue;
                    case '\x37':
                        _0x2c704d['\x6c\x78\x4b\x49\x78'](_0x46b9be, _0x447654, _0x3cf1b5(0x2c1), _0x2c704d[_0x3cf1b5(0x43a)], _0x2c704d[_0x3cf1b5(0x200)], -0x2cd2e + 0x4de * 0x1 + 0x487a2);
                        continue;
                    case '\x38':
                        _0x2c704d[_0x3cf1b5(0x2a7)](_0x2b3cc9, _0x45cab1, _0x3cf1b5(0x461), _0x2c704d[_0x3cf1b5(0x390)], _0x2c704d['\x69\x5a\x6e\x56\x55'], -0x6485 * -0x7 + 0x33399 + -0x433ea);
                        continue;
                    }
                    break;
                }
            } else
                return;
        }
        CharacterReleaseTotal(targetMember), targetMember[_0x3cf1b5(0x25f)][_0x3cf1b5(0x3d9)] = -0x19d8 + 0x35 * 0x13 + 0x15e9, ChatRoomCharacterUpdate(targetMember);
    }), _0x1cf7bb['\x73\x4a\x55\x54\x50'](GM_registerMenuCommand, _0x4466f9(0x3f3), () => {
        const _0x176695 = _0x4466f9, _0x479dbc = _0x1cf7bb[_0x176695(0x2eb)][_0x176695(0x24b)]('\x7c');
        let _0xcd1d31 = 0x2 * -0xce5 + 0x2bb * -0xa + 0x3518;
        while (!![]) {
            switch (_0x479dbc[_0xcd1d31++]) {
            case '\x30':
                _0x1cf7bb['\x58\x77\x64\x43\x6f'](ChatRoomCharacterUpdate, targetMember);
                continue;
            case '\x31':
                targetMember[_0x176695(0x25f)][_0x176695(0x3d9)] = -0x1c94 + 0x1e8d * -0x1 + -0x1 * -0x3b21;
                continue;
            case '\x32':
                if (_0x1cf7bb[_0x176695(0x2c3)](targetMember, null))
                    return;
                continue;
            case '\x33':
                targetMember = Character[_0x176695(0x34d)](_0x222fb5 => _0x222fb5['\x4e\x61\x6d\x65'][_0x176695(0x2c9)]() == targetName);
                continue;
            case '\x34':
                _0x1cf7bb['\x78\x4f\x5a\x4b\x70'](InventoryWear, targetMember, _0x1cf7bb[_0x176695(0x30e)], _0x176695(0x346), '\x23\x32\x30\x32\x30\x32\x30', -0x18e8f + 0x378ae + 0x2acd * -0x1);
                continue;
            case '\x35':
                if (!(Player[_0x176695(0x1e7)] && _0x1cf7bb[_0x176695(0x3b6)](Player['\x4f\x77\x6e\x65\x72\x73\x68\x69\x70'][_0x176695(0x306)], _0x176695(0x29c)))) {
                    if (Player[_0x176695(0x306)] != _0x176695(0x29c)) {
                        _0x1cf7bb['\x64\x6d\x70\x58\x6d'](alert, _0x1cf7bb[_0x176695(0x234)]);
                        return;
                    }
                }
                continue;
            case '\x36':
                _0x1cf7bb[_0x176695(0x21a)](InventoryWear, targetMember, _0x1cf7bb['\x71\x79\x59\x42\x70'], _0x1cf7bb[_0x176695(0x3a0)], _0x1cf7bb[_0x176695(0x386)], -0xec0c * 0x2 + 0x1c0ff * 0x1 + 0xb79 * 0x29);
                continue;
            case '\x37':
                targetName = prompt(_0x176695(0x368), _0x1cf7bb[_0x176695(0x38e)]);
                continue;
            }
            break;
        }
    }), _0x1cf7bb['\x44\x6f\x4a\x63\x47'](GM_registerMenuCommand, _0x1cf7bb[_0x4466f9(0x297)], () => {
        const _0x336e13 = _0x4466f9, _0x39e2ee = {
                '\x4d\x69\x50\x79\x57': _0x1cf7bb['\x6b\x58\x6a\x63\x75'],
                '\x66\x42\x4d\x74\x4f': function (_0x59ed56, _0x2066ea) {
                    const _0x22dc5e = _0x5e23;
                    return _0x1cf7bb[_0x22dc5e(0x240)](_0x59ed56, _0x2066ea);
                },
                '\x51\x6e\x56\x70\x42': _0x336e13(0x45d),
                '\x4a\x50\x5a\x58\x78': _0x1cf7bb[_0x336e13(0x466)],
                '\x68\x62\x69\x52\x44': function (_0xd02f50, _0x311554) {
                    return _0xd02f50 > _0x311554;
                },
                '\x44\x4d\x56\x79\x49': _0x336e13(0x305),
                '\x72\x4a\x4b\x45\x79': function (_0x572c0b, _0x910565) {
                    const _0x3f1dca = _0x336e13;
                    return _0x1cf7bb[_0x3f1dca(0x22c)](_0x572c0b, _0x910565);
                },
                '\x76\x63\x6f\x77\x6c': '\x4c\x6f\x63\x6b'
            };
        if (_0x1cf7bb['\x4e\x47\x4e\x6f\x6f'] !== _0x1cf7bb[_0x336e13(0x355)])
            _0x1788f4[_0x336e13(0x283)][_0x336e13(0x20e)] = [];
        else {
            if (!(Player['\x4f\x77\x6e\x65\x72\x73\x68\x69\x70'] && Player[_0x336e13(0x1e7)][_0x336e13(0x306)] == _0x1cf7bb['\x57\x4b\x79\x67\x69'])) {
                if (_0x1cf7bb[_0x336e13(0x444)] !== _0x1cf7bb[_0x336e13(0x273)]) {
                    if (_0x1cf7bb['\x4c\x68\x46\x78\x57'](Player[_0x336e13(0x306)], _0x1cf7bb[_0x336e13(0x38e)])) {
                        if (_0x1cf7bb[_0x336e13(0x240)](_0x1cf7bb[_0x336e13(0x354)], _0x1cf7bb[_0x336e13(0x354)]))
                            _0x515f2b[_0x336e13(0x283)][_0x336e13(0x20e)][_0x336e13(0x424)](_0x336e13(0x1f4));
                        else {
                            _0x1cf7bb[_0x336e13(0x26e)](alert, _0x336e13(0x3cf));
                            return;
                        }
                    }
                } else {
                    const _0x5447b6 = QJDSFN[_0x336e13(0x26e)](_0x3f1e7f, QJDSFN[_0x336e13(0x302)](QJDSFN['\x73\x51\x79\x67\x4d'](QJDSFN['\x70\x65\x77\x56\x69'], _0x336e13(0x2a8)), '\x29\x3b'));
                    _0x33fc43 = QJDSFN[_0x336e13(0x474)](_0x5447b6);
                }
            }
            targetName = _0x1cf7bb[_0x336e13(0x2bd)](prompt, '\u8981\u4e0a\u9501\u7684\u73a9\u5bb6\u540d\u79f0\x28\u5168\u5c0f\u5199\x29', _0x1cf7bb[_0x336e13(0x38e)]), targetMember = Character[_0x336e13(0x34d)](_0x467680 => _0x467680[_0x336e13(0x306)][_0x336e13(0x2c9)]() == targetName);
            if (_0x1cf7bb[_0x336e13(0x24f)](targetMember, null)) {
                if (_0x1cf7bb[_0x336e13(0x220)](_0x1cf7bb[_0x336e13(0x230)], _0x336e13(0x406)))
                    return;
                else
                    _0x1cf7bb[_0x336e13(0x42e)](_0x175058, _0x1cf7bb[_0x336e13(0x26d)](_0x43fd8f, _0x1cf7bb[_0x336e13(0x30c)], _0x336e13(0x3f9)), 0x74 * 0x43c + 0x1c328 * 0x1 + -0x2 * 0xf783, !![]);
            }
            targetMember[_0x336e13(0x42f)][_0x336e13(0x3bf)](_0x42f91a => {
                const _0x5d53c5 = _0x336e13;
                if (_0x39e2ee['\x66\x42\x4d\x74\x4f'](_0x5d53c5(0x37e), _0x39e2ee['\x51\x6e\x56\x70\x42'])) {
                    let _0x488e05 = -0x2352 + 0x1 * -0x1731 + 0x3a83;
                    if (_0x42f91a[_0x5d53c5(0x26b)] > 0xb * 0x5e + 0x1 * 0x1aca + -0x1ed4) {
                        const _0x4ee11f = _0x39e2ee[_0x5d53c5(0x213)][_0x5d53c5(0x24b)]('\x7c');
                        let _0x150113 = 0x1 * -0x61b + 0x395 * -0x6 + 0x1b99;
                        while (!![]) {
                            switch (_0x4ee11f[_0x150113++]) {
                            case '\x30':
                                _0x42f91a[_0x5d53c5(0x283)] == null && (_0x42f91a[_0x5d53c5(0x283)] = {});
                                continue;
                            case '\x31':
                                _0x42f91a[_0x5d53c5(0x283)][_0x5d53c5(0x417)] = Player[_0x5d53c5(0x21b)];
                                continue;
                            case '\x32':
                                _0x42f91a[_0x5d53c5(0x283)][_0x5d53c5(0x20e)] == null && (_0x42f91a[_0x5d53c5(0x283)][_0x5d53c5(0x20e)] = []);
                                continue;
                            case '\x33':
                                targetMember[_0x5d53c5(0x42f)][_0x488e05] = _0x42f91a;
                                continue;
                            case '\x34':
                                _0x39e2ee[_0x5d53c5(0x22e)](Math[_0x5d53c5(0x462)](), 0x7 * 0x4bd + -0x1cce + -0x1 * 0x45d + 0.5) ? _0x42f91a[_0x5d53c5(0x283)][_0x5d53c5(0x399)] = '\x4d\x69\x73\x74\x72\x65\x73\x73\x50\x61\x64\x6c\x6f\x63\x6b' : _0x42f91a[_0x5d53c5(0x283)][_0x5d53c5(0x399)] = _0x39e2ee[_0x5d53c5(0x1e6)];
                                continue;
                            case '\x35':
                                _0x39e2ee[_0x5d53c5(0x33a)](_0x42f91a['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x5d53c5(0x20e)][_0x5d53c5(0x403)](_0x39e2ee[_0x5d53c5(0x1f7)]), -0x3e0 + -0x1885 + 0x1c65) && _0x42f91a['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x5d53c5(0x20e)][_0x5d53c5(0x424)](_0x39e2ee['\x76\x63\x6f\x77\x6c']);
                                continue;
                            }
                            break;
                        }
                    }
                    _0x488e05++;
                } else
                    _0x5c5bf6(_0x39e2ee[_0x5d53c5(0x23e)], -0x32e4 * -0x10 + 0x2a3a3 * -0x1 + 0x134b5);
            }), targetMember['\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73'][_0x336e13(0x3d9)] = -0xf2 * 0x1f + -0x203e + 0x3d8c, _0x1cf7bb[_0x336e13(0x43e)](ChatRoomCharacterUpdate, targetMember);
        }
    }), _0x1cf7bb['\x58\x75\x49\x41\x53'](GM_registerMenuCommand, _0x1cf7bb[_0x4466f9(0x32e)], () => {
        const _0x52cc3d = _0x4466f9;
        _0x1cf7bb[_0x52cc3d(0x32c)](ReputationChange, prompt(_0x1cf7bb[_0x52cc3d(0x30c)], _0x1cf7bb['\x51\x45\x68\x6e\x61']), -0x1250 + -0x2 * 0xd631 + 0x37e04, !![]);
    });
}()));
function _0x5e23(_0x406486, _0x5e23c2) {
    const _0x5bdae2 = _0x4064();
    return _0x5e23 = function (_0x2d1bbc, _0x2c3636) {
        _0x2d1bbc = _0x2d1bbc - (-0x2505 + -0x225b + -0x1 * -0x493d);
        let _0x1b2649 = _0x5bdae2[_0x2d1bbc];
        return _0x1b2649;
    }, _0x5e23(_0x406486, _0x5e23c2);
}
function _0x4064() {
    const _0x1d28cb = [
        '\x6b\x47\x53\x57\x59',
        '\x47\x55\x63\x67\x75',
        '\u5e7b\u5f71\u79fb\u5f62\x28\u80fd\u7ed9\u522b\u4eba\u5f00\u9501\x29',
        '\x4f\x50\x49\x48\x75',
        '\x4c\x6f\x63\x6b\x50\x69\x63\x6b\x69\x6e\x67',
        '\x44\x79\x4e\x42\x6f',
        '\x41\x70\x6f\x74\x6c',
        '\x41\x69\x6f\x4e\x43',
        '\x73\x67\x69\x56\x43',
        '\x69\x74\x66\x6a\x5a',
        '\x6a\x58\x6c\x75\x44',
        '\x62\x74\x4b\x74\x78',
        '\x58\x55\x6d\x49\x6b',
        '\x6d\x54\x55\x53\x43',
        '\x4f\x58\x48\x66\x79',
        '\u4f60\u5fc5\u987b\u662f\x61\x77\x61\x71\x77\x71\u7684\x73\x75\x62\u624d\u80fd\u8fd9\u4e48\u505a\u5462\x7e',
        '\x49\x6e\x66\x69\x6c\x74\x72\x61\x74\x69\x6f\x6e',
        '\x61\x77\x42\x4f\x54\x20',
        '\x34\x7c\x30\x7c\x32\x7c\x33\x7c\x31',
        '\x70\x6c\x4f\x50\x49',
        '\x4c\x79\x52\x6a\x50',
        '\x41\x6e\x69\x63\x45',
        '\x6b\x6b\x75\x4e\x4e',
        '\x46\x71\x49\x51\x4c',
        '\x6c\x71\x41\x78\x73',
        '\x50\x72\x6f\x67\x72\x65\x73\x73',
        '\x57\x69\x52\x57\x4c',
        '\x58\x69\x76\x4c\x72',
        '\x70\x7a\x64\x67\x49',
        '\x77\x6f\x51\x71\x50',
        '\x6f\x43\x4d\x75\x59',
        '\x6f\x59\x6f\x46\x72',
        '\x78\x4f\x5a\x4b\x70',
        '\x69\x6e\x66\x6f',
        '\x65\x72\x72\x6f\x72',
        '\x50\x6f\x48\x51\x61',
        '\x61\x5a\x63\x6b\x74',
        '\x79\x48\x74\x62\x49',
        '\x69\x56\x56\x4f\x51',
        '\x4f\x73\x6e\x6b\x4c',
        '\x72\x6d\x47\x75\x41',
        '\x74\x46\x52\x51\x64',
        '\x30\x7c\x32\x7c\x35\x7c\x34\x7c\x31\x7c\x33',
        '\x4b\x59\x7a\x4e\x50',
        '\x59\x4d\x46\x43\x59',
        '\x46\x6d\x45\x53\x61',
        '\x42\x6f\x6e\x64\x61\x67\x65',
        '\x77\x64\x64\x46\x62',
        '\x42\x51\x70\x6a\x75',
        '\x74\x4a\x67\x76\x4b',
        '\x61\x77\x42\x4f\x54',
        '\u901f\u901f\u7ed1\u7f1a\x28\u641e\u4e8b\u60c5\u4e13\u7528\x29',
        '\x75\x4d\x76\x49\x50',
        '\x62\x6f\x6e\x64\x61\x67\x65',
        '\x51\x4e\x71\x66\x57',
        '\x4d\x75\x77\x42\x71',
        '\x45\x76\x61\x73\x69\x6f\x6e',
        '\x44\x6f\x6d\x69\x6e\x61\x6e\x74\x20\x20\x4b\x69\x64\x6e\x61\x70\x20\x20\x41\x42\x44\x4c\x20\x20\x47\x61\x6d\x69\x6e\x67\x20\x20\x4d\x61\x69\x64\x20\x20\x4c\x41\x52\x50\x20\x20\x41\x73\x79\x6c\x75\x6d\x20\x20\x47\x61\x6d\x62\x6c\x69\x6e\x67\x20\x20\x48\x6f\x75\x73\x65\x4d\x61\x69\x65\x73\x74\x61\x73\x20\x20\x48\x6f\x75\x73\x65\x56\x69\x6e\x63\x75\x6c\x61\x20\x20\x48\x6f\x75\x73\x65\x41\x6d\x70\x6c\x65\x63\x74\x6f\x72\x20\x20\x48\x6f\x75\x73\x65\x43\x6f\x72\x70\x6f\x72\x69\x73',
        '\x44\x6f\x4a\x63\x47',
        '\x54\x62\x4a\x7a\x50',
        '\x69\x78\x6c\x76\x66',
        '\x54\x51\x67\x62\x59',
        '\x57\x69\x66\x66\x6c\x65\x47\x61\x67',
        '\x45\x64\x6b\x41\x6d',
        '\x4c\x64\x70\x55\x5a',
        '\x62\x71\x67\x50\x55',
        '\x53\x69\x69\x4c\x6b',
        '\x69\x6e\x64\x65\x78\x4f\x66',
        '\x4a\x6f\x53\x53\x48',
        '\x72\x63\x41\x76\x63',
        '\x52\x6f\x48\x45\x76',
        '\x51\x47\x78\x6a\x73',
        '\x77\x49\x50\x76\x58',
        '\x45\x7a\x55\x44\x4a',
        '\u83b7\u5f97\u96f6\u82b1\u94b1',
        '\x58\x67\x62\x68\x41',
        '\x72\x6f\x48\x41\x63',
        '\u548c\u6211\u7b7e\u8ba2\u5951\u7ea6\uff0c\u6210\u4e3a\u9b54\u6cd5\u5c11\u5973\u5427\uff01',
        '\x4d\x50\x4b\x4b\x53',
        '\x77\x4c\x6c\x79\x4a',
        '\x49\x74\x65\x6d\x42\x75\x74\x74',
        '\x36\x7c\x31\x7c\x37\x7c\x33\x7c\x30\x7c\x32\x7c\x35\x7c\x34',
        '\u63d0\u5347\u6346\u7ed1\u7b49\u7ea7',
        '\x46\x48\x54\x51\x41',
        '\x49\x74\x65\x6d\x44\x65\x76\x69\x63\x65\x73',
        '\x49\x74\x65\x6d\x56\x75\x6c\x76\x61',
        '\x71\x47\x51\x41\x67',
        '\x4c\x6f\x63\x6b\x4d\x65\x6d\x62\x65\x72\x4e\x75\x6d\x62\x65\x72',
        '\x4e\x52\x6e\x68\x6f',
        '\x56\x44\x48\x43\x41',
        '\x4e\x4a\x73\x51\x43',
        '\x6d\x4a\x48\x4f\x49',
        '\x76\x4d\x54\x77\x46',
        '\x52\x61\x69\x46\x6d',
        '\x39\x37\x30\x72\x77\x46\x4f\x66\x41',
        '\x67\x52\x76\x79\x49',
        '\x59\x63\x64\x72\x44',
        '\x41\x65\x63\x4c\x54',
        '\x50\x53\x66\x6d\x63',
        '\x35\x32\x34\x39\x35\x35\x54\x53\x78\x78\x6e\x53',
        '\x70\x75\x73\x68',
        '\x53\x4c\x41\x6e\x4a',
        '\x56\x57\x68\x68\x53',
        '\x42\x7a\x64\x73\x49',
        '\x49\x6b\x57\x6d\x55',
        '\x50\x54\x71\x71\x7a',
        '\x31\x54\x6c\x74\x4c\x71\x44',
        '\x79\x50\x65\x48\x70',
        '\x54\x68\x52\x73\x63',
        '\x75\x4f\x64\x43\x46',
        '\x76\x48\x47\x6d\x6b',
        '\x41\x70\x70\x65\x61\x72\x61\x6e\x63\x65',
        '\x48\x4e\x4c\x61\x45',
        '\x58\x6a\x4d\x4b\x58',
        '\x61\x77\x42\x4f\x54\x20\x43\x61\x53\x65\x20\x53\x65\x4e\x73\x49\x74\x49\x76\x45\x21',
        '\u8981\u89e3\u9501\u7684\u73a9\u5bb6\u540d\u79f0\x28\u5168\u5c0f\u5199\x29',
        '\x57\x73\x64\x6e\x71',
        '\x53\x67\x66\x79\x72',
        '\x76\x61\x45\x6a\x6a',
        '\x6c\x46\x71\x4d\x70',
        '\x73\x46\x41\x78\x53',
        '\x71\x75\x62\x47\x47',
        '\x5a\x4f\x79\x65\x63',
        '\x50\x44\x77\x43\x49',
        '\x6c\x42\x4a\x68\x68',
        '\x6b\x74\x78\x67\x69',
        '\x59\x6a\x44\x68\x46',
        '\x76\x62\x55\x6e\x63',
        '\x56\x62\x4b\x52\x7a',
        '\x62\x64\x6d\x69\x74',
        '\x42\x65\x65\x70',
        '\u62ff\u7bb1\u5b50',
        '\x6c\x45\x77\x51\x66',
        '\x4d\x6a\x42\x66\x70',
        '\x33\x35\x34\x38\x36\x34\x69\x6c\x77\x6d\x54\x76',
        '\x41\x74\x70\x4e\x70',
        '\x4a\x78\x62\x63\x6a',
        '\x63\x67\x6f\x43\x51',
        '\x62\x50\x4f\x65\x54',
        '\x79\x64\x50\x68\x7a',
        '\x47\x6c\x57\x41\x74',
        '\x5a\x7a\x73\x58\x71',
        '\x5a\x47\x74\x64\x5a',
        '\x6c\x76\x51\x4f\x70',
        '\x4e\x59\x6c\x77\x55',
        '\x4d\x57\x45\x4a\x66',
        '\x56\x43\x56\x4d\x77',
        '\x41\x64\x56\x73\x47',
        '\x44\x53\x71\x75\x77',
        '\x42\x69\x74\x63\x68\x53\x75\x69\x74',
        '\x47\x63\x72\x6e\x68',
        '\x58\x5a\x65\x59\x71',
        '\x49\x74\x65\x6d\x4e\x69\x70\x70\x6c\x65\x73',
        '\x77\x59\x54\x4b\x57',
        '\x68\x41\x72\x72\x68',
        '\x54\x79\x72\x59\x4b',
        '\x6c\x5a\x75\x44\x51',
        '\x50\x4f\x79\x47\x72',
        '\u63d0\u5347\u5185\u9b3c\u7b49\u7ea7',
        '\x4a\x59\x57\x55\x45',
        '\x6f\x4a\x46\x49\x63',
        '\x53\x74\x65\x65\x6c\x50\x6f\x73\x74\x75\x72\x65\x43\x6f\x6c\x6c\x61\x72',
        '\x72\x61\x6e\x64\x6f\x6d',
        '\x47\x45\x62\x6d\x75',
        '\x49\x72\x69\x73\x68\x38\x43\x75\x66\x66\x73',
        '\u53e3\u7403\u7834\u8bd1',
        '\x7a\x4c\x45\x6b\x6a',
        '\x49\x74\x65\x6d\x56\x75\x6c\x76\x61\x50\x69\x65\x72\x63\x69\x6e\x67\x73',
        '\x4b\x59\x6f\x76\x65',
        '\x76\x4a\x6e\x57\x41',
        '\x76\x31\x2e\x30\x37\x20\x62\x79\x20\x68\x75\x7a\x70\x73\x62\x20\x2f\x20\x53\x72\x63\x20\x77\x69\x6c\x6c\x20\x62\x65\x20\x6f\x6e\x20\x67\x69\x74\x68\x75\x62\x20\x73\x6f\x6f\x6e',
        '\x4f\x75\x53\x42\x48',
        '\x6c\x62\x63\x6f\x58',
        '\x42\x66\x50\x57\x74',
        '\x51\x67\x49\x77\x6f',
        '\x66\x59\x64\x52\x70',
        '\x76\x58\x6c\x6f\x58',
        '\x57\x69\x6c\x6c\x70\x6f\x77\x65\x72',
        '\x4c\x63\x4d\x67\x45',
        '\x67\x6b\x78\x42\x70',
        '\x51\x6b\x56\x77\x4b',
        '\x41\x43\x78\x76\x56',
        '\x41\x66\x64\x44\x69',
        '\x54\x69\x63\x45\x44',
        '\x73\x70\x6c\x69\x63\x65',
        '\x43\x56\x47\x6e\x73',
        '\x69\x77\x45\x78\x4b',
        '\x41\x63\x74\x69\x6f\x6e',
        '\x57\x4f\x4e\x67\x43',
        '\x4c\x65\x61\x74\x68\x65\x72\x42\x65\x6c\x74',
        '\x44\x4d\x56\x79\x49',
        '\x4f\x77\x6e\x65\x72\x73\x68\x69\x70',
        '\x79\x6d\x6c\x48\x65',
        '\x6f\x42\x59\x6c\x4a',
        '\x73\x42\x67\x79\x65',
        '\x5a\x63\x56\x54\x71',
        '\x72\x65\x6c\x65\x61\x73\x65',
        '\x6a\x44\x70\x71\x51',
        '\x54\x70\x5a\x63\x48',
        '\x70\x4c\x69\x6a\x54',
        '\x6c\x78\x4b\x49\x78',
        '\x53\x47\x53\x6e\x59',
        '\x57\x53\x51\x49\x66',
        '\x65\x68\x4a\x47\x64',
        '\x4c\x6f\x63\x6b',
        '\x55\x76\x74\x42\x75',
        '\x76\x70\x78\x47\x43',
        '\x76\x63\x6f\x77\x6c',
        '\u63d0\u5347\u7740\u88c5\u7b49\u7ea7',
        '\x31\x36\x50\x78\x6b\x6e\x4b\x7a',
        '\x63\x4c\x6c\x78\x57',
        '\x52\x46\x68\x61\x4c',
        '\x5a\x6b\x66\x51\x53',
        '\x6d\x67\x43\x76\x70',
        '\x71\x66\x61\x76\x6b',
        '\x61\x58\x6a\x49\x63',
        '\x69\x5a\x6e\x56\x55',
        '\x52\x47\x52\x4d\x65',
        '\x69\x74\x43\x62\x50',
        '\x6a\x52\x67\x51\x45',
        '\x58\x6e\x73\x61\x53',
        '\u58f0\u97f3\u6d2a\u4eae\x28\u8bf4\u4ec0\u4e48\u5c31\u662f\u4ec0\u4e48\x29',
        '\x74\x55\x4f\x4c\x77',
        '\x4a\x61\x6d\x55\x72',
        '\x23\x32\x30\x32\x30\x32\x30',
        '\x67\x50\x45\x59\x6d',
        '\x63\x57\x6f\x56\x6d',
        '\x6a\x78\x67\x68\x5a',
        '\x64\x52\x6b\x43\x75',
        '\x6b\x58\x4a\x69\x46',
        '\x45\x66\x66\x65\x63\x74',
        '\x4d\x70\x70\x4a\x5a',
        '\x6d\x6c\x6c\x6e\x6a',
        '\x7a\x49\x45\x7a\x6d',
        '\x4e\x41\x77\x49\x65',
        '\x4a\x50\x5a\x58\x78',
        '\x6b\x4e\x5a\x63\x54',
        '\u6346\u6b7b\u6211',
        '\x49\x4f\x73\x70\x73',
        '\x49\x53\x56\x6e\x66',
        '\x4d\x68\x63\x4b\x54',
        '\x4a\x6c\x44\x4e\x52',
        '\x67\x54\x43\x6e\x74',
        '\x4d\x65\x6d\x62\x65\x72\x4e\x75\x6d\x62\x65\x72',
        '\x79\x47\x6a\x49\x6f',
        '\x49\x70\x49\x49\x64',
        '\x74\x5a\x64\x4d\x4d',
        '\x6d\x44\x78\x50\x54',
        '\x52\x52\x59\x72\x63',
        '\x67\x75\x7a\x70\x6a',
        '\x77\x6d\x4b\x43\x54',
        '\x65\x70\x62\x58\x42',
        '\x6d\x72\x6a\x71\x54',
        '\x75\x48\x57\x71\x6f',
        '\x42\x69\x4e\x6f\x6d',
        '\x61\x43\x70\x42\x74',
        '\x70\x74\x54\x62\x4e',
        '\x49\x74\x65\x6d\x4e\x6f\x73\x65',
        '\u5982\u4f60\u6240\u613f\x20\x28\u5e38\u89c1\u95ee\u9898\x3a\u4e0d\u89e3\u4e3b\u4eba\x2f\u604b\u4eba\x2c\u8bf7\u5f00\u6743\u9650\x29\x7e',
        '\x46\x43\x73\x7a\x62',
        '\x75\x4b\x74\x68\x55',
        '\x57\x4a\x71\x45\x6b',
        '\x68\x62\x69\x52\x44',
        '\x47\x76\x76\x44\x62',
        '\x61\x51\x6a\x58\x75',
        '\x31\x39\x35\x36\x39\x30\x36\x30\x6e\x65\x72\x63\x6a\x4d',
        '\x4e\x78\x75\x6e\x46',
        '\x4a\x77\x71\x78\x55',
        '\x66\x4c\x4e\x6f\x42',
        '\x6f\x56\x6a\x42\x4b',
        '\x77\x79\x6e\x6e\x63',
        '\x45\x5a\x72\x71\x4c',
        '\x5a\x58\x65\x56\x45',
        '\x4b\x41\x76\x55\x73',
        '\x50\x59\x4d\x64\x77',
        '\x6d\x77\x59\x7a\x75',
        '\x70\x4c\x71\x61\x5a',
        '\x49\x74\x65\x6d\x50\x65\x6c\x76\x69\x73',
        '\x4d\x69\x50\x79\x57',
        '\x79\x41\x5a\x43\x6e',
        '\x78\x74\x69\x6a\x54',
        '\x76\x79\x4c\x69\x66',
        '\x54\x4b\x6c\x52\x72',
        '\x77\x63\x69\x58\x57',
        '\x77\x7a\x66\x6c\x54',
        '\x4f\x67\x65\x76\x58',
        '\x73\x4a\x49\x6e\x71',
        '\x64\x6e\x65\x75\x57',
        '\x4a\x78\x7a\x58\x6e',
        '\x4a\x51\x4d\x45\x54',
        '\x79\x4e\x6c\x69\x4d',
        '\x73\x70\x6c\x69\x74',
        '\x44\x66\x6e\x62\x68',
        '\x49\x6f\x79\x6b\x6d',
        '\x78\x6a\x6b\x52\x72',
        '\x71\x75\x5a\x64\x59',
        '\x61\x69\x4e\x4c\x66',
        '\u901f\u901f\u81ea\u7f1a',
        '\u53e3\u7403\x6c\x76',
        '\x61\x62\x6f\x75\x74',
        '\x49\x74\x65\x6d\x4e\x65\x63\x6b\x52\x65\x73\x74\x72\x61\x69\x6e\x74\x73',
        '\x6f\x77\x47\x77\x68',
        '\x41\x73\x20\x75\x20\x77\x69\x73\x68\x7e\x28\x4d\x61\x6b\x65\x20\x73\x75\x72\x65\x20\x75\x20\x72\x20\x6e\x6f\x74\x20\x6f\x77\x6e\x65\x72\x2f\x6c\x6f\x76\x65\x72\x20\x6c\x6f\x63\x6b\x65\x64\x20\x26\x20\x68\x61\x76\x65\x20\x70\x65\x72\x6d\x69\x74\x74\x65\x64\x20\x6d\x65\x29',
        '\x56\x50\x54\x4c\x6d',
        '\x75\x6a\x59\x6b\x62',
        '\x74\x61\x62\x6c\x65',
        '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68\x32',
        '\x45\x45\x68\x61\x49',
        '\u5c01\u7981\u5931\u8d25\x3a\u73a9\u5bb6\u6ca1\u6709\u88ab\u5c01\u7981',
        '\x49\x74\x65\x6d\x54\x6f\x72\x73\x6f',
        '\x74\x64\x6c\x74\x64',
        '\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73',
        '\x6c\x6f\x67',
        '\x59\x5a\x70\x65\x4a',
        '\x63\x6f\x6e\x73\x74\x72\x75\x63\x74\x6f\x72',
        '\x61\x48\x74\x59\x43',
        '\x54\x71\x44\x64\x54',
        '\x57\x65\x4c\x59\x72',
        '\x65\x43\x54\x44\x47',
        '\x61\x77\x42\x4f\x54\x5f\u5c01\u7981',
        '\x53\x63\x72\x69\x70\x74\x20\x6d\x61\x64\x65\x20\x62\x79\x3a\x61\x77\x61\x71\x77\x71\x5f\x68\x75\x7a\x70\x73\x62',
        '\x62\x75\x4c\x6f\x54',
        '\x33\x32\x34\x4e\x63\x70\x68\x51\x57',
        '\x44\x69\x66\x66\x69\x63\x75\x6c\x74\x79',
        '\x6b\x74\x58\x64\x78',
        '\x58\x75\x49\x41\x53',
        '\x42\x56\x6c\x41\x6a',
        '\x78\x46\x76\x44\x51',
        '\x76\x31\x2e\x30\x37\x20\x62\x79\x20\x41\x77\u9171\x20\u5728\x61\x77\x61\x71\x77\x71\u7684\u4e2a\u4eba\u7b80\u4ecb\u91cc\u9762\u6709\u4e0b\u8f7d\u94fe\u63a5\u7684\u8bf4\x7e',
        '\x4e\x56\x4d\x6a\x4d',
        '\x4c\x55\x45\x6f\x72',
        '\x70\x62\x4d\x46\x4b',
        '\x4d\x69\x73\x74\x72\x65\x73\x73\x50\x61\x64\x6c\x6f\x63\x6b',
        '\x64\x64\x64\x54\x66',
        '\x75\x65\x44\x57\x54',
        '\x74\x46\x79\x5a\x74',
        '\x58\x4b\x4d\x65\x4e',
        '\x78\x6f\x4a\x6b\x69',
        '\x6e\x70\x5a\x56\x4b',
        '\x41\x74\x48\x46\x5a',
        '\x48\x4d\x61\x66\x75',
        '\x6b\x64\x47\x57\x70',
        '\x4d\x61\x69\x6e\x48\x61\x6c\x6c',
        '\x4b\x75\x56\x79\x51',
        '\x61\x77\x42\x4f\x54\x5f\u5173\u95ed\u9677\u9631\u5c4b',
        '\u963f\u62c9\u970d\u6d1e\u5f00',
        '\x63\x71\x6d\x63\x65',
        '\x50\x72\x6f\x70\x65\x72\x74\x79',
        '\x34\x7c\x31\x7c\x32\x7c\x37\x7c\x33\x7c\x35\x7c\x36\x7c\x30',
        '\x66\x73\x76\x55\x4a',
        '\x70\x65\x77\x56\x69',
        '\x62\x65\x72\x73\x58',
        '\x62\x63\x75\x44\x4d',
        '\x78\x59\x69\x65\x71',
        '\x54\x69\x48\x75\x71',
        '\x4e\x74\x73\x72\x7a',
        '\x47\x64\x68\x43\x4e',
        '\x49\x74\x65\x6d\x4e\x65\x63\x6b',
        '\x51\x6c\x61\x79\x6f',
        '\x64\x6c\x57\x6f\x77',
        '\x49\x74\x65\x6d\x4c\x65\x67\x73',
        '\x42\x52\x4a\x68\x4b',
        '\x50\x45\x6c\x55\x45',
        '\x71\x6f\x53\x68\x5a',
        '\x49\x74\x65\x6d\x4d\x69\x73\x63',
        '\x4b\x79\x6b\x76\x56',
        '\x4f\x44\x76\x72\x56',
        '\x54\x5a\x63\x57\x63',
        '\x6b\x73\x4e\x4c\x47',
        '\x71\x79\x59\x42\x70',
        '\x55\x55\x59\x56\x4b',
        '\x63\x50\x41\x61\x47',
        '\x61\x77\x61\x71\x77\x71',
        '\x47\x57\x46\x4f\x72',
        '\x32\x33\x38\x31\x32\x71\x63\x61\x49\x6d\x63',
        '\u672a\u77e5\u6307\u4ee4\uff01\x20\u53ef\u7528\u6307\u4ee4\x3a\x20\u6346\u6211\x20\u6346\u6b7b\u6211\x20\u8214\u6211\x20\u6551\u6211\x20\u73a9\u6211\x20\u9501\u6211\x20\u5173\u4e8e\x20\u5982\u679c\u4e00\u53e5\u8bdd\u540c\u65f6\u5305\u542b\x22\x61\x77\u9171\x22\u548c\u6307\u4ee4\uff0c\u6307\u4ee4\u5c31\u4f1a\u88ab\u6267\u884c\x7e',
        '\x30\x7c\x34\x7c\x32\x7c\x38\x7c\x35\x7c\x33\x7c\x31\x7c\x37\x7c\x36',
        '\x64\x51\x43\x51\x6a',
        '\x77\x71\x48\x4e\x44',
        '\x7a\x46\x48\x4e\x56',
        '\x61\x77\u9171',
        '\x43\x68\x61\x74\x52\x6f\x6f\x6d',
        '\x50\x78\x73\x56\x6a',
        '\x66\x78\x49\x49\x4a',
        '\x7b\x7d\x2e\x63\x6f\x6e\x73\x74\x72\x75\x63\x74\x6f\x72\x28\x22\x72\x65\x74\x75\x72\x6e\x20\x74\x68\x69\x73\x22\x29\x28\x20\x29',
        '\x51\x6c\x4f\x47\x48',
        '\x54\x43\x69\x71\x6b',
        '\x5a\x63\x78\x76\x63',
        '\x61\x77\x61\x71\x77\x71\x20\x69\x73\x20\x68\x75\x7a\x70\x73\x62',
        '\x46\x57\x50\x67\x4b',
        '\x5a\x74\x66\x62\x76',
        '\x67\x6d\x6d\x4c\x49',
        '\x6a\x4b\x6d\x69\x63',
        '\u63d0\u5347\u81ea\u7f1a\u7b49\u7ea7',
        '\x43\x6f\x6c\x6c\x61\x72\x43\x68\x61\x69\x6e\x4c\x6f\x6e\x67',
        '\x79\x52\x6a\x62\x65',
        '\x65\x58\x7a\x76\x4f',
        '\x63\x51\x62\x58\x4b',
        '\x6c\x6f\x63\x6b',
        '\x45\x74\x49\x76\x70',
        '\x6f\x6f\x6d\x75\x66',
        '\x53\x70\x74\x4f\x57',
        '\x49\x74\x65\x6d\x42\x72\x65\x61\x73\x74',
        '\x48\x55\x74\x50\x6e',
        '\x49\x74\x65\x6d\x48\x65\x61\x64',
        '\x73\x4a\x55\x54\x50',
        '\u79fb\u9664\u6781\u9650\x43\x44\x28\u5fc5\u987b\u65b0\u5207\x52\x50\u540e\u7528\x29',
        '\x4e\x74\x4c\x68\x70',
        '\x6d\x4a\x61\x5a\x6e',
        '\x4c\x65\x61\x74\x68\x65\x72\x41\x72\x6d\x62\x69\x6e\x64\x65\x72',
        '\x73\x69\x57\x49\x6c',
        '\x6f\x65\x69\x46\x69',
        '\x48\x6e\x6f\x55\x47',
        '\x4c\x64\x4c\x50\x7a',
        '\x46\x4b\x41\x49\x47',
        '\x59\x6d\x74\x41\x76',
        '\x77\x45\x6e\x50\x6d',
        '\x74\x6f\x4c\x6f\x77\x65\x72\x43\x61\x73\x65',
        '\x76\x71\x41\x56\x6c',
        '\x4a\x54\x67\x4e\x48',
        '\x78\x72\x6a\x6b\x54',
        '\x4f\x64\x6d\x46\x4a',
        '\x74\x4c\x79\x44\x54',
        '\x6c\x69\x63\x6b\x73\x20',
        '\x52\x55\x75\x53\x42',
        '\x69\x70\x49\x56\x6a',
        '\x77\x61\x72\x6e',
        '\x53\x65\x6c\x66\x42\x6f\x6e\x64\x61\x67\x65',
        '\x56\x5a\x50\x77\x66',
        '\x4d\x48\x51\x6f\x48',
        '\x76\x4e\x69\x53\x70',
        '\x77\x72\x6a\x6d\x75',
        '\x50\x61\x64\x64\x65\x64\x4d\x69\x74\x74\x65\x6e\x73',
        '\x4c\x65\x61\x74\x68\x65\x72\x48\x6f\x6f\x64\x4f\x70\x65\x6e\x4d\x6f\x75\x74\x68',
        '\x56\x61\x6c\x61\x73',
        '\x55\x44\x4d\x67\x78',
        '\x6e\x56\x4e\x6f\x4f',
        '\x4c\x62\x58\x66\x53',
        '\x68\x6f\x56\x75\x52',
        '\x71\x59\x49\x6a\x55',
        '\x52\x73\x70\x4b\x56',
        '\x44\x77\x6b\x69\x6d',
        '\x63\x6f\x6e\x73\x6f\x6c\x65',
        '\x67\x78\x6e\x78\x50',
        '\x49\x74\x65\x6d\x48\x61\x6e\x64\x73',
        '\x74\x79\x70\x65\x44',
        '\x54\x6c\x50\x53\x75',
        '\x4c\x65\x61\x74\x68\x65\x72\x48\x61\x72\x6e\x65\x73\x73',
        '\x61\x70\x70\x6c\x79',
        '\x4c\x74\x65\x6f\x54',
        '\x38\x34\x33\x36\x33\x32\x71\x41\x6c\x66\x75\x6e',
        '\x63\x48\x77\x6a\x4e',
        '\x6c\x7a\x77\x55\x62',
        '\x49\x74\x65\x6d\x4e\x69\x70\x70\x6c\x65\x73\x50\x69\x65\x72\x63\x69\x6e\x67\x73',
        '\x31\x34\x37\x30\x31\x35\x39\x7a\x52\x55\x50\x67\x76',
        '\x6c\x65\x6e\x67\x74\x68',
        '\x61\x77\x71',
        '\x44\x67\x70\x49\x41',
        '\x47\x49\x76\x72\x43',
        '\x61\x47\x46\x55\x6c',
        '\x47\x79\x49\x57\x68',
        '\x7a\x68\x62\x6f\x57',
        '\x72\x6e\x70\x55\x64',
        '\x41\x73\x20\x75\x20\x77\x69\x73\x68\x7e\x28\x4d\x61\x6b\x65\x20\x73\x75\x72\x65\x20\x75\x20\x68\x61\x76\x65\x20\x70\x65\x72\x6d\x69\x74\x74\x65\x64\x20\x6d\x65\x29',
        '\x49\x43\x75\x54\x69',
        '\x43\x68\x61\x74',
        '\x42\x6f\x75\x6e\x74\x79\x53\x75\x69\x74\x63\x61\x73\x65',
        '\u95e8\u94a5\u5319',
        '\x6a\x5a\x72\x57\x52',
        '\x57\x65\x41\x70\x48',
        '\x70\x49\x47\x77\x48',
        '\x63\x62\x4d\x4b\x51',
        '\x47\x62\x6f\x41\x57',
        '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68',
        '\x76\x77\x61\x47\x73',
        '\x65\x4e\x41\x73\x54',
        '\x48\x73\x65\x78\x47',
        '\x50\x61\x6e\x64\x6f\x72\x61\x50\x61\x64\x6c\x6f\x63\x6b',
        '\x4e\x61\x6d\x65',
        '\x5a\x6e\x75\x57\x73',
        '\x74\x42\x7a\x64\x4e',
        '\x75\x76\x54\x57\x49',
        '\u58f0\u540d\u8fdc\u626c\x28\u4fee\u6539\u5404\u7c7b\u58f0\u8a89\x29',
        '\x6b\x4b\x54\x67\x69',
        '\x75\x6a\x55\x72\x53',
        '\x55\x6a\x75\x41\x63',
        '\x70\x45\x6f\x7a\x6d',
        '\x71\x59\x63\x48\x4c',
        '\x4c\x72\x79\x77\x72',
        '\x49\x57\x53\x48\x65',
        '\x61\x75\x50\x44\x7a',
        '\x74\x6f\x53\x74\x72\x69\x6e\x67',
        '\x68\x7a\x4a\x43\x41',
        '\x74\x54\x51\x44\x4f',
        '\x62\x77\x50\x79\x46',
        '\x41\x4d\x72\x70\x54',
        '\x44\x47\x7a\x55\x67',
        '\x62\x7a\x6a\x57\x4e',
        '\x43\x68\x61\x74\x52\x6f\x6f\x6d\x43\x68\x61\x74',
        '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68\x33',
        '\x54\x78\x73\x61\x6c',
        '\x6d\x65\x6f\x77\x7e\x28\x4d\x61\x6b\x65\x20\x73\x75\x72\x65\x20\x75\x20\x68\x61\x76\x65\x20\x70\x65\x72\x6d\x69\x74\x74\x65\x64\x20\x6d\x65\x29',
        '\x5a\x74\x73\x6b\x44',
        '\x6b\x68\x64\x64\x4c',
        '\x4a\x41\x64\x64\x6d',
        '\x56\x76\x45\x41\x75',
        '\x6f\x70\x72\x73\x65',
        '\x79\x48\x68\x65\x41',
        '\u81ea\u5df1\u5220\u6389\u4e0d\u5bf9\u7684\x2c\x20\u8f93\u9519\u4e86\u540e\u679c\u81ea\u8d1f\x21',
        '\x57\x6a\x70\x5a\x78',
        '\x4f\x67\x79\x48\x4b',
        '\x50\x76\x58\x75\x6d',
        '\x65\x78\x63\x65\x70\x74\x69\x6f\x6e',
        '\x49\x79\x46\x50\x74',
        '\x69\x65\x79\x46\x4b',
        '\x6d\x6e\x6e\x71\x54',
        '\x49\x47\x72\x75\x52',
        '\x69\x6b\x6a\x67\x74',
        '\x50\x47\x69\x50\x62',
        '\x73\x79\x42\x54\x4d',
        '\x42\x54\x74\x78\x6d',
        '\x46\x68\x65\x73\x78',
        '\x70\x6b\x42\x59\x71',
        '\x70\x66\x74\x47\x6d',
        '\x4b\x57\x6f\x42\x65',
        '\x68\x65\x52\x45\x6f',
        '\x43\x63\x64\x49\x76',
        '\x43\x68\x61\x74\x52\x6f\x6f\x6d\x4c\x65\x61\x76\x65',
        '\x4d\x49\x51\x65\x73',
        '\x47\x59\x59\x67\x4c',
        '\x72\x4a\x4b\x45\x79',
        '\x58\x64\x4c\x78\x55',
        '\x62\x5a\x55\x4f\x69',
        '\x6b\x58\x6a\x63\x75',
        '\x74\x41\x43\x72\x49',
        '\x78\x58\x66\x6e\x74',
        '\x72\x65\x74\x75\x72\x6e\x20\x28\x66\x75\x6e\x63\x74\x69\x6f\x6e\x28\x29\x20',
        '\x71\x66\x66\x54\x51',
        '\x62\x63\x4a\x77\x5a',
        '\x6e\x52\x75\x55\x74',
        '\x64\x75\x50\x67\x75',
        '\x4e\x55\x4e\x71\x4f',
        '\x49\x74\x65\x6d\x46\x65\x65\x74',
        '\x49\x74\x65\x6d\x4e\x65\x63\x6b\x41\x63\x63\x65\x73\x73\x6f\x72\x69\x65\x73',
        '\x4e\x54\x4f\x65\x41',
        '\x53\x64\x72\x50\x5a',
        '\x4e\x6c\x4b\x5a\x62',
        '\x49\x74\x65\x6d\x42\x6f\x6f\x74\x73',
        '\x41\x43\x6c\x70\x54',
        '\x66\x69\x6e\x64',
        '\x4b\x4f\x68\x66\x55',
        '\x79\x62\x54\x6d\x50',
        '\x47\x69\x65\x75\x61',
        '\x59\x55\x54\x77\x5a',
        '\x73\x4d\x77\x77\x6b',
        '\x4b\x64\x44\x77\x6f',
        '\x46\x55\x76\x71\x46',
        '\x4e\x47\x4e\x6f\x6f',
        '\x57\x4d\x67\x41\x4a',
        '\x4e\x6c\x6a\x70\x66',
        '\x65\x63\x4a\x4b\x6c',
        '\x78\x48\x4f\x61\x59',
        '\x61\x6f\x6f\x73\x67',
        '\x4e\x61\x6e\x49\x63',
        '\x78\x4d\x6c\x76\x72',
        '\x62\x69\x6e\x64',
        '\x71\x47\x5a\x70\x4c',
        '\x58\x58\x4e\x4d\x62',
        '\x5f\x5f\x70\x72\x6f\x74\x6f\x5f\x5f',
        '\x70\x43\x6c\x41\x69',
        '\x56\x6e\x4e\x59\x5a',
        '\x43\x70\x78\x50\x75',
        '\x58\x75\x75\x4a\x4a',
        '\x67\x41\x4d\x4a\x53',
        '\x67\x47\x7a\x48\x63',
        '\x35\x7c\x37\x7c\x33\x7c\x32\x7c\x36\x7c\x34\x7c\x31\x7c\x30',
        '\u8981\u6346\u7684\u73a9\u5bb6\u540d\u79f0\x28\u5168\u5c0f\u5199\x29',
        '\x79\x54\x4e\x6c\x43',
        '\x75\x45\x67\x6e\x75',
        '\x62\x79\x44\x59\x4a',
        '\x4a\x41\x52\x7a\x43',
        '\x52\x59\x42\x63\x47',
        '\x70\x45\x48\x55\x74',
        '\x4c\x61\x73\x74\x43\x68\x61\x6e\x67\x65',
        '\x65\x73\x6b\x45\x4b',
        '\x71\x5a\x76\x58\x68',
        '\u63d0\u5347\u6323\u624e\u7b49\u7ea7',
        '\x4f\x73\x79\x61\x49',
        '\x43\x68\x61\x74\x53\x65\x61\x72\x63\x68',
        '\x54\x78\x62\x62\x64',
        '\x76\x4e\x48\x61\x55',
        '\x56\x4f\x65\x6f\x4c',
        '\x68\x45\x44\x67\x45',
        '\x58\x76\x59\x4f\x67',
        '\x7a\x4e\x4e\x6e\x4d',
        '\x45\x6d\x61\x6c\x58',
        '\x37\x30\x53\x6e\x4f\x55\x51\x44',
        '\x44\x65\x67\x44\x5a',
        '\x74\x72\x44\x6c\x56',
        '\x43\x54\x62\x6f\x5a',
        '\x77\x41\x56\x53\x4c',
        '\x69\x69\x5a\x64\x76',
        '\x71\x75\x58\x4f\x53',
        '\x6c\x4b\x71\x42\x48',
        '\x6b\x6c\x4a\x76\x55',
        '\x41\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x2d\x77\x6f\x72\x64\x73\x3a\x72\x65\x6c\x65\x61\x73\x65\x2c\x62\x6f\x6e\x64\x61\x67\x65\x2c\x70\x6c\x61\x79\x73\x75\x69\x74\x2c\x6c\x6f\x63\x6b\x2c\x61\x62\x6f\x75\x74\x2c\x6c\x69\x63\x6b\x2c\x72\x61\x6e\x64\x6f\x6d\x2c\x62\x61\x6e\x6d\x65\x28\x74\x6f\x20\x67\x65\x74\x20\x73\x74\x75\x63\x6b\x2c\x75\x73\x65\x20\x74\x68\x69\x73\x20\x61\x66\x74\x65\x72\x20\x72\x61\x6e\x64\x6f\x6d\x20\x61\x6e\x64\x20\x6c\x6f\x63\x6b\x2e\x29\x2e\x49\x66\x20\x61\x20\x73\x65\x6e\x74\x65\x6e\x63\x65\x20\x69\x6e\x63\x6c\x75\x64\x69\x6e\x67\x20\x22\x61\x77\x71\x22\x20\x68\x61\x73\x20\x61\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x2d\x77\x6f\x72\x64\x20\x61\x74\x20\x74\x68\x65\x20\x73\x61\x6d\x65\x20\x74\x69\x6d\x65\x2c\x20\x74\x68\x65\x6e\x20\x74\x68\x65\x20\x63\x6f\x72\x72\x65\x73\x70\x6f\x6e\x64\x69\x6e\x67\x20\x61\x63\x74\x69\x6f\x6e\x20\x77\x69\x6c\x6c\x20\x62\x65\x20\x74\x61\x6b\x65\x6e\x2e',
        '\x53\x52\x53\x4f\x79',
        '\x49\x74\x65\x6d\x48\x6f\x6f\x64',
        '\x74\x43\x42\x48\x79',
        '\x52\x50\x79\x72\x70',
        '\x53\x78\x76\x6a\x62',
        '\x75\x56\x48\x47\x55',
        '\x65\x72\x4b\x49\x56',
        '\x6f\x53\x76\x54\x5a',
        '\x57\x4b\x79\x67\x69',
        '\x49\x74\x65\x6d\x41\x72\x6d\x73',
        '\x72\x6e\x6f\x63\x6b',
        '\x49\x41\x6f\x51\x41',
        '\x61\x6f\x69\x61\x56',
        '\x72\x45\x69\x50\x4a',
        '\u5c01\u7981\u5931\u8d25\x3a\u73a9\u5bb6\u5df2\u7ecf\u88ab\u5c01\u7981',
        '\u63d0\u5347\u64ac\u9501\u7b49\u7ea7',
        '\x59\x58\x4e\x6c\x41',
        '\x68\x43\x73\x61\x76',
        '\x56\x44\x62\x74\x54',
        '\x4c\x6f\x63\x6b\x65\x64\x42\x79',
        '\x4a\x5a\x64\x41\x6d',
        '\x5a\x62\x62\x43\x6f',
        '\x79\x68\x78\x4b\x6d',
        '\x49\x42\x6a\x6a\x65',
        '\u8981\u89e3\u5c01\u7684\u73a9\u5bb6\u540d\u79f0',
        '\u8981\u5c01\u7981\u7684\u73a9\u5bb6\u540d\u79f0',
        '\x4a\x6e\x50\x4a\x6e',
        '\x76\x6d\x43\x51\x41',
        '\x4a\x42\x4f\x58\x4b',
        '\x70\x6c\x61\x79\x73\x75\x69\x74',
        '\x75\x44\x6f\x45\x77',
        '\x47\x52\x50\x65\x75',
        '\x61\x77\x42\x4f\x54\x20\x53\x6f\x72\x72\x79\x20\x62\x75\x74\x20\x79\x6f\x75\x27\x76\x65\x20\x62\x65\x65\x6e\x20\x62\x61\x6e\x6e\x65\x64\x20\x62\x79\x20\x61\x6e\x20\x6f\x70\x65\x72\x61\x74\x6f\x72\x2e',
        '\x41\x51\x61\x69\x4a',
        '\x61\x48\x49\x50\x50',
        '\x6d\x48\x6e\x75\x6e',
        '\x68\x6a\x47\x78\x56',
        '\x66\x72\x56\x4b\x65',
        '\x51\x62\x62\x6f\x72',
        '\x70\x69\x7a\x45\x4e',
        '\x55\x67\x67\x42\x52',
        '\x4a\x62\x48\x7a\x6b',
        '\x6d\x68\x63\x66\x4f',
        '\x6d\x74\x42\x54\x58',
        '\x58\x56\x72\x47\x41',
        '\x35\x35\x38\x36\x39\x6d\x79\x54\x73\x74\x67',
        '\x59\x6f\x6a\x68\x69',
        '\x43\x45\x42\x79\x64',
        '\x63\x45\x74\x63\x4b',
        '\x70\x72\x6f\x74\x6f\x74\x79\x70\x65',
        '\x6c\x76\x44\x6d\x70',
        '\x49\x42\x6c\x5a\x62',
        '\x71\x78\x45\x75\x6e',
        '\x69\x6e\x51\x53\x4d',
        '\x77\x53\x4d\x67\x4c',
        '\x6c\x69\x63\x6b',
        '\x66\x56\x79\x72\x75',
        '\x66\x6f\x72\x45\x61\x63\x68'
    ];
    _0x4064 = function () {
        return _0x1d28cb;
    };
    return _0x4064();
}