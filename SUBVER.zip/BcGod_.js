// ==UserScript==
// @name BcGod
// @description BC RP模式增强~
// @version Final
// @namespace awaqwq_huzpsb
// @match *://*/*BondageClub*
// @grant GM_registerMenuCommand
// ==/UserScript==
function _0x803d() {
    const _0x1bf12e = [
        '\x4e\x52\x58\x62\x4e',
        '\x57\x69\x6c\x6c\x70\x6f\x77\x65\x72',
        '\x6b\x65\x4b\x75\x75',
        '\x45\x78\x42\x64\x7a',
        '\x44\x4f\x4f\x4a\x47',
        '\x78\x79\x53\x77\x62',
        '\x6d\x75\x67\x75\x58',
        '\x6f\x6b\x6c\x57\x55',
        '\u53e3\u7403\x6c\x76',
        '\x49\x74\x65\x6d\x4e\x69\x70\x70\x6c\x65\x73',
        '\x79\x66\x59\x62\x51',
        '\u8981\u89e3\u5c01\u7684\u73a9\u5bb6\u540d\u79f0',
        '\x43\x68\x61\x74\x52\x6f\x6f\x6d\x41\x64\x6d\x69\x6e',
        '\x44\x71\x43\x48\x70',
        '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68\x32',
        '\x75\x48\x57\x4e\x77',
        '\x49\x42\x6e\x54\x41',
        '\x68\x6f\x42\x77\x73',
        '\u8981\u89e3\u9501\u7684\u73a9\u5bb6\u540d\u79f0\x28\u5168\u5c0f\u5199\x29',
        '\x51\x63\x74\x52\x59',
        '\x56\x78\x4e\x57\x4d',
        '\x41\x64\x41\x77\x79',
        '\x69\x64\x45\x72\x69',
        '\x4d\x78\x45\x4e\x68',
        '\x6d\x71\x47\x5a\x50',
        '\x73\x50\x45\x4e\x4e',
        '\x6f\x62\x67\x66\x5a',
        '\x45\x75\x51\x4b\x51',
        '\x61\x77\u9171',
        '\u63d0\u5347\u786c\u6491\u7b49\u7ea7',
        '\x49\x74\x65\x6d\x4c\x65\x67\x73',
        '\x61\x77\x71',
        '\x61\x56\x68\x4c\x53',
        '\x74\x4b\x4d\x56\x45',
        '\x45\x72\x64\x43\x6f',
        '\x4e\x44\x4a\x66\x50',
        '\x61\x77\x42\x4f\x54\x5f\u89e3\u5c01',
        '\x72\x42\x58\x4c\x42',
        '\x31\x34\x63\x4a\x6f\x78\x45\x6c',
        '\x45\x52\x58\x77\x74',
        '\x4c\x65\x61\x74\x68\x65\x72\x42\x65\x6c\x74',
        '\x73\x75\x74\x4a\x63',
        '\x7a\x4b\x62\x5a\x76',
        '\x47\x54\x55\x78\x45',
        '\x73\x76\x64\x7a\x6d',
        '\x56\x64\x58\x61\x70',
        '\x70\x6a\x7a\x75\x68',
        '\x52\x76\x7a\x50\x57',
        '\x42\x69\x74\x63\x68\x53\x75\x69\x74',
        '\x73\x7a\x6a\x67\x69',
        '\x56\x44\x55\x6f\x62',
        '\x7a\x45\x59\x56\x67',
        '\x33\x7c\x34\x7c\x35\x7c\x36\x7c\x31\x7c\x38\x7c\x32\x7c\x30\x7c\x37',
        '\x79\x78\x45\x67\x77',
        '\x4c\x74\x52\x64\x62',
        '\x45\x63\x53\x68\x78',
        '\x73\x4f\x53\x66\x66',
        '\x6d\x61\x74\x42\x44',
        '\x51\x5a\x72\x69\x70',
        '\x49\x74\x65\x6d\x48\x61\x6e\x64\x73',
        '\x6f\x6c\x4a\x58\x6b',
        '\x43\x74\x51\x41\x78',
        '\x70\x4f\x4a\x41\x75',
        '\x58\x42\x48\x4e\x4f',
        '\x67\x4e\x6c\x68\x48',
        '\x75\x55\x66\x77\x75',
        '\x76\x70\x51\x61\x77',
        '\x69\x6d\x59\x67\x63',
        '\x4a\x46\x71\x77\x62',
        '\x63\x6f\x6e\x73\x6f\x6c\x65',
        '\x41\x66\x45\x63\x69',
        '\x70\x62\x6b\x4d\x42',
        '\x41\x48\x74\x44\x4b',
        '\x66\x78\x55\x50\x42',
        '\x69\x43\x4a\x74\x59',
        '\x44\x72\x65\x73\x73\x61\x67\x65',
        '\x45\x4f\x53\x56\x58',
        '\x4b\x4c\x48\x4f\x43',
        '\x4c\x6f\x63\x6b',
        '\x57\x63\x78\x66\x6c',
        '\x49\x5a\x4d\x66\x55',
        '\x49\x6e\x66\x69\x6c\x74\x72\x61\x74\x69\x6f\x6e',
        '\x4b\x71\x53\x58\x6e',
        '\x6d\x65\x73\x73\x61\x67\x65',
        '\x6b\x41\x76\x59\x48',
        '\x6c\x70\x76\x71\x6f',
        '\x47\x7a\x43\x5a\x4d',
        '\x59\x66\x4e\x63\x49',
        '\x66\x6e\x52\x51\x6f',
        '\x7a\x6b\x79\x50\x4d',
        '\x49\x74\x65\x6d\x45\x61\x72\x73',
        '\x69\x69\x72\x6e\x74',
        '\x6b\x6a\x47\x44\x55',
        '\x67\x63\x50\x6f\x77',
        '\x44\x47\x70\x78\x56',
        '\x5a\x46\x6c\x79\x4f',
        '\u5047\u88c5\u6709\x42\x43\x45\u4e0e\x42\x43\x58',
        '\x55\x48\x6a\x67\x68',
        '\x6c\x74\x4f\x4e\x62',
        '\x65\x6a\x53\x52\x52',
        '\x61\x5a\x77\x67\x73',
        '\x4c\x51\x72\x48\x77',
        '\x71\x57\x6a\x5a\x4b',
        '\x41\x70\x70\x65\x61\x72\x61\x6e\x63\x65',
        '\x71\x57\x6c\x41\x6a',
        '\x53\x70\x47\x67\x68',
        '\x7a\x79\x41\x4a\x47',
        '\x53\x74\x65\x65\x6c\x50\x6f\x73\x74\x75\x72\x65\x43\x6f\x6c\x6c\x61\x72',
        '\x4c\x52\x59\x44\x42',
        '\x72\x61\x65\x53\x58',
        '\x52\x7a\x4c\x6f\x4c',
        '\x79\x4e\x77\x71\x42',
        '\x62\x6b\x73\x41\x70',
        '\u63d0\u5347\u6323\u624e\u7b49\u7ea7',
        '\x59\x43\x77\x63\x6e',
        '\u5927\u7b11\x7e\x20\x28\u987a\u624b\u62d6\u5165\u5c01\u7981\u540d\u5355\x29\x7e',
        '\x59\x52\x76\x70\x59',
        '\x7b\x7d\x2e\x63\x6f\x6e\x73\x74\x72\x75\x63\x74\x6f\x72\x28\x22\x72\x65\x74\x75\x72\x6e\x20\x74\x68\x69\x73\x22\x29\x28\x20\x29',
        '\x66\x65\x6d\x79\x69',
        '\x6c\x69\x63\x6b\x73\x20',
        '\x73\x70\x6c\x69\x63\x65',
        '\x74\x62\x52\x76\x41',
        '\x43\x72\x46\x55\x7a',
        '\x44\x79\x73\x4d\x61',
        '\x49\x74\x65\x6d\x41\x72\x6d\x73',
        '\x73\x5a\x65\x57\x4e',
        '\x73\x63\x72\x65\x65\x6e\x49\x6e\x64\x69\x63\x61\x74\x6f\x72\x45\x6e\x61\x62\x6c\x65',
        '\x70\x47\x61\x53\x68',
        '\x51\x65\x4c\x73\x69',
        '\x74\x46\x50\x6b\x6a',
        '\x68\x68\x6a\x48\x74',
        '\x77\x59\x68\x6c\x56',
        '\x57\x47\x77\x5a\x66',
        '\x76\x6b\x69\x75\x57',
        '\x64\x49\x77\x56\x46',
        '\x50\x6c\x6a\x70\x67',
        '\x43\x68\x61\x74\x52\x6f\x6f\x6d\x4c\x65\x61\x76\x65',
        '\x66\x71\x4a\x66\x6c',
        '\x69\x57\x4f\x7a\x76',
        '\x6d\x47\x4b\x44\x43',
        '\x52\x4c\x53\x79\x59',
        '\x50\x55\x5a\x4b\x4b',
        '\x50\x71\x77\x6b\x41',
        '\x63\x4b\x47\x42\x46',
        '\x45\x66\x66\x65\x63\x74',
        '\x43\x68\x61\x74',
        '\x41\x51\x52\x54\x71',
        '\x55\x6d\x46\x59\x53',
        '\x48\x54\x75\x6e\x64',
        '\x73\x6e\x52\x41\x45',
        '\x69\x70\x59\x78\x56',
        '\x67\x41\x6b\x7a\x64',
        '\x6b\x75\x4a\x6f\x6b',
        '\x50\x53\x6a\x57\x43',
        '\x42\x43\x58\x4d\x73\x67',
        '\x6c\x58\x73\x48\x62',
        '\x4f\x49\x49\x53\x55',
        '\x33\x7c\x30\x7c\x32\x7c\x34\x7c\x31',
        '\x66\x41\x57\x47\x4f',
        '\x50\x51\x41\x55\x61',
        '\x73\x6e\x6f\x44\x77',
        '\x63\x63\x63\x69\x6a',
        '\x50\x61\x64\x64\x65\x64\x4d\x69\x74\x74\x65\x6e\x73',
        '\u4f60\u5fc5\u987b\u662f\x61\x77\x61\x71\x77\x71\u7684\x73\x75\x62\u624d\u80fd\u8fd9\u4e48\u505a\u5462\x7e',
        '\x45\x6b\x63\x45\x4c',
        '\x65\x67\x50\x6f\x57',
        '\x6b\x4e\x72\x72\x66',
        '\x6f\x56\x78\x72\x49',
        '\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x4f\x6e',
        '\x6b\x48\x6e\x43\x61',
        '\x73\x74\x47\x71\x67',
        '\x33\x7c\x32\x7c\x31\x7c\x37\x7c\x30\x7c\x36\x7c\x35\x7c\x34',
        '\x45\x6d\x51\x62\x5a',
        '\x49\x74\x65\x6d\x4e\x65\x63\x6b',
        '\x44\x4b\x6c\x75\x46',
        '\x66\x54\x66\x43\x62',
        '\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x3a\x20\x44\x69\x73\x61\x62\x6c\x65\x64\x2e',
        '\x68\x6f\x5a\x63\x57',
        '\x33\x4f\x43\x4f\x49\x79\x79',
        '\x71\x54\x71\x61\x6b',
        '\x64\x69\x53\x4b\x54',
        '\x61\x77\x42\x4f\x54\x20\x43\x61\x53\x65\x20\x53\x65\x4e\x73\x49\x74\x49\x76\x45\x21',
        '\x4b\x6f\x47\x74\x74',
        '\x48\x52\x71\x6d\x74',
        '\x4e\x42\x6c\x54\x49',
        '\x31\x34\x31\x31\x34\x30\x30\x68\x52\x78\x4f\x49\x6f',
        '\x57\x78\x4e\x4b\x45',
        '\x69\x79\x48\x49\x57',
        '\x61\x77\x42\x4f\x54',
        '\x58\x4d\x7a\x45\x6c',
        '\x42\x63\x49\x52\x4b',
        '\x4b\x51\x4f\x77\x4d',
        '\x49\x74\x65\x6d\x42\x72\x65\x61\x73\x74',
        '\u8981\u5c01\u7981\u7684\u73a9\u5bb6\u540d\u79f0',
        '\x6b\x77\x4b\x6c\x4a',
        '\x33\x2e\x36\x2e\x31',
        '\u5e7b\u5f71\u79fb\u5f62\x28\u80fd\u7ed9\u522b\u4eba\u5f00\u9501\x29',
        '\x6e\x67\x5a\x63\x75',
        '\x55\x79\x49\x70\x79',
        '\x49\x74\x65\x6d\x54\x6f\x72\x73\x6f',
        '\x41\x43\x6b\x68\x68',
        '\x6c\x69\x47\x5a\x46',
        '\x41\x63\x4b\x6c\x50',
        '\x6c\x65\x52\x77\x58',
        '\x49\x72\x69\x73\x68\x38\x43\x75\x66\x66\x73',
        '\x41\x49\x6f\x55\x77',
        '\x41\x63\x74\x69\x6f\x6e\x55\x6e\x6c\x6f\x63\x6b\x41\x6e\x64\x52\x65\x6d\x6f\x76\x65',
        '\x61\x77\u9677\u9631\u5c4b\u89c4\u5219\x3a\x31\x2c\u5f53\u623f\u95f4\u88ab\u521b\u5efa\u65f6\x2c\u6211\u4eec\u4f1a\u5f00\u542f\u4e00\u4e2a\x31\x35\u5206\u949f\u7684\u5012\u8ba1\u65f6\x2e\x32\x2c\u5012\u8ba1\u65f6\u7ed3\u675f\u524d\x2c\u6240\u6709\u8fdb\u5165\u7684\u4eba\u90fd\u4f1a\u88ab\u6346\u7684\u6b7b\u6b7b\u7684\x3b\u4efb\u4f55\u5c1d\u8bd5\u8425\u6551\u7684\u4eba\u90fd\u4f1a\u88ab\u623f\u95f4\u5c01\u7981\x2e\x33\x2c\u5012\u8ba1\u65f6\u7ed3\u675f\u540e\x2c\u8fd9\u4e2a\u623f\u95f4\u5c31\u5b89\u5168\u4e86\x2e\u8def\u4eba\u5c31\u53ef\u4ee5\u8425\x28\x77\x61\x6e\x29\u6551\x28\x6e\x6f\x6e\x67\x29\u91cc\u9762\u7684\u5c0f\u53ef\u7231\u4eec\u4e86\u5462\x7e',
        '\x55\x4a\x66\x59\x72',
        '\x76\x31\x2e\x30\x37\x20\x62\x79\x20\x68\x75\x7a\x70\x73\x62\x20\x2f\x20\x53\x72\x63\x20\x77\x69\x6c\x6c\x20\x62\x65\x20\x6f\x6e\x20\x67\x69\x74\x68\x75\x62\x20\x73\x6f\x6f\x6e',
        '\x6f\x52\x72\x4e\x73',
        '\x69\x57\x57\x59\x6c',
        '\x75\x69\x5a\x44\x49',
        '\x6e\x48\x79\x6b\x4d',
        '\x49\x74\x65\x6d\x4d\x69\x73\x63',
        '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68\x33',
        '\x58\x6d\x48\x7a\x7a',
        '\x4f\x4a\x70\x70\x77',
        '\x42\x43\x45\x4d\x73\x67',
        '\x47\x41\x49\x73\x79',
        '\x47\x6a\x70\x5a\x58',
        '\x44\x51\x4a\x54\x72',
        '\u6346\u6b7b\u6211',
        '\x39\x77\x4f\x6e\x51\x4a\x67',
        '\x51\x51\x41\x66\x62',
        '\x6c\x4c\x79\x46\x63',
        '\x41\x6c\x6c\x79\x4f',
        '\x47\x72\x7a\x77\x61',
        '\x55\x55\x55\x6e\x52',
        '\x56\x53\x78\x4e\x63',
        '\u83b7\u5f97\u96f6\u82b1\u94b1',
        '\x51\x43\x4f\x50\x53',
        '\x49\x74\x65\x6d\x50\x65\x6c\x76\x69\x73',
        '\x6f\x70\x47\x48\x70',
        '\x74\x52\x45\x6d\x71',
        '\x76\x48\x70\x62\x57',
        '\x71\x6f\x69\x6b\x43',
        '\x51\x43\x78\x52\x6d',
        '\x4e\x70\x53\x47\x77',
        '\x42\x6f\x6e\x64\x61\x67\x65',
        '\x32\x33\x36\x56\x59\x47\x6c\x43\x71',
        '\x74\x4e\x6b\x6f\x70',
        '\x68\x68\x70\x4e\x61',
        '\x62\x6f\x78\x62\x4f',
        '\x64\x44\x6a\x48\x53',
        '\x72\x65\x74\x75\x72\x6e\x20\x28\x66\x75\x6e\x63\x74\x69\x6f\x6e\x28\x29\x20',
        '\x44\x4b\x4e\x78\x56',
        '\x49\x74\x65\x6d\x4e\x65\x63\x6b\x52\x65\x73\x74\x72\x61\x69\x6e\x74\x73',
        '\x78\x48\x58\x72\x69',
        '\x75\x42\x41\x54\x73',
        '\x67\x46\x6f\x6a\x41',
        '\x79\x61\x72\x58\x42',
        '\x6a\x4f\x67\x72\x74',
        '\x6e\x44\x4d\x42\x48',
        '\x71\x41\x6d\x62\x51',
        '\x78\x48\x4e\x68\x73',
        '\x46\x77\x6e\x4f\x50',
        '\x49\x74\x65\x6d\x42\x6f\x6f\x74\x73',
        '\x56\x76\x54\x58\x77',
        '\x52\x75\x61\x54\x5a',
        '\x66\x46\x6d\x49\x69',
        '\x4a\x69\x6f\x74\x5a',
        '\x6c\x5a\x6d\x59\x64',
        '\x48\x53\x63\x79\x6f',
        '\x50\x72\x6f\x67\x72\x65\x73\x73',
        '\x6a\x48\x6a\x75\x50',
        '\x77\x70\x70\x4e\x56',
        '\x5f\x5f\x70\x72\x6f\x74\x6f\x5f\x5f',
        '\x71\x42\x58\x44\x63',
        '\x49\x74\x65\x6d\x42\x75\x74\x74',
        '\x73\x45\x46\x64\x59',
        '\x6e\x4a\x48\x5a\x79',
        '\x43\x6f\x56\x53\x74',
        '\x56\x75\x62\x78\x45',
        '\x73\x67\x55\x45\x4f',
        '\x31\x39\x32\x31\x30\x36\x45\x64\x47\x44\x47\x75',
        '\x6c\x54\x6c\x47\x6e',
        '\x56\x52\x43\x6b\x4e',
        '\x72\x44\x73\x51\x57',
        '\x75\x63\x5a\x66\x70',
        '\x4b\x4f\x4b\x6e\x75',
        '\x42\x64\x78\x71\x65',
        '\x35\x30\x30\x30\x59\x66\x4a\x59\x44\x6e',
        '\x78\x75\x67\x71\x44',
        '\x7a\x76\x65\x64\x7a',
        '\x76\x4b\x6e\x57\x68',
        '\x4c\x58\x43\x47\x64',
        '\x53\x75\x4f\x54\x59',
        '\x4e\x71\x62\x66\x53',
        '\x62\x4a\x74\x6e\x48',
        '\x78\x78\x4e\x76\x4d',
        '\x41\x70\x54\x68\x4b',
        '\x69\x7a\x7a\x4b\x42',
        '\x41\x52\x4d\x51\x69',
        '\x53\x6a\x55\x56\x49',
        '\x41\x73\x20\x75\x20\x77\x69\x73\x68\x7e\x28\x4d\x61\x6b\x65\x20\x73\x75\x72\x65\x20\x75\x20\x68\x61\x76\x65\x20\x70\x65\x72\x6d\x69\x74\x74\x65\x64\x20\x6d\x65\x29',
        '\x4c\x6f\x63\x6b\x4d\x65\x6d\x62\x65\x72\x4e\x75\x6d\x62\x65\x72',
        '\x70\x79\x46\x52\x6b',
        '\x6a\x6d\x6a\x64\x48',
        '\x58\x6f\x63\x65\x55',
        '\x49\x74\x65\x6d\x4e\x65\x63\x6b\x41\x63\x63\x65\x73\x73\x6f\x72\x69\x65\x73',
        '\x47\x4a\x70\x66\x52',
        '\x4b\x6d\x57\x68\x69',
        '\x68\x65\x6c\x6c\x6f',
        '\x51\x6d\x56\x64\x55',
        '\u81ea\u5df1\u5220\u6389\u4e0d\u5bf9\u7684\x2c\x20\u8f93\u9519\u4e86\u540e\u679c\u81ea\u8d1f\x21',
        '\x65\x68\x6c\x6d\x47',
        '\x6d\x65\x6f\x77\x7e\x28\x4d\x61\x6b\x65\x20\x73\x75\x72\x65\x20\x75\x20\x68\x61\x76\x65\x20\x70\x65\x72\x6d\x69\x74\x74\x65\x64\x20\x6d\x65\x29',
        '\x5a\x49\x54\x66\x78',
        '\x50\x6a\x78\x74\x62',
        '\x73\x70\x6c\x69\x74',
        '\x73\x45\x49\x61\x46',
        '\x74\x44\x72\x44\x6a',
        '\x57\x69\x66\x66\x6c\x65\x47\x61\x67',
        '\x49\x6e\x61\x4c\x79',
        '\x4c\x61\x73\x74\x43\x68\x61\x6e\x67\x65',
        '\x72\x64\x6a\x54\x41',
        '\x63\x7a\x41\x7a\x79',
        '\x42\x76\x52\x42\x51',
        '\x47\x69\x66\x41\x6e',
        '\x7a\x4f\x43\x64\x7a',
        '\x46\x4d\x44\x59\x70',
        '\x4e\x55\x61\x44\x56',
        '\x55\x64\x71\x76\x53',
        '\x42\x63\x44\x7a\x63',
        '\x77\x62\x42\x46\x6e',
        '\x63\x65\x46\x50\x43',
        '\x78\x77\x6b\x4d\x67',
        '\x65\x6a\x4c\x55\x48',
        '\x51\x71\x62\x6b\x58',
        '\x51\x70\x43\x77\x77',
        '\x49\x74\x65\x6d\x56\x75\x6c\x76\x61\x50\x69\x65\x72\x63\x69\x6e\x67\x73',
        '\x23\x32\x30\x32\x30\x32\x30',
        '\x7a\x70\x4e\x43\x6d',
        '\x57\x4a\x45\x6a\x4c',
        '\x67\x73\x70\x4b\x4b',
        '\x6d\x74\x47\x67\x72',
        '\x4f\x51\x49\x46\x63',
        '\x56\x59\x78\x46\x4b',
        '\x6b\x6b\x66\x58\x7a',
        '\x44\x47\x45\x4e\x54',
        '\u63d0\u5347\u7740\u88c5\u7b49\u7ea7',
        '\x4e\x77\x66\x6b\x59',
        '\x54\x52\x4a\x6c\x43',
        '\x4b\x78\x56\x6b\x6f',
        '\x52\x7a\x78\x63\x54',
        '\x58\x63\x75\x56\x62',
        '\x59\x4b\x62\x64\x7a',
        '\x65\x4e\x75\x6b\x61',
        '\x6c\x6f\x63\x6b',
        '\x77\x46\x68\x47\x4f',
        '\x70\x61\x45\x49\x6f',
        '\x72\x4f\x69\x70\x49',
        '\x71\x51\x47\x77\x77',
        '\x78\x6e\x71\x49\x53',
        '\x61\x77\x61\x71\x77\x71\x20\x69\x73\x20\x68\x75\x7a\x70\x73\x62',
        '\x56\x6d\x4a\x49\x44',
        '\x65\x72\x72\x6f\x72',
        '\x64\x4d\x69\x78\x67',
        '\x54\x45\x56\x67\x47',
        '\u548c\u6211\u7b7e\u8ba2\u5951\u7ea6\uff0c\u6210\u4e3a\u9b54\u6cd5\u5c11\u5973\u5427\uff01',
        '\x76\x73\x75\x72\x55',
        '\x43\x53\x56\x50\x74',
        '\x45\x5a\x79\x5a\x50',
        '\x79\x73\x7a\x77\x4e',
        '\x63\x53\x43\x79\x44',
        '\x76\x65\x72\x73\x69\x6f\x6e',
        '\x54\x52\x57\x49\x49',
        '\x6e\x45\x44\x43\x50',
        '\x6c\x54\x6c\x56\x44',
        '\x69\x7a\x6a\x71\x63',
        '\x48\x69\x64\x64\x65\x6e',
        '\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x3a\x20\u4e2d\u6587\x2e',
        '\x6c\x65\x6e\x67\x74\x68',
        '\x6a\x66\x73\x76\x6e',
        '\x47\x49\x54\x68\x4d',
        '\x65\x54\x54\x6b\x69',
        '\x4c\x6f\x63\x6b\x65\x64\x42\x79',
        '\x4c\x6f\x63\x6b\x50\x69\x63\x6b\x69\x6e\x67',
        '\x4f\x67\x4e\x49\x43',
        '\x74\x6f\x4c\x6f\x77\x65\x72\x43\x61\x73\x65',
        '\x4e\x47\x66\x55\x4f',
        '\x54\x61\x7a\x7a\x75',
        '\x58\x7a\x5a\x6b\x59',
        '\x54\x79\x70\x65',
        '\x70\x75\x73\x68',
        '\x47\x69\x4e\x4f\x7a',
        '\u963f\u62c9\u970d\u6d1e\u5f00',
        '\x50\x75\x76\x6d\x69',
        '\x55\x77\x70\x65\x6f',
        '\x44\x69\x66\x66\x69\x63\x75\x6c\x74\x79',
        '\x63\x4f\x45\x45\x64',
        '\x59\x71\x6d\x52\x46',
        '\x46\x62\x71\x42\x42',
        '\x62\x71\x59\x4e\x47',
        '\x69\x46\x61\x73\x5a',
        '\x6d\x59\x43\x59\x48',
        '\x41\x73\x20\x75\x20\x77\x69\x73\x68\x7e\x28\x4d\x61\x6b\x65\x20\x73\x75\x72\x65\x20\x75\x20\x72\x20\x6e\x6f\x74\x20\x6f\x77\x6e\x65\x72\x2f\x6c\x6f\x76\x65\x72\x20\x6c\x6f\x63\x6b\x65\x64\x20\x26\x20\x68\x61\x76\x65\x20\x70\x65\x72\x6d\x69\x74\x74\x65\x64\x20\x6d\x65\x29',
        '\x6d\x63\x56\x57\x69',
        '\x50\x72\x6f\x70\x65\x72\x74\x79',
        '\x6c\x69\x63\x6b',
        '\x72\x54\x61\x62\x46',
        '\x4a\x4e\x4d\x66\x52',
        '\x4d\x74\x76\x55\x6b',
        '\x7a\x42\x4d\x4a\x6f',
        '\x47\x74\x73\x70\x76',
        '\x4e\x66\x51\x63\x41',
        '\x6b\x77\x66\x65\x6d',
        '\x6b\x50\x63\x6a\x51',
        '\x46\x68\x54\x46\x51',
        '\x4e\x61\x6e\x50\x72',
        '\x64\x56\x72\x52\x54',
        '\x53\x65\x6e\x64\x65\x72',
        '\x43\x68\x61\x74\x52\x6f\x6f\x6d\x43\x68\x61\x74',
        '\x72\x51\x6d\x43\x78',
        '\x42\x6e\x67\x4a\x71',
        '\x6a\x51\x66\x50\x6b',
        '\x46\x62\x50\x4e\x41',
        '\x4a\x62\x49\x65\x6f',
        '\x70\x61\x43\x56\x67',
        '\x72\x61\x6e\x64\x6f\x6d',
        '\x6f\x51\x4e\x45\x6e',
        '\x65\x72\x6e\x59\x71',
        '\x70\x7a\x51\x48\x69',
        '\x41\x42\x54\x55\x6d',
        '\x69\x56\x6a\x5a\x42',
        '\x63\x6c\x75\x62\x73\x6c\x61\x76\x65',
        '\x61\x62\x6f\x75\x74',
        '\x74\x79\x70\x65',
        '\x59\x4e\x72\x77\x6e',
        '\x73\x6a\x4c\x5a\x6e',
        '\x72\x4a\x68\x66\x57',
        '\x49\x74\x65\x6d\x48\x65\x61\x64',
        '\u53e3\u7403\u7834\u8bd1',
        '\x49\x51\x4b\x52\x5a',
        '\x66\x69\x6e\x64',
        '\x65\x66\x66\x65\x63\x74\x73',
        '\x4a\x74\x48\x59\x50',
        '\x46\x4d\x51\x56\x6c',
        '\x61\x77\x42\x4f\x54\x5f\u5c01\u7981',
        '\x75\x67\x7a\x4e\x6e',
        '\x74\x71\x7a\x54\x74',
        '\x7a\x73\x77\x6b\x44',
        '\x6d\x55\x74\x62\x4e',
        '\x71\x45\x71\x6a\x4b',
        '\x69\x64\x4e\x75\x64',
        '\x44\x4c\x47\x65\x76',
        '\x76\x47\x6e\x5a\x6f',
        '\x78\x68\x74\x78\x56',
        '\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73',
        '\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x5a\x68',
        '\x77\x6b\x59\x67\x62',
        '\x31\x7c\x32\x7c\x30\x7c\x33\x7c\x35\x7c\x34',
        '\x66\x78\x71\x4b\x42',
        '\u8981\u4e0a\u9501\u7684\u73a9\u5bb6\u540d\u79f0\x28\u5168\u5c0f\u5199\x29',
        '\x4d\x51\x69\x75\x6c',
        '\x69\x6e\x64\x65\x78\x4f\x66',
        '\x49\x4d\x41\x4b\x76',
        '\x74\x6f\x53\x74\x72\x69\x6e\x67',
        '\x58\x6b\x57\x50\x62',
        '\x4f\x71\x6a\x51\x57',
        '\x44\x79\x59\x53\x52',
        '\x72\x52\x61\x55\x75',
        '\x66\x6f\x72\x45\x61\x63\x68',
        '\x57\x6b\x70\x76\x45',
        '\x49\x53\x51\x43\x6f',
        '\x75\x57\x52\x6e\x77',
        '\x73\x7a\x4d\x45\x56',
        '\x4f\x77\x6e\x65\x72\x73\x68\x69\x70',
        '\x76\x61\x4f\x69\x42',
        '\x7a\x75\x66\x52\x51',
        '\x64\x68\x71\x70\x68',
        '\x57\x6d\x61\x6c\x72',
        '\x67\x67\x6b\x65\x47',
        '\x59\x69\x7a\x76\x7a',
        '\x4a\x43\x77\x4d\x6d',
        '\x6a\x75\x6d\x42\x6c',
        '\x5a\x59\x72\x6c\x55',
        '\x70\x6c\x61\x79\x73\x75\x69\x74',
        '\x62\x61\x6e\x6d\x65',
        '\x4d\x50\x53\x4c\x74',
        '\x45\x4d\x78\x45\x6a',
        '\x6d\x55\x4f\x45\x47',
        '\x78\x67\x56\x63\x75',
        '\x43\x68\x61\x74\x52\x6f\x6f\x6d\x4d\x65\x73\x73\x61\x67\x65',
        '\u5982\u4f60\u6240\u613f\x20\x28\u5e38\u89c1\u95ee\u9898\x3a\u8bf7\u5f00\u6743\u9650\x29\x7e',
        '\x49\x74\x65\x6d\x46\x65\x65\x74',
        '\x4d\x69\x73\x74\x72\x65\x73\x73\x50\x61\x64\x6c\x6f\x63\x6b',
        '\x61\x77\x61\x71\x77\x71',
        '\x76\x54\x67\x66\x5a',
        '\x32\x36\x37\x36\x37\x32\x38\x77\x6e\x47\x6a\x45\x79',
        '\x51\x76\x78\x47\x7a',
        '\x72\x42\x66\x62\x44',
        '\x30\x2e\x38\x2e\x33\x2d\x33\x65\x35\x34\x35\x62\x63\x32',
        '\x32\x35\x38\x36\x36\x36\x78\x77\x4a\x73\x71\x6b',
        '\x73\x56\x6a\x70\x59',
        '\x4e\x4c\x55\x57\x52',
        '\x69\x41\x61\x44\x50',
        '\x59\x76\x48\x77\x42',
        '\x43\x6f\x6e\x74\x65\x6e\x74',
        '\x4d\x56\x5a\x6c\x4e',
        '\x73\x59\x59\x55\x6b',
        '\x4b\x4e\x58\x46\x76',
        '\x75\x72\x76\x54\x44',
        '\x65\x4a\x53\x54\x54',
        '\x61\x77\x42\x4f\x54\x20',
        '\x70\x72\x6f\x74\x6f\x74\x79\x70\x65',
        '\x7a\x6e\x66\x56\x59',
        '\x57\x41\x50\x71\x52',
        '\x63\x50\x58\x4d\x6d',
        '\x41\x4a\x6f\x4e\x77',
        '\x57\x53\x63\x76\x57',
        '\x68\x77\x78\x78\x6b',
        '\x55\x66\x62\x58\x4b',
        '\x75\x71\x6f\x61\x63',
        '\x4c\x43\x78\x42\x43',
        '\x7a\x70\x71\x6f\x4e',
        '\x63\x4e\x76\x79\x77',
        '\x4c\x46\x6c\x51\x4d',
        '\x70\x79\x66\x53\x59',
        '\x73\x51\x50\x4d\x67',
        '\x6f\x66\x66',
        '\x49\x4c\x7a\x61\x4d',
        '\x45\x41\x43\x4d\x64',
        '\x57\x41\x71\x67\x62',
        '\x61\x47\x76\x52\x6f',
        '\x6b\x7a\x61\x74\x62',
        '\x54\x51\x44\x51\x6d',
        '\x48\x52\x75\x64\x41',
        '\x47\x58\x74\x75\x47',
        '\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x3a\x20\x45\x6e\x67\x6c\x69\x73\x68\x2e',
        '\x38\x31\x33\x32\x31\x6f\x49\x75\x54\x77\x51',
        '\x42\x44\x44\x46\x56',
        '\x64\x74\x58\x52\x79',
        '\x6b\x54\x75\x65\x58',
        '\x42\x61\x6e',
        '\x4f\x6d\x5a\x72\x71',
        '\x56\x41\x79\x45\x79',
        '\x49\x74\x65\x6d\x48\x6f\x6f\x64',
        '\x42\x4c\x52\x74\x4d',
        '\x5a\x64\x67\x4d\x73',
        '\u5982\u4f60\u6240\u613f\x20\x28\u5e38\u89c1\u95ee\u9898\x3a\u4e0d\u89e3\u4e3b\u4eba\x2f\u604b\u4eba\x2c\u8bf7\u5f00\u6743\u9650\x29\x7e',
        '\x7a\x73\x53\x45\x62',
        '\x48\x75\x44\x69\x46',
        '\x72\x77\x56\x70\x4e',
        '\x58\x46\x50\x62\x4f',
        '\x37\x39\x34\x36\x34\x53\x66\x49\x42\x49\x77',
        '\x45\x76\x61\x73\x69\x6f\x6e',
        '\x46\x78\x43\x64\x66',
        '\x43\x6f\x6c\x6c\x61\x72\x43\x68\x61\x69\x6e\x4c\x6f\x6e\x67',
        '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68',
        '\x62\x6b\x6b\x58\x4e',
        '\x66\x58\x41\x5a\x7a',
        '\x41\x67\x49\x47\x71',
        '\x6b\x71\x48\x4a\x7a',
        '\x4b\x4c\x50\x74\x68',
        '\x79\x70\x50\x76\x6f',
        '\x51\x69\x46\x46\x69',
        '\x6e\x46\x58\x52\x58',
        '\u901f\u901f\u81ea\u7f1a',
        '\x41\x49\x6d\x41\x56',
        '\x52\x4c\x6b\x43\x58',
        '\x50\x4d\x6f\x4c\x57',
        '\x71\x53\x6a\x76\x55',
        '\x43\x68\x61\x74\x53\x65\x61\x72\x63\x68',
        '\x66\x72\x52\x64\x74',
        '\x4d\x63\x51\x79\x55',
        '\x4c\x6f\x43\x4a\x79',
        '\x62\x6f\x6e\x64\x61\x67\x65',
        '\x6c\x6c\x43\x41\x74',
        '\x64\x77\x5a\x43\x44',
        '\x58\x65\x4a\x72\x54',
        '\x63\x4b\x54\x4f\x54',
        '\x56\x4c\x66\x6e\x69',
        '\x78\x45\x73\x70\x72',
        '\x76\x31\x2e\x30\x37\x20\x62\x79\x20\x41\x77\u9171\x20\u5728\x61\x77\x61\x71\x77\x71\u7684\u4e2a\u4eba\u7b80\u4ecb\u91cc\u9762\u6709\u4e0b\u8f7d\u94fe\u63a5\u7684\u8bf4\x7e',
        '\x69\x4c\x61\x79\x74',
        '\x42\x4c\x6a\x53\x4f',
        '\x45\x4c\x76\x52\x4e',
        '\x6a\x6a\x56\x61\x57',
        '\x49\x4c\x42\x47\x68',
        '\x79\x70\x4c\x77\x61',
        '\x62\x69\x6e\x64',
        '\x49\x62\x78\x72\x65',
        '\x70\x62\x42\x4e\x58',
        '\x46\x58\x76\x62\x42',
        '\x6c\x61\x51\x57\x43',
        '\x48\x42\x68\x66\x4b',
        '\x50\x61\x6e\x64\x6f\x72\x61\x50\x61\x64\x6c\x6f\x63\x6b',
        '\x49\x46\x61\x6d\x4e',
        '\x4e\x61\x6d\x65',
        '\x41\x77\x71',
        '\x56\x53\x49\x45\x57',
        '\x72\x65\x6c\x65\x61\x73\x65',
        '\x49\x46\x78\x4d\x54',
        '\x50\x74\x43\x4a\x49',
        '\x4c\x65\x61\x74\x68\x65\x72\x41\x72\x6d\x62\x69\x6e\x64\x65\x72',
        '\x4c\x70\x79\x72\x51',
        '\x6f\x63\x56\x59\x71',
        '\x79\x77\x5a\x41\x56',
        '\x6f\x4c\x45\x4d\x41',
        '\x77\x77\x6f\x51\x78',
        '\u58f0\u540d\u8fdc\u626c\x28\u4fee\u6539\u5404\u7c7b\u58f0\u8a89\x29',
        '\x4a\x58\x6d\x76\x48',
        '\x4b\x45\x59\x66\x41',
        '\x76\x65\x63\x44\x66',
        '\x41\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x2d\x77\x6f\x72\x64\x73\x3a\x72\x65\x6c\x65\x61\x73\x65\x2c\x62\x6f\x6e\x64\x61\x67\x65\x2c\x70\x6c\x61\x79\x73\x75\x69\x74\x2c\x6c\x6f\x63\x6b\x2c\x61\x62\x6f\x75\x74\x2c\x6c\x69\x63\x6b\x2c\x72\x61\x6e\x64\x6f\x6d\x2c\x62\x61\x6e\x6d\x65\x28\x74\x6f\x20\x67\x65\x74\x20\x73\x74\x75\x63\x6b\x2c\x75\x73\x65\x20\x74\x68\x69\x73\x20\x61\x66\x74\x65\x72\x20\x72\x61\x6e\x64\x6f\x6d\x20\x61\x6e\x64\x20\x6c\x6f\x63\x6b\x2e\x29\x2e\x49\x66\x20\x61\x20\x73\x65\x6e\x74\x65\x6e\x63\x65\x20\x69\x6e\x63\x6c\x75\x64\x69\x6e\x67\x20\x27\x61\x77\x71\x27\x20\x68\x61\x73\x20\x61\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x2d\x77\x6f\x72\x64\x20\x61\x74\x20\x74\x68\x65\x20\x73\x61\x6d\x65\x20\x74\x69\x6d\x65\x2c\x20\x74\x68\x65\x6e\x20\x74\x68\x65\x20\x63\x6f\x72\x72\x65\x73\x70\x6f\x6e\x64\x69\x6e\x67\x20\x61\x63\x74\x69\x6f\x6e\x20\x77\x69\x6c\x6c\x20\x62\x65\x20\x74\x61\x6b\x65\x6e\x2e',
        '\x54\x54\x73\x77\x64',
        '\x72\x45\x64\x65\x41',
        '\x74\x73\x50\x46\x64',
        '\x56\x71\x57\x52\x52',
        '\x52\x58\x69\x4a\x4d',
        '\x7a\x45\x75\x65\x44',
        '\x57\x46\x4d\x6f\x51',
        '\x6b\x6b\x73\x76\x5a',
        '\x6e\x6f\x6e\x65',
        '\x51\x59\x77\x69\x41',
        '\x67\x46\x69\x65\x77',
        '\x6e\x48\x6b\x52\x7a',
        '\x51\x49\x72\x71\x51',
        '\x54\x49\x56\x62\x57',
        '\x77\x67\x6a\x6d\x72',
        '\x6a\x68\x70\x70\x63',
        '\x76\x57\x72\x69\x46',
        '\x49\x74\x65\x6d\x56\x75\x6c\x76\x61',
        '\x4b\x53\x65\x52\x61',
        '\u79fb\u9664\u6781\u9650\x43\x44\x28\u5fc5\u987b\u65b0\u5207\x52\x50\u540e\u7528\x29',
        '\x76\x77\x54\x6c\x4e',
        '\x48\x6d\x71\x6f\x6b',
        '\x56\x6f\x64\x50\x5a',
        '\x54\x55\x66\x52\x46',
        '\x4e\x4a\x57\x44\x58',
        '\x61\x77\x42\x4f\x54\x20\u62b1\u6b49\x2c\u60a8\u5df2\u7ecf\u88ab\u5c01\u7981\u3002',
        '\x74\x79\x70\x69\x6e\x67\x49\x6e\x64\x69\x63\x61\x74\x6f\x72\x45\x6e\x61\x62\x6c\x65',
        '\x50\x76\x78\x51\x74',
        '\x46\x4a\x53\x6f\x6f',
        '\x61\x70\x70\x6c\x79',
        '\x42\x6f\x75\x6e\x74\x79\x53\x75\x69\x74\x63\x61\x73\x65',
        '\x68\x4d\x67\x6e\x64',
        '\u63d0\u5347\u64ac\u9501\u7b49\u7ea7',
        '\x68\x6e\x67\x64\x48',
        '\x72\x65\x71\x75\x65\x73\x74',
        '\x69\x6e\x66\x6f',
        '\u63d0\u5347\u5185\u9b3c\u7b49\u7ea7',
        '\x38\x31\x34\x46\x70\x59\x51\x56\x79',
        '\x4d\x65\x6d\x62\x65\x72\x4e\x75\x6d\x62\x65\x72',
        '\x49\x74\x65\x6d\x4e\x69\x70\x70\x6c\x65\x73\x50\x69\x65\x72\x63\x69\x6e\x67\x73',
        '\x48\x50\x58\x6d\x64',
        '\x6a\x54\x74\x62\x76',
        '\x4b\x72\x41\x78\x5a',
        '\x78\x68\x48\x42\x5a',
        '\x49\x74\x65\x6d\x4e\x6f\x73\x65',
        '\x63\x71\x4d\x55\x59',
        '\x78\x4e\x48\x47\x6d',
        '\x48\x6b\x71\x62\x73',
        '\x43\x78\x70\x71\x4c',
        '\x49\x7a\x49\x68\x67',
        '\x6e\x61\x7a\x65\x57',
        '\x46\x59\x66\x52\x6f',
        '\x41\x63\x74\x69\x6f\x6e\x52\x65\x6d\x6f\x76\x65',
        '\x73\x6d\x43\x6d\x66',
        '\x76\x74\x68\x66\x4c',
        '\x77\x41\x64\x78\x65',
        '\x62\x6c\x48\x70\x6b',
        '\x61\x77\x42\x4f\x54\x5f\u5f00\u5173\u9677\u9631\u5c4b',
        '\x46\x79\x58\x61\x48',
        '\x59\x70\x76\x50\x78',
        '\u7b11\x7e\x20\x28\u5e38\u89c1\u95ee\u9898\x3a\u8bf7\u5f00\u6743\u9650\x29\x7e',
        '\u95e8\u94a5\u5319',
        '\x42\x61\x41\x6b\x44',
        '\x47\x43\x61\x4d\x61',
        '\x5a\x42\x49\x54\x71',
        '\x43\x71\x50\x43\x74',
        '\u8981\u6346\u7684\u73a9\u5bb6\u540d\u79f0\x28\u5168\u5c0f\u5199\x29',
        '\x4f\x6e\x6c\x69\x6e\x65',
        '\x41\x50\x4a\x76\x51',
        '\x72\x77\x4d\x48\x55',
        '\x61\x77\x42\x4f\x54\x20\x53\x6f\x72\x72\x79\x20\x62\x75\x74\x20\x79\x6f\x75\x27\x76\x65\x20\x62\x65\x65\x6e\x20\x62\x61\x6e\x6e\x65\x64\x20\x62\x79\x20\x61\x6e\x20\x6f\x70\x65\x72\x61\x74\x6f\x72\x2e',
        '\x51\x45\x70\x6f\x6a',
        '\x55\x4e\x47\x4a\x72',
        '\x6a\x77\x41\x6d\x51',
        '\x6c\x64\x52\x71\x64',
        '\x61\x77\x54\x52\x41\x50\x20\x52\x75\x6c\x65\x73\x3a\x31\x2c\x57\x68\x65\x6e\x20\x74\x68\x65\x20\x72\x6f\x6f\x6d\x20\x77\x61\x73\x20\x63\x72\x65\x61\x74\x65\x64\x2c\x61\x20\x74\x69\x6d\x65\x72\x20\x77\x61\x73\x20\x73\x65\x74\x20\x74\x6f\x20\x31\x35\x20\x6d\x69\x6e\x73\x2e\x32\x2c\x42\x65\x66\x6f\x72\x65\x20\x74\x68\x65\x20\x74\x69\x6d\x65\x72\x20\x72\x75\x6e\x73\x20\x6f\x75\x74\x2c\x61\x6e\x79\x6f\x6e\x65\x20\x77\x68\x6f\x20\x63\x6f\x6d\x65\x73\x20\x69\x6e\x74\x6f\x20\x74\x68\x69\x73\x20\x72\x6f\x6f\x6d\x20\x77\x69\x6c\x6c\x20\x67\x65\x74\x20\x74\x72\x61\x70\x70\x65\x64\x2e\x33\x2c\x42\x65\x66\x72\x6f\x65\x20\x74\x68\x65\x20\x74\x69\x6d\x65\x72\x20\x72\x75\x6e\x73\x20\x6f\x75\x74\x2c\x61\x6e\x79\x6f\x6e\x65\x20\x77\x68\x6f\x20\x61\x74\x74\x65\x6d\x70\x74\x73\x20\x74\x6f\x20\x72\x65\x73\x63\x75\x65\x20\x77\x69\x6c\x6c\x20\x62\x65\x20\x62\x61\x6e\x6e\x65\x64\x2e\x34\x2c\x41\x66\x74\x65\x72\x20\x74\x68\x65\x20\x74\x69\x6d\x65\x72\x20\x72\x75\x6e\x73\x20\x6f\x75\x74\x2c\x20\x61\x77\x54\x52\x41\x50\x20\x77\x69\x6c\x6c\x20\x62\x65\x20\x73\x61\x66\x65\x2e\x54\x68\x6f\x73\x65\x20\x77\x68\x6f\x20\x61\x72\x65\x20\x74\x72\x61\x70\x70\x65\x64\x20\x63\x61\x6e\x20\x70\x6c\x65\x61\x64\x20\x70\x61\x73\x73\x65\x72\x2d\x62\x79\x73\x20\x66\x6f\x72\x20\x68\x65\x6c\x70\x20\x74\x68\x65\x6e\x2e',
        '\x59\x67\x53\x4e\x68',
        '\x6b\x59\x58\x79\x54',
        '\x53\x68\x53\x49\x4f',
        '\x59\x79\x4c\x57\x69',
        '\x65\x63\x43\x5a\x73',
        '\x73\x79\x6c\x6d\x75',
        '\x48\x65\x6c\x6c\x6f',
        '\x6e\x6e\x59\x71\x4a',
        '\x4d\x5a\x4b\x6b\x41',
        '\x69\x73\x63\x46\x58',
        '\x4d\x61\x79\x50\x6c',
        '\x41\x58\x52\x43\x64',
        '\x57\x63\x51\x45\x42',
        '\x56\x73\x4c\x72\x45',
        '\x51\x6f\x46\x45\x56'
    ];
    _0x803d = function () {
        return _0x1bf12e;
    };
    return _0x803d();
}
function _0x1c0d(_0x19a5d0, _0x803d58) {
    const _0x1c0da5 = _0x803d();
    return _0x1c0d = function (_0x37c014, _0x262cb0) {
        _0x37c014 = _0x37c014 - (0x38 + -0x157b + 0x15f4);
        let _0x4578d0 = _0x1c0da5[_0x37c014];
        return _0x4578d0;
    }, _0x1c0d(_0x19a5d0, _0x803d58);
}
(function (_0x9fc380, _0x199fae) {
    const _0x3ef142 = _0x1c0d, _0x10afd1 = _0x9fc380();
    while (!![]) {
        try {
            const _0x468836 = parseInt(_0x3ef142(0x33e)) / (-0x5 * 0x5a3 + 0x279 * 0x1 + 0x19b7) * (-parseInt(_0x3ef142(0xe5)) / (-0x25be + 0x15ef + 0x1 * 0xfd1)) + -parseInt(_0x3ef142(0x1e5)) / (-0x21 * -0x87 + -0x136e + 0x20a) + parseInt(_0x3ef142(0xc2)) / (-0x2f * 0xa4 + -0x2150 * -0x1 + -0x330) * (-parseInt(_0x3ef142(0xec)) / (0x2145 + 0xf * 0x15b + -0x3595 * 0x1)) + parseInt(_0x3ef142(0x1c0)) / (-0xfaa + 0x56 * -0x73 + 0x332 * 0x11) * (-parseInt(_0x3ef142(0x2b2)) / (0x21 * 0xeb + 0x2 * 0xdbc + 0x1 * -0x39bc)) + parseInt(_0x3ef142(0x1bc)) / (0xd73 + 0x1 * -0x8d2 + -0x499) * (parseInt(_0x3ef142(0xb1)) / (-0x1 * -0x5a8 + 0x2197 * -0x1 + 0x1bf8)) + -parseInt(_0x3ef142(0x345)) / (-0x12af * -0x2 + -0x1341 * 0x1 + -0x1213) + -parseInt(_0x3ef142(0x256)) / (-0x124d * -0x1 + 0x16 * 0xad + -0x8 * 0x424) * (-parseInt(_0x3ef142(0x1f4)) / (-0x161 * -0x17 + -0x1 * 0x222b + 0x280));
            if (_0x468836 === _0x199fae)
                break;
            else
                _0x10afd1['push'](_0x10afd1['shift']());
        } catch (_0x1221fe) {
            _0x10afd1['push'](_0x10afd1['shift']());
        }
    }
}(_0x803d, 0x20f + -0x5a199 + 0xd * 0xb1bd), (function () {
    const _0x3f8630 = _0x1c0d, _0x3e1db2 = {
            '\x67\x46\x6f\x6a\x41': function (_0x190c72, _0x1b6bec) {
                return _0x190c72 !== _0x1b6bec;
            },
            '\x7a\x6e\x66\x56\x59': _0x3f8630(0x1a7),
            '\x72\x77\x4d\x48\x55': _0x3f8630(0x16f),
            '\x53\x75\x4f\x54\x59': _0x3f8630(0x24a),
            '\x46\x68\x54\x46\x51': '\x43\x68\x61\x74',
            '\x69\x69\x72\x6e\x74': function (_0x54c9af, _0x351505) {
                return _0x54c9af === _0x351505;
            },
            '\x41\x67\x49\x47\x71': _0x3f8630(0x2f9),
            '\x45\x4d\x78\x45\x6a': function (_0x3f6eff, _0x5d8f3d, _0x1c0903, _0xfcc8a9, _0x14ba1b, _0x467ec5) {
                return _0x3f6eff(_0x5d8f3d, _0x1c0903, _0xfcc8a9, _0x14ba1b, _0x467ec5);
            },
            '\x6d\x75\x67\x75\x58': '\x42\x69\x74\x63\x68\x53\x75\x69\x74',
            '\x68\x68\x6a\x48\x74': _0x3f8630(0x308),
            '\x4d\x74\x76\x55\x6b': '\x23\x32\x30\x32\x30\x32\x30',
            '\x64\x44\x6a\x48\x53': function (_0xe16452, _0x2c5f10) {
                return _0xe16452(_0x2c5f10);
            },
            '\x6b\x6b\x66\x58\x7a': _0x3f8630(0x26d),
            '\x78\x45\x73\x70\x72': _0x3f8630(0xc7),
            '\x51\x46\x64\x61\x7a': _0x3f8630(0x301),
            '\x46\x78\x43\x64\x66': function (_0x52ec48) {
                return _0x52ec48();
            },
            '\x59\x43\x77\x63\x6e': _0x3f8630(0x157),
            '\x73\x79\x6c\x6d\x75': '\x6c\x6f\x67',
            '\x51\x65\x4c\x73\x69': '\x77\x61\x72\x6e',
            '\x6e\x69\x49\x64\x64': _0x3f8630(0x254),
            '\x43\x6f\x56\x53\x74': _0x3f8630(0x137),
            '\x6a\x75\x66\x70\x6f': '\x65\x78\x63\x65\x70\x74\x69\x6f\x6e',
            '\x63\x4f\x45\x45\x64': '\x74\x61\x62\x6c\x65',
            '\x78\x79\x53\x77\x62': function (_0x4d145e, _0x633419) {
                return _0x4d145e < _0x633419;
            },
            '\x4f\x6d\x5a\x72\x71': _0x3f8630(0x1b9),
            '\x5a\x64\x67\x4d\x73': _0x3f8630(0x1ba),
            '\x46\x4d\x51\x56\x6c': function (_0x32ebc0, _0x4f8842) {
                return _0x32ebc0 > _0x4f8842;
            },
            '\x6b\x7a\x61\x74\x62': function (_0x305bdb, _0x368e05) {
                return _0x305bdb !== _0x368e05;
            },
            '\x6f\x6c\x4a\x58\x6b': function (_0x302579, _0x599b31) {
                return _0x302579 == _0x599b31;
            },
            '\x73\x50\x45\x4e\x4e': function (_0x1fd40e, _0x134e55) {
                return _0x1fd40e == _0x134e55;
            },
            '\x4c\x74\x4c\x4c\x58': function (_0x5360f0, _0x185ee5) {
                return _0x5360f0 < _0x185ee5;
            },
            '\x49\x46\x61\x6d\x4e': function (_0x4faaba, _0x53b692) {
                return _0x4faaba !== _0x53b692;
            },
            '\x63\x53\x43\x79\x44': _0x3f8630(0x351),
            '\x76\x74\x68\x66\x4c': '\x4c\x6f\x63\x6b',
            '\x69\x43\x4a\x74\x59': _0x3f8630(0x32d),
            '\x4b\x71\x53\x58\x6e': function (_0x3ef5b5, _0x59dbd1, _0x2ffb21, _0x4e4278) {
                return _0x3ef5b5(_0x59dbd1, _0x2ffb21, _0x4e4278);
            },
            '\x70\x7a\x51\x48\x69': function (_0x4fd939, _0x2f2d87) {
                return _0x4fd939 > _0x2f2d87;
            },
            '\x71\x57\x6c\x41\x6a': _0x3f8630(0x110),
            '\x6a\x68\x70\x70\x63': _0x3f8630(0xf5),
            '\x53\x68\x53\x49\x4f': '\x67\x62\x69\x6b\x6a',
            '\x70\x47\x61\x53\x68': function (_0x2bc400, _0x422ada, _0x28a254, _0x329760, _0x30a1b6, _0x27d5f0) {
                return _0x2bc400(_0x422ada, _0x28a254, _0x329760, _0x30a1b6, _0x27d5f0);
            },
            '\x73\x6d\x43\x6d\x66': _0x3f8630(0x24f),
            '\x61\x5a\x77\x67\x73': function (_0x52a1ab, _0x2ec6be) {
                return _0x52a1ab != _0x2ec6be;
            },
            '\x4b\x45\x59\x66\x41': function (_0x4ce46f, _0x309eda) {
                return _0x4ce46f + _0x309eda;
            },
            '\x74\x4e\x6b\x6f\x70': '\x61\x77\x42\x4f\x54',
            '\x41\x64\x41\x77\x79': function (_0x2b4ac1, _0x153f73) {
                return _0x2b4ac1 === _0x153f73;
            },
            '\x42\x4c\x6a\x53\x4f': _0x3f8630(0xe6),
            '\x59\x70\x76\x50\x78': '\x69\x65\x56\x78\x4c',
            '\x44\x70\x72\x77\x70': function (_0x336dcd, _0x464a92, _0x53e7d1) {
                return _0x336dcd(_0x464a92, _0x53e7d1);
            },
            '\x45\x75\x51\x4b\x51': function (_0x4a4bc3, _0x1be367, _0x4e9ab7) {
                return _0x4a4bc3(_0x1be367, _0x4e9ab7);
            },
            '\x6b\x77\x4b\x6c\x4a': function (_0x547c31, _0x384526) {
                return _0x547c31 !== _0x384526;
            },
            '\x4a\x59\x46\x6a\x4f': _0x3f8630(0x13e),
            '\x50\x55\x5a\x4b\x4b': function (_0x437270, _0xb60217) {
                return _0x437270 + _0xb60217;
            },
            '\x54\x55\x66\x52\x46': function (_0x33c097, _0xbdee0b) {
                return _0x33c097 + _0xbdee0b;
            },
            '\x65\x6a\x53\x52\x52': _0x3f8630(0x294),
            '\x78\x77\x6b\x4d\x67': function (_0x56b8f7, _0x3418eb) {
                return _0x56b8f7 + _0x3418eb;
            },
            '\x78\x68\x48\x42\x5a': _0x3f8630(0x366),
            '\x4c\x58\x43\x47\x64': _0x3f8630(0x145),
            '\x73\x67\x55\x45\x4f': _0x3f8630(0x34f),
            '\x77\x62\x42\x46\x6e': _0x3f8630(0x17c),
            '\x73\x45\x49\x61\x46': function (_0x3b9420, _0x571970) {
                return _0x3b9420(_0x571970);
            },
            '\x68\x6e\x67\x64\x48': '\u4f60\u5fc5\u987b\u662f\x61\x77\x61\x71\x77\x71\u7684\x73\x75\x62\u624d\u80fd\u8fd9\u4e48\u505a\u5462\x7e',
            '\x6f\x56\x78\x72\x49': '\x77\x70\x70\x4e\x56',
            '\x58\x6b\x57\x50\x62': function (_0x2c635f, _0x43c89e) {
                return _0x2c635f > _0x43c89e;
            },
            '\x49\x53\x51\x43\x6f': '\x78\x77\x55\x74\x69',
            '\x66\x54\x66\x43\x62': _0x3f8630(0x305),
            '\x58\x42\x48\x4e\x4f': _0x3f8630(0xe3),
            '\x7a\x4f\x43\x64\x7a': _0x3f8630(0x114),
            '\x62\x4a\x74\x6e\x48': '\x50\x61\x6e\x64\x6f\x72\x61\x50\x61\x64\x6c\x6f\x63\x6b',
            '\x7a\x73\x77\x6b\x44': function (_0x35c804, _0x4ae09e, _0x282977, _0x106521, _0x3d5aa2, _0x5960ed) {
                return _0x35c804(_0x4ae09e, _0x282977, _0x106521, _0x3d5aa2, _0x5960ed);
            },
            '\x62\x6f\x78\x62\x4f': _0x3f8630(0xf9),
            '\x44\x79\x73\x4d\x61': function (_0x469581, _0x5c50e5) {
                return _0x469581 + _0x5c50e5;
            },
            '\x54\x49\x56\x62\x57': _0x3f8630(0x18e),
            '\x5a\x49\x54\x66\x78': _0x3f8630(0x142),
            '\x57\x6d\x61\x6c\x72': '\x78\x56\x6f\x4d\x76',
            '\x4e\x42\x6c\x54\x49': _0x3f8630(0x284),
            '\x57\x50\x43\x53\x4c': _0x3f8630(0xce),
            '\x42\x77\x72\x6a\x42': '\u672a\u77e5\u6307\u4ee4\uff01\x20\u53ef\u7528\u6307\u4ee4\x3a\x20\u6346\u6211\x20\u6346\u6b7b\u6211\x20\u8214\u6211\x20\u6551\u6211\x20\u73a9\u6211\x20\u9501\u6211\x20\u5173\u4e8e\x20\u5982\u679c\u4e00\u53e5\u8bdd\u540c\u65f6\u5305\u542b\x27\x61\x77\u9171\x27\u548c\u6307\u4ee4\uff0c\u6307\u4ee4\u5c31\u4f1a\u88ab\u6267\u884c\x7e',
            '\x69\x64\x45\x72\x69': _0x3f8630(0x226),
            '\x6c\x67\x46\x6c\x44': _0x3f8630(0x1b7),
            '\x52\x75\x61\x54\x5a': function (_0x510162, _0x42a705) {
                return _0x510162 === _0x42a705;
            },
            '\x4b\x51\x4f\x77\x4d': _0x3f8630(0x148),
            '\x56\x59\x78\x46\x4b': function (_0x5a5a51, _0x2d98c4) {
                return _0x5a5a51 != _0x2d98c4;
            },
            '\x78\x4b\x47\x5a\x69': '\x6e\x4d\x73\x57\x79',
            '\x6b\x6b\x73\x76\x5a': _0x3f8630(0x272),
            '\x46\x58\x76\x62\x42': _0x3f8630(0xd3),
            '\x75\x48\x57\x4e\x77': _0x3f8630(0xdf),
            '\x42\x4c\x52\x74\x4d': _0x3f8630(0x2e6),
            '\x6a\x75\x6d\x42\x6c': _0x3f8630(0x2aa),
            '\x51\x51\x41\x66\x62': '\x49\x74\x65\x6d\x4d\x69\x73\x63',
            '\x64\x49\x77\x56\x46': _0x3f8630(0x29a),
            '\x4d\x51\x69\x75\x6c': _0x3f8630(0x363),
            '\x4a\x46\x71\x77\x62': _0x3f8630(0xfe),
            '\x56\x52\x43\x6b\x4e': _0x3f8630(0x295),
            '\x74\x4b\x4d\x56\x45': _0x3f8630(0x258),
            '\x6b\x50\x63\x6a\x51': _0x3f8630(0x25d),
            '\x76\x65\x63\x44\x66': _0x3f8630(0x353),
            '\x66\x72\x52\x64\x74': '\x49\x74\x65\x6d\x56\x75\x6c\x76\x61',
            '\x77\x41\x64\x78\x65': _0x3f8630(0x1cb),
            '\x58\x58\x4d\x6d\x6e': _0x3f8630(0x32b),
            '\x42\x61\x79\x56\x47': _0x3f8630(0x230),
            '\x69\x41\x61\x44\x50': function (_0x3f13cc, _0x4e5270) {
                return _0x3f13cc(_0x4e5270);
            },
            '\x73\x4d\x70\x6a\x6c': function (_0x2d314d, _0x3cd90c) {
                return _0x2d314d === _0x3cd90c;
            },
            '\x4b\x66\x66\x79\x65': _0x3f8630(0x1f9),
            '\x6b\x78\x46\x4e\x79': _0x3f8630(0x329),
            '\x4b\x4f\x4b\x6e\x75': '\x41\x73\x20\x75\x20\x77\x69\x73\x68\x7e\x28\x47\x6f\x6f\x64\x20\x6c\x75\x63\x6b\x21\x29',
            '\x6d\x71\x47\x5a\x50': _0x3f8630(0x17d),
            '\x6e\x48\x6b\x52\x7a': _0x3f8630(0x105),
            '\x63\x65\x46\x50\x43': _0x3f8630(0x12f),
            '\x58\x4d\x7a\x45\x6c': function (_0x1c57c3, _0x54a8d0) {
                return _0x1c57c3 != _0x54a8d0;
            },
            '\x52\x76\x7a\x50\x57': _0x3f8630(0x176),
            '\x76\x47\x6e\x5a\x6f': _0x3f8630(0x1c9),
            '\x57\x63\x78\x66\x6c': _0x3f8630(0x1de),
            '\x4b\x53\x65\x52\x61': _0x3f8630(0x34c),
            '\x6c\x65\x52\x77\x58': _0x3f8630(0x1f8),
            '\x4e\x70\x53\x47\x77': _0x3f8630(0x339),
            '\x48\x6b\x71\x62\x73': _0x3f8630(0xc9),
            '\x50\x76\x55\x75\x61': function (_0xf3fe69, _0x51162a) {
                return _0xf3fe69(_0x51162a);
            },
            '\x75\x67\x7a\x4e\x6e': _0x3f8630(0x221),
            '\x64\x77\x5a\x43\x44': _0x3f8630(0x341),
            '\x43\x74\x51\x41\x78': function (_0x27820b, _0x39f121) {
                return _0x27820b == _0x39f121;
            },
            '\x46\x77\x6e\x4f\x50': function (_0x4d21d4, _0x2aea93) {
                return _0x4d21d4 != _0x2aea93;
            },
            '\x79\x4e\x77\x71\x42': _0x3f8630(0x135),
            '\x45\x63\x53\x68\x78': _0x3f8630(0x146),
            '\x4b\x4c\x50\x74\x68': _0x3f8630(0x15b),
            '\x45\x5a\x79\x5a\x50': function (_0x25661a, _0x46a7c1) {
                return _0x25661a(_0x46a7c1);
            },
            '\x57\x6b\x70\x76\x45': function (_0x22ab89, _0x21c1df, _0x45c1a9) {
                return _0x22ab89(_0x21c1df, _0x45c1a9);
            },
            '\x62\x72\x73\x4c\x6c': _0x3f8630(0x283),
            '\x5a\x7a\x45\x74\x52': function (_0x1e3b89, _0x3e556b, _0x332ac6) {
                return _0x1e3b89(_0x3e556b, _0x332ac6);
            },
            '\x45\x6b\x63\x45\x4c': _0x3f8630(0x326),
            '\x41\x50\x4a\x76\x51': _0x3f8630(0x1bf),
            '\x72\x51\x6d\x43\x78': function (_0x5a0890, _0x3decdf) {
                return _0x5a0890 > _0x3decdf;
            },
            '\x47\x49\x54\x68\x4d': function (_0x41ea62, _0xe954ea) {
                return _0x41ea62 == _0xe954ea;
            },
            '\x73\x45\x46\x64\x59': function (_0x3725d3, _0x228767) {
                return _0x3725d3 !== _0x228767;
            },
            '\x78\x68\x74\x78\x56': _0x3f8630(0x1b8),
            '\x69\x7a\x6a\x71\x63': _0x3f8630(0x1ec),
            '\x78\x4f\x6e\x61\x54': _0x3f8630(0xba),
            '\x79\x54\x65\x74\x45': '\x49\x74\x65\x6d\x56\x75\x6c\x76\x61\x50\x69\x65\x72\x63\x69\x6e\x67\x73',
            '\x43\x53\x56\x50\x74': _0x3f8630(0x27c),
            '\x59\x67\x53\x4e\x68': function (_0x155f0a, _0x18e75a, _0x2772a4, _0x551bb3) {
                return _0x155f0a(_0x18e75a, _0x2772a4, _0x551bb3);
            },
            '\x4e\x4a\x57\x44\x58': function (_0x21fac7, _0x425738, _0x25daf5) {
                return _0x21fac7(_0x425738, _0x25daf5);
            },
            '\x55\x4a\x66\x59\x72': '\x44\x6f\x6d\x69\x6e\x61\x6e\x74\x20\x20\x4b\x69\x64\x6e\x61\x70\x20\x20\x41\x42\x44\x4c\x20\x20\x47\x61\x6d\x69\x6e\x67\x20\x20\x4d\x61\x69\x64\x20\x20\x4c\x41\x52\x50\x20\x20\x41\x73\x79\x6c\x75\x6d\x20\x20\x47\x61\x6d\x62\x6c\x69\x6e\x67\x20\x20\x48\x6f\x75\x73\x65\x4d\x61\x69\x65\x73\x74\x61\x73\x20\x20\x48\x6f\x75\x73\x65\x56\x69\x6e\x63\x75\x6c\x61\x20\x20\x48\x6f\x75\x73\x65\x41\x6d\x70\x6c\x65\x63\x74\x6f\x72\x20\x20\x48\x6f\x75\x73\x65\x43\x6f\x72\x70\x6f\x72\x69\x73',
            '\x4e\x47\x66\x55\x4f': _0x3f8630(0x121),
            '\x46\x65\x5a\x6e\x6e': function (_0x4820f6, _0xedb891) {
                return _0x4820f6 == _0xedb891;
            },
            '\x71\x57\x6a\x5a\x4b': _0x3f8630(0x265),
            '\x54\x61\x7a\x7a\x75': _0x3f8630(0x1e9),
            '\x54\x51\x44\x51\x6d': '\x76\x31\x2e\x30\x37\x20\x62\x79\x20\x41\x77\u9171\x20\u5728\x61\x77\x61\x71\x77\x71\u7684\u4e2a\u4eba\u7b80\u4ecb\u91cc\u9762\u6709\u4e0b\u8f7d\u94fe\u63a5\u7684\u8bf4\x7e',
            '\x43\x72\x46\x55\x7a': '\x4a\x5a\x48\x46\x63',
            '\x49\x4c\x42\x47\x68': function (_0x538ae7, _0x1b9498) {
                return _0x538ae7 == _0x1b9498;
            },
            '\x4d\x63\x51\x79\x55': function (_0x4b26fe, _0x290f15) {
                return _0x4b26fe === _0x290f15;
            },
            '\x70\x61\x45\x49\x6f': '\x76\x45\x52\x6f\x43',
            '\x45\x6d\x51\x62\x5a': function (_0x269c20, _0x45de8c) {
                return _0x269c20 == _0x45de8c;
            },
            '\x46\x4d\x44\x59\x70': function (_0x192b23, _0x66079b) {
                return _0x192b23 == _0x66079b;
            },
            '\x73\x51\x4d\x41\x67': _0x3f8630(0x239),
            '\x68\x6f\x5a\x63\x57': function (_0x12e19a, _0x2bb3c5) {
                return _0x12e19a === _0x2bb3c5;
            },
            '\x79\x65\x64\x43\x56': _0x3f8630(0x365),
            '\x6c\x69\x47\x5a\x46': _0x3f8630(0xed),
            '\x4e\x62\x76\x62\x6b': function (_0x3b08ad, _0x13bd09) {
                return _0x3b08ad(_0x13bd09);
            },
            '\x41\x4a\x6f\x4e\x77': _0x3f8630(0x322),
            '\x75\x57\x52\x6e\x77': _0x3f8630(0x2b6),
            '\x6a\x6d\x6a\x64\x48': function (_0x40fc5b, _0x34f6d7, _0x183b74) {
                return _0x40fc5b(_0x34f6d7, _0x183b74);
            },
            '\x7a\x76\x65\x64\x7a': function (_0x12f25c, _0x5e0b23) {
                return _0x12f25c === _0x5e0b23;
            },
            '\x69\x46\x61\x73\x5a': _0x3f8630(0x2f8),
            '\x71\x46\x71\x63\x4a': '\x50\x72\x52\x51\x61',
            '\x7a\x45\x59\x56\x67': '\u5c01\u7981\u5931\u8d25\x3a\u73a9\u5bb6\u5df2\u7ecf\u88ab\u5c01\u7981',
            '\x71\x71\x6f\x72\x65': _0x3f8630(0x29e),
            '\x73\x7a\x6a\x67\x69': function (_0x541b1c, _0x45544c) {
                return _0x541b1c(_0x45544c);
            },
            '\x65\x4a\x53\x54\x54': function (_0x50a7f7, _0x39ace9, _0x422321) {
                return _0x50a7f7(_0x39ace9, _0x422321);
            },
            '\x47\x72\x7a\x77\x61': _0x3f8630(0x297),
            '\x54\x52\x4a\x6c\x43': function (_0x50b59a, _0x28bc4b) {
                return _0x50b59a == _0x28bc4b;
            },
            '\x64\x74\x58\x52\x79': '\u5c01\u7981\u5931\u8d25\x3a\u73a9\u5bb6\u6ca1\u6709\u88ab\u5c01\u7981',
            '\x55\x4e\x47\x4a\x72': _0x3f8630(0xd4),
            '\x66\x46\x6d\x49\x69': function (_0x5447a8, _0x17a235, _0x37557a) {
                return _0x5447a8(_0x17a235, _0x37557a);
            },
            '\x75\x63\x5a\x66\x70': '\x58\x67\x45\x6d\x42',
            '\x66\x58\x41\x5a\x7a': '\x62\x49\x58\x52\x69',
            '\x4c\x46\x6c\x51\x4d': '\x53\x63\x72\x69\x70\x74\x20\x6d\x61\x64\x65\x20\x62\x79\x3a\x61\x77\x61\x71\x77\x71\x5f\x68\x75\x7a\x70\x73\x62',
            '\x47\x4a\x70\x66\x52': function (_0xef96ce, _0x540c44, _0x21cfdf) {
                return _0xef96ce(_0x540c44, _0x21cfdf);
            },
            '\x47\x74\x73\x70\x76': '\x53\x65\x6c\x66\x42\x6f\x6e\x64\x61\x67\x65',
            '\x63\x4b\x54\x4f\x54': _0x3f8630(0x2af),
            '\x69\x79\x48\x49\x57': _0x3f8630(0x2c2),
            '\x45\x78\x42\x64\x7a': function (_0x2f52e5, _0x47e3ed) {
                return _0x2f52e5(_0x47e3ed);
            },
            '\x65\x4e\x75\x6b\x61': function (_0x31780a, _0x596b45) {
                return _0x31780a == _0x596b45;
            },
            '\x79\x4f\x50\x67\x79': _0x3f8630(0x314),
            '\x78\x67\x56\x63\x75': _0x3f8630(0x274),
            '\x61\x77\x66\x52\x67': function (_0xeb6476) {
                return _0xeb6476();
            },
            '\x48\x53\x63\x79\x6f': '\x4d\x61\x69\x6e\x48\x61\x6c\x6c',
            '\x72\x4a\x68\x66\x57': _0x3f8630(0xc1),
            '\x4d\x44\x47\x6c\x68': _0x3f8630(0x14c),
            '\x63\x71\x4d\x55\x59': function (_0x2387cb, _0x5b8ef2, _0x56d671, _0x31199f) {
                return _0x2387cb(_0x5b8ef2, _0x56d671, _0x31199f);
            },
            '\x64\x66\x42\x4c\x56': _0x3f8630(0x1f5),
            '\x56\x71\x57\x52\x52': function (_0x4f0de5, _0x40034d) {
                return _0x4f0de5 !== _0x40034d;
            },
            '\x65\x54\x54\x6b\x69': _0x3f8630(0x2b8),
            '\x56\x6f\x64\x50\x5a': _0x3f8630(0x2dd),
            '\x47\x69\x66\x41\x6e': function (_0x25b49a, _0x4e8ec6, _0x43c89c) {
                return _0x25b49a(_0x4e8ec6, _0x43c89c);
            },
            '\x72\x4d\x57\x4b\x4e': _0x3f8630(0x2c0),
            '\x78\x48\x58\x72\x69': _0x3f8630(0x1f7),
            '\x6f\x51\x4e\x45\x6e': function (_0x47116d, _0x169715, _0x1de314, _0x4882ab, _0x3a188e, _0x4c52de) {
                return _0x47116d(_0x169715, _0x1de314, _0x4882ab, _0x3a188e, _0x4c52de);
            },
            '\x41\x43\x6b\x68\x68': _0x3f8630(0x358),
            '\x68\x68\x70\x4e\x61': _0x3f8630(0x10b),
            '\x6c\x58\x73\x48\x62': function (_0x3d7a47, _0x5be67d, _0x1e2288, _0x2c39df, _0x13908f, _0xe1d8df) {
                return _0x3d7a47(_0x5be67d, _0x1e2288, _0x2c39df, _0x13908f, _0xe1d8df);
            },
            '\x58\x6f\x63\x65\x55': '\x4c\x65\x61\x74\x68\x65\x72\x48\x6f\x6f\x64\x4f\x70\x65\x6e\x4d\x6f\x75\x74\x68',
            '\x6b\x54\x75\x65\x58': '\x49\x74\x65\x6d\x48\x65\x61\x64',
            '\x68\x6f\x42\x77\x73': '\x4c\x65\x61\x74\x68\x65\x72\x48\x61\x72\x6e\x65\x73\x73',
            '\x50\x74\x43\x4a\x49': function (_0x370579, _0x49a04d, _0x18e43c, _0x57a99d, _0x4bd62b, _0x277c00) {
                return _0x370579(_0x49a04d, _0x18e43c, _0x57a99d, _0x4bd62b, _0x277c00);
            },
            '\x50\x4e\x75\x5a\x48': _0x3f8630(0x2f7),
            '\x7a\x6b\x79\x50\x4d': _0x3f8630(0x32e),
            '\x72\x45\x64\x65\x41': _0x3f8630(0x2c7),
            '\x6d\x63\x56\x57\x69': function (_0x3f36da, _0x5c938a, _0x2189fe, _0x6665f6, _0x34149c, _0xc5a68f) {
                return _0x3f36da(_0x5c938a, _0x2189fe, _0x6665f6, _0x34149c, _0xc5a68f);
            },
            '\x6a\x77\x41\x6d\x51': _0x3f8630(0x2b4),
            '\x4c\x51\x72\x48\x77': function (_0x11c27d, _0x5f35cd) {
                return _0x11c27d !== _0x5f35cd;
            },
            '\x45\x74\x66\x68\x7a': _0x3f8630(0x325),
            '\x59\x64\x4f\x5a\x4c': '\x70\x63\x48\x65\x67',
            '\x44\x4d\x59\x66\x65': function (_0x59ff80, _0x2dde88) {
                return _0x59ff80(_0x2dde88);
            },
            '\x7a\x70\x4e\x43\x6d': '\x6d\x69\x45\x54\x73',
            '\x74\x52\x45\x6d\x71': '\x42\x65\x65\x70',
            '\x76\x57\x72\x69\x46': function (_0x4efdf5, _0x4566b0, _0x20a8c2) {
                return _0x4efdf5(_0x4566b0, _0x20a8c2);
            },
            '\x41\x49\x6d\x41\x56': '\u4f60\u8981\u8bf4\u7684\u8bdd',
            '\x6f\x4c\x45\x4d\x41': _0x3f8630(0x13a),
            '\x47\x54\x55\x78\x45': _0x3f8630(0x337),
            '\x73\x5a\x65\x57\x4e': function (_0x20ff0a) {
                return _0x20ff0a();
            },
            '\x47\x7a\x43\x5a\x4d': _0x3f8630(0x1a0),
            '\x74\x73\x50\x46\x64': function (_0x13bc26, _0x14b63c, _0x5c2bff) {
                return _0x13bc26(_0x14b63c, _0x5c2bff);
            },
            '\x4d\x56\x5a\x6c\x4e': function (_0x21e34e, _0x2b55d9) {
                return _0x21e34e(_0x2b55d9);
            },
            '\x51\x69\x46\x46\x69': function (_0x15beb7, _0x62899c, _0x4b6a7b, _0x5b9396, _0x41fba3, _0x21a651) {
                return _0x15beb7(_0x62899c, _0x4b6a7b, _0x5b9396, _0x41fba3, _0x21a651);
            },
            '\x66\x65\x6d\x79\x69': function (_0x38bdb0, _0x475e5e, _0x51b73e, _0x5b7efa, _0x31c967, _0x5cc282) {
                return _0x38bdb0(_0x475e5e, _0x51b73e, _0x5b7efa, _0x31c967, _0x5cc282);
            },
            '\x71\x6f\x69\x6b\x43': '\x43\x4b\x51\x4e\x77',
            '\x75\x69\x5a\x44\x49': _0x3f8630(0x22b),
            '\x42\x64\x78\x71\x65': function (_0x56660e, _0x23768f) {
                return _0x56660e == _0x23768f;
            },
            '\x49\x6e\x61\x4c\x79': _0x3f8630(0x1f0),
            '\x68\x4d\x67\x6e\x64': function (_0x3dbac9, _0x494a3e) {
                return _0x3dbac9(_0x494a3e);
            },
            '\x6e\x61\x7a\x65\x57': function (_0x5aa3e4, _0x16e680, _0x447b08) {
                return _0x5aa3e4(_0x16e680, _0x447b08);
            },
            '\x6c\x6c\x43\x41\x74': _0x3f8630(0x273),
            '\x48\x75\x44\x69\x46': function (_0x500614, _0xc4ee4e) {
                return _0x500614 == _0xc4ee4e;
            },
            '\x77\x46\x68\x47\x4f': function (_0x48eb2a, _0x1a8995, _0x4da38b, _0x3c8a7e, _0x1a342d, _0x594270) {
                return _0x48eb2a(_0x1a8995, _0x4da38b, _0x3c8a7e, _0x1a342d, _0x594270);
            },
            '\x56\x44\x55\x6f\x62': function (_0x49ddd4, _0x5582aa) {
                return _0x49ddd4(_0x5582aa);
            },
            '\x50\x5a\x64\x4f\x50': function (_0x46ace2, _0x114ba0) {
                return _0x46ace2 === _0x114ba0;
            },
            '\x57\x47\x77\x5a\x66': _0x3f8630(0x17f),
            '\x59\x52\x76\x70\x59': _0x3f8630(0x246),
            '\x6b\x77\x66\x65\x6d': function (_0xb4b677, _0x4010a2) {
                return _0xb4b677 !== _0x4010a2;
            },
            '\x72\x64\x6a\x54\x41': _0x3f8630(0x138),
            '\x75\x71\x6f\x61\x63': _0x3f8630(0x2ca),
            '\x41\x64\x6f\x78\x46': _0x3f8630(0xfb),
            '\x73\x51\x50\x4d\x67': _0x3f8630(0x198),
            '\x42\x63\x49\x52\x4b': function (_0x64005a, _0xac96e) {
                return _0x64005a(_0xac96e);
            },
            '\x79\x70\x50\x76\x6f': function (_0x3f149f, _0x33e5c1, _0x4e11b9) {
                return _0x3f149f(_0x33e5c1, _0x4e11b9);
            },
            '\x79\x66\x59\x62\x51': function (_0x4615ed, _0x511a4b, _0x26573c) {
                return _0x4615ed(_0x511a4b, _0x26573c);
            },
            '\x48\x54\x75\x6e\x64': function (_0x44d977) {
                return _0x44d977();
            },
            '\x6f\x79\x73\x61\x45': function (_0xb7a9ec, _0x17fa50, _0x415c12) {
                return _0xb7a9ec(_0x17fa50, _0x415c12);
            },
            '\x49\x51\x4b\x52\x5a': _0x3f8630(0x2ec),
            '\x4a\x43\x77\x4d\x6d': function (_0x106946, _0x253258, _0x1b02a4) {
                return _0x106946(_0x253258, _0x1b02a4);
            },
            '\x44\x47\x45\x4e\x54': _0x3f8630(0x26a),
            '\x79\x77\x5a\x41\x56': _0x3f8630(0x189),
            '\x4d\x50\x53\x4c\x74': _0x3f8630(0x2b0),
            '\x63\x43\x70\x49\x41': _0x3f8630(0x183),
            '\x79\x70\x4c\x77\x61': function (_0x396694, _0x3f0cfb, _0x5a0f5f) {
                return _0x396694(_0x3f0cfb, _0x5a0f5f);
            },
            '\x76\x5a\x43\x74\x68': _0x3f8630(0xb8),
            '\x73\x6a\x4c\x5a\x6e': _0x3f8630(0x26e),
            '\x4b\x47\x79\x64\x53': '\u529b\u5927\u65e0\u7a77\x28\u77ac\u95f4\u6323\u8131\x29',
            '\x43\x78\x70\x71\x4c': function (_0x43b942, _0x542d8e, _0x2ec24e) {
                return _0x43b942(_0x542d8e, _0x2ec24e);
            },
            '\x65\x6a\x4c\x55\x48': '\u63d0\u5347\u81ea\u7f1a\u7b49\u7ea7',
            '\x5a\x59\x72\x6c\x55': _0x3f8630(0x251),
            '\x74\x69\x6b\x57\x67': function (_0x468044, _0x5d22eb, _0x3d09ce) {
                return _0x468044(_0x5d22eb, _0x3d09ce);
            },
            '\x6e\x4a\x48\x5a\x79': _0x3f8630(0x244),
            '\x4b\x4e\x58\x46\x76': function (_0x2d120d, _0x1a1889, _0xc270c4) {
                return _0x2d120d(_0x1a1889, _0xc270c4);
            },
            '\x73\x4f\x53\x66\x66': _0x3f8630(0x255),
            '\x6c\x70\x76\x71\x6f': function (_0x100c78, _0x53f861, _0x16f769) {
                return _0x100c78(_0x53f861, _0x16f769);
            },
            '\x4e\x66\x51\x63\x41': _0x3f8630(0x127),
            '\x71\x54\x71\x61\x6b': function (_0x27da52, _0x21d987, _0x2d54c3) {
                return _0x27da52(_0x21d987, _0x2d54c3);
            },
            '\x47\x6a\x70\x5a\x58': '\u62ff\u7bb1\u5b50',
            '\x44\x71\x43\x48\x70': _0x3f8630(0x155),
            '\x51\x43\x4f\x50\x53': '\u58f0\u97f3\u6d2a\u4eae\x28\u8bf4\u4ec0\u4e48\u5c31\u662f\u4ec0\u4e48\x29',
            '\x55\x69\x64\x7a\x54': function (_0x4a54d7, _0x1b9636, _0x520f14) {
                return _0x4a54d7(_0x1b9636, _0x520f14);
            },
            '\x41\x49\x6f\x55\x77': '\u901f\u901f\u7ed1\u7f1a\x28\u641e\u4e8b\u60c5\u4e13\u7528\x29',
            '\x51\x5a\x72\x69\x70': function (_0x9098f1, _0x1afc11, _0x289252) {
                return _0x9098f1(_0x1afc11, _0x289252);
            },
            '\x50\x71\x77\x6b\x41': '\u4e0a\u9501\x28\u641e\u4e8b\u60c5\u4e13\u7528\x29',
            '\x56\x6d\x4a\x49\x44': function (_0x16e674, _0x539daa, _0x383cd0) {
                return _0x16e674(_0x539daa, _0x383cd0);
            }
        }, _0x1297f1 = (function () {
            const _0x3d5d67 = _0x3f8630, _0xe2023c = {
                    '\x6a\x69\x43\x52\x74': function (_0x205439, _0x4ddd76) {
                        const _0x4cba98 = _0x1c0d;
                        return _0x3e1db2[_0x4cba98(0xcc)](_0x205439, _0x4ddd76);
                    },
                    '\x50\x76\x78\x51\x74': _0x3e1db2[_0x3d5d67(0x1cd)],
                    '\x4a\x62\x49\x65\x6f': _0x3d5d67(0x28c),
                    '\x44\x4b\x4e\x78\x56': _0x3e1db2[_0x3d5d67(0x276)],
                    '\x46\x62\x50\x4e\x41': _0x3e1db2[_0x3d5d67(0xf1)],
                    '\x4d\x6b\x64\x54\x6a': _0x3e1db2[_0x3d5d67(0x16b)]
                };
            if (_0x3e1db2[_0x3d5d67(0x2e7)](_0x3e1db2['\x41\x67\x49\x47\x71'], _0x3e1db2[_0x3d5d67(0x1fb)])) {
                let _0x49d73d = !![];
                return function (_0xa8613a, _0x3e2847) {
                    const _0x281dc3 = _0x3d5d67, _0x2a8daf = {};
                    _0x2a8daf['\x74\x45\x5a\x45\x74'] = _0x281dc3(0x1b9);
                    const _0x2f32a4 = _0x2a8daf, _0x4af2a2 = _0x49d73d ? function () {
                            const _0x279040 = _0x281dc3;
                            if (_0xe2023c['\x6a\x69\x43\x52\x74'](_0xe2023c[_0x279040(0x24c)], _0xe2023c[_0x279040(0x174)])) {
                                if (_0x3e2847) {
                                    const _0x2688f3 = _0x3e2847[_0x279040(0x24e)](_0xa8613a, arguments);
                                    return _0x3e2847 = null, _0x2688f3;
                                }
                            } else
                                _0x2c4d76[_0x279040(0x161)][_0x279040(0x14b)] = _0x2f32a4['\x74\x45\x5a\x45\x74'];
                        } : function () {
                        };
                    return _0x49d73d = ![], _0x4af2a2;
                };
            } else
                _0x1076e8(_0xe2023c[_0x3d5d67(0xc8)], {
                    '\x43\x6f\x6e\x74\x65\x6e\x74': _0xe2023c[_0x3d5d67(0x173)],
                    '\x54\x79\x70\x65': _0xe2023c['\x4d\x6b\x64\x54\x6a']
                });
        }()), _0xd05991 = _0x3e1db2[_0x3f8630(0x296)](_0x1297f1, this, function () {
            const _0x4a89d9 = _0x3f8630;
            let _0x142c9f;
            try {
                const _0x1ee531 = _0x3e1db2[_0x4a89d9(0xc6)](Function, _0x3e1db2[_0x4a89d9(0x210)] + _0x3e1db2['\x51\x46\x64\x61\x7a'] + '\x29\x3b');
                _0x142c9f = _0x3e1db2[_0x4a89d9(0x1f6)](_0x1ee531);
            } catch (_0x557e1e) {
                _0x3e1db2['\x59\x43\x77\x63\x6e'] !== _0x3e1db2[_0x4a89d9(0x2fe)] ? (_0x3e1db2[_0x4a89d9(0x1b3)](_0x4e6e8b, _0x406503, _0x3e1db2[_0x4a89d9(0x292)], _0x3e1db2[_0x4a89d9(0x30e)], _0x3e1db2[_0x4a89d9(0x165)], -0x11788 + 0xe1e * -0x31 + 0x58a98), _0x2260ec[_0x4a89d9(0x193)]['\x50\x72\x6f\x67\x72\x65\x73\x73'] = -0x1fcc + -0x1 * 0x2456 + -0x22 * -0x201, _0x3e1db2[_0x4a89d9(0xc6)](_0x2d2bc6, _0x33f91b), _0x1c5cbf = _0x3e1db2['\x6b\x6b\x66\x58\x7a']) : _0x142c9f = window;
            }
            const _0x5353df = _0x142c9f[_0x4a89d9(0x2d1)] = _0x142c9f[_0x4a89d9(0x2d1)] || {}, _0x39bb96 = [
                    _0x3e1db2[_0x4a89d9(0x282)],
                    _0x3e1db2[_0x4a89d9(0x30c)],
                    _0x3e1db2['\x6e\x69\x49\x64\x64'],
                    _0x3e1db2[_0x4a89d9(0xe2)],
                    _0x3e1db2['\x6a\x75\x66\x70\x6f'],
                    _0x3e1db2[_0x4a89d9(0x159)],
                    '\x74\x72\x61\x63\x65'
                ];
            for (let _0x693f2c = 0x227f + -0x1 * 0x23bd + 0x13e; _0x3e1db2['\x78\x79\x53\x77\x62'](_0x693f2c, _0x39bb96[_0x4a89d9(0x147)]); _0x693f2c++) {
                const _0x54a53f = _0x1297f1['\x63\x6f\x6e\x73\x74\x72\x75\x63\x74\x6f\x72'][_0x4a89d9(0x1cc)][_0x4a89d9(0x218)](_0x1297f1), _0x3883c0 = _0x39bb96[_0x693f2c], _0x502657 = _0x5353df[_0x3883c0] || _0x54a53f;
                _0x54a53f[_0x4a89d9(0xdd)] = _0x1297f1['\x62\x69\x6e\x64'](_0x1297f1), _0x54a53f['\x74\x6f\x53\x74\x72\x69\x6e\x67'] = _0x502657[_0x4a89d9(0x19c)][_0x4a89d9(0x218)](_0x502657), _0x5353df[_0x3883c0] = _0x54a53f;
            }
        });
    _0x3e1db2[_0x3f8630(0x320)](_0xd05991), _0x3e1db2['\x6f\x79\x73\x61\x45'](GM_registerMenuCommand, _0x3f8630(0x348), () => {
        const _0x6d4eb1 = _0x3f8630, _0x3e4a78 = {
                '\x6e\x46\x58\x52\x58': function (_0x5bca6b, _0x5e3f72) {
                    const _0x38d466 = _0x1c0d;
                    return _0x3e1db2[_0x38d466(0x119)](_0x5bca6b, _0x5e3f72);
                },
                '\x7a\x79\x41\x4a\x47': _0x3e1db2[_0x6d4eb1(0x2ef)],
                '\x51\x6d\x56\x64\x55': function (_0x224b81, _0x37efcc, _0x2880a7) {
                    return _0x224b81(_0x37efcc, _0x2880a7);
                },
                '\x50\x4d\x6f\x4c\x57': _0x3e1db2[_0x6d4eb1(0x25c)],
                '\x44\x4f\x4f\x4a\x47': _0x3e1db2[_0x6d4eb1(0xf0)],
                '\x69\x4c\x61\x79\x74': _0x3e1db2[_0x6d4eb1(0xe4)],
                '\x75\x52\x45\x7a\x50': _0x3e1db2[_0x6d4eb1(0x117)],
                '\x4e\x61\x6e\x50\x72': function (_0x1dd4d2, _0x107945) {
                    const _0x386c3b = _0x6d4eb1;
                    return _0x3e1db2[_0x386c3b(0x109)](_0x1dd4d2, _0x107945);
                },
                '\x4b\x6f\x47\x74\x74': _0x3e1db2[_0x6d4eb1(0x252)],
                '\x69\x73\x63\x46\x58': _0x6d4eb1(0x1ef),
                '\x49\x5a\x4d\x66\x55': function (_0x2fa80d, _0x201127) {
                    return _0x2fa80d !== _0x201127;
                },
                '\x62\x71\x59\x4e\x47': _0x3e1db2[_0x6d4eb1(0x333)],
                '\x66\x78\x55\x50\x42': function (_0x515c55, _0xd585e) {
                    const _0x27dd0f = _0x6d4eb1;
                    return _0x3e1db2[_0x27dd0f(0x19d)](_0x515c55, _0xd585e);
                },
                '\x59\x66\x4e\x63\x49': _0x3e1db2[_0x6d4eb1(0x1a3)],
                '\x72\x4f\x69\x70\x49': _0x3e1db2[_0x6d4eb1(0x33b)],
                '\x59\x79\x4c\x57\x69': _0x3e1db2[_0x6d4eb1(0x2cb)],
                '\x57\x41\x50\x71\x52': _0x3e1db2[_0x6d4eb1(0x112)],
                '\x56\x78\x4e\x57\x4d': _0x3e1db2[_0x6d4eb1(0x267)],
                '\x79\x61\x72\x58\x42': _0x3e1db2[_0x6d4eb1(0x1ea)],
                '\x47\x58\x74\x75\x47': _0x3e1db2[_0x6d4eb1(0xf3)],
                '\x4c\x52\x41\x6d\x42': function (_0x1edde1, _0x3f177a, _0x710a87, _0x549092) {
                    return _0x1edde1(_0x3f177a, _0x710a87, _0x549092);
                },
                '\x42\x44\x44\x46\x56': function (_0xa22e5b, _0x3bbe4d) {
                    const _0x42741d = _0x6d4eb1;
                    return _0x3e1db2[_0x42741d(0xc6)](_0xa22e5b, _0x3bbe4d);
                },
                '\x6c\x64\x52\x71\x64': function (_0x5cf4c4, _0x44dd3f, _0x54e71b, _0x10672b, _0x2419e3, _0x39e207) {
                    const _0x3e297f = _0x6d4eb1;
                    return _0x3e1db2[_0x3e297f(0x18c)](_0x5cf4c4, _0x44dd3f, _0x54e71b, _0x10672b, _0x2419e3, _0x39e207);
                },
                '\x4a\x4e\x4d\x66\x52': _0x6d4eb1(0x358),
                '\x70\x61\x43\x56\x67': _0x6d4eb1(0x1b8),
                '\x69\x57\x4f\x7a\x76': '\x23\x32\x30\x32\x30\x32\x30',
                '\x58\x46\x50\x62\x4f': _0x3e1db2[_0x6d4eb1(0xc5)],
                '\x6f\x53\x63\x47\x46': function (_0x47dbff, _0x5dc71d) {
                    const _0x319897 = _0x6d4eb1;
                    return _0x3e1db2[_0x319897(0x307)](_0x47dbff, _0x5dc71d);
                },
                '\x48\x42\x68\x66\x4b': _0x6d4eb1(0x303),
                '\x50\x6c\x6a\x70\x67': _0x3e1db2[_0x6d4eb1(0x16b)],
                '\x6a\x51\x66\x50\x6b': _0x3e1db2[_0x6d4eb1(0x23e)],
                '\x59\x69\x7a\x76\x7a': _0x3e1db2[_0x6d4eb1(0x106)],
                '\x42\x6e\x67\x4a\x71': function (_0x56eaa0, _0x493539) {
                    const _0xc5085d = _0x6d4eb1;
                    return _0x3e1db2[_0xc5085d(0x2e7)](_0x56eaa0, _0x493539);
                },
                '\x72\x42\x58\x4c\x42': _0x3e1db2[_0x6d4eb1(0x1aa)],
                '\x6f\x70\x47\x48\x70': _0x3e1db2[_0x6d4eb1(0x344)],
                '\x46\x79\x58\x61\x48': _0x3e1db2['\x57\x50\x43\x53\x4c'],
                '\x5a\x42\x49\x54\x71': _0x3e1db2['\x42\x77\x72\x6a\x42'],
                '\x63\x4b\x47\x42\x46': function (_0x1dd356, _0x3a6440) {
                    return _0x3e1db2['\x61\x5a\x77\x67\x73'](_0x1dd356, _0x3a6440);
                },
                '\x65\x72\x6e\x59\x71': _0x3e1db2['\x69\x64\x45\x72\x69'],
                '\x53\x53\x56\x58\x6c': function (_0x519d09, _0x48c28c) {
                    const _0x3909a6 = _0x6d4eb1;
                    return _0x3e1db2[_0x3909a6(0x109)](_0x519d09, _0x48c28c);
                },
                '\x67\x67\x6b\x65\x47': _0x3e1db2['\x6c\x67\x46\x6c\x44'],
                '\x61\x59\x64\x50\x4c': function (_0x21e0e6, _0x2d129b) {
                    const _0x1cb18b = _0x6d4eb1;
                    return _0x3e1db2[_0x1cb18b(0xd5)](_0x21e0e6, _0x2d129b);
                },
                '\x55\x55\x55\x6e\x52': _0x3e1db2[_0x6d4eb1(0x34b)],
                '\x47\x65\x56\x6f\x6c': _0x6d4eb1(0x211),
                '\x67\x63\x50\x6f\x77': function (_0x34cf63, _0x1a52ee) {
                    const _0xfbc104 = _0x6d4eb1;
                    return _0x3e1db2[_0xfbc104(0x124)](_0x34cf63, _0x1a52ee);
                },
                '\x65\x63\x43\x5a\x73': _0x3e1db2['\x78\x4b\x47\x5a\x69'],
                '\x76\x70\x51\x61\x77': _0x3e1db2[_0x6d4eb1(0x238)],
                '\x57\x63\x51\x45\x42': function (_0x3c744b, _0x4095c6, _0x3e63dd, _0x424a61, _0x3f2029, _0x36a3e9) {
                    return _0x3c744b(_0x4095c6, _0x3e63dd, _0x424a61, _0x3f2029, _0x36a3e9);
                },
                '\x42\x61\x41\x6b\x44': _0x3e1db2[_0x6d4eb1(0x30e)],
                '\x6f\x52\x72\x4e\x73': _0x3e1db2[_0x6d4eb1(0x125)],
                '\x58\x63\x75\x56\x62': function (_0x4d2bc2, _0x47fc2f) {
                    const _0x3e8626 = _0x6d4eb1;
                    return _0x3e1db2[_0x3e8626(0x2f0)](_0x4d2bc2, _0x47fc2f);
                },
                '\x4f\x45\x78\x46\x42': _0x6d4eb1(0x36a),
                '\x6b\x6a\x47\x44\x55': _0x3e1db2[_0x6d4eb1(0x21b)],
                '\x71\x4b\x56\x66\x59': _0x3e1db2[_0x6d4eb1(0x29b)],
                '\x49\x4c\x7a\x61\x4d': '\x49\x74\x65\x6d\x44\x65\x76\x69\x63\x65\x73',
                '\x41\x66\x45\x63\x69': _0x3e1db2[_0x6d4eb1(0x1ed)],
                '\x4f\x49\x49\x53\x55': _0x6d4eb1(0x2c7),
                '\x4d\x78\x45\x4e\x68': _0x6d4eb1(0x182),
                '\x69\x64\x4e\x75\x64': _0x6d4eb1(0x1ec),
                '\x4c\x43\x78\x42\x43': _0x3e1db2[_0x6d4eb1(0x1ae)],
                '\x41\x48\x74\x44\x4b': _0x3e1db2[_0x6d4eb1(0xb2)],
                '\x73\x74\x47\x71\x67': _0x3e1db2[_0x6d4eb1(0x312)],
                '\x45\x52\x58\x77\x74': _0x3e1db2[_0x6d4eb1(0x199)],
                '\x71\x4d\x78\x6b\x6e': _0x3e1db2[_0x6d4eb1(0x2d0)],
                '\x52\x4c\x6b\x43\x58': _0x3e1db2[_0x6d4eb1(0xe7)],
                '\x6b\x41\x76\x59\x48': _0x3e1db2[_0x6d4eb1(0x2ad)],
                '\x4f\x6b\x71\x78\x74': _0x3e1db2[_0x6d4eb1(0x16a)],
                '\x65\x41\x5a\x66\x66': _0x6d4eb1(0xba),
                '\x49\x42\x6e\x54\x41': _0x3e1db2[_0x6d4eb1(0x22f)],
                '\x64\x56\x72\x52\x54': _0x3e1db2[_0x6d4eb1(0x207)],
                '\x74\x46\x50\x6b\x6a': _0x6d4eb1(0x11d),
                '\x55\x64\x71\x76\x53': function (_0x5470f6, _0x28afea) {
                    const _0x53d013 = _0x6d4eb1;
                    return _0x3e1db2[_0x53d013(0xc6)](_0x5470f6, _0x28afea);
                },
                '\x50\x75\x76\x6d\x69': _0x6d4eb1(0x2ff),
                '\x6b\x65\x4b\x75\x75': function (_0x3d0295, _0x5d96d4, _0x581cbc) {
                    return _0x3e1db2['\x44\x70\x72\x77\x70'](_0x3d0295, _0x5d96d4, _0x581cbc);
                },
                '\x6f\x63\x56\x59\x71': _0x6d4eb1(0x16f),
                '\x7a\x70\x71\x6f\x4e': function (_0x5a90ed, _0x1f998b) {
                    return _0x3e1db2['\x78\x77\x6b\x4d\x67'](_0x5a90ed, _0x1f998b);
                },
                '\x6f\x62\x67\x66\x5a': _0x3e1db2[_0x6d4eb1(0x268)],
                '\x79\x78\x45\x67\x77': function (_0x19f2a4, _0x4bee72) {
                    const _0x377564 = _0x6d4eb1;
                    return _0x3e1db2[_0x377564(0x124)](_0x19f2a4, _0x4bee72);
                },
                '\x73\x5a\x49\x58\x79': _0x3e1db2['\x58\x58\x4d\x6d\x6e'],
                '\x4f\x67\x4e\x49\x43': _0x3e1db2['\x42\x61\x79\x56\x47'],
                '\x58\x5a\x75\x44\x4e': function (_0x53b2d2, _0x5c3b51) {
                    return _0x53b2d2 != _0x5c3b51;
                },
                '\x55\x79\x49\x70\x79': function (_0xdf3502, _0x2119a0) {
                    const _0x36912b = _0x6d4eb1;
                    return _0x3e1db2[_0x36912b(0x1c3)](_0xdf3502, _0x2119a0);
                },
                '\x70\x62\x6b\x4d\x42': function (_0x10dfae, _0x5c5cfb) {
                    return _0x3e1db2['\x73\x4d\x70\x6a\x6c'](_0x10dfae, _0x5c5cfb);
                },
                '\x56\x4c\x66\x6e\x69': _0x3e1db2['\x4b\x66\x66\x79\x65'],
                '\x78\x6e\x71\x49\x53': _0x3e1db2['\x6b\x78\x46\x4e\x79'],
                '\x55\x6d\x53\x57\x6a': _0x3e1db2['\x4b\x4f\x4b\x6e\x75'],
                '\x52\x76\x41\x65\x52': _0x3e1db2[_0x6d4eb1(0x2a4)],
                '\x64\x68\x71\x70\x68': _0x6d4eb1(0x35d),
                '\x69\x57\x57\x59\x6c': function (_0x110d90, _0x583d74) {
                    const _0x5ae951 = _0x6d4eb1;
                    return _0x3e1db2[_0x5ae951(0x2f0)](_0x110d90, _0x583d74);
                },
                '\x51\x49\x72\x71\x51': _0x6d4eb1(0x162),
                '\x6b\x4e\x72\x72\x66': function (_0x4814f8, _0x9ad1b4) {
                    return _0x3e1db2['\x78\x77\x6b\x4d\x67'](_0x4814f8, _0x9ad1b4);
                },
                '\x6f\x70\x53\x53\x79': function (_0x10ef66, _0x53404b) {
                    const _0x593eba = _0x6d4eb1;
                    return _0x3e1db2[_0x593eba(0x319)](_0x10ef66, _0x53404b);
                },
                '\x54\x63\x44\x68\x6e': _0x3e1db2[_0x6d4eb1(0x292)],
                '\x6f\x6b\x6c\x57\x55': _0x3e1db2[_0x6d4eb1(0x23c)],
                '\x4b\x6d\x57\x68\x69': _0x3e1db2[_0x6d4eb1(0x118)],
                '\x61\x56\x68\x4c\x53': function (_0x3ea101, _0x462b19) {
                    return _0x3ea101(_0x462b19);
                },
                '\x4a\x74\x48\x59\x50': function (_0x361fa5, _0x4add15) {
                    const _0x1ba8e9 = _0x6d4eb1;
                    return _0x3e1db2[_0x1ba8e9(0x349)](_0x361fa5, _0x4add15);
                },
                '\x4d\x61\x79\x50\x6c': _0x3e1db2[_0x6d4eb1(0x2bb)],
                '\x4c\x70\x79\x72\x51': function (_0x551846, _0x4f2b7d) {
                    return _0x551846 !== _0x4f2b7d;
                },
                '\x4e\x71\x62\x66\x53': _0x3e1db2[_0x6d4eb1(0x191)],
                '\x55\x6d\x46\x59\x53': _0x3e1db2[_0x6d4eb1(0x2db)],
                '\x69\x6d\x59\x67\x63': _0x3e1db2[_0x6d4eb1(0x243)],
                '\x61\x6f\x45\x52\x65': _0x3e1db2[_0x6d4eb1(0x357)],
                '\x48\x64\x74\x75\x6e': _0x3e1db2[_0x6d4eb1(0xc0)],
                '\x68\x77\x78\x78\x6b': _0x3e1db2['\x48\x6b\x71\x62\x73'],
                '\x61\x47\x76\x52\x6f': function (_0x3e615d, _0x257a7c) {
                    return _0x3e1db2['\x50\x76\x55\x75\x61'](_0x3e615d, _0x257a7c);
                },
                '\x56\x41\x79\x45\x79': function (_0x359b1d, _0x4cc4dc) {
                    return _0x359b1d + _0x4cc4dc;
                },
                '\x58\x7a\x5a\x6b\x59': _0x3e1db2[_0x6d4eb1(0x18a)],
                '\x4c\x6f\x43\x4a\x79': _0x3e1db2[_0x6d4eb1(0x20c)],
                '\x4a\x69\x6f\x74\x5a': function (_0x4671f8, _0x589caf, _0x16dd28) {
                    return _0x3e1db2['\x45\x75\x51\x4b\x51'](_0x4671f8, _0x589caf, _0x16dd28);
                },
                '\x45\x49\x4a\x77\x47': '\x61\x77\x71',
                '\x74\x76\x54\x74\x66': function (_0x2a7e47, _0x8b2af3, _0x1a2f65) {
                    return _0x2a7e47(_0x8b2af3, _0x1a2f65);
                }
            };
        if (!(Player[_0x6d4eb1(0x1a6)] && _0x3e1db2[_0x6d4eb1(0x2c9)](Player[_0x6d4eb1(0x1a6)][_0x6d4eb1(0x220)], _0x3e1db2[_0x6d4eb1(0x1ee)]))) {
            if (_0x3e1db2[_0x6d4eb1(0xd2)](Player[_0x6d4eb1(0x220)], _0x3e1db2[_0x6d4eb1(0x1ee)])) {
                _0x3e1db2[_0x6d4eb1(0x1c3)](alert, _0x3e1db2[_0x6d4eb1(0x252)]);
                return;
            }
        }
        AwBotLast = _0x3e1db2[_0x6d4eb1(0x2fb)], AwBotBan = [], SpeechGarble = function (_0x26b63a, _0x4f079b, _0x4b38f2) {
            const _0x18749f = _0x6d4eb1, _0x46bcc3 = {
                    '\x4e\x4c\x55\x57\x52': _0x3e1db2[_0x18749f(0x1ea)],
                    '\x4b\x72\x41\x78\x5a': function (_0x4814cd, _0x3361c0) {
                        return _0x4814cd != _0x3361c0;
                    },
                    '\x64\x75\x74\x4e\x45': _0x3e1db2['\x5a\x64\x67\x4d\x73'],
                    '\x44\x79\x59\x53\x52': function (_0x2aaae0, _0x2a4131) {
                        return _0x2aaae0(_0x2a4131);
                    },
                    '\x51\x63\x74\x52\x59': function (_0x3dd82c, _0x190984) {
                        return _0x3e1db2['\x46\x4d\x51\x56\x6c'](_0x3dd82c, _0x190984);
                    },
                    '\x4e\x77\x66\x6b\x59': function (_0x5c174a, _0x2f6068) {
                        return _0x3e1db2['\x6b\x7a\x61\x74\x62'](_0x5c174a, _0x2f6068);
                    },
                    '\x6b\x59\x58\x79\x54': _0x18749f(0x1cf),
                    '\x51\x43\x78\x52\x6d': function (_0x3c1eec, _0x5da81c) {
                        const _0x2711ea = _0x18749f;
                        return _0x3e1db2[_0x2711ea(0x2c8)](_0x3c1eec, _0x5da81c);
                    },
                    '\x67\x4e\x6c\x68\x48': function (_0x547042, _0x2a500a) {
                        const _0x1bd4a4 = _0x18749f;
                        return _0x3e1db2[_0x1bd4a4(0x2a5)](_0x547042, _0x2a500a);
                    },
                    '\x73\x59\x59\x55\x6b': function (_0x3b4733, _0x554edf) {
                        return _0x3e1db2['\x4c\x74\x4c\x4c\x58'](_0x3b4733, _0x554edf);
                    },
                    '\x52\x7a\x78\x63\x54': function (_0x9874be, _0x3026d7) {
                        const _0x4d07d0 = _0x18749f;
                        return _0x3e1db2[_0x4d07d0(0x21f)](_0x9874be, _0x3026d7);
                    },
                    '\x4a\x58\x6d\x76\x48': _0x18749f(0x1c4),
                    '\x55\x48\x6a\x67\x68': _0x3e1db2[_0x18749f(0x13f)],
                    '\x69\x7a\x7a\x4b\x42': _0x3e1db2['\x76\x74\x68\x66\x4c'],
                    '\x67\x46\x69\x65\x77': function (_0x454ff6, _0x3dc62d) {
                        return _0x454ff6 === _0x3dc62d;
                    },
                    '\x51\x45\x70\x6f\x6a': _0x3e1db2[_0x18749f(0x2d6)],
                    '\x77\x6b\x59\x67\x62': _0x18749f(0x21e),
                    '\x57\x78\x4e\x4b\x45': function (_0x463c4f, _0x158d2d, _0x32f9fc, _0x3705a7) {
                        return _0x3e1db2['\x4b\x71\x53\x58\x6e'](_0x463c4f, _0x158d2d, _0x32f9fc, _0x3705a7);
                    },
                    '\x6b\x71\x48\x4a\x7a': function (_0x242cf8, _0x1c7a2e) {
                        const _0x1fac96 = _0x18749f;
                        return _0x3e1db2[_0x1fac96(0x179)](_0x242cf8, _0x1c7a2e);
                    },
                    '\x77\x6a\x4f\x7a\x6a': function (_0x4763e3, _0x33613b) {
                        const _0x321a60 = _0x18749f;
                        return _0x3e1db2[_0x321a60(0xcc)](_0x4763e3, _0x33613b);
                    },
                    '\x76\x6b\x69\x75\x57': _0x3e1db2[_0x18749f(0x2f4)],
                    '\x51\x76\x78\x47\x7a': function (_0x2e17d5, _0xb5bd11) {
                        return _0x2e17d5 === _0xb5bd11;
                    },
                    '\x6d\x76\x75\x57\x6b': _0x3e1db2[_0x18749f(0x240)],
                    '\x66\x71\x4a\x66\x6c': _0x3e1db2[_0x18749f(0x27f)],
                    '\x4a\x55\x71\x4e\x42': function (_0x2fad6a, _0x353107, _0x1eafd7, _0x263b84, _0xb3f001, _0x6cf71d) {
                        const _0x5a74a6 = _0x18749f;
                        return _0x3e1db2[_0x5a74a6(0x30b)](_0x2fad6a, _0x353107, _0x1eafd7, _0x263b84, _0xb3f001, _0x6cf71d);
                    },
                    '\x41\x52\x4d\x51\x69': _0x18749f(0x11e),
                    '\x49\x7a\x49\x68\x67': _0x18749f(0x105),
                    '\x6b\x75\x4a\x6f\x6b': function (_0x204d16, _0x40edba, _0x45dbe1, _0x5dbe2f) {
                        return _0x204d16(_0x40edba, _0x45dbe1, _0x5dbe2f);
                    },
                    '\x78\x4e\x48\x47\x6d': _0x3e1db2[_0x18749f(0x266)]
                };
            _0x3e1db2[_0x18749f(0x2f0)](AwBotLast, _0x3e1db2[_0x18749f(0x22e)](_0x4f079b, _0x26b63a[_0x18749f(0x220)])) && _0x3e1db2['\x73\x50\x45\x4e\x4e'](_0x4f079b[_0x18749f(0x19a)](_0x3e1db2[_0x18749f(0xc3)]), -(-0xe5 * 0x29 + -0x47 * 0x1f + 0x43 * 0xad)) && (_0x3e1db2[_0x18749f(0x2a1)](_0x3e1db2[_0x18749f(0x213)], _0x3e1db2[_0x18749f(0x26c)]) ? _0xb85dae[_0x18749f(0x161)][_0x18749f(0x14b)] = _0x46bcc3[_0x18749f(0x1c2)] : _0x3e1db2['\x44\x70\x72\x77\x70'](setTimeout, function () {
                const _0x20b5cf = _0x18749f, _0x5a0ff7 = {
                        '\x6d\x55\x74\x62\x4e': function (_0xbefa11, _0x309e8b) {
                            const _0x3145f1 = _0x1c0d;
                            return _0x3e4a78[_0x3145f1(0x200)](_0xbefa11, _0x309e8b);
                        },
                        '\x75\x55\x66\x77\x75': function (_0x133f28, _0x45175c) {
                            return _0x133f28 + _0x45175c;
                        },
                        '\x69\x6c\x6f\x7a\x61': _0x3e4a78[_0x20b5cf(0x2f6)],
                        '\x6a\x54\x74\x62\x76': function (_0x13458d, _0x181f3f, _0x5dfccb) {
                            const _0x52e536 = _0x20b5cf;
                            return _0x3e4a78[_0x52e536(0x102)](_0x13458d, _0x181f3f, _0x5dfccb);
                        },
                        '\x47\x62\x51\x62\x65': _0x3e4a78[_0x20b5cf(0x204)],
                        '\x78\x48\x4e\x68\x73': _0x3e4a78[_0x20b5cf(0x290)],
                        '\x63\x7a\x41\x7a\x79': _0x20b5cf(0x283),
                        '\x4c\x7a\x79\x41\x71': _0x3e4a78[_0x20b5cf(0x212)],
                        '\x71\x41\x6d\x62\x51': _0x3e4a78['\x75\x52\x45\x7a\x50'],
                        '\x66\x6e\x52\x51\x6f': function (_0x1f4d24, _0xb4edf6) {
                            const _0x40d362 = _0x20b5cf;
                            return _0x3e4a78[_0x40d362(0x16c)](_0x1f4d24, _0xb4edf6);
                        },
                        '\x6a\x48\x6a\x75\x50': function (_0x82397a, _0x3daed4) {
                            return _0x82397a != _0x3daed4;
                        },
                        '\x70\x62\x51\x62\x48': _0x20b5cf(0x1ba),
                        '\x71\x53\x6a\x76\x55': function (_0xbbdefc, _0x14f876) {
                            const _0x457540 = _0x20b5cf;
                            return _0x3e4a78[_0x457540(0x16c)](_0xbbdefc, _0x14f876);
                        },
                        '\x72\x54\x61\x62\x46': _0x3e4a78[_0x20b5cf(0x342)],
                        '\x41\x63\x4b\x6c\x50': _0x3e4a78[_0x20b5cf(0x286)],
                        '\x55\x66\x62\x58\x4b': function (_0x86f386, _0x4906d0) {
                            const _0xd76760 = _0x20b5cf;
                            return _0x3e4a78[_0xd76760(0x2dc)](_0x86f386, _0x4906d0);
                        },
                        '\x57\x46\x4d\x6f\x51': _0x3e4a78[_0x20b5cf(0x15c)],
                        '\x4b\x78\x56\x6b\x6f': function (_0x1791c7, _0x4220a5) {
                            const _0x225406 = _0x20b5cf;
                            return _0x3e4a78[_0x225406(0x2d5)](_0x1791c7, _0x4220a5);
                        },
                        '\x6a\x6a\x56\x61\x57': _0x3e4a78[_0x20b5cf(0x2e3)],
                        '\x4a\x43\x63\x76\x50': _0x20b5cf(0x190),
                        '\x46\x59\x66\x52\x6f': function (_0x488a5f, _0x1829c3) {
                            return _0x488a5f == _0x1829c3;
                        },
                        '\x65\x67\x50\x6f\x57': function (_0x284f02, _0x3a310d) {
                            return _0x284f02 !== _0x3a310d;
                        },
                        '\x70\x62\x42\x4e\x58': _0x20b5cf(0xe8),
                        '\x4d\x68\x79\x77\x48': _0x3e4a78[_0x20b5cf(0x132)],
                        '\x76\x73\x75\x72\x55': function (_0x1ca086, _0x57e8df) {
                            return _0x1ca086 === _0x57e8df;
                        },
                        '\x62\x6c\x48\x70\x6b': _0x3e4a78[_0x20b5cf(0x280)],
                        '\x74\x71\x7a\x54\x74': _0x3e4a78[_0x20b5cf(0x1ce)],
                        '\x6d\x47\x4b\x44\x43': _0x3e4a78[_0x20b5cf(0x2a0)],
                        '\x76\x54\x67\x66\x5a': _0x20b5cf(0x11c),
                        '\x65\x68\x6c\x6d\x47': _0x3e4a78[_0x20b5cf(0xcd)],
                        '\x71\x51\x47\x77\x77': _0x3e4a78[_0x20b5cf(0x1e3)],
                        '\x78\x78\x4e\x76\x4d': function (_0x12881c, _0x1ae3d4) {
                            return _0x12881c(_0x1ae3d4);
                        },
                        '\x48\x50\x58\x6d\x64': function (_0x2f78a9, _0x1b17c1, _0x685a3b, _0x4013cb) {
                            return _0x3e4a78['\x4c\x52\x41\x6d\x42'](_0x2f78a9, _0x1b17c1, _0x685a3b, _0x4013cb);
                        },
                        '\x45\x4c\x76\x52\x4e': function (_0x48585b, _0x355080) {
                            const _0x262e68 = _0x20b5cf;
                            return _0x3e4a78[_0x262e68(0x1e6)](_0x48585b, _0x355080);
                        },
                        '\x73\x56\x6a\x70\x59': function (_0x39f0db, _0x437642, _0xdd123d, _0x49be36, _0x36d5db, _0xf6c915) {
                            const _0x52eaef = _0x20b5cf;
                            return _0x3e4a78[_0x52eaef(0x27b)](_0x39f0db, _0x437642, _0xdd123d, _0x49be36, _0x36d5db, _0xf6c915);
                        },
                        '\x47\x41\x49\x73\x79': _0x20b5cf(0x226),
                        '\x73\x6e\x52\x41\x45': _0x3e4a78[_0x20b5cf(0x164)],
                        '\x77\x67\x6a\x6d\x72': _0x3e4a78[_0x20b5cf(0x175)],
                        '\x4f\x71\x6a\x51\x57': _0x3e4a78[_0x20b5cf(0x316)],
                        '\x4b\x67\x78\x46\x43': _0x3e4a78[_0x20b5cf(0x1f3)],
                        '\x4e\x77\x4f\x42\x77': function (_0x2a74c0, _0x3e340c) {
                            return _0x3e4a78['\x6f\x53\x63\x47\x46'](_0x2a74c0, _0x3e340c);
                        },
                        '\x6d\x74\x47\x67\x72': function (_0x5631de, _0x364cd9) {
                            return _0x3e4a78['\x6f\x53\x63\x47\x46'](_0x5631de, _0x364cd9);
                        },
                        '\x50\x6a\x78\x74\x62': _0x3e4a78[_0x20b5cf(0x21d)],
                        '\x71\x42\x58\x44\x63': function (_0x11e5f3, _0xeb49c2, _0x3d3680) {
                            const _0x3ba5c7 = _0x20b5cf;
                            return _0x3e4a78[_0x3ba5c7(0x102)](_0x11e5f3, _0xeb49c2, _0x3d3680);
                        },
                        '\x77\x47\x5a\x6d\x64': '\x61\x77\x54\x52\x41\x50\x20\x52\x75\x6c\x65\x73\x3a\x31\x2c\x57\x68\x65\x6e\x20\x74\x68\x65\x20\x72\x6f\x6f\x6d\x20\x77\x61\x73\x20\x63\x72\x65\x61\x74\x65\x64\x2c\x61\x20\x74\x69\x6d\x65\x72\x20\x77\x61\x73\x20\x73\x65\x74\x20\x74\x6f\x20\x31\x35\x20\x6d\x69\x6e\x73\x2e\x32\x2c\x42\x65\x66\x6f\x72\x65\x20\x74\x68\x65\x20\x74\x69\x6d\x65\x72\x20\x72\x75\x6e\x73\x20\x6f\x75\x74\x2c\x61\x6e\x79\x6f\x6e\x65\x20\x77\x68\x6f\x20\x63\x6f\x6d\x65\x73\x20\x69\x6e\x74\x6f\x20\x74\x68\x69\x73\x20\x72\x6f\x6f\x6d\x20\x77\x69\x6c\x6c\x20\x67\x65\x74\x20\x74\x72\x61\x70\x70\x65\x64\x2e\x33\x2c\x42\x65\x66\x72\x6f\x65\x20\x74\x68\x65\x20\x74\x69\x6d\x65\x72\x20\x72\x75\x6e\x73\x20\x6f\x75\x74\x2c\x61\x6e\x79\x6f\x6e\x65\x20\x77\x68\x6f\x20\x61\x74\x74\x65\x6d\x70\x74\x73\x20\x74\x6f\x20\x72\x65\x73\x63\x75\x65\x20\x77\x69\x6c\x6c\x20\x62\x65\x20\x62\x61\x6e\x6e\x65\x64\x2e\x34\x2c\x41\x66\x74\x65\x72\x20\x74\x68\x65\x20\x74\x69\x6d\x65\x72\x20\x72\x75\x6e\x73\x20\x6f\x75\x74\x2c\x20\x61\x77\x54\x52\x41\x50\x20\x77\x69\x6c\x6c\x20\x62\x65\x20\x73\x61\x66\x65\x2e\x54\x68\x6f\x73\x65\x20\x77\x68\x6f\x20\x61\x72\x65\x20\x74\x72\x61\x70\x70\x65\x64\x20\x63\x61\x6e\x20\x70\x6c\x65\x61\x64\x20\x70\x61\x73\x73\x65\x72\x2d\x62\x79\x73\x20\x66\x6f\x72\x20\x68\x65\x6c\x70\x20\x74\x68\x65\x6e\x2e',
                        '\x70\x6a\x7a\x75\x68': _0x3e4a78[_0x20b5cf(0x313)],
                        '\x62\x6b\x73\x41\x70': _0x3e4a78[_0x20b5cf(0x172)],
                        '\x45\x72\x64\x43\x6f': _0x3e4a78[_0x20b5cf(0x1ac)]
                    };
                if (_0x3e4a78[_0x20b5cf(0x171)](_0x3e4a78['\x72\x42\x58\x4c\x42'], _0x3e4a78[_0x20b5cf(0x2b1)])) {
                    if (AwBotBan[_0x20b5cf(0x19a)](_0x26b63a[_0x20b5cf(0x220)]) == -(0x1612 + -0x1 * 0x1d75 + 0x764)) {
                        if (_0x4f079b[_0x20b5cf(0x19a)]('\x61\x77\u9171') != -(-0xde2 + -0xdd6 + 0x1bb9)) {
                            if (_0x3e4a78[_0x20b5cf(0x2dc)](_0x3e4a78[_0x20b5cf(0xbb)], _0x3e4a78[_0x20b5cf(0x26b)])) {
                                let _0x2c387f = _0x3e4a78[_0x20b5cf(0x271)];
                                if (_0x3e4a78['\x63\x4b\x47\x42\x46'](_0x4f079b[_0x20b5cf(0x19a)]('\u6551\u6211'), -(0x21 * -0x29 + 0x26db + -0x2191 * 0x1)))
                                    CharacterReleaseTotal(_0x26b63a), _0x26b63a[_0x20b5cf(0x193)][_0x20b5cf(0xda)] = 0x19bb + -0x602 * -0x2 + -0x25bf, _0x3e4a78[_0x20b5cf(0x16c)](ChatRoomCharacterUpdate, _0x26b63a), _0x2c387f = _0x20b5cf(0x1ef);
                                else {
                                    if (_0x3e4a78[_0x20b5cf(0x31b)](_0x4f079b[_0x20b5cf(0x19a)]('\u6346\u6211'), -(0x2352 + 0x30b * -0x6 + 0x110f * -0x1)))
                                        InventoryWear(_0x26b63a, _0x3e4a78[_0x20b5cf(0x178)], _0x20b5cf(0x308), _0x3e4a78[_0x20b5cf(0x316)], -0x6e * -0x24c + -0x707 * -0x47 + -0x13047), InventoryWear(_0x26b63a, _0x20b5cf(0x358), _0x20b5cf(0x1b8), _0x3e4a78['\x69\x57\x4f\x7a\x76'], -0x2f8bf + 0x34f9 + 0x1564 * 0x36), _0x26b63a['\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73']['\x50\x72\x6f\x67\x72\x65\x73\x73'] = 0x1f7c + 0x1 * -0x244a + 0x4ce, _0x3e4a78['\x53\x53\x56\x58\x6c'](ChatRoomCharacterUpdate, _0x26b63a), _0x2c387f = _0x3e4a78[_0x20b5cf(0x1ab)];
                                    else {
                                        if (_0x3e4a78['\x63\x4b\x47\x42\x46'](_0x4f079b[_0x20b5cf(0x19a)]('\u5173\u4e8e'), -(-0xd5c + -0x1aea * 0x1 + 0x2847)))
                                            _0x3e4a78['\x61\x59\x64\x50\x4c'](_0x3e4a78[_0x20b5cf(0xb6)], _0x20b5cf(0x235)) ? _0x2fbd3e[_0x20b5cf(0x161)]['\x45\x66\x66\x65\x63\x74'] = [] : _0x2c387f = _0x3e4a78['\x47\x65\x56\x6f\x6c'];
                                        else {
                                            if (_0x3e4a78['\x67\x63\x50\x6f\x77'](_0x4f079b[_0x20b5cf(0x19a)]('\u8214\u6211'), -(-0x5dc * -0x1 + 0x81a + -0x18d * 0x9)))
                                                _0x3e4a78[_0x20b5cf(0x281)] !== _0x3e4a78[_0x20b5cf(0x2ce)] ? _0x2c387f = _0x3e4a78['\x6e\x46\x58\x52\x58'](_0x3e4a78[_0x20b5cf(0x21d)], _0x26b63a[_0x20b5cf(0x220)]) + '\x2e' : _0x2c392e = _0x5a0ff7[_0x20b5cf(0x18d)](_0x5a0ff7['\x6d\x55\x74\x62\x4e'](_0x5a0ff7[_0x20b5cf(0x2cd)](_0x5a0ff7['\x69\x6c\x6f\x7a\x61'], _0x4afb7b), '\x20'), _0x37e5eb);
                                            else {
                                                if (_0x3e4a78['\x67\x63\x50\x6f\x77'](_0x4f079b[_0x20b5cf(0x19a)]('\u73a9\u6211'), -(0x211 + 0x11 * 0x1de + 0x1 * -0x21ce)))
                                                    _0x3e4a78[_0x20b5cf(0x289)](InventoryWear, _0x26b63a, _0x20b5cf(0x2bc), _0x3e4a78[_0x20b5cf(0x26f)], _0x3e4a78[_0x20b5cf(0x316)], 0x1d * -0x66b + 0x31 * 0x469 + 0xa6f * 0x28), _0x26b63a[_0x20b5cf(0x193)]['\x50\x72\x6f\x67\x72\x65\x73\x73'] = 0x6c8 + 0x1953 + -0x201b, _0x3e4a78[_0x20b5cf(0x1e6)](ChatRoomCharacterUpdate, _0x26b63a), _0x2c387f = _0x3e4a78[_0x20b5cf(0x35e)];
                                                else {
                                                    if (_0x3e4a78[_0x20b5cf(0x12c)](_0x4f079b[_0x20b5cf(0x19a)]('\u9501\u6211'), -(0x15d9 + -0x45b + -0x1 * 0x117d)))
                                                        _0x26b63a['\x41\x70\x70\x65\x61\x72\x61\x6e\x63\x65'][_0x20b5cf(0x1a1)](_0x1a1b80 => {
                                                            const _0x178c70 = _0x20b5cf;
                                                            if (_0x5a0ff7[_0x178c70(0x1d3)](_0x178c70(0xdc), _0x5a0ff7[_0x178c70(0x237)])) {
                                                                _0x5a0ff7['\x6a\x54\x74\x62\x76'](_0x93cb18, '\x43\x68\x61\x74\x52\x6f\x6f\x6d\x43\x68\x61\x74', {
                                                                    '\x43\x6f\x6e\x74\x65\x6e\x74': _0x5a0ff7['\x47\x62\x51\x62\x65'],
                                                                    '\x54\x79\x70\x65': _0x5a0ff7[_0x178c70(0xd1)],
                                                                    '\x44\x69\x63\x74\x69\x6f\x6e\x61\x72\x79': [{
                                                                            '\x6d\x65\x73\x73\x61\x67\x65': {
                                                                                '\x74\x79\x70\x65': _0x5a0ff7[_0x178c70(0x10f)],
                                                                                '\x76\x65\x72\x73\x69\x6f\x6e': _0x5a0ff7['\x4c\x7a\x79\x41\x71'],
                                                                                '\x61\x6c\x74\x65\x72\x6e\x61\x74\x65\x41\x72\x6f\x75\x73\x61\x6c': !![],
                                                                                '\x72\x65\x70\x6c\x79\x52\x65\x71\x75\x65\x73\x74\x65\x64': ![],
                                                                                '\x63\x61\x70\x61\x62\x69\x6c\x69\x74\x69\x65\x73': [_0x5a0ff7[_0x178c70(0xd0)]],
                                                                                '\x6e\x69\x63\x6b': null
                                                                            }
                                                                        }]
                                                                });
                                                                const _0x365ee6 = {};
                                                                _0x365ee6[_0x178c70(0x31c)] = [];
                                                                const _0xd8aba5 = {};
                                                                _0xd8aba5[_0x178c70(0x140)] = _0x178c70(0x1bf), _0xd8aba5[_0x178c70(0x253)] = ![], _0xd8aba5[_0x178c70(0x186)] = _0x365ee6, _0xd8aba5[_0x178c70(0x24b)] = ![], _0xd8aba5[_0x178c70(0x30a)] = ![];
                                                                const _0x4bfadb = {};
                                                                _0x4bfadb[_0x178c70(0x17e)] = _0x178c70(0x101), _0x4bfadb[_0x178c70(0x2df)] = _0xd8aba5;
                                                                const _0x283d26 = {};
                                                                _0x283d26[_0x178c70(0x1c5)] = _0x178c70(0x326), _0x283d26['\x54\x79\x70\x65'] = _0x178c70(0x145), _0x283d26['\x44\x69\x63\x74\x69\x6f\x6e\x61\x72\x79'] = _0x4bfadb, _0x5a0ff7[_0x178c70(0x25a)](_0x32d6f4, _0x178c70(0x16f), _0x283d26);
                                                            } else {
                                                                let _0x5f8837 = 0x59 * 0x13 + 0x22c * 0xd + 0x1 * -0x22d7;
                                                                if (_0x5a0ff7[_0x178c70(0x12a)](_0x1a1b80[_0x178c70(0x158)], 0x785 + -0x36b + -0x46 * 0xf)) {
                                                                    if (_0x5a0ff7[_0x178c70(0x215)] !== _0x5a0ff7['\x4a\x43\x63\x76\x50']) {
                                                                        if (_0x5a0ff7[_0x178c70(0x264)](_0x1a1b80['\x50\x72\x6f\x70\x65\x72\x74\x79'], null)) {
                                                                            if (_0x5a0ff7[_0x178c70(0x331)](_0x5a0ff7[_0x178c70(0x21a)], _0x5a0ff7['\x4d\x68\x79\x77\x48']))
                                                                                _0x1a1b80[_0x178c70(0x161)] = {};
                                                                            else {
                                                                                _0x5a0ff7[_0x178c70(0x2e4)](_0x1a6b37, _0x178c70(0x32f));
                                                                                return;
                                                                            }
                                                                        }
                                                                        _0x1a1b80[_0x178c70(0x161)]['\x45\x66\x66\x65\x63\x74'] == null && (_0x5a0ff7[_0x178c70(0x13b)](_0x5a0ff7[_0x178c70(0x269)], _0x5a0ff7[_0x178c70(0x18b)]) ? _0x4e5ca5 = 0x801 + 0x271 * 0xb + -0x7 * 0x4e9 : _0x1a1b80[_0x178c70(0x161)][_0x178c70(0x31c)] = []);
                                                                        _0x1a1b80[_0x178c70(0x161)][_0x178c70(0x31c)][_0x178c70(0x19a)](_0x5a0ff7[_0x178c70(0x317)]) < 0x215 + -0x26d + 0x58 && _0x1a1b80[_0x178c70(0x161)][_0x178c70(0x31c)][_0x178c70(0x153)](_0x178c70(0x2da));
                                                                        if (_0x5a0ff7[_0x178c70(0x12a)](Math[_0x178c70(0x176)](), 0x1a89 * -0x1 + 0x1f * 0x112 + -0x6a5 + 0.5)) {
                                                                            if ('\x49\x46\x6e\x6a\x51' !== _0x5a0ff7[_0x178c70(0x1bb)])
                                                                                _0x1a1b80[_0x178c70(0x161)][_0x178c70(0x14b)] = _0x5a0ff7[_0x178c70(0x104)];
                                                                            else {
                                                                                if (_0x5a0ff7[_0x178c70(0xdb)](_0x5a52d['\x4e\x61\x6d\x65'], _0x5a0ff7['\x70\x62\x51\x62\x48'])) {
                                                                                    _0x5a0ff7[_0x178c70(0x205)](_0x53921c, _0x5a0ff7[_0x178c70(0x163)]);
                                                                                    return;
                                                                                }
                                                                            }
                                                                        } else
                                                                            _0x1a1b80[_0x178c70(0x161)]['\x4c\x6f\x63\x6b\x65\x64\x42\x79'] = _0x5a0ff7[_0x178c70(0x133)];
                                                                        _0x1a1b80[_0x178c70(0x161)][_0x178c70(0xfa)] = Player['\x4d\x65\x6d\x62\x65\x72\x4e\x75\x6d\x62\x65\x72'], _0x26b63a[_0x178c70(0x2f3)][_0x5f8837] = _0x1a1b80;
                                                                    } else
                                                                        _0x5a301d(_0x5108e9), _0x51aac3[_0x178c70(0x193)][_0x178c70(0xda)] = -0x2 * -0x179 + 0xa99 * 0x1 + -0xd8b, _0x10bbb6(_0x333178), _0x2f03f4 = _0x5a0ff7[_0x178c70(0x356)];
                                                                }
                                                                _0x5f8837++;
                                                            }
                                                        }), _0x26b63a[_0x20b5cf(0x193)][_0x20b5cf(0xda)] = 0xe * 0xa + 0x1ab + -0x1b * 0x15, _0x3e4a78['\x53\x53\x56\x58\x6c'](ChatRoomCharacterUpdate, _0x26b63a), _0x2c387f = _0x3e4a78[_0x20b5cf(0x35e)];
                                                    else {
                                                        if (_0x3e4a78['\x58\x63\x75\x56\x62'](_0x4f079b['\x69\x6e\x64\x65\x78\x4f\x66'](_0x3e4a78['\x4f\x45\x78\x46\x42']), -(0x1570 + -0x2 * 0x9b2 + -0x20b * 0x1))) {
                                                            let _0x58ae1b = [
                                                                _0x3e4a78[_0x20b5cf(0x26f)],
                                                                _0x3e4a78[_0x20b5cf(0x2e8)],
                                                                '\x49\x74\x65\x6d\x42\x72\x65\x61\x73\x74',
                                                                _0x3e4a78['\x71\x4b\x56\x66\x59'],
                                                                _0x3e4a78[_0x20b5cf(0x1dc)],
                                                                _0x3e4a78[_0x20b5cf(0x2d2)],
                                                                _0x3e4a78[_0x20b5cf(0x175)],
                                                                _0x3e4a78[_0x20b5cf(0x328)],
                                                                _0x3e4a78[_0x20b5cf(0x2a3)],
                                                                _0x3e4a78[_0x20b5cf(0x18f)],
                                                                _0x3e4a78[_0x20b5cf(0x1d5)],
                                                                _0x3e4a78[_0x20b5cf(0x2d4)],
                                                                _0x20b5cf(0x1f8),
                                                                _0x3e4a78[_0x20b5cf(0x336)],
                                                                _0x3e4a78[_0x20b5cf(0x2b3)],
                                                                '\x49\x74\x65\x6d\x4e\x65\x63\x6b',
                                                                _0x3e4a78['\x71\x4d\x78\x6b\x6e'],
                                                                _0x20b5cf(0xc9),
                                                                _0x3e4a78[_0x20b5cf(0x203)],
                                                                _0x3e4a78[_0x20b5cf(0x2e0)],
                                                                _0x3e4a78['\x4f\x6b\x71\x78\x74'],
                                                                _0x3e4a78['\x65\x41\x5a\x66\x66'],
                                                                _0x3e4a78['\x49\x42\x6e\x54\x41'],
                                                                _0x3e4a78[_0x20b5cf(0x16d)],
                                                                _0x3e4a78[_0x20b5cf(0x30d)]
                                                            ];
                                                            _0x58ae1b[_0x20b5cf(0x1a1)](_0x3a6607 => {
                                                                const _0x4d6436 = _0x20b5cf, _0x403ccb = {
                                                                        '\x49\x62\x78\x72\x65': function (_0x1b6137, _0x33b1fe) {
                                                                            return _0x1b6137 != _0x33b1fe;
                                                                        },
                                                                        '\x48\x52\x75\x64\x41': _0x4d6436(0x1ba),
                                                                        '\x48\x52\x71\x6d\x74': function (_0x1c1189, _0x5afcfc) {
                                                                            const _0x297c4c = _0x4d6436;
                                                                            return _0x5a0ff7[_0x297c4c(0xf4)](_0x1c1189, _0x5afcfc);
                                                                        },
                                                                        '\x56\x73\x4c\x72\x45': _0x5a0ff7[_0x4d6436(0x163)]
                                                                    };
                                                                if (_0x4d6436(0x154) === '\x47\x69\x4e\x4f\x7a')
                                                                    _0x5a0ff7[_0x4d6436(0x259)](InventoryWearRandom, _0x26b63a, _0x3a6607, -0x22036 + 0x276ed + 0x1f3 * 0xb9);
                                                                else {
                                                                    if (_0x403ccb[_0x4d6436(0x219)](_0x4c3dbc['\x4e\x61\x6d\x65'], _0x403ccb[_0x4d6436(0x1e2)])) {
                                                                        _0x403ccb[_0x4d6436(0x343)](_0x44d0d6, _0x403ccb[_0x4d6436(0x28a)]);
                                                                        return;
                                                                    }
                                                                }
                                                            }), _0x26b63a['\x41\x70\x70\x65\x61\x72\x61\x6e\x63\x65'][_0x20b5cf(0x1a1)](_0x551d65 => {
                                                                const _0x597386 = _0x20b5cf, _0x39342d = {
                                                                        '\x7a\x42\x4d\x4a\x6f': function (_0x2f183d, _0x16b04a) {
                                                                            const _0x38df11 = _0x1c0d;
                                                                            return _0x46bcc3[_0x38df11(0x25b)](_0x2f183d, _0x16b04a);
                                                                        },
                                                                        '\x45\x4f\x53\x56\x58': _0x46bcc3['\x64\x75\x74\x4e\x45'],
                                                                        '\x76\x77\x54\x6c\x4e': function (_0x21b3e7, _0x2def2b) {
                                                                            const _0x24f7c7 = _0x1c0d;
                                                                            return _0x46bcc3[_0x24f7c7(0x19f)](_0x21b3e7, _0x2def2b);
                                                                        },
                                                                        '\x58\x55\x4b\x73\x4d': _0x597386(0x32f)
                                                                    };
                                                                let _0x404afa = 0x259d + -0x4db + -0x20c2;
                                                                if (_0x46bcc3[_0x597386(0x29f)](_0x551d65[_0x597386(0x158)], -0xa47 + -0x1703 + 0x214a)) {
                                                                    if (_0x46bcc3[_0x597386(0x128)](_0x46bcc3[_0x597386(0x27e)], _0x46bcc3[_0x597386(0x27e)])) {
                                                                        if (_0x39342d[_0x597386(0x166)](_0x50740c[_0x597386(0x220)], _0x39342d[_0x597386(0x2d8)])) {
                                                                            _0x39342d[_0x597386(0x245)](_0x234f8b, _0x39342d['\x58\x55\x4b\x73\x4d']);
                                                                            return;
                                                                        }
                                                                    } else {
                                                                        _0x46bcc3[_0x597386(0xbf)](_0x551d65[_0x597386(0x161)], null) && (_0x551d65[_0x597386(0x161)] = {});
                                                                        _0x46bcc3[_0x597386(0x2cc)](_0x551d65['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x597386(0x31c)], null) && (_0x551d65[_0x597386(0x161)][_0x597386(0x31c)] = []);
                                                                        _0x46bcc3[_0x597386(0x1c7)](_0x551d65[_0x597386(0x161)][_0x597386(0x31c)][_0x597386(0x19a)](_0x597386(0x2da)), -0x5 * 0x143 + -0x1b4e + -0x219d * -0x1) && (_0x46bcc3[_0x597386(0x12b)](_0x46bcc3[_0x597386(0x22d)], _0x46bcc3[_0x597386(0x2ed)]) ? _0x551d65[_0x597386(0x161)][_0x597386(0x31c)]['\x70\x75\x73\x68'](_0x46bcc3[_0x597386(0xf6)]) : this[_0x597386(0x194)] == ![] || this[_0x597386(0x194)] == _0x1acb89 ? (this[_0x597386(0x194)] = !![], _0x5a0ff7[_0x597386(0x214)](_0x40abfd, _0x597386(0x146))) : (this[_0x597386(0x194)] = ![], _0x5a0ff7[_0x597386(0x205)](_0x28ed31, '\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x3a\x20\x45\x6e\x67\x6c\x69\x73\x68\x2e')));
                                                                        if (Math['\x72\x61\x6e\x64\x6f\x6d']() > 0x24bf + 0x4 * 0x38b + -0x32eb + 0.5)
                                                                            _0x551d65[_0x597386(0x161)]['\x4c\x6f\x63\x6b\x65\x64\x42\x79'] = _0x46bcc3[_0x597386(0x1c2)];
                                                                        else {
                                                                            if (_0x46bcc3[_0x597386(0x23b)](_0x46bcc3['\x51\x45\x70\x6f\x6a'], _0x46bcc3[_0x597386(0x278)]))
                                                                                _0x551d65['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x597386(0x14b)] = _0x46bcc3[_0x597386(0x195)];
                                                                            else
                                                                                return;
                                                                        }
                                                                        _0x551d65[_0x597386(0x161)][_0x597386(0xfa)] = Player[_0x597386(0x257)], _0x26b63a['\x41\x70\x70\x65\x61\x72\x61\x6e\x63\x65'][_0x404afa] = _0x551d65;
                                                                    }
                                                                }
                                                                _0x404afa++;
                                                            }), _0x26b63a[_0x20b5cf(0x193)][_0x20b5cf(0xda)] = 0x1e72 + 0x242d * 0x1 + -0x429f, _0x3e4a78[_0x20b5cf(0x115)](ChatRoomCharacterUpdate, _0x26b63a), _0x2c387f = _0x3e4a78[_0x20b5cf(0x156)], AwBotBan['\x70\x75\x73\x68'](_0x26b63a[_0x20b5cf(0x220)]);
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                _0x3e4a78[_0x20b5cf(0x28e)](ServerSend, _0x3e4a78[_0x20b5cf(0x228)], {
                                    '\x43\x6f\x6e\x74\x65\x6e\x74': _0x3e4a78[_0x20b5cf(0x1d6)](_0x3e4a78['\x6f\x62\x67\x66\x5a'], _0x2c387f),
                                    '\x54\x79\x70\x65': _0x3e4a78[_0x20b5cf(0x313)]
                                });
                            } else
                                _0x5a0ff7[_0x20b5cf(0x1c1)](_0x561dce, _0x569188, _0x5a0ff7[_0x20b5cf(0x367)], _0x20b5cf(0x308), _0x20b5cf(0x11e), 0x25fe5 + 0xaeb4 + -0x14f47), _0x1fc8be(_0xc7874b, _0x5a0ff7[_0x20b5cf(0x321)], _0x5a0ff7[_0x20b5cf(0x23f)], _0x5a0ff7[_0x20b5cf(0x19e)], -0x3 * -0x111a7 + 0x2c883 + -0x43e26), _0x1b4214['\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73'][_0x20b5cf(0xda)] = 0x1b47 + 0xf1d * -0x1 + -0x207 * 0x6, _0x5a0ff7[_0x20b5cf(0x205)](_0x2e9f5e, _0x4fe84a), _0xf29d4b = _0x5a0ff7['\x4b\x67\x78\x46\x43'];
                        } else {
                            if (_0x3e4a78[_0x20b5cf(0x2c1)](_0x4f079b['\x69\x6e\x64\x65\x78\x4f\x66'](_0x20b5cf(0x2ab)), -(0x1316 + 0x109d * -0x1 + 0x4f * -0x8))) {
                                if (_0x3e4a78[_0x20b5cf(0x2dc)](_0x20b5cf(0x32b), _0x3e4a78['\x73\x5a\x49\x58\x79'])) {
                                    _0x5a0ff7['\x66\x6e\x52\x51\x6f'](_0x209023, _0x5a0ff7[_0x20b5cf(0x163)]);
                                    return;
                                } else {
                                    let _0x5d9eb0 = _0x3e4a78[_0x20b5cf(0x14d)];
                                    if (_0x3e4a78['\x58\x5a\x75\x44\x4e'](_0x4f079b[_0x20b5cf(0x19a)](_0x20b5cf(0x223)), -(-0x2 * -0x1087 + 0x17f1 + -0x38fe)))
                                        '\x6c\x49\x7a\x46\x65' !== _0x20b5cf(0x12d) ? (_0x3e4a78['\x4e\x61\x6e\x50\x72'](CharacterReleaseTotal, _0x26b63a), _0x26b63a[_0x20b5cf(0x193)][_0x20b5cf(0xda)] = 0x204a + 0xbdf * -0x2 + -0x88c, _0x3e4a78[_0x20b5cf(0x352)](ChatRoomCharacterUpdate, _0x26b63a), _0x5d9eb0 = _0x20b5cf(0x15f)) : _0x46bcc3[_0x20b5cf(0x346)](_0x93b65a, _0x1bb2e9, _0x330ff2, 0x27609 + 0x2d3c3 + -0x38a7a);
                                    else {
                                        if (_0x3e4a78[_0x20b5cf(0x12c)](_0x4f079b[_0x20b5cf(0x19a)](_0x20b5cf(0x20a)), -(0x977 + -0x1 * 0xa8e + 0x5 * 0x38))) {
                                            if (_0x3e4a78[_0x20b5cf(0x2d3)](_0x20b5cf(0x1f9), _0x3e4a78[_0x20b5cf(0x20f)])) {
                                                const _0x1182a7 = _0x3e4a78[_0x20b5cf(0x134)][_0x20b5cf(0x108)]('\x7c');
                                                let _0x65c2c4 = 0x230c + 0x2564 + -0x4870;
                                                while (!![]) {
                                                    switch (_0x1182a7[_0x65c2c4++]) {
                                                    case '\x30':
                                                        _0x3e4a78[_0x20b5cf(0x289)](InventoryWear, _0x26b63a, _0x3e4a78[_0x20b5cf(0x164)], _0x20b5cf(0x1b8), _0x3e4a78[_0x20b5cf(0x316)], 0x1 * 0xf90d + -0x8cbd * 0x2 + 0x3f7 * 0x79);
                                                        continue;
                                                    case '\x31':
                                                        _0x5d9eb0 = _0x3e4a78[_0x20b5cf(0x1f3)];
                                                        continue;
                                                    case '\x32':
                                                        _0x26b63a[_0x20b5cf(0x193)][_0x20b5cf(0xda)] = 0x11ad + -0x6b7 + 0x17 * -0x7a;
                                                        continue;
                                                    case '\x33':
                                                        _0x3e4a78[_0x20b5cf(0x27b)](InventoryWear, _0x26b63a, _0x3e4a78[_0x20b5cf(0x178)], _0x20b5cf(0x308), _0x3e4a78[_0x20b5cf(0x316)], -0x1ae70 * -0x2 + 0x13981 + -0x2d70f);
                                                        continue;
                                                    case '\x34':
                                                        ChatRoomCharacterUpdate(_0x26b63a);
                                                        continue;
                                                    }
                                                    break;
                                                }
                                            } else
                                                _0x67bd20 = _0x5a0ff7['\x4e\x77\x4f\x42\x77'](_0x5a0ff7[_0x20b5cf(0x122)](_0x5a0ff7[_0x20b5cf(0x107)], _0x417435[_0x20b5cf(0x220)]), '\x2e');
                                        } else {
                                            if (_0x4f079b[_0x20b5cf(0x19a)](_0x20b5cf(0x1b1)) != -(0x1a83 + -0x2ab + 0x17d7 * -0x1))
                                                AwBotBan['\x70\x75\x73\x68'](_0x26b63a[_0x20b5cf(0x220)]), _0x5d9eb0 = _0x3e4a78['\x55\x6d\x53\x57\x6a'];
                                            else {
                                                if (_0x4f079b[_0x20b5cf(0x19a)](_0x3e4a78['\x52\x76\x41\x65\x52']) != -(0xde8 + -0x1e78 + 0x1091))
                                                    _0x5d9eb0 = _0x3e4a78[_0x20b5cf(0x1a9)];
                                                else {
                                                    if (_0x3e4a78[_0x20b5cf(0x35f)](_0x4f079b[_0x20b5cf(0x19a)](_0x3e4a78[_0x20b5cf(0x23d)]), -(0x14fd * -0x1 + 0x57e + -0x80 * -0x1f)))
                                                        _0x5d9eb0 = _0x3e4a78[_0x20b5cf(0x332)](_0x3e4a78['\x6f\x70\x53\x53\x79'](_0x3e4a78[_0x20b5cf(0x21d)], _0x26b63a[_0x20b5cf(0x220)]), '\x2e');
                                                    else {
                                                        if (_0x3e4a78[_0x20b5cf(0x2e9)](_0x4f079b[_0x20b5cf(0x19a)](_0x20b5cf(0x1b0)), -(-0x67f * -0x2 + 0x31e + -0x101b)))
                                                            _0x3e4a78[_0x20b5cf(0x27b)](InventoryWear, _0x26b63a, _0x3e4a78['\x54\x63\x44\x68\x6e'], '\x49\x74\x65\x6d\x41\x72\x6d\x73', _0x3e4a78[_0x20b5cf(0x316)], -0x107 * 0x7b + 0x2e075 + 0x90b * -0x12), _0x26b63a[_0x20b5cf(0x193)][_0x20b5cf(0xda)] = -0x1267 + -0x9 * -0x348 + 0x103 * -0xb, _0x3e4a78['\x42\x44\x44\x46\x56'](ChatRoomCharacterUpdate, _0x26b63a), _0x5d9eb0 = _0x3e4a78[_0x20b5cf(0x293)];
                                                        else {
                                                            if (_0x4f079b[_0x20b5cf(0x19a)](_0x3e4a78[_0x20b5cf(0x100)]) != -(-0x1 * 0x25e8 + 0x1 * 0x261a + -0x7 * 0x7))
                                                                _0x26b63a[_0x20b5cf(0x2f3)][_0x20b5cf(0x1a1)](_0x2ea812 => {
                                                                    const _0x17a81c = _0x20b5cf;
                                                                    let _0x4826cf = 0x1f57 + -0x16b2 + -0x1 * 0x8a5;
                                                                    if (_0x46bcc3[_0x17a81c(0x1fc)](_0x2ea812[_0x17a81c(0x158)], -0x4 * 0x5dd + 0x224f * 0x1 + -0x18d * 0x7)) {
                                                                        _0x46bcc3['\x67\x4e\x6c\x68\x48'](_0x2ea812[_0x17a81c(0x161)], null) && (_0x2ea812['\x50\x72\x6f\x70\x65\x72\x74\x79'] = {});
                                                                        if (_0x46bcc3[_0x17a81c(0x2cc)](_0x2ea812['\x50\x72\x6f\x70\x65\x72\x74\x79']['\x45\x66\x66\x65\x63\x74'], null)) {
                                                                            if (_0x46bcc3['\x77\x6a\x4f\x7a\x6a'](_0x46bcc3[_0x17a81c(0x311)], _0x46bcc3[_0x17a81c(0x311)]))
                                                                                return;
                                                                            else
                                                                                _0x2ea812['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x17a81c(0x31c)] = [];
                                                                        }
                                                                        _0x46bcc3[_0x17a81c(0x1c7)](_0x2ea812[_0x17a81c(0x161)]['\x45\x66\x66\x65\x63\x74'][_0x17a81c(0x19a)](_0x46bcc3['\x69\x7a\x7a\x4b\x42']), 0x985 + -0x16f8 + 0xd73) && (_0x46bcc3[_0x17a81c(0x23b)]('\x4e\x4e\x42\x66\x62', '\x4e\x4e\x42\x66\x62') ? _0x2ea812['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x17a81c(0x31c)]['\x70\x75\x73\x68'](_0x46bcc3[_0x17a81c(0xf6)]) : _0x5a0ff7[_0x17a81c(0xde)](_0x197ab0, _0x17a81c(0x16f), {
                                                                            '\x43\x6f\x6e\x74\x65\x6e\x74': _0x5a0ff7['\x77\x47\x5a\x6d\x64'],
                                                                            '\x54\x79\x70\x65': _0x5a0ff7[_0x17a81c(0x2ba)]
                                                                        })), _0x46bcc3[_0x17a81c(0x1fc)](Math[_0x17a81c(0x176)](), 0x2e * -0x2f + 0x3e * 0x1f + -0x78 * -0x2 + 0.5) ? _0x2ea812['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x17a81c(0x14b)] = _0x46bcc3[_0x17a81c(0x1c2)] : _0x46bcc3[_0x17a81c(0x1bd)](_0x46bcc3['\x6d\x76\x75\x57\x6b'], _0x46bcc3[_0x17a81c(0x315)]) ? _0x22f869[_0x17a81c(0x161)][_0x17a81c(0x31c)] = [] : _0x2ea812[_0x17a81c(0x161)]['\x4c\x6f\x63\x6b\x65\x64\x42\x79'] = _0x46bcc3[_0x17a81c(0x195)], _0x2ea812[_0x17a81c(0x161)][_0x17a81c(0xfa)] = Player[_0x17a81c(0x257)], _0x26b63a['\x41\x70\x70\x65\x61\x72\x61\x6e\x63\x65'][_0x4826cf] = _0x2ea812;
                                                                    }
                                                                    _0x4826cf++;
                                                                }), _0x26b63a[_0x20b5cf(0x193)][_0x20b5cf(0xda)] = 0x1 * 0x18a3 + -0x20a2 + -0x1 * -0x7ff, _0x3e4a78[_0x20b5cf(0x2ac)](ChatRoomCharacterUpdate, _0x26b63a), _0x5d9eb0 = _0x3e4a78[_0x20b5cf(0x293)];
                                                            else {
                                                                if (_0x3e4a78[_0x20b5cf(0x187)](_0x4f079b['\x69\x6e\x64\x65\x78\x4f\x66'](_0x3e4a78[_0x20b5cf(0x287)]), -(-0x1 * 0x1b65 + -0x5a0 + 0x2106 * 0x1))) {
                                                                    if (_0x3e4a78[_0x20b5cf(0x227)](_0x3e4a78[_0x20b5cf(0xf2)], _0x3e4a78[_0x20b5cf(0x31f)])) {
                                                                        let _0x33b11b = [
                                                                            '\x49\x74\x65\x6d\x41\x72\x6d\x73',
                                                                            _0x3e4a78[_0x20b5cf(0x2e8)],
                                                                            _0x3e4a78[_0x20b5cf(0x2cf)],
                                                                            _0x20b5cf(0xdf),
                                                                            _0x3e4a78['\x49\x4c\x7a\x61\x4d'],
                                                                            _0x3e4a78[_0x20b5cf(0x2d2)],
                                                                            _0x3e4a78[_0x20b5cf(0x175)],
                                                                            _0x3e4a78[_0x20b5cf(0x328)],
                                                                            _0x3e4a78[_0x20b5cf(0x2a3)],
                                                                            _0x20b5cf(0x1ec),
                                                                            _0x20b5cf(0x2aa),
                                                                            _0x3e4a78[_0x20b5cf(0x2d4)],
                                                                            _0x3e4a78['\x61\x6f\x45\x52\x65'],
                                                                            _0x3e4a78[_0x20b5cf(0x336)],
                                                                            _0x3e4a78['\x45\x52\x58\x77\x74'],
                                                                            _0x3e4a78['\x48\x64\x74\x75\x6e'],
                                                                            _0x3e4a78['\x71\x4d\x78\x6b\x6e'],
                                                                            _0x3e4a78[_0x20b5cf(0x1d2)],
                                                                            _0x3e4a78[_0x20b5cf(0x203)],
                                                                            _0x3e4a78[_0x20b5cf(0x2e0)],
                                                                            _0x20b5cf(0x25d),
                                                                            _0x3e4a78['\x65\x41\x5a\x66\x66'],
                                                                            _0x3e4a78[_0x20b5cf(0x29c)],
                                                                            _0x3e4a78[_0x20b5cf(0x16d)],
                                                                            _0x20b5cf(0x11d)
                                                                        ];
                                                                        _0x33b11b[_0x20b5cf(0x1a1)](_0x54edf8 => {
                                                                            const _0x1339ef = _0x20b5cf;
                                                                            _0x5a0ff7[_0x1339ef(0x1d3)](_0x5a0ff7[_0x1339ef(0x2fc)], _0x5a0ff7[_0x1339ef(0x2ae)]) ? InventoryWearRandom(_0x26b63a, _0x54edf8, 0x7 * 0x9b8 + 0x14f85 + 0x2bc5) : _0x4f67e8['\x50\x72\x6f\x70\x65\x72\x74\x79']['\x45\x66\x66\x65\x63\x74'] = [];
                                                                        }), _0x26b63a[_0x20b5cf(0x193)][_0x20b5cf(0xda)] = -0x1bf1 + 0x7 * -0x451 + -0x4 * -0xe8a, _0x3e4a78[_0x20b5cf(0x1df)](ChatRoomCharacterUpdate, _0x26b63a), _0x5d9eb0 = _0x3e4a78[_0x20b5cf(0x293)];
                                                                    } else
                                                                        _0x46bcc3['\x4a\x55\x71\x4e\x42'](_0x1531af, _0x1a629c, _0x20b5cf(0x2bc), _0x20b5cf(0x308), _0x46bcc3[_0x20b5cf(0xf7)], 0x417 * -0x4a + 0x272b9 + -0x329 * -0x27), _0x26aafd['\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73']['\x50\x72\x6f\x67\x72\x65\x73\x73'] = -0x98b * 0x1 + 0xe03 + 0x16 * -0x34, _0x46bcc3[_0x20b5cf(0x19f)](_0x27ad0e, _0x5c9fcd), _0xffa72e = _0x46bcc3[_0x20b5cf(0x262)];
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    _0x3e4a78[_0x20b5cf(0x28e)](ServerSend, _0x3e4a78[_0x20b5cf(0x228)], {
                                        '\x43\x6f\x6e\x74\x65\x6e\x74': _0x3e4a78[_0x20b5cf(0x1eb)](_0x3e4a78[_0x20b5cf(0x2a6)], _0x5d9eb0),
                                        '\x54\x79\x70\x65': _0x3e4a78[_0x20b5cf(0x313)]
                                    });
                                }
                            } else
                                _0x4f079b['\x69\x6e\x64\x65\x78\x4f\x66'](_0x3e4a78[_0x20b5cf(0x151)]) != -(0xae4 + -0x2594 + 0x1ab1) && (_0x20b5cf(0x1be) === '\x69\x6e\x4f\x4f\x75' ? _0x4ef46e[_0x20b5cf(0x161)]['\x45\x66\x66\x65\x63\x74']['\x70\x75\x73\x68']('\x4c\x6f\x63\x6b') : _0x3e4a78['\x51\x6d\x56\x64\x55'](ServerSend, _0x20b5cf(0x16f), {
                                    '\x43\x6f\x6e\x74\x65\x6e\x74': _0x3e4a78[_0x20b5cf(0x209)],
                                    '\x54\x79\x70\x65': _0x3e4a78[_0x20b5cf(0x313)]
                                }));
                        }
                    } else {
                        if (_0x3e4a78['\x58\x63\x75\x56\x62'](_0x4f079b[_0x20b5cf(0x19a)](_0x20b5cf(0x2a8)), -(0x56e + -0x9 * -0x37c + 0x81 * -0x49)))
                            _0x3e4a78[_0x20b5cf(0xd7)](ServerSend, _0x3e4a78['\x6f\x63\x56\x59\x71'], {
                                '\x43\x6f\x6e\x74\x65\x6e\x74': _0x20b5cf(0x24a),
                                '\x54\x79\x70\x65': _0x3e4a78['\x50\x6c\x6a\x70\x67']
                            });
                        else {
                            if (_0x3e4a78[_0x20b5cf(0x2c1)](_0x4f079b[_0x20b5cf(0x19a)](_0x3e4a78['\x45\x49\x4a\x77\x47']), -(-0x1310 + 0x10d7 * 0x2 + 0x57 * -0x2b))) {
                                const _0x587082 = {};
                                _0x587082['\x43\x6f\x6e\x74\x65\x6e\x74'] = _0x20b5cf(0x277), _0x587082[_0x20b5cf(0x152)] = _0x20b5cf(0x31d), _0x3e4a78['\x74\x76\x54\x74\x66'](ServerSend, _0x3e4a78[_0x20b5cf(0x228)], _0x587082);
                            }
                        }
                    }
                } else
                    return;
            }, -0x64 * 0x5b + -0x315 * -0x1 + 0x245f));
            AwBotLast = _0x3e1db2[_0x18749f(0x22e)](_0x4f079b, _0x26b63a['\x4e\x61\x6d\x65']);
            let _0x320628 = _0x4f079b, _0x204bed = _0x3e1db2['\x45\x75\x51\x4b\x51'](SpeechGetTotalGagLevel, _0x26b63a, _0x4b38f2);
            return _0x204bed > 0x2237 + 0x102f + -0x1 * 0x3266 && (_0x3e1db2[_0x18749f(0x34e)](_0x18749f(0x340), _0x3e1db2['\x4a\x59\x46\x6a\x4f']) ? _0x320628 = _0x3e1db2[_0x18749f(0x22e)](_0x3e1db2[_0x18749f(0x319)](_0x3e1db2[_0x18749f(0x248)](_0x3e1db2[_0x18749f(0x2ef)], _0x204bed), '\x20'), _0x320628) : _0x46bcc3[_0x18749f(0x324)](_0x49129a, _0x1dbb59, _0x46bcc3[_0x18749f(0x25f)], _0x18749f(0x362))), _0x320628;
        };
    }), _0x3e1db2[_0x3f8630(0x111)](GM_registerMenuCommand, '\x61\x77\x42\x4f\x54\x5f\u5207\u6362\u9677\u9631\u5c4b\u8bed\u8a00', () => {
        const _0x154a5c = _0x3f8630;
        _0x3e1db2['\x6f\x6c\x4a\x58\x6b'](this[_0x154a5c(0x194)], ![]) || _0x3e1db2[_0x154a5c(0x2a5)](this[_0x154a5c(0x194)], undefined) ? (this[_0x154a5c(0x194)] = !![], ChatRoomSendLocal(_0x3e1db2[_0x154a5c(0x2c3)])) : _0x3e1db2[_0x154a5c(0x1fd)] === _0x3e1db2['\x4b\x4c\x50\x74\x68'] ? (this[_0x154a5c(0x194)] = ![], _0x3e1db2[_0x154a5c(0x13d)](ChatRoomSendLocal, _0x154a5c(0x1e4))) : _0x1ab5bb[_0x154a5c(0x161)]['\x45\x66\x66\x65\x63\x74'][_0x154a5c(0x153)](_0x3e1db2['\x76\x74\x68\x66\x4c']);
    }), GM_registerMenuCommand(_0x3e1db2[_0x3f8630(0x184)], () => {
        const _0x10ec48 = _0x3f8630;
        _0x3e1db2[_0x10ec48(0x1a2)](ServerSend, _0x10ec48(0x16f), {
            '\x43\x6f\x6e\x74\x65\x6e\x74': _0x3e1db2['\x78\x68\x48\x42\x5a'],
            '\x54\x79\x70\x65': '\x48\x69\x64\x64\x65\x6e',
            '\x44\x69\x63\x74\x69\x6f\x6e\x61\x72\x79': [{
                    '\x6d\x65\x73\x73\x61\x67\x65': {
                        '\x74\x79\x70\x65': _0x3e1db2['\x62\x72\x73\x4c\x6c'],
                        '\x76\x65\x72\x73\x69\x6f\x6e': _0x3e1db2['\x73\x67\x55\x45\x4f'],
                        '\x61\x6c\x74\x65\x72\x6e\x61\x74\x65\x41\x72\x6f\x75\x73\x61\x6c': !![],
                        '\x72\x65\x70\x6c\x79\x52\x65\x71\x75\x65\x73\x74\x65\x64': ![],
                        '\x63\x61\x70\x61\x62\x69\x6c\x69\x74\x69\x65\x73': [_0x3e1db2['\x77\x62\x42\x46\x6e']],
                        '\x6e\x69\x63\x6b': null
                    }
                }]
        });
        const _0x1ae65c = {};
        _0x1ae65c[_0x10ec48(0x31c)] = [], _0x3e1db2['\x5a\x7a\x45\x74\x52'](ServerSend, _0x3e1db2[_0x10ec48(0x276)], {
            '\x43\x6f\x6e\x74\x65\x6e\x74': _0x3e1db2[_0x10ec48(0x330)],
            '\x54\x79\x70\x65': _0x3e1db2['\x4c\x58\x43\x47\x64'],
            '\x44\x69\x63\x74\x69\x6f\x6e\x61\x72\x79': {
                '\x74\x79\x70\x65': _0x10ec48(0x101),
                '\x6d\x65\x73\x73\x61\x67\x65': {
                    '\x76\x65\x72\x73\x69\x6f\x6e': _0x3e1db2[_0x10ec48(0x275)],
                    '\x72\x65\x71\x75\x65\x73\x74': ![],
                    '\x65\x66\x66\x65\x63\x74\x73': _0x1ae65c,
                    '\x74\x79\x70\x69\x6e\x67\x49\x6e\x64\x69\x63\x61\x74\x6f\x72\x45\x6e\x61\x62\x6c\x65': ![],
                    '\x73\x63\x72\x65\x65\x6e\x49\x6e\x64\x69\x63\x61\x74\x6f\x72\x45\x6e\x61\x62\x6c\x65': ![]
                }
            }
        });
    }), _0x3e1db2[_0x3f8630(0x1ad)](GM_registerMenuCommand, _0x3e1db2[_0x3f8630(0x126)], () => {
        const _0x454b79 = _0x3f8630, _0x420ffa = {
                '\x6c\x4c\x79\x46\x63': function (_0x33723b, _0x3e76ac) {
                    const _0x374361 = _0x1c0d;
                    return _0x3e1db2[_0x374361(0x149)](_0x33723b, _0x3e76ac);
                },
                '\x54\x45\x56\x67\x47': function (_0x59867b, _0x10a688) {
                    return _0x3e1db2['\x46\x65\x5a\x6e\x6e'](_0x59867b, _0x10a688);
                },
                '\x66\x78\x71\x4b\x42': _0x454b79(0x35a),
                '\x6d\x61\x74\x42\x44': function (_0x122fec, _0x54c226) {
                    const _0x2a8d34 = _0x454b79;
                    return _0x3e1db2[_0x2a8d34(0x2c9)](_0x122fec, _0x54c226);
                },
                '\x6c\x74\x4f\x4e\x62': _0x3e1db2[_0x454b79(0x2f2)],
                '\x57\x53\x63\x76\x57': function (_0x21762b, _0x5e83a5, _0x298ff6) {
                    return _0x21762b(_0x5e83a5, _0x298ff6);
                },
                '\x47\x69\x6a\x5a\x43': _0x3e1db2[_0x454b79(0x150)],
                '\x4b\x48\x51\x46\x75': _0x3e1db2[_0x454b79(0x1e1)]
            };
        if (_0x3e1db2[_0x454b79(0x2a1)](_0x3e1db2[_0x454b79(0x306)], _0x3e1db2[_0x454b79(0x306)])) {
            if (!(Player['\x4f\x77\x6e\x65\x72\x73\x68\x69\x70'] && _0x3e1db2[_0x454b79(0x216)](Player[_0x454b79(0x1a6)][_0x454b79(0x220)], _0x3e1db2[_0x454b79(0x1ee)]))) {
                if (Player[_0x454b79(0x220)] != _0x3e1db2['\x5a\x64\x67\x4d\x73']) {
                    if (_0x3e1db2[_0x454b79(0x208)](_0x3e1db2[_0x454b79(0x131)], _0x3e1db2['\x70\x61\x45\x49\x6f'])) {
                        _0x3e1db2[_0x454b79(0xc6)](alert, _0x3e1db2[_0x454b79(0x252)]);
                        return;
                    } else {
                        const _0x3c5ec1 = {};
                        _0x3c5ec1[_0x454b79(0x1c5)] = '\x61\x77\u9677\u9631\u5c4b\u89c4\u5219\x3a\x31\x2c\u5f53\u623f\u95f4\u88ab\u521b\u5efa\u65f6\x2c\u6211\u4eec\u4f1a\u5f00\u542f\u4e00\u4e2a\x31\x35\u5206\u949f\u7684\u5012\u8ba1\u65f6\x2e\x32\x2c\u5012\u8ba1\u65f6\u7ed3\u675f\u524d\x2c\u6240\u6709\u8fdb\u5165\u7684\u4eba\u90fd\u4f1a\u88ab\u6346\u7684\u6b7b\u6b7b\u7684\x3b\u4efb\u4f55\u5c1d\u8bd5\u8425\u6551\u7684\u4eba\u90fd\u4f1a\u88ab\u623f\u95f4\u5c01\u7981\x2e\x33\x2c\u5012\u8ba1\u65f6\u7ed3\u675f\u540e\x2c\u8fd9\u4e2a\u623f\u95f4\u5c31\u5b89\u5168\u4e86\x2e\u8def\u4eba\u5c31\u53ef\u4ee5\u8425\x28\x77\x61\x6e\x29\u6551\x28\x6e\x6f\x6e\x67\x29\u91cc\u9762\u7684\u5c0f\u53ef\u7231\u4eec\u4e86\u5462\x7e', _0x3c5ec1[_0x454b79(0x152)] = _0x3e1db2[_0x454b79(0x16b)], _0x1fea36(_0x454b79(0x16f), _0x3c5ec1);
                    }
                }
            }
            _0x3e1db2[_0x454b79(0x338)](this[_0x454b79(0x334)], ![]) || _0x3e1db2['\x46\x4d\x44\x59\x70'](this[_0x454b79(0x334)], undefined) ? (this[_0x454b79(0x194)] = !![], _0x3e1db2[_0x454b79(0xc6)](ChatRoomSendLocal, '\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x3a\x20\x52\x65\x61\x64\x79\x2e'), AwAutoKickOn = !![], AwAutoKicker = function (_0x3b6e30) {
                const _0xa23510 = _0x454b79;
                let _0x2540b4 = ChatRoomCharacter['\x66\x69\x6e\x64'](_0x4ab99d => _0x4ab99d[_0xa23510(0x257)] === _0x3b6e30[_0xa23510(0x16e)]);
                _0x420ffa[_0xa23510(0xb3)](_0x3b6e30[_0xa23510(0x152)], '\x41\x63\x74\x69\x6f\x6e') && (_0x420ffa[_0xa23510(0x139)](_0x3b6e30[_0xa23510(0x1c5)], _0x420ffa[_0xa23510(0x197)]) || _0x420ffa[_0xa23510(0x2c5)](_0x3b6e30['\x43\x6f\x6e\x74\x65\x6e\x74'], _0x420ffa[_0xa23510(0x2ee)])) && _0x420ffa[_0xa23510(0x1d1)](ServerSend, _0xa23510(0x298), {
                    '\x4d\x65\x6d\x62\x65\x72\x4e\x75\x6d\x62\x65\x72': _0x2540b4[_0xa23510(0x257)],
                    '\x41\x63\x74\x69\x6f\x6e': _0x420ffa['\x47\x69\x6a\x5a\x43']
                });
                ;
            }, ServerSocket['\x6f\x6e'](_0x454b79(0x1b6), AwAutoKicker), AwBotTrap = _0x3e1db2['\x73\x51\x4d\x41\x67'], ChatRoomNotificationRaiseChatJoin = function (_0x2cf6c3) {
                const _0x2320d5 = _0x454b79, _0x4870c3 = {
                        '\x73\x7a\x4d\x45\x56': function (_0x597cbf, _0x1c9cb3, _0x3b44bf, _0x565c72) {
                            const _0x1804c2 = _0x1c0d;
                            return _0x3e1db2[_0x1804c2(0x2de)](_0x597cbf, _0x1c9cb3, _0x3b44bf, _0x565c72);
                        },
                        '\x41\x42\x54\x55\x6d': function (_0x935e4a, _0x4b90ca) {
                            const _0x291793 = _0x1c0d;
                            return _0x3e1db2[_0x291793(0x170)](_0x935e4a, _0x4b90ca);
                        },
                        '\x58\x6d\x48\x7a\x7a': function (_0x3136df, _0x15cf8b) {
                            const _0x45de57 = _0x1c0d;
                            return _0x3e1db2[_0x45de57(0x149)](_0x3136df, _0x15cf8b);
                        },
                        '\x51\x71\x62\x6b\x58': function (_0x12ad91, _0xe5064b) {
                            const _0x3c24eb = _0x1c0d;
                            return _0x3e1db2[_0x3c24eb(0x2a1)](_0x12ad91, _0xe5064b);
                        },
                        '\x64\x6a\x52\x71\x53': _0x3e1db2[_0x2320d5(0x1ea)],
                        '\x54\x52\x57\x49\x49': function (_0x47cd25, _0x2e8ba8) {
                            const _0x1f177d = _0x2320d5;
                            return _0x3e1db2[_0x1f177d(0xe0)](_0x47cd25, _0x2e8ba8);
                        },
                        '\x4d\x5a\x4b\x6b\x41': '\x62\x76\x6e\x47\x4d',
                        '\x54\x54\x73\x77\x64': _0x3e1db2[_0x2320d5(0xf3)],
                        '\x4b\x4c\x48\x4f\x43': function (_0x3f71c2, _0x49903e) {
                            return _0x3e1db2['\x56\x59\x78\x46\x4b'](_0x3f71c2, _0x49903e);
                        },
                        '\x6e\x48\x79\x6b\x4d': _0x3e1db2[_0x2320d5(0x30e)],
                        '\x70\x6c\x6c\x46\x6e': _0x3e1db2[_0x2320d5(0x29b)],
                        '\x50\x47\x55\x74\x58': _0x3e1db2[_0x2320d5(0x1ed)],
                        '\x41\x58\x52\x43\x64': _0x3e1db2[_0x2320d5(0x192)],
                        '\x44\x4b\x6c\x75\x46': _0x3e1db2[_0x2320d5(0x144)],
                        '\x46\x6b\x7a\x55\x66': _0x3e1db2[_0x2320d5(0x1ae)],
                        '\x49\x4d\x41\x4b\x76': _0x3e1db2[_0x2320d5(0x357)],
                        '\x6c\x5a\x6d\x59\x64': _0x3e1db2[_0x2320d5(0x312)],
                        '\x44\x47\x70\x78\x56': _0x3e1db2[_0x2320d5(0x199)],
                        '\x68\x42\x41\x53\x70': _0x2320d5(0x339),
                        '\x77\x45\x4f\x51\x6a': _0x3e1db2[_0x2320d5(0x260)],
                        '\x77\x59\x68\x6c\x56': _0x3e1db2[_0x2320d5(0xe7)],
                        '\x57\x4a\x45\x6a\x4c': _0x3e1db2[_0x2320d5(0x2ad)],
                        '\x71\x79\x58\x7a\x73': _0x3e1db2['\x6b\x50\x63\x6a\x51'],
                        '\x7a\x75\x66\x52\x51': _0x3e1db2['\x78\x4f\x6e\x61\x54'],
                        '\x46\x4a\x53\x6f\x6f': _0x3e1db2['\x79\x54\x65\x74\x45'],
                        '\x49\x46\x78\x4d\x54': function (_0x36899b, _0x30744a, _0x34073f) {
                            return _0x36899b(_0x30744a, _0x34073f);
                        },
                        '\x5a\x41\x42\x6a\x6b': _0x3e1db2['\x72\x77\x4d\x48\x55'],
                        '\x77\x69\x43\x55\x6c': _0x3e1db2[_0x2320d5(0x13c)],
                        '\x49\x53\x59\x69\x59': _0x3e1db2[_0x2320d5(0x16b)]
                    };
                return setTimeout(function () {
                    const _0x2780bc = _0x2320d5, _0x3d800d = {
                            '\x53\x70\x47\x67\x68': function (_0x5a2e75, _0x4e3959, _0x2d7e22, _0x3a1bb0) {
                                const _0x3670dd = _0x1c0d;
                                return _0x4870c3[_0x3670dd(0x1a5)](_0x5a2e75, _0x4e3959, _0x2d7e22, _0x3a1bb0);
                            },
                            '\x62\x56\x6c\x58\x72': function (_0x250cfe, _0x40f73e) {
                                const _0x19bf8c = _0x1c0d;
                                return _0x4870c3[_0x19bf8c(0x17a)](_0x250cfe, _0x40f73e);
                            },
                            '\x5a\x46\x6c\x79\x4f': function (_0x28a434, _0x156963) {
                                return _0x4870c3['\x58\x6d\x48\x7a\x7a'](_0x28a434, _0x156963);
                            },
                            '\x56\x53\x49\x45\x57': function (_0x40e4df, _0x3739a1) {
                                const _0x309e6f = _0x1c0d;
                                return _0x4870c3[_0x309e6f(0x364)](_0x40e4df, _0x3739a1);
                            },
                            '\x6d\x59\x43\x59\x48': '\x4c\x6f\x63\x6b',
                            '\x62\x63\x4b\x6c\x69': function (_0x23e708, _0xb56585) {
                                return _0x4870c3['\x41\x42\x54\x55\x6d'](_0x23e708, _0xb56585);
                            },
                            '\x72\x48\x6f\x78\x45': function (_0x3e12a9, _0x255d81) {
                                const _0x3f8ee5 = _0x1c0d;
                                return _0x4870c3[_0x3f8ee5(0x11b)](_0x3e12a9, _0x255d81);
                            },
                            '\x44\x79\x61\x4d\x45': '\x41\x51\x52\x54\x71',
                            '\x6c\x54\x6c\x56\x44': _0x4870c3['\x64\x6a\x52\x71\x53'],
                            '\x58\x63\x4f\x73\x41': function (_0x3f1e07, _0x56a422) {
                                const _0x38527f = _0x1c0d;
                                return _0x4870c3[_0x38527f(0x141)](_0x3f1e07, _0x56a422);
                            },
                            '\x42\x63\x44\x7a\x63': _0x4870c3[_0x2780bc(0x285)],
                            '\x73\x75\x74\x4a\x63': _0x4870c3[_0x2780bc(0x231)]
                        };
                    if (_0x4870c3[_0x2780bc(0x2d9)](AwBotTrap, _0x2cf6c3[_0x2780bc(0x220)])) {
                        AwBotTrap = _0x2cf6c3[_0x2780bc(0x220)];
                        let _0x54b167 = [
                            _0x4870c3[_0x2780bc(0x361)],
                            '\x49\x74\x65\x6d\x42\x6f\x6f\x74\x73',
                            _0x2780bc(0x34c),
                            _0x4870c3['\x70\x6c\x6c\x46\x6e'],
                            '\x49\x74\x65\x6d\x44\x65\x76\x69\x63\x65\x73',
                            _0x4870c3['\x50\x47\x55\x74\x58'],
                            _0x4870c3[_0x2780bc(0x288)],
                            '\x49\x74\x65\x6d\x48\x61\x6e\x64\x73',
                            _0x2780bc(0x182),
                            _0x4870c3[_0x2780bc(0x33a)],
                            _0x4870c3['\x46\x6b\x7a\x55\x66'],
                            _0x2780bc(0x362),
                            _0x4870c3[_0x2780bc(0x19b)],
                            _0x4870c3[_0x2780bc(0xd8)],
                            _0x4870c3[_0x2780bc(0x2ea)],
                            _0x4870c3['\x68\x42\x41\x53\x70'],
                            _0x2780bc(0xfe),
                            _0x4870c3['\x77\x45\x4f\x51\x6a'],
                            _0x4870c3[_0x2780bc(0x30f)],
                            _0x4870c3[_0x2780bc(0x120)],
                            _0x4870c3['\x71\x79\x58\x7a\x73'],
                            _0x4870c3[_0x2780bc(0x1a8)],
                            '\x49\x74\x65\x6d\x54\x6f\x72\x73\x6f',
                            _0x2780bc(0x242),
                            _0x4870c3[_0x2780bc(0x24d)]
                        ];
                        _0x54b167[_0x2780bc(0x1a1)](_0x1aa776 => {
                            const _0x470752 = _0x2780bc;
                            _0x4870c3[_0x470752(0x1a5)](InventoryWearRandom, _0x2cf6c3, _0x1aa776, 0xb * 0x36af + 0x229 * -0x53 + -0xb * -0x248);
                        }), _0x2cf6c3[_0x2780bc(0x2f3)][_0x2780bc(0x1a1)](_0x27804f => {
                            const _0x45dd0f = _0x2780bc;
                            let _0x660461 = -0xa * -0x4 + -0x1 * 0x13df + 0x13b7;
                            _0x3d800d['\x62\x56\x6c\x58\x72'](_0x27804f[_0x45dd0f(0x158)], 0x1426 * -0x1 + 0x16ec + -0x2c6) && (_0x3d800d[_0x45dd0f(0x2eb)](_0x27804f[_0x45dd0f(0x161)], null) && (_0x27804f[_0x45dd0f(0x161)] = {}), _0x3d800d[_0x45dd0f(0x222)](_0x27804f['\x50\x72\x6f\x70\x65\x72\x74\x79']['\x45\x66\x66\x65\x63\x74'], null) && (_0x27804f[_0x45dd0f(0x161)]['\x45\x66\x66\x65\x63\x74'] = []), _0x27804f['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x45dd0f(0x31c)]['\x69\x6e\x64\x65\x78\x4f\x66'](_0x3d800d[_0x45dd0f(0x15e)]) < 0x1 * 0x4b2 + -0x4 * -0x3ce + 0x1 * -0x13ea && _0x27804f[_0x45dd0f(0x161)][_0x45dd0f(0x31c)][_0x45dd0f(0x153)](_0x3d800d[_0x45dd0f(0x15e)]), _0x3d800d['\x62\x63\x4b\x6c\x69'](Math[_0x45dd0f(0x176)](), 0x1a1f + 0x1 * 0x229f + -0x19 * 0x26e + 0.5) ? _0x3d800d['\x72\x48\x6f\x78\x45'](_0x3d800d['\x44\x79\x61\x4d\x45'], _0x45dd0f(0x31e)) ? _0x27804f['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x45dd0f(0x14b)] = _0x3d800d[_0x45dd0f(0x143)] : _0x4447d2[_0x45dd0f(0x161)][_0x45dd0f(0x14b)] = _0x45dd0f(0x21e) : _0x3d800d['\x58\x63\x4f\x73\x41']('\x62\x76\x6e\x47\x4d', _0x3d800d[_0x45dd0f(0x116)]) ? _0x3d800d[_0x45dd0f(0x2f5)](_0x949702, _0x365c99, _0x7b4e16, 0x30643 + 0x2eaa7 * 0x1 + -0x43198) : _0x27804f[_0x45dd0f(0x161)][_0x45dd0f(0x14b)] = _0x3d800d[_0x45dd0f(0x2b5)], _0x27804f[_0x45dd0f(0x161)][_0x45dd0f(0xfa)] = Player[_0x45dd0f(0x257)], _0x2cf6c3[_0x45dd0f(0x2f3)][_0x660461] = _0x27804f), _0x660461++;
                        }), _0x2cf6c3[_0x2780bc(0x193)][_0x2780bc(0xda)] = 0x25 * -0x2b + -0x2400 + -0x6b * -0x65, ChatRoomCharacterUpdate(_0x2cf6c3);
                        if (this['\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x5a\x68']) {
                            const _0xfecb0f = {};
                            _0xfecb0f[_0x2780bc(0x1c5)] = _0x2780bc(0x35b), _0xfecb0f[_0x2780bc(0x152)] = _0x2780bc(0x31d), ServerSend(_0x2780bc(0x16f), _0xfecb0f);
                        } else
                            _0x4870c3[_0x2780bc(0x224)](ServerSend, _0x4870c3['\x5a\x41\x42\x6a\x6b'], {
                                '\x43\x6f\x6e\x74\x65\x6e\x74': _0x4870c3['\x77\x69\x43\x55\x6c'],
                                '\x54\x79\x70\x65': _0x4870c3['\x49\x53\x59\x69\x59']
                            });
                    }
                }, 0x1 * 0x12a3 + 0x699 + -0x1554), !![];
            }) : _0x3e1db2[_0x454b79(0x33d)](_0x3e1db2['\x79\x65\x64\x43\x56'], _0x3e1db2[_0x454b79(0x355)]) ? _0x3e1db2[_0x454b79(0x27d)](_0x1d6ee8, _0x3e1db2[_0x454b79(0x249)](_0x1fb98a, _0x454b79(0x103), _0x3e1db2[_0x454b79(0x35c)]), -0x1c6a * -0x1 + 0x3153f + -0x17257, !![]) : (AwAutoKickOn = ![], ServerSocket[_0x454b79(0x1db)](_0x454b79(0x1b6), AwAutoKicker), _0x3e1db2['\x4e\x62\x76\x62\x6b'](ChatRoomSendLocal, _0x454b79(0x33c)), ChatRoomNotificationRaiseChatJoin = function (_0x24182a) {
                const _0x3ff3f8 = _0x454b79;
                if (_0x3e1db2[_0x3ff3f8(0x14f)] === _0x3ff3f8(0x121))
                    return !![];
                else
                    _0x2f17b8 = _0x420ffa['\x4b\x48\x51\x46\x75'];
            });
        } else
            _0x3e1db2['\x4b\x71\x53\x58\x6e'](_0x1813a9, _0x79a91e, _0x309d0c, -0x30aaa + 0xa2f7 + 0x42705);
    }), _0x3e1db2[_0x3f8630(0x263)](GM_registerMenuCommand, _0x3e1db2[_0x3f8630(0x229)], () => {
        const _0xfe9a0e = _0x3f8630;
        _0x3e1db2[_0xfe9a0e(0x1d0)] !== _0x3e1db2[_0xfe9a0e(0x1a4)] ? (targetName = _0x3e1db2[_0xfe9a0e(0xfc)](prompt, _0xfe9a0e(0x34d), '\x61\x77\x61\x71\x77\x71'), AwBotBan[_0xfe9a0e(0x19a)](targetName) != -(0x6d * 0x33 + -0x8d1 * -0x1 + 0xa2d * -0x3) && (_0x3e1db2[_0xfe9a0e(0xee)](_0x3e1db2[_0xfe9a0e(0x15d)], _0x3e1db2['\x71\x46\x71\x63\x4a']) ? _0x27cedc['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0xfe9a0e(0x14b)] = _0x3e1db2[_0xfe9a0e(0x1ea)] : alert(_0x3e1db2[_0xfe9a0e(0x2bf)])), AwBotBan[_0xfe9a0e(0x153)](targetName)) : _0x186451[_0xfe9a0e(0x161)][_0xfe9a0e(0x14b)] = _0x3e1db2['\x4f\x6d\x5a\x72\x71'];
    }), GM_registerMenuCommand(_0x3e1db2[_0x3f8630(0x1b2)], () => {
        const _0x5cc335 = _0x3f8630, _0x50791e = {
                '\x76\x48\x70\x62\x57': _0x5cc335(0x196),
                '\x41\x6c\x6c\x79\x4f': function (_0x1bc9f0, _0x2876be) {
                    return _0x1bc9f0 == _0x2876be;
                },
                '\x4d\x6a\x5a\x58\x57': function (_0x5276a1, _0x245e55, _0x5477de) {
                    return _0x5276a1(_0x245e55, _0x5477de);
                },
                '\x76\x78\x50\x4b\x43': _0x3e1db2['\x71\x71\x6f\x72\x65'],
                '\x75\x53\x4e\x66\x71': _0x3e1db2['\x5a\x64\x67\x4d\x73'],
                '\x56\x64\x58\x61\x70': function (_0x483ec3, _0x141b34) {
                    const _0x45d54c = _0x5cc335;
                    return _0x3e1db2[_0x45d54c(0x2bd)](_0x483ec3, _0x141b34);
                }
            };
        targetName = _0x3e1db2[_0x5cc335(0x1ca)](prompt, _0x3e1db2[_0x5cc335(0xb5)], _0x3e1db2['\x5a\x64\x67\x4d\x73']), banIndex = AwBotBan[_0x5cc335(0x19a)](targetName);
        if (_0x3e1db2[_0x5cc335(0x129)](banIndex, -(-0x102e + -0x1c92 + -0x9 * -0x4f9))) {
            if (_0x3e1db2[_0x5cc335(0xe0)]('\x4d\x54\x41\x6f\x63', _0x5cc335(0x1f2)))
                alert(_0x3e1db2[_0x5cc335(0x1e7)]);
            else {
                const _0x2cfcc1 = _0x50791e[_0x5cc335(0xbd)][_0x5cc335(0x108)]('\x7c');
                let _0x213b1e = -0xa41 + -0x1d91 + 0x27d2 * 0x1;
                while (!![]) {
                    switch (_0x2cfcc1[_0x213b1e++]) {
                    case '\x30':
                        if (_0x50791e[_0x5cc335(0xb4)](_0x3f5984, null))
                            return;
                        continue;
                    case '\x31':
                        _0x59f2d5 = _0x50791e['\x4d\x6a\x5a\x58\x57'](_0x5cc219, _0x50791e['\x76\x78\x50\x4b\x43'], _0x50791e['\x75\x53\x4e\x66\x71']);
                        continue;
                    case '\x32':
                        _0x75a6ed = _0xd7faed[_0x5cc335(0x185)](_0x3af0be => _0x3af0be[_0x5cc335(0x220)][_0x5cc335(0x14e)]() == _0x91416c);
                        continue;
                    case '\x33':
                        _0x36b365(_0x139d96);
                        continue;
                    case '\x34':
                        _0x50791e[_0x5cc335(0x2b9)](_0x289e2b, _0x444d79);
                        continue;
                    case '\x35':
                        _0x4e2a7a[_0x5cc335(0x193)][_0x5cc335(0xda)] = 0xe10 + 0x6c8 * -0x4 + 0xd10;
                        continue;
                    }
                    break;
                }
            }
        }
        AwBotBan[_0x5cc335(0x304)](banIndex, -0x295 + -0x156a + 0x1800);
    }), _0x3e1db2[_0x3f8630(0x263)](GM_registerMenuCommand, _0x3e1db2['\x63\x43\x70\x49\x41'], () => {
        const _0x518254 = _0x3f8630, _0x58416b = {
                '\x62\x43\x79\x4e\x5a': function (_0xaabe28, _0x20b6cf) {
                    return _0xaabe28(_0x20b6cf);
                },
                '\x4f\x51\x49\x46\x63': _0x3e1db2['\x68\x6e\x67\x64\x48'],
                '\x4a\x6c\x58\x4c\x54': function (_0xee6efb, _0x57c3c6) {
                    const _0x5ba366 = _0x1c0d;
                    return _0x3e1db2[_0x5ba366(0x208)](_0xee6efb, _0x57c3c6);
                },
                '\x66\x41\x57\x47\x4f': _0x3e1db2[_0x518254(0x279)],
                '\x44\x51\x4a\x54\x72': function (_0x2aab3a, _0x2a3dbf, _0x12bf80) {
                    return _0x3e1db2['\x66\x46\x6d\x49\x69'](_0x2aab3a, _0x2a3dbf, _0x12bf80);
                },
                '\x51\x6f\x46\x45\x56': function (_0x342e50, _0x24ce3c) {
                    return _0x342e50 > _0x24ce3c;
                },
                '\x45\x41\x43\x4d\x64': function (_0x211d79, _0xa1a5c8) {
                    const _0x337bc1 = _0x518254;
                    return _0x3e1db2[_0x337bc1(0x319)](_0x211d79, _0xa1a5c8);
                },
                '\x6d\x55\x4f\x45\x47': function (_0x3968d8, _0xf8250e) {
                    const _0x428635 = _0x518254;
                    return _0x3e1db2[_0x428635(0x119)](_0x3968d8, _0xf8250e);
                },
                '\x70\x79\x66\x53\x59': _0x518254(0x294)
            };
        _0x3e1db2[_0x518254(0xe9)] === _0x3e1db2[_0x518254(0x1fa)] ? _0x37db56[_0x518254(0x161)][_0x518254(0x31c)] = [] : SpeechGarble = function (_0x5be4f3, _0x8cccb0, _0x5e3e78) {
            const _0x49bf98 = _0x518254, _0x2e5d5f = {
                    '\x43\x63\x75\x61\x6b': function (_0x456bb6, _0xf7524f) {
                        return _0x58416b['\x62\x43\x79\x4e\x5a'](_0x456bb6, _0xf7524f);
                    },
                    '\x75\x42\x41\x54\x73': _0x58416b[_0x49bf98(0x123)]
                };
            if (_0x58416b['\x4a\x6c\x58\x4c\x54'](_0x58416b[_0x49bf98(0x32a)], _0x58416b[_0x49bf98(0x32a)])) {
                let _0x2679f3 = _0x8cccb0, _0x15a8c1 = _0x58416b[_0x49bf98(0x369)](SpeechGetTotalGagLevel, _0x5be4f3, _0x5e3e78);
                return _0x58416b[_0x49bf98(0x28b)](_0x15a8c1, 0x193c + 0x452 + 0x3 * -0x9da) && (_0x2679f3 = _0x58416b[_0x49bf98(0x1dd)](_0x58416b[_0x49bf98(0x1b4)](_0x58416b[_0x49bf98(0x1d9)], _0x15a8c1), '\x20') + _0x2679f3), _0x2679f3;
            } else {
                _0x2e5d5f['\x43\x63\x75\x61\x6b'](_0x42ab22, _0x2e5d5f[_0x49bf98(0xcb)]);
                return;
            }
        };
    }), _0x3e1db2[_0x3f8630(0x217)](GM_registerMenuCommand, '\u83b7\u53d6\u7bb1\u5b50', () => {
        const _0x3e3bb2 = _0x3f8630;
        _0x3e1db2[_0x3e3bb2(0x27d)](InventoryWear, targetMember, _0x3e1db2['\x73\x6d\x43\x6d\x66'], _0x3e3bb2(0x362));
    }), _0x3e1db2['\x74\x73\x50\x46\x64'](GM_registerMenuCommand, _0x3e1db2['\x76\x5a\x43\x74\x68'], () => {
        alert(_0x3e1db2['\x4c\x46\x6c\x51\x4d']), CharacterChangeMoney(Player, -0x12b0 + -0x128 + 0x143c);
    }), GM_registerMenuCommand(_0x3e1db2[_0x3f8630(0x180)], () => {
        const _0x486c61 = _0x3f8630;
        if (!(Player['\x4f\x77\x6e\x65\x72\x73\x68\x69\x70'] && _0x3e1db2[_0x486c61(0x216)](Player[_0x486c61(0x1a6)][_0x486c61(0x220)], _0x3e1db2[_0x486c61(0x1ee)]))) {
            if (_0x3e1db2['\x68\x6f\x5a\x63\x57'](_0x3e1db2[_0x486c61(0x20e)], _0x3e1db2[_0x486c61(0x347)]))
                _0x3e1db2[_0x486c61(0xff)](_0x3eae8b, _0x3e1db2[_0x486c61(0x167)], -0x14591 + -0x28a3b + 0x58f1e);
            else {
                if (Player['\x4e\x61\x6d\x65'] != _0x486c61(0x1ba)) {
                    _0x3e1db2['\x45\x78\x42\x64\x7a'](alert, _0x486c61(0x32f));
                    return;
                }
            }
        }
        _0x3e1db2[_0x486c61(0x12e)](CurrentScreen, '\x43\x68\x61\x74\x52\x6f\x6f\x6d') ? (DialogLentLockpicks = ![], _0x3e1db2[_0x486c61(0x1f6)](ChatRoomClearAllElements), ServerSend(_0x3e1db2['\x79\x4f\x50\x67\x79'], ''), ChatRoomSetLastChatRoom(''), ChatRoomLeashPlayer = null, CommonSetScreen(_0x3e1db2['\x78\x67\x56\x63\x75'], _0x486c61(0x206)), CharacterDeleteAllOnline(), _0x3e1db2['\x61\x77\x66\x52\x67'](ChatSearchExit)) : _0x3e1db2[_0x486c61(0x13d)](MainHallWalk, _0x3e1db2[_0x486c61(0xd9)]);
    }), _0x3e1db2['\x76\x57\x72\x69\x46'](GM_registerMenuCommand, _0x3e1db2['\x4b\x47\x79\x64\x53'], () => {
        StruggleProgress = 0x3 * 0xaf2 + -0xd * -0x233 + -0x4b0 * 0xd;
    }), GM_registerMenuCommand('\u63d0\u5347\u6346\u7ed1\u7b49\u7ea7', () => {
        const _0x2322f2 = _0x3f8630;
        SkillProgress(_0x3e1db2[_0x2322f2(0x181)], 0x8ac * -0x29 + 0x17123 + -0x109 * -0x1a3);
    }), _0x3e1db2[_0x3f8630(0x261)](GM_registerMenuCommand, _0x3e1db2[_0x3f8630(0x11a)], () => {
        const _0x392a6d = _0x3f8630;
        SkillProgress(_0x3e1db2[_0x392a6d(0x167)], 0x157a2 + -0xd1b8 + -0x18 * -0xd0f);
    }), _0x3e1db2[_0x3f8630(0x263)](GM_registerMenuCommand, _0x3e1db2[_0x3f8630(0x1af)], () => {
        SkillProgress(_0x3e1db2['\x4d\x44\x47\x6c\x68'], -0x267ba + 0x4bf2 + 0x3db1a);
    }), _0x3e1db2['\x74\x69\x6b\x57\x67'](GM_registerMenuCommand, _0x3f8630(0x2fd), () => {
        const _0x36de59 = _0x3f8630;
        _0x3e1db2[_0x36de59(0x21f)](_0x36de59(0x20d), _0x36de59(0x20d)) ? _0x3e1db2[_0x36de59(0x25e)](_0x52e820, _0x2bd9f4, _0x3e1db2[_0x36de59(0x266)], _0x3e1db2[_0x36de59(0xb2)]) : _0x3e1db2['\x57\x6b\x70\x76\x45'](SkillProgress, _0x3e1db2['\x64\x66\x42\x4c\x56'], 0x961 * 0x29 + -0x5 * 0x3d99 + -0x172c6 * -0x1);
    }), _0x3e1db2[_0x3f8630(0x1a2)](GM_registerMenuCommand, _0x3e1db2[_0x3f8630(0xe1)], () => {
        const _0xc3c6b2 = _0x3f8630;
        _0x3e1db2[_0xc3c6b2(0x234)](_0x3e1db2[_0xc3c6b2(0x14a)], _0x3e1db2[_0xc3c6b2(0x14a)]) ? _0x289343 = _0x3e1db2[_0xc3c6b2(0x319)](_0x3e1db2[_0xc3c6b2(0x307)](_0xc3c6b2(0x294), _0x4bfc7c), '\x20') + _0x30fd98 : Player[_0xc3c6b2(0x158)][_0xc3c6b2(0x10d)] = -0x17 * -0x6e + -0x21a8 + 0xbe3 * 0x2;
    }), _0x3e1db2[_0x3f8630(0x1c8)](GM_registerMenuCommand, _0x3f8630(0x2a9), () => {
        const _0x3d8b30 = _0x3f8630;
        _0x3e1db2['\x4e\x4a\x57\x44\x58'](SkillProgress, _0x3d8b30(0x28d), 0x10cdf + -0x182ca + 0x2353d);
    }), _0x3e1db2['\x4b\x4e\x58\x46\x76'](GM_registerMenuCommand, _0x3e1db2[_0x3f8630(0x2c4)], () => {
        const _0x1385f7 = _0x3f8630;
        _0x3e1db2[_0x1385f7(0xfc)](SkillProgress, _0x3e1db2[_0x1385f7(0x247)], 0x127eb + 0x146de + -0xaf77);
    }), _0x3e1db2[_0x3f8630(0x2e1)](GM_registerMenuCommand, _0x3e1db2[_0x3f8630(0x168)], () => {
        const _0x372d07 = _0x3f8630;
        _0x3e1db2[_0x372d07(0x111)](SkillProgress, _0x372d07(0x2d7), 0x266be + -0x1 * 0x153f0 + -0x1 * -0xac84);
    }), _0x3e1db2[_0x3f8630(0x217)](GM_registerMenuCommand, _0x3f8630(0x201), () => {
        const _0x16d6f0 = _0x3f8630, _0x3e26ef = _0x3e1db2['\x72\x4d\x57\x4b\x4e'][_0x16d6f0(0x108)]('\x7c');
        let _0x530ec5 = 0x7 * 0x47f + 0x1a21 + -0x399a;
        while (!![]) {
            switch (_0x3e26ef[_0x530ec5++]) {
            case '\x30':
                _0x3e1db2[_0x16d6f0(0x18c)](InventoryWear, Player, _0x3e1db2[_0x16d6f0(0x2a2)], _0x3e1db2['\x68\x68\x6a\x48\x74'], _0x3e1db2[_0x16d6f0(0x165)], 0x2c4 * -0x13c + -0x28f15 + 0x7b857);
                continue;
            case '\x31':
                _0x3e1db2[_0x16d6f0(0x30b)](InventoryWear, Player, _0x3e1db2[_0x16d6f0(0xca)], _0x3e1db2[_0x16d6f0(0x2d0)], _0x16d6f0(0x11e), -0xf0e1 * -0x3 + -0xb9b7 * -0x3 + -0x34076);
                continue;
            case '\x32':
                _0x3e1db2[_0x16d6f0(0x177)](InventoryWear, Player, _0x3e1db2[_0x16d6f0(0x354)], _0x3e1db2['\x78\x68\x74\x78\x56'], _0x3e1db2[_0x16d6f0(0x165)], 0x5cf * -0x89 + 0xb5cd + 0x4254c);
                continue;
            case '\x33':
                _0x3e1db2[_0x16d6f0(0x177)](InventoryWear, Player, _0x3e1db2[_0x16d6f0(0xc4)], _0x16d6f0(0x1f8), _0x3e1db2['\x4d\x74\x76\x55\x6b'], 0x1cf51 * 0x1 + 0x3f * -0x19e + 0x3 * 0x1ca1);
                continue;
            case '\x34':
                _0x3e1db2[_0x16d6f0(0x327)](InventoryWear, Player, _0x3e1db2[_0x16d6f0(0xfd)], _0x3e1db2['\x6b\x54\x75\x65\x58'], _0x16d6f0(0x11e), -0x4e * -0x32b + -0x1bb47 + 0x2837f);
                continue;
            case '\x35':
                InventoryWear(Player, _0x3e1db2[_0x16d6f0(0x29d)], _0x16d6f0(0x353), _0x3e1db2[_0x16d6f0(0x165)], 0xd7ba * -0x1 + -0x2e40 + 0x2c54c);
                continue;
            case '\x36':
                _0x3e1db2[_0x16d6f0(0x225)](InventoryWear, Player, _0x3e1db2['\x50\x4e\x75\x5a\x48'], _0x3e1db2[_0x16d6f0(0xc0)], _0x3e1db2[_0x16d6f0(0x165)], -0x14816 + 0x47f * 0xf + 0x2c3f7);
                continue;
            case '\x37':
                InventoryWear(Player, _0x3e1db2[_0x16d6f0(0x2e5)], _0x3e1db2[_0x16d6f0(0x232)], _0x3e1db2[_0x16d6f0(0x165)], -0x5d4 * 0x6a + 0x216d * -0xd + 0x5dba3);
                continue;
            case '\x38':
                _0x3e1db2[_0x16d6f0(0x160)](InventoryWear, Player, _0x3e1db2['\x6a\x77\x41\x6d\x51'], _0x3e1db2[_0x16d6f0(0x1ae)], _0x3e1db2[_0x16d6f0(0x165)], 0x336ff + 0x1f92b + -0x370d8);
                continue;
            }
            break;
        }
    }), _0x3e1db2[_0x3f8630(0x33f)](GM_registerMenuCommand, _0x3e1db2[_0x3f8630(0x368)], () => {
        InventoryWear(Player, _0x3e1db2['\x73\x6d\x43\x6d\x66'], _0x3e1db2['\x51\x51\x41\x66\x62']);
    }), _0x3e1db2['\x66\x46\x6d\x49\x69'](GM_registerMenuCommand, _0x3e1db2[_0x3f8630(0x299)], () => {
        const _0x22554a = _0x3f8630, _0x5e46ff = {};
        _0x5e46ff[_0x22554a(0x10a)] = _0x3e1db2[_0x22554a(0x1d8)];
        const _0x14bf25 = _0x5e46ff;
        _0x3e1db2[_0x22554a(0x2f1)](_0x3e1db2['\x45\x74\x66\x68\x7a'], _0x22554a(0x325)) ? (_0x42f46e(_0x14bf25[_0x22554a(0x10a)]), _0x386af0(_0x59e0d7, 0x22f7 * 0x1 + 0x36f * 0x4 + 0x53 * -0x95)) : !(Player[_0x22554a(0x1a6)] && Player[_0x22554a(0x1a6)][_0x22554a(0x220)] == _0x22554a(0x1ba)) && (_0x3e1db2['\x59\x64\x4f\x5a\x4c'] === _0x22554a(0x17b) ? (_0x291179['\x70\x75\x73\x68'](_0x5476fd[_0x22554a(0x220)]), _0x25901f = _0x3e1db2[_0x22554a(0xea)]) : _0x3e1db2['\x44\x4d\x59\x66\x65'](CharacterReleaseTotal, Player));
    }), _0x3e1db2[_0x3f8630(0x1ad)](GM_registerMenuCommand, _0x3e1db2[_0x3f8630(0xb9)], () => {
        const _0x300df5 = _0x3f8630;
        _0x300df5(0xef) !== _0x3e1db2[_0x300df5(0x11f)] ? ServerSend(_0x3e1db2[_0x300df5(0x276)], {
            '\x43\x6f\x6e\x74\x65\x6e\x74': '\x42\x65\x65\x70',
            '\x54\x79\x70\x65': '\x41\x63\x74\x69\x6f\x6e',
            '\x54\x61\x72\x67\x65\x74': null,
            '\x44\x69\x63\x74\x69\x6f\x6e\x61\x72\x79': [{
                    '\x54\x61\x67': _0x3e1db2[_0x300df5(0xbc)],
                    '\x54\x65\x78\x74': _0x3e1db2[_0x300df5(0x241)](prompt, _0x3e1db2[_0x300df5(0x202)], _0x3e1db2[_0x300df5(0x22a)])
                }]
        }) : _0xe54f84['\x50\x72\x6f\x70\x65\x72\x74\x79'] = {};
    }), _0x3e1db2[_0x3f8630(0x2e1)](GM_registerMenuCommand, _0x3f8630(0x350), () => {
        const _0x3b6b40 = _0x3f8630;
        if (_0x3e1db2[_0x3b6b40(0x2e2)] === _0x3b6b40(0x15a)) {
            const _0x48d30c = _0x3e1db2[_0x3b6b40(0x2b7)][_0x3b6b40(0x108)]('\x7c');
            let _0x24132a = 0x123a + 0x229c + -0x34d6;
            while (!![]) {
                switch (_0x48d30c[_0x24132a++]) {
                case '\x30':
                    _0x5d95b9 = null;
                    continue;
                case '\x31':
                    _0x3e1db2[_0x3b6b40(0xd6)](_0x364fe8, _0x3e1db2['\x79\x4f\x50\x67\x79'], '');
                    continue;
                case '\x32':
                    _0x3e1db2[_0x3b6b40(0x1f6)](_0x3197a4);
                    continue;
                case '\x33':
                    _0x3336bc = ![];
                    continue;
                case '\x34':
                    _0x3e1db2['\x73\x5a\x65\x57\x4e'](_0x47eaf6);
                    continue;
                case '\x35':
                    _0x3e1db2[_0x3b6b40(0x309)](_0x37896a);
                    continue;
                case '\x36':
                    _0x4c534d(_0x3e1db2[_0x3b6b40(0x1b5)], _0x3b6b40(0x206));
                    continue;
                case '\x37':
                    _0x3e1db2[_0x3b6b40(0x2bd)](_0x46b4f4, '');
                    continue;
                }
                break;
            }
        } else {
            targetName = _0x3e1db2[_0x3b6b40(0x233)](prompt, _0x3b6b40(0x29e), _0x3e1db2[_0x3b6b40(0x1ee)]), targetMember = Character[_0x3b6b40(0x185)](_0x5e1201 => _0x5e1201[_0x3b6b40(0x220)]['\x74\x6f\x4c\x6f\x77\x65\x72\x43\x61\x73\x65']() == targetName);
            if (_0x3e1db2[_0x3b6b40(0x129)](targetMember, null))
                return;
            _0x3e1db2[_0x3b6b40(0x13d)](CharacterReleaseTotal, targetMember), targetMember[_0x3b6b40(0x193)][_0x3b6b40(0xda)] = -0x379 + -0x67d * -0x3 + 0x59 * -0x2e, _0x3e1db2[_0x3b6b40(0x1c6)](ChatRoomCharacterUpdate, targetMember);
        }
    }), _0x3e1db2['\x55\x69\x64\x7a\x54'](GM_registerMenuCommand, _0x3e1db2[_0x3f8630(0x359)], () => {
        const _0x2babe6 = _0x3f8630, _0x12c1d6 = {
                '\x62\x47\x7a\x61\x78': _0x3e1db2[_0x2babe6(0xfd)],
                '\x4b\x43\x52\x41\x53': _0x3e1db2[_0x2babe6(0x1e8)],
                '\x51\x59\x77\x69\x41': function (_0x25df3f, _0x27c7de, _0x3e745d, _0xe7c79e, _0x8dcf96, _0x276119) {
                    const _0x3d4400 = _0x2babe6;
                    return _0x3e1db2[_0x3d4400(0x1ff)](_0x25df3f, _0x27c7de, _0x3e745d, _0xe7c79e, _0x8dcf96, _0x276119);
                },
                '\x6b\x48\x6e\x43\x61': _0x3e1db2[_0x2babe6(0x2a2)],
                '\x6c\x61\x51\x57\x43': _0x3e1db2[_0x2babe6(0x165)],
                '\x49\x43\x66\x6e\x53': function (_0x1e55bf, _0x362353, _0x3bea45, _0x255920, _0x214a6e, _0x12e253) {
                    return _0x1e55bf(_0x362353, _0x3bea45, _0x255920, _0x214a6e, _0x12e253);
                },
                '\x52\x53\x76\x66\x43': _0x3e1db2[_0x2babe6(0x232)],
                '\x47\x43\x61\x4d\x61': _0x3e1db2[_0x2babe6(0x354)],
                '\x52\x7a\x4c\x6f\x4c': _0x3e1db2[_0x2babe6(0x192)],
                '\x6e\x44\x4d\x42\x48': _0x3e1db2[_0x2babe6(0xca)],
                '\x53\x6a\x55\x56\x49': _0x3e1db2['\x4a\x46\x71\x77\x62'],
                '\x56\x53\x78\x4e\x63': _0x3e1db2['\x68\x6f\x42\x77\x73'],
                '\x7a\x45\x75\x65\x44': _0x3e1db2[_0x2babe6(0x22f)],
                '\x6b\x67\x45\x5a\x63': _0x3e1db2[_0x2babe6(0xc4)],
                '\x65\x49\x51\x55\x64': function (_0x46b2ee, _0x52a647, _0x2bf490, _0x4f9e41, _0x208287, _0x52f391) {
                    const _0x3b2a3f = _0x2babe6;
                    return _0x3e1db2[_0x3b2a3f(0x302)](_0x46b2ee, _0x52a647, _0x2bf490, _0x4f9e41, _0x208287, _0x52f391);
                },
                '\x6f\x47\x50\x66\x47': _0x3e1db2[_0x2babe6(0x27a)],
                '\x4b\x51\x78\x51\x53': _0x3e1db2[_0x2babe6(0x1ae)]
            };
        if (_0x3e1db2[_0x2babe6(0xcc)](_0x3e1db2[_0x2babe6(0xbe)], _0x3e1db2[_0x2babe6(0x360)])) {
            if (!(Player[_0x2babe6(0x1a6)] && _0x3e1db2[_0x2babe6(0xeb)](Player[_0x2babe6(0x1a6)]['\x4e\x61\x6d\x65'], _0x3e1db2[_0x2babe6(0x1ee)]))) {
                if (_0x3e1db2['\x4d\x63\x51\x79\x55'](_0x3e1db2[_0x2babe6(0x10c)], _0x2babe6(0x32c))) {
                    const _0xbb01f9 = '\x37\x7c\x30\x7c\x36\x7c\x33\x7c\x35\x7c\x38\x7c\x34\x7c\x31\x7c\x32'['\x73\x70\x6c\x69\x74']('\x7c');
                    let _0x32f053 = 0x24d7 + -0xdf8 + -0x16df;
                    while (!![]) {
                        switch (_0xbb01f9[_0x32f053++]) {
                        case '\x30':
                            _0x624494(_0x202e15, _0x12c1d6['\x62\x47\x7a\x61\x78'], _0x12c1d6['\x4b\x43\x52\x41\x53'], '\x23\x32\x30\x32\x30\x32\x30', -0x36755 + 0x4b99 * 0x6 + 0x36111);
                            continue;
                        case '\x31':
                            _0x12c1d6[_0x2babe6(0x23a)](_0x3dae21, _0x294968, _0x12c1d6[_0x2babe6(0x335)], _0x2babe6(0x308), _0x12c1d6['\x6c\x61\x51\x57\x43'], 0x348db + 0x1d65e + -0x35fe7);
                            continue;
                        case '\x32':
                            _0x12c1d6['\x49\x43\x66\x6e\x53'](_0x43880c, _0x2b1ece, _0x2babe6(0x32e), _0x12c1d6['\x52\x53\x76\x66\x43'], _0x2babe6(0x11e), 0x1421f + -0x1c51 * 0x12 + 0x27ae5);
                            continue;
                        case '\x33':
                            _0x52a6eb(_0x1e9e6f, '\x53\x74\x65\x65\x6c\x50\x6f\x73\x74\x75\x72\x65\x43\x6f\x6c\x6c\x61\x72', _0x2babe6(0x339), _0x2babe6(0x11e), -0x6539 + -0xe75f + -0x1 * -0x30bea);
                            continue;
                        case '\x34':
                            _0x12c1d6['\x51\x59\x77\x69\x41'](_0x484933, _0x60ee60, _0x12c1d6[_0x2babe6(0x270)], _0x12c1d6[_0x2babe6(0x2fa)], _0x12c1d6[_0x2babe6(0x21c)], -0x1 * 0x31bf1 + 0x1f75f + 0x171f2 * 0x2);
                            continue;
                        case '\x35':
                            _0x4da1c4(_0x5e3f2f, _0x12c1d6[_0x2babe6(0xcf)], _0x12c1d6[_0x2babe6(0xf8)], _0x12c1d6['\x6c\x61\x51\x57\x43'], -0x9 * 0x29cd + -0x1 * 0xad90 + -0xa5 * -0x60b);
                            continue;
                        case '\x36':
                            _0x2674b9(_0x29fde2, _0x12c1d6[_0x2babe6(0xb7)], _0x12c1d6[_0x2babe6(0x236)], _0x12c1d6[_0x2babe6(0x21c)], -0x1aff * -0x5 + -0x2ec43 + 0x4249a);
                            continue;
                        case '\x37':
                            _0x59c960(_0x54043b, _0x12c1d6['\x6b\x67\x45\x5a\x63'], _0x2babe6(0x1f8), _0x12c1d6[_0x2babe6(0x21c)], -0xf436 * 0x2 + 0x283e5 + 0x123d9);
                            continue;
                        case '\x38':
                            _0x12c1d6['\x65\x49\x51\x55\x64'](_0x5a2547, _0x49a536, _0x12c1d6['\x6f\x47\x50\x66\x47'], _0x12c1d6['\x4b\x51\x78\x51\x53'], _0x12c1d6[_0x2babe6(0x21c)], 0x1f0da + -0x2e88d + -0xb * -0x3f2f);
                            continue;
                        }
                        break;
                    }
                } else {
                    if (_0x3e1db2[_0x2babe6(0xd2)](Player[_0x2babe6(0x220)], _0x3e1db2[_0x2babe6(0x1ee)])) {
                        _0x3e1db2[_0x2babe6(0x250)](alert, _0x2babe6(0x32f));
                        return;
                    }
                }
            }
            targetName = _0x3e1db2[_0x2babe6(0x263)](prompt, _0x3e1db2[_0x2babe6(0x20b)], _0x3e1db2['\x5a\x64\x67\x4d\x73']), targetMember = Character[_0x2babe6(0x185)](_0x1979ec => _0x1979ec[_0x2babe6(0x220)]['\x74\x6f\x4c\x6f\x77\x65\x72\x43\x61\x73\x65']() == targetName);
            if (_0x3e1db2[_0x2babe6(0x1f1)](targetMember, null))
                return;
            _0x3e1db2[_0x2babe6(0x130)](InventoryWear, targetMember, _0x3e1db2[_0x2babe6(0x2a2)], _0x3e1db2[_0x2babe6(0x30e)], _0x2babe6(0x11e), -0x2a8ba * -0x1 + -0x20c63 + 0xb7 * 0x197), _0x3e1db2[_0x2babe6(0x18c)](InventoryWear, targetMember, _0x2babe6(0x358), _0x2babe6(0x1b8), _0x3e1db2['\x4d\x74\x76\x55\x6b'], 0x16450 + -0x2697f + 0x21bd * 0x15), targetMember[_0x2babe6(0x193)][_0x2babe6(0xda)] = -0x2d7 + -0x123 * -0x11 + -0x107c, _0x3e1db2[_0x2babe6(0x2be)](ChatRoomCharacterUpdate, targetMember);
        } else
            _0x2cbb83(_0x279325);
    }), _0x3e1db2[_0x3f8630(0x2c6)](GM_registerMenuCommand, _0x3e1db2[_0x3f8630(0x31a)], () => {
        const _0x123189 = _0x3f8630, _0x4d4a8d = {
                '\x63\x4e\x76\x79\x77': function (_0x256be8, _0x4cfc03, _0x89bf03) {
                    return _0x256be8(_0x4cfc03, _0x89bf03);
                },
                '\x67\x41\x6b\x7a\x64': function (_0x1d447b, _0x21c849) {
                    const _0x1fffe8 = _0x1c0d;
                    return _0x3e1db2[_0x1fffe8(0x22e)](_0x1d447b, _0x21c849);
                },
                '\x52\x4c\x53\x79\x59': _0x3e1db2[_0x123189(0x2ef)]
            };
        if (!(Player['\x4f\x77\x6e\x65\x72\x73\x68\x69\x70'] && _0x3e1db2[_0x123189(0x129)](Player[_0x123189(0x1a6)][_0x123189(0x220)], _0x123189(0x1ba)))) {
            if (_0x3e1db2[_0x123189(0x1e0)](_0x3e1db2['\x41\x64\x6f\x78\x46'], _0x3e1db2['\x41\x64\x6f\x78\x46']))
                _0x5ed451 = _0x3e1db2[_0x123189(0x2a7)](_0x597d24, _0x3e1db2[_0x123189(0xb5)], _0x3e1db2['\x5a\x64\x67\x4d\x73']), _0x300659 = _0x51f90a['\x69\x6e\x64\x65\x78\x4f\x66'](_0x4b8d0c), _0x3e1db2[_0x123189(0x113)](_0x40c78d, -(0xd91 + -0x1 * -0x6b6 + -0x1446)) && _0x3e1db2[_0x123189(0x28f)](_0x3d012b, _0x3e1db2[_0x123189(0x1e7)]), _0x5abab5['\x73\x70\x6c\x69\x63\x65'](_0x3bca66, -0x1 * 0x33b + 0x2f9 * -0xb + 0x23ef);
            else {
                if (_0x3e1db2[_0x123189(0x349)](Player[_0x123189(0x220)], _0x3e1db2[_0x123189(0x1ee)])) {
                    alert(_0x3e1db2[_0x123189(0x252)]);
                    return;
                }
            }
        }
        targetName = _0x3e1db2[_0x123189(0x249)](prompt, _0x3e1db2[_0x123189(0x1da)], _0x3e1db2[_0x123189(0x1ee)]), targetMember = Character[_0x123189(0x185)](_0xcf8e76 => _0xcf8e76[_0x123189(0x220)][_0x123189(0x14e)]() == targetName);
        if (targetMember == null)
            return;
        targetMember[_0x123189(0x2f3)]['\x66\x6f\x72\x45\x61\x63\x68'](_0x335fca => {
            const _0x3573b6 = _0x123189;
            let _0x35fe9c = -0x16a7 + 0x1d08 + -0x661;
            if (_0x3e1db2[_0x3573b6(0x188)](_0x335fca['\x44\x69\x66\x66\x69\x63\x75\x6c\x74\x79'], -0xb38 + -0x1 * -0x1c43 + 0x110b * -0x1)) {
                _0x3e1db2['\x46\x4d\x44\x59\x70'](_0x335fca['\x50\x72\x6f\x70\x65\x72\x74\x79'], null) && (_0x335fca[_0x3573b6(0x161)] = {});
                if (_0x3e1db2[_0x3573b6(0x2c8)](_0x335fca['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x3573b6(0x31c)], null)) {
                    if (_0x3e1db2['\x50\x5a\x64\x4f\x50'](_0x3e1db2['\x57\x47\x77\x5a\x66'], _0x3e1db2[_0x3573b6(0x310)]))
                        _0x335fca[_0x3573b6(0x161)][_0x3573b6(0x31c)] = [];
                    else
                        return !![];
                }
                if (_0x3e1db2[_0x3573b6(0x291)](_0x335fca[_0x3573b6(0x161)][_0x3573b6(0x31c)]['\x69\x6e\x64\x65\x78\x4f\x66'](_0x3573b6(0x2da)), 0x11fa * -0x2 + 0xedd + 0x1517)) {
                    if (_0x3e1db2[_0x3573b6(0x300)] === _0x3e1db2[_0x3573b6(0x300)])
                        _0x335fca[_0x3573b6(0x161)][_0x3573b6(0x31c)]['\x70\x75\x73\x68'](_0x3573b6(0x2da));
                    else {
                        let _0x6d515c = _0xcb6b2, _0x4d2365 = _0x4d4a8d[_0x3573b6(0x1d7)](_0x4ba329, _0x32b29a, _0x3cbe62);
                        return _0x4d2365 > -0x1348 + -0x1cf7 + 0x45 * 0xb3 && (_0x6d515c = _0x4d4a8d[_0x3573b6(0x323)](_0x4d4a8d[_0x3573b6(0x323)](_0x4d4a8d[_0x3573b6(0x323)](_0x4d4a8d[_0x3573b6(0x318)], _0x4d2365), '\x20'), _0x6d515c)), _0x6d515c;
                    }
                }
                _0x3e1db2[_0x3573b6(0x170)](Math['\x72\x61\x6e\x64\x6f\x6d'](), -0x215 * 0xb + 0x1f * 0x65 + 0xaac + 0.5) ? _0x3e1db2[_0x3573b6(0x169)](_0x3e1db2[_0x3573b6(0x10e)], _0x3e1db2[_0x3573b6(0x1d4)]) ? _0x335fca[_0x3573b6(0x161)][_0x3573b6(0x14b)] = _0x3e1db2[_0x3573b6(0x1ea)] : _0x4f930b[_0x3573b6(0x161)] = {} : _0x335fca[_0x3573b6(0x161)]['\x4c\x6f\x63\x6b\x65\x64\x42\x79'] = _0x3573b6(0x21e), _0x335fca[_0x3573b6(0x161)]['\x4c\x6f\x63\x6b\x4d\x65\x6d\x62\x65\x72\x4e\x75\x6d\x62\x65\x72'] = Player[_0x3573b6(0x257)], targetMember[_0x3573b6(0x2f3)][_0x35fe9c] = _0x335fca;
            }
            _0x35fe9c++;
        }), targetMember[_0x123189(0x193)][_0x123189(0xda)] = 0x347 * 0x2 + -0x1 * 0xd11 + 0x683, _0x3e1db2[_0x123189(0x34a)](ChatRoomCharacterUpdate, targetMember);
    }), _0x3e1db2[_0x3f8630(0x136)](GM_registerMenuCommand, _0x3f8630(0x22c), () => {
        const _0x50548f = _0x3f8630;
        _0x3e1db2['\x4b\x71\x53\x58\x6e'](ReputationChange, _0x3e1db2[_0x50548f(0x1fe)](prompt, _0x50548f(0x103), _0x3e1db2[_0x50548f(0x35c)]), 0x10df5 * 0x1 + 0x2a1be + -0x5fb * 0x53, !![]);
    });
}()));