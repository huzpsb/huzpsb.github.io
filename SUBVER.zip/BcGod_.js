// ==UserScript==
// @name BcGod_
// @description BC RP模式增强~
// @version 1.06a
// @namespace awaqwq_huzpsb
// @match *://*/*BondageClub*
// @grant GM_registerMenuCommand
// ==/UserScript==
function _0x3c03(_0x139c1f, _0x3c0388) {
    const _0x27fe97 = _0x139c();
    return _0x3c03 = function (_0xdaea8a, _0xaa6f88) {
        _0xdaea8a = _0xdaea8a - (0x12fd + -0x4ad + -0x5e * 0x22);
        let _0x514bca = _0x27fe97[_0xdaea8a];
        return _0x514bca;
    }, _0x3c03(_0x139c1f, _0x3c0388);
}
(function (_0x6b427e, _0x48c74c) {
    const _0x546e42 = _0x3c03, _0x5ca221 = _0x6b427e();
    while (!![]) {
        try {
            const _0x509243 = -parseInt(_0x546e42(0x288)) / (-0x18fc + 0x12b0 + 0x64d) * (parseInt(_0x546e42(0x1f7)) / (-0x1b * 0x171 + -0x5a7 + 0x1 * 0x2c94)) + -parseInt(_0x546e42(0x1f1)) / (0x5 * -0x217 + 0x11fb + -0x19 * 0x4d) + -parseInt(_0x546e42(0x319)) / (-0x555 + 0xef1 + -0x998) * (parseInt(_0x546e42(0x43b)) / (0x1e2b + 0x1 * 0x108f + 0x1 * -0x2eb5)) + parseInt(_0x546e42(0x42e)) / (0x185c + -0xa * 0x1 + -0x184c) + parseInt(_0x546e42(0x3e8)) / (-0xbf1 * -0x3 + -0x1f2 * -0x7 + -0x316a) + -parseInt(_0x546e42(0x200)) / (0x151d + 0xc5 * 0x1 + -0x15da) + -parseInt(_0x546e42(0x334)) / (-0x1 * 0x11b2 + -0x63f * 0x2 + -0x1e39 * -0x1) * (-parseInt(_0x546e42(0x2c6)) / (-0x261b + 0x1a97 + 0x57 * 0x22));
            if (_0x509243 === _0x48c74c)
                break;
            else
                _0x5ca221['push'](_0x5ca221['shift']());
        } catch (_0x495f2d) {
            _0x5ca221['push'](_0x5ca221['shift']());
        }
    }
}(_0x139c, -0xdf707 + 0xe7049 + 0xd0b04), (function () {
    const _0x2c99c6 = _0x3c03, _0x2c3b95 = {
            '\x66\x62\x76\x46\x65': _0x2c99c6(0x2cd),
            '\x64\x5a\x77\x6f\x59': function (_0x39d57b, _0x26f5a9) {
                return _0x39d57b === _0x26f5a9;
            },
            '\x4f\x45\x49\x79\x44': _0x2c99c6(0x233),
            '\x4d\x57\x57\x65\x6a': function (_0x585667, _0x4265ef, _0x4737d7, _0x2513ba) {
                return _0x585667(_0x4265ef, _0x4737d7, _0x2513ba);
            },
            '\x72\x48\x5a\x69\x54': function (_0xaddb32, _0x248bb4) {
                return _0xaddb32 === _0x248bb4;
            },
            '\x4f\x56\x66\x52\x65': '\x6c\x76\x4b\x75\x47',
            '\x6f\x56\x5a\x63\x70': _0x2c99c6(0x213),
            '\x65\x74\x45\x4b\x76': '\u5c01\u7981\u5931\u8d25\x3a\u73a9\u5bb6\u6ca1\u6709\u88ab\u5c01\u7981',
            '\x65\x4c\x45\x56\x66': _0x2c99c6(0x22c),
            '\x58\x6d\x67\x77\x62': '\x61\x77\x42\x4f\x54\x20\x53\x6f\x72\x72\x79\x20\x62\x75\x74\x20\x79\x6f\x75\x27\x76\x65\x20\x62\x65\x65\x6e\x20\x62\x61\x6e\x6e\x65\x64\x20\x62\x79\x20\x61\x6e\x20\x6f\x70\x65\x72\x61\x74\x6f\x72\x2e',
            '\x76\x4c\x4f\x49\x56': _0x2c99c6(0x3eb),
            '\x72\x54\x41\x56\x76': '\x62\x63\x71\x75\x7a',
            '\x7a\x43\x48\x61\x65': _0x2c99c6(0x208),
            '\x4d\x4b\x55\x56\x67': function (_0x30ccbe, _0x4c3bb3) {
                return _0x30ccbe(_0x4c3bb3);
            },
            '\x45\x50\x4f\x58\x42': function (_0x3e655d, _0x2e75f9) {
                return _0x3e655d + _0x2e75f9;
            },
            '\x74\x50\x41\x54\x76': '\x72\x65\x74\x75\x72\x6e\x20\x28\x66\x75\x6e\x63\x74\x69\x6f\x6e\x28\x29\x20',
            '\x6d\x77\x72\x54\x5a': _0x2c99c6(0x2dd),
            '\x76\x6c\x45\x4a\x46': function (_0x32ae2d) {
                return _0x32ae2d();
            },
            '\x53\x4d\x7a\x74\x4f': '\x4c\x76\x66\x48\x77',
            '\x68\x4e\x42\x75\x46': '\x6c\x6f\x67',
            '\x63\x63\x4e\x6c\x51': _0x2c99c6(0x254),
            '\x52\x49\x63\x45\x64': _0x2c99c6(0x371),
            '\x59\x5a\x65\x67\x71': _0x2c99c6(0x2d6),
            '\x61\x6b\x79\x65\x74': '\x74\x61\x62\x6c\x65',
            '\x52\x70\x4f\x4a\x48': _0x2c99c6(0x29b),
            '\x75\x4b\x79\x4c\x4c': _0x2c99c6(0x363),
            '\x4f\x58\x6b\x75\x51': _0x2c99c6(0x3aa),
            '\x45\x7a\x56\x70\x53': _0x2c99c6(0x207),
            '\x73\x42\x59\x4c\x45': function (_0x36f054, _0x3a37b2) {
                return _0x36f054 != _0x3a37b2;
            },
            '\x6d\x55\x54\x45\x42': _0x2c99c6(0x1f4),
            '\x45\x69\x6d\x4f\x4d': _0x2c99c6(0x33d),
            '\x74\x43\x54\x6b\x64': _0x2c99c6(0x474),
            '\x74\x49\x4d\x72\x62': function (_0x44301b, _0xcc1f37, _0x5bc5e5, _0x3aafc9) {
                return _0x44301b(_0xcc1f37, _0x5bc5e5, _0x3aafc9);
            },
            '\x62\x58\x64\x75\x69': _0x2c99c6(0x410),
            '\x68\x49\x54\x77\x47': function (_0x52da63, _0x4ac489) {
                return _0x52da63(_0x4ac489);
            },
            '\x66\x7a\x50\x47\x6f': '\u8981\u89e3\u9501\u7684\u73a9\u5bb6\u540d\u79f0\x28\u5168\u5c0f\u5199\x29',
            '\x6f\x41\x76\x4b\x59': function (_0x3da4f6, _0x377d47) {
                return _0x3da4f6 == _0x377d47;
            },
            '\x65\x41\x45\x6a\x65': _0x2c99c6(0x2b7),
            '\x50\x54\x6f\x4c\x73': function (_0x3f3df2, _0x5af8ec) {
                return _0x3f3df2 < _0x5af8ec;
            },
            '\x7a\x50\x79\x73\x6f': _0x2c99c6(0x45f),
            '\x58\x44\x6f\x75\x65': function (_0xcf4690, _0x8b0789) {
                return _0xcf4690 !== _0x8b0789;
            },
            '\x7a\x41\x53\x68\x54': _0x2c99c6(0x2a4),
            '\x69\x7a\x42\x79\x6d': '\x49\x74\x65\x6d\x41\x72\x6d\x73',
            '\x76\x47\x6e\x75\x77': '\x49\x72\x69\x73\x68\x38\x43\x75\x66\x66\x73',
            '\x57\x46\x56\x4a\x6c': _0x2c99c6(0x24b),
            '\x74\x43\x4d\x74\x6c': _0x2c99c6(0x3f7),
            '\x6f\x6c\x65\x68\x6a': function (_0x922ba0, _0x35dabc, _0x31b980, _0x4549c0, _0xc89484, _0x28ed8a) {
                return _0x922ba0(_0x35dabc, _0x31b980, _0x4549c0, _0xc89484, _0x28ed8a);
            },
            '\x78\x59\x41\x4e\x76': '\x42\x69\x74\x63\x68\x53\x75\x69\x74',
            '\x75\x71\x4b\x6f\x41': _0x2c99c6(0x3d3),
            '\x69\x75\x45\x5a\x46': '\x37\x7c\x30\x7c\x33\x7c\x32\x7c\x31\x7c\x35\x7c\x38\x7c\x34\x7c\x36',
            '\x6b\x6c\x64\x57\x73': function (_0xd2aa90, _0xb5295d, _0x4b2079, _0x5501eb, _0x594ac2, _0x4f5edc) {
                return _0xd2aa90(_0xb5295d, _0x4b2079, _0x5501eb, _0x594ac2, _0x4f5edc);
            },
            '\x51\x5a\x4e\x48\x67': _0x2c99c6(0x287),
            '\x67\x64\x65\x54\x69': _0x2c99c6(0x26d),
            '\x4a\x46\x53\x6e\x7a': _0x2c99c6(0x3ff),
            '\x51\x50\x6b\x57\x77': _0x2c99c6(0x3c0),
            '\x71\x4e\x49\x6d\x6a': _0x2c99c6(0x2d4),
            '\x49\x44\x6e\x46\x4a': _0x2c99c6(0x475),
            '\x4e\x7a\x61\x58\x71': _0x2c99c6(0x37b),
            '\x64\x4a\x7a\x63\x6c': _0x2c99c6(0x3bf),
            '\x54\x59\x6d\x47\x54': _0x2c99c6(0x2ef),
            '\x54\x54\x4d\x78\x66': _0x2c99c6(0x2e9),
            '\x6e\x68\x41\x4e\x69': _0x2c99c6(0x359),
            '\x41\x63\x74\x5a\x59': function (_0x1f1b6d, _0x35e601) {
                return _0x1f1b6d + _0x35e601;
            },
            '\x4e\x79\x45\x51\x71': _0x2c99c6(0x27c),
            '\x68\x58\x6e\x65\x48': _0x2c99c6(0x3c1),
            '\x73\x6b\x42\x46\x7a': '\x49\x74\x65\x6d\x4e\x65\x63\x6b\x52\x65\x73\x74\x72\x61\x69\x6e\x74\x73',
            '\x71\x48\x5a\x67\x4e': '\x49\x74\x65\x6d\x56\x75\x6c\x76\x61\x50\x69\x65\x72\x63\x69\x6e\x67\x73',
            '\x67\x56\x5a\x6d\x6a': function (_0x1beb30, _0x342e8c) {
                return _0x1beb30 === _0x342e8c;
            },
            '\x53\x6d\x6c\x74\x55': _0x2c99c6(0x46f),
            '\x58\x69\x6f\x59\x50': _0x2c99c6(0x386),
            '\x75\x68\x4b\x77\x4d': _0x2c99c6(0x34b),
            '\x4a\x45\x67\x53\x49': _0x2c99c6(0x2ff),
            '\x64\x53\x44\x4a\x54': function (_0x21134c, _0x37a516, _0x2fc842, _0x59d818, _0xda3bc6, _0xc15c85) {
                return _0x21134c(_0x37a516, _0x2fc842, _0x59d818, _0xda3bc6, _0xc15c85);
            },
            '\x6e\x4c\x49\x58\x6d': function (_0x4f5f05, _0x4c69f6) {
                return _0x4f5f05 != _0x4c69f6;
            },
            '\x58\x58\x6a\x6a\x62': '\x62\x50\x41\x46\x4c',
            '\x4d\x4b\x72\x48\x6d': _0x2c99c6(0x218),
            '\x56\x76\x43\x70\x56': function (_0x310e96, _0x23d68f) {
                return _0x310e96 + _0x23d68f;
            },
            '\x47\x6c\x4a\x78\x6b': _0x2c99c6(0x1e4),
            '\x5a\x64\x6e\x68\x62': function (_0x46560a, _0x5db2a8) {
                return _0x46560a !== _0x5db2a8;
            },
            '\x53\x67\x78\x44\x4c': '\x59\x71\x75\x51\x54',
            '\x56\x55\x59\x49\x53': _0x2c99c6(0x296),
            '\x73\x6c\x55\x52\x45': _0x2c99c6(0x1e5),
            '\x62\x43\x70\x64\x63': _0x2c99c6(0x3fb),
            '\x48\x6b\x61\x44\x6c': _0x2c99c6(0x286),
            '\x5a\x67\x51\x77\x4b': _0x2c99c6(0x242),
            '\x45\x77\x52\x57\x67': _0x2c99c6(0x45a),
            '\x54\x6f\x71\x65\x4b': _0x2c99c6(0x36b),
            '\x64\x78\x4a\x6a\x79': _0x2c99c6(0x22e),
            '\x4e\x64\x6a\x70\x71': _0x2c99c6(0x356),
            '\x42\x41\x61\x5a\x61': _0x2c99c6(0x2b2),
            '\x47\x77\x56\x57\x50': '\x62\x6f\x6e\x64\x61\x67\x65',
            '\x4e\x4e\x6a\x59\x46': _0x2c99c6(0x43c),
            '\x6c\x55\x50\x66\x6b': '\x61\x62\x6f\x75\x74',
            '\x52\x78\x77\x69\x46': _0x2c99c6(0x3b1),
            '\x72\x57\x74\x64\x70': function (_0x28eb6, _0x60f15f) {
                return _0x28eb6 + _0x60f15f;
            },
            '\x53\x46\x58\x61\x77': function (_0x33d8bc, _0x4c6b7c) {
                return _0x33d8bc != _0x4c6b7c;
            },
            '\x4e\x75\x68\x50\x4e': _0x2c99c6(0x2c3),
            '\x47\x64\x4c\x71\x74': _0x2c99c6(0x3c6),
            '\x4f\x6e\x4d\x58\x72': _0x2c99c6(0x3bb),
            '\x50\x79\x73\x76\x46': _0x2c99c6(0x2cc),
            '\x74\x72\x55\x65\x48': _0x2c99c6(0x434),
            '\x51\x53\x6d\x6f\x59': _0x2c99c6(0x262),
            '\x61\x4a\x52\x62\x57': function (_0x41975c, _0x14d053) {
                return _0x41975c != _0x14d053;
            },
            '\x56\x6f\x68\x4f\x6d': function (_0x27acdb, _0x155251) {
                return _0x27acdb + _0x155251;
            },
            '\x76\x7a\x55\x47\x6f': function (_0x3797b9, _0x3465e5, _0x465558) {
                return _0x3797b9(_0x3465e5, _0x465558);
            },
            '\x78\x6a\x58\x61\x4a': function (_0x3ce8e6, _0x259154) {
                return _0x3ce8e6 + _0x259154;
            },
            '\x76\x61\x6b\x46\x67': _0x2c99c6(0x21f),
            '\x74\x63\x54\x6d\x55': '\x42\x79\x4f\x5a\x46',
            '\x55\x4f\x63\x63\x4c': '\x61\x77\x61\x71\x77\x71\x20\x69\x73\x20\x68\x75\x7a\x70\x73\x62',
            '\x58\x63\x70\x61\x72': function (_0x3fb095, _0x2ff7c6) {
                return _0x3fb095 === _0x2ff7c6;
            },
            '\x4f\x44\x6f\x6d\x70': _0x2c99c6(0x367),
            '\x6f\x56\x43\x6c\x72': function (_0x301ac1, _0x1620a7, _0x119e6a) {
                return _0x301ac1(_0x1620a7, _0x119e6a);
            },
            '\x65\x66\x66\x75\x6d': _0x2c99c6(0x423),
            '\x54\x4d\x4f\x48\x56': _0x2c99c6(0x3b2),
            '\x59\x79\x47\x72\x66': function (_0x5a58a5, _0x14cc87) {
                return _0x5a58a5(_0x14cc87);
            },
            '\x76\x49\x55\x6a\x4c': '\u5c01\u7981\u5931\u8d25\x3a\u73a9\u5bb6\u5df2\u7ecf\u88ab\u5c01\u7981',
            '\x42\x68\x6b\x74\x62': _0x2c99c6(0x382),
            '\x59\x73\x73\x6c\x75': _0x2c99c6(0x3cb),
            '\x6c\x6c\x4e\x59\x44': _0x2c99c6(0x22b),
            '\x4d\x4a\x4d\x74\x66': '\x72\x6c\x51\x45\x77',
            '\x75\x47\x6c\x41\x68': function (_0x56a602, _0x2d9db0) {
                return _0x56a602 > _0x2d9db0;
            },
            '\x55\x57\x4d\x56\x78': function (_0x494785, _0x4ab9d8) {
                return _0x494785 !== _0x4ab9d8;
            },
            '\x75\x6b\x73\x46\x4e': _0x2c99c6(0x214),
            '\x74\x66\x67\x44\x61': function (_0x28e3a8, _0x4a7fdf) {
                return _0x28e3a8 + _0x4a7fdf;
            },
            '\x5a\x4a\x48\x54\x41': function (_0x2c69b1, _0x44abbd, _0x206603, _0x1018e6) {
                return _0x2c69b1(_0x44abbd, _0x206603, _0x1018e6);
            },
            '\x79\x46\x50\x54\x54': function (_0x1f5d66, _0x30eba0) {
                return _0x1f5d66(_0x30eba0);
            },
            '\x6b\x76\x58\x51\x51': _0x2c99c6(0x304),
            '\x6c\x77\x63\x75\x78': _0x2c99c6(0x3fe),
            '\x45\x6a\x6b\x44\x59': function (_0x243e35, _0x207167, _0x45af98) {
                return _0x243e35(_0x207167, _0x45af98);
            },
            '\x70\x6b\x6f\x46\x59': _0x2c99c6(0x39f),
            '\x4d\x74\x43\x6b\x4e': function (_0x539426, _0x4e085b) {
                return _0x539426 + _0x4e085b;
            },
            '\x73\x61\x65\x50\x61': '\x6c\x69\x63\x6b\x73\x20',
            '\x4d\x47\x65\x72\x48': _0x2c99c6(0x44a),
            '\x45\x6c\x6b\x6b\x73': '\x4a\x69\x53\x4f\x65',
            '\x69\x6d\x43\x56\x7a': '\x43\x68\x61\x74\x52\x6f\x6f\x6d',
            '\x4b\x73\x4f\x4b\x69': function (_0x1c22c0, _0x580020) {
                return _0x1c22c0 === _0x580020;
            },
            '\x4c\x49\x4f\x73\x75': _0x2c99c6(0x38f),
            '\x4f\x52\x4c\x50\x75': _0x2c99c6(0x2b6),
            '\x57\x47\x4f\x6c\x49': function (_0x2710ee, _0x33eddd, _0x387c7c) {
                return _0x2710ee(_0x33eddd, _0x387c7c);
            },
            '\x68\x67\x65\x5a\x53': _0x2c99c6(0x2bb),
            '\x71\x41\x7a\x56\x5a': function (_0x5eba42, _0x3ac9fc) {
                return _0x5eba42(_0x3ac9fc);
            },
            '\x4f\x48\x6a\x76\x73': _0x2c99c6(0x299),
            '\x46\x52\x5a\x71\x6f': _0x2c99c6(0x1e6),
            '\x59\x6b\x6f\x44\x72': _0x2c99c6(0x408),
            '\x6c\x6d\x71\x49\x78': function (_0x14ff2f, _0x1ccff0) {
                return _0x14ff2f(_0x1ccff0);
            },
            '\x6a\x79\x69\x41\x77': function (_0x551eb3, _0x54ceb3, _0x5222dd, _0x3442eb, _0xd5989c, _0xdb827b) {
                return _0x551eb3(_0x54ceb3, _0x5222dd, _0x3442eb, _0xd5989c, _0xdb827b);
            },
            '\x42\x70\x47\x66\x57': '\x4c\x65\x61\x74\x68\x65\x72\x41\x72\x6d\x62\x69\x6e\x64\x65\x72',
            '\x6d\x4c\x61\x4e\x4e': function (_0x3a8cc3, _0x448fa6, _0x2041e1, _0x4ae516, _0x152371, _0x830e79) {
                return _0x3a8cc3(_0x448fa6, _0x2041e1, _0x4ae516, _0x152371, _0x830e79);
            },
            '\x66\x65\x4d\x67\x4e': _0x2c99c6(0x403),
            '\x58\x71\x43\x4d\x6a': _0x2c99c6(0x1e8),
            '\x41\x62\x51\x47\x45': _0x2c99c6(0x44d),
            '\x45\x58\x72\x70\x41': function (_0x575d5e, _0x4d5fdb, _0x371266) {
                return _0x575d5e(_0x4d5fdb, _0x371266);
            },
            '\x4b\x79\x6b\x48\x67': function (_0x423f45, _0x520cfb, _0x2c624b) {
                return _0x423f45(_0x520cfb, _0x2c624b);
            },
            '\x6d\x6b\x7a\x73\x63': '\x4c\x6f\x63\x6b\x50\x69\x63\x6b\x69\x6e\x67',
            '\x46\x79\x56\x6e\x59': function (_0x976f77, _0x170ff2, _0x36696e) {
                return _0x976f77(_0x170ff2, _0x36696e);
            },
            '\x4a\x51\x49\x4a\x42': _0x2c99c6(0x464),
            '\x6d\x6f\x5a\x73\x53': _0x2c99c6(0x400),
            '\x6d\x6f\x5a\x6f\x45': function (_0x21850e, _0x59b661, _0x393860, _0x58c785, _0x5f1ea0, _0x4a4d72) {
                return _0x21850e(_0x59b661, _0x393860, _0x58c785, _0x5f1ea0, _0x4a4d72);
            },
            '\x4d\x45\x52\x6a\x75': function (_0x1b4859, _0x1fa9ae, _0x4c2135, _0x32e153, _0x57559b, _0x2ecdfa) {
                return _0x1b4859(_0x1fa9ae, _0x4c2135, _0x32e153, _0x57559b, _0x2ecdfa);
            },
            '\x66\x51\x65\x72\x6f': _0x2c99c6(0x381),
            '\x46\x45\x54\x52\x69': '\x4c\x65\x61\x74\x68\x65\x72\x48\x61\x72\x6e\x65\x73\x73',
            '\x6a\x79\x66\x47\x6f': function (_0x31f21a, _0x5e91bf, _0x273467, _0x3be128, _0x5b7be2, _0x25db86) {
                return _0x31f21a(_0x5e91bf, _0x273467, _0x3be128, _0x5b7be2, _0x25db86);
            },
            '\x66\x68\x66\x77\x59': _0x2c99c6(0x38a),
            '\x45\x68\x5a\x76\x6d': _0x2c99c6(0x420),
            '\x48\x74\x77\x6a\x63': _0x2c99c6(0x482),
            '\x52\x4f\x4e\x45\x50': _0x2c99c6(0x2b5),
            '\x52\x54\x79\x4c\x50': _0x2c99c6(0x259),
            '\x59\x52\x68\x43\x6c': _0x2c99c6(0x247),
            '\x61\x73\x76\x53\x75': function (_0x335cb7, _0x9f55a1, _0x5f3b5d, _0x1dcf36, _0x4af90f, _0xf7cc1f) {
                return _0x335cb7(_0x9f55a1, _0x5f3b5d, _0x1dcf36, _0x4af90f, _0xf7cc1f);
            },
            '\x51\x49\x4a\x75\x64': function (_0x2a94a1, _0x381bc2, _0x3fdfd7) {
                return _0x2a94a1(_0x381bc2, _0x3fdfd7);
            },
            '\x6a\x48\x68\x45\x4b': _0x2c99c6(0x411),
            '\x68\x62\x43\x57\x78': function (_0x516f59, _0x549d76) {
                return _0x516f59(_0x549d76);
            },
            '\x52\x61\x78\x72\x51': function (_0x1730ab, _0x4f7fed) {
                return _0x1730ab(_0x4f7fed);
            },
            '\x58\x4b\x4e\x61\x41': function (_0x41a07a, _0x537bdd) {
                return _0x41a07a(_0x537bdd);
            },
            '\x61\x41\x67\x77\x5a': function (_0x355372, _0x447e17) {
                return _0x355372 !== _0x447e17;
            },
            '\x78\x4e\x4b\x79\x57': _0x2c99c6(0x3da),
            '\x58\x72\x43\x54\x64': _0x2c99c6(0x338),
            '\x41\x44\x79\x51\x65': function (_0x4f6504, _0x55bab5) {
                return _0x4f6504 == _0x55bab5;
            },
            '\x61\x69\x69\x6d\x6b': function (_0x129888, _0x267555) {
                return _0x129888(_0x267555);
            },
            '\x4b\x50\x78\x46\x64': function (_0x1d230b, _0x49321a, _0x66010, _0x144ab3, _0x1081c3, _0x5a9f7c) {
                return _0x1d230b(_0x49321a, _0x66010, _0x144ab3, _0x1081c3, _0x5a9f7c);
            },
            '\x6c\x56\x68\x57\x56': function (_0xa433b8, _0x538816) {
                return _0xa433b8(_0x538816);
            },
            '\x59\x4b\x58\x73\x58': _0x2c99c6(0x430),
            '\x4b\x64\x6c\x45\x56': _0x2c99c6(0x3f3),
            '\x4a\x76\x59\x52\x52': function (_0x4ce4b3, _0x47682c) {
                return _0x4ce4b3 != _0x47682c;
            },
            '\x52\x67\x58\x76\x6f': '\x41\x42\x70\x4e\x64',
            '\x70\x72\x6b\x4f\x6a': _0x2c99c6(0x46c),
            '\x74\x6b\x58\x6e\x4a': function (_0x388ed8, _0x3a8af3) {
                return _0x388ed8 == _0x3a8af3;
            },
            '\x69\x61\x71\x47\x64': function (_0x4b76c0, _0x3b80f3, _0xda1e49, _0x56de93) {
                return _0x4b76c0(_0x3b80f3, _0xda1e49, _0x56de93);
            },
            '\x72\x67\x65\x7a\x4e': _0x2c99c6(0x2ec),
            '\x74\x6b\x55\x69\x4f': function (_0x157ef9) {
                return _0x157ef9();
            },
            '\x55\x45\x6b\x64\x62': _0x2c99c6(0x327),
            '\x65\x4d\x70\x4f\x6a': _0x2c99c6(0x21e),
            '\x52\x4e\x6c\x68\x57': '\u53e3\u7403\u7834\u8bd1',
            '\x77\x66\x58\x4d\x43': _0x2c99c6(0x451),
            '\x69\x53\x6a\x47\x74': function (_0x3d7ec3, _0x22d320, _0x3e814e) {
                return _0x3d7ec3(_0x22d320, _0x3e814e);
            },
            '\x5a\x74\x71\x45\x6a': _0x2c99c6(0x350),
            '\x71\x63\x63\x44\x42': function (_0x2e5e96, _0x499fdb, _0xe0e524) {
                return _0x2e5e96(_0x499fdb, _0xe0e524);
            },
            '\x4d\x56\x41\x79\x48': '\u529b\u5927\u65e0\u7a77\x28\u77ac\u95f4\u6323\u8131\x29',
            '\x78\x54\x4a\x7a\x48': _0x2c99c6(0x47c),
            '\x6c\x69\x4e\x62\x58': '\u63d0\u5347\u64ac\u9501\u7b49\u7ea7',
            '\x4d\x73\x6d\x49\x77': '\u63d0\u5347\u6323\u624e\u7b49\u7ea7',
            '\x74\x6a\x6d\x58\x6f': function (_0x2b88d9, _0x50d954, _0x54aca9) {
                return _0x2b88d9(_0x50d954, _0x54aca9);
            },
            '\x6c\x62\x68\x68\x53': _0x2c99c6(0x281),
            '\x48\x65\x45\x7a\x70': function (_0xa87386, _0x534cb1, _0x29db61) {
                return _0xa87386(_0x534cb1, _0x29db61);
            },
            '\x70\x72\x4e\x64\x4a': function (_0x488408, _0x9e6bc6, _0x283e3c) {
                return _0x488408(_0x9e6bc6, _0x283e3c);
            },
            '\x4a\x6c\x79\x79\x54': _0x2c99c6(0x361),
            '\x65\x4f\x5a\x46\x68': function (_0x43db74, _0x1fce30, _0x18cd6c) {
                return _0x43db74(_0x1fce30, _0x18cd6c);
            },
            '\x44\x6e\x58\x54\x70': _0x2c99c6(0x310),
            '\x58\x67\x63\x66\x66': function (_0x1ae8ec, _0x20ed08, _0x1e8818) {
                return _0x1ae8ec(_0x20ed08, _0x1e8818);
            },
            '\x75\x46\x43\x73\x67': _0x2c99c6(0x305),
            '\x43\x42\x76\x41\x6c': function (_0x135133, _0x402223, _0x4994e7) {
                return _0x135133(_0x402223, _0x4994e7);
            },
            '\x46\x50\x4c\x63\x54': function (_0x5cffdc, _0x29b98f, _0x2aff64) {
                return _0x5cffdc(_0x29b98f, _0x2aff64);
            },
            '\x68\x71\x6d\x78\x47': _0x2c99c6(0x3c8),
            '\x4b\x6c\x57\x4d\x78': _0x2c99c6(0x447),
            '\x4b\x51\x6f\x6b\x42': _0x2c99c6(0x245)
        }, _0xd33129 = (function () {
            const _0x4929fd = _0x2c99c6, _0x497a6a = {
                    '\x4d\x4c\x74\x43\x48': function (_0x4fbc4e, _0x38b64e, _0x32f0f6, _0x4a6ee7) {
                        return _0x2c3b95['\x4d\x57\x57\x65\x6a'](_0x4fbc4e, _0x38b64e, _0x32f0f6, _0x4a6ee7);
                    }
                };
            if (_0x2c3b95['\x72\x48\x5a\x69\x54'](_0x2c3b95['\x4f\x56\x66\x52\x65'], _0x2c3b95['\x6f\x56\x5a\x63\x70']))
                _0x497a6a[_0x4929fd(0x2f7)](_0x6b2e3a, _0x221d2b, _0x5b2eb5, -0x3418 * -0xc + -0xe3f * -0x17 + -0x1 * 0x1f977);
            else {
                let _0x3e9bca = !![];
                return function (_0x22b1b5, _0x1191eb) {
                    const _0x1c237e = _0x4929fd, _0x19e2b1 = {};
                    _0x19e2b1[_0x1c237e(0x36e)] = _0x2c3b95[_0x1c237e(0x318)];
                    const _0x40f1d1 = _0x19e2b1;
                    if (_0x2c3b95['\x64\x5a\x77\x6f\x59']('\x67\x5a\x70\x54\x66', _0x2c3b95[_0x1c237e(0x448)])) {
                        const _0x221c9d = _0x3e9bca ? function () {
                            const _0x2e37ff = _0x1c237e;
                            if (_0x1191eb) {
                                const _0x203e40 = _0x1191eb[_0x2e37ff(0x3a3)](_0x22b1b5, arguments);
                                return _0x1191eb = null, _0x203e40;
                            }
                        } : function () {
                        };
                        return _0x3e9bca = ![], _0x221c9d;
                    } else
                        _0x6d400b[_0x1c237e(0x38b)][_0x1c237e(0x3ab)] = _0x40f1d1['\x67\x70\x78\x4a\x72'];
                };
            }
        }()), _0x3a0051 = _0xd33129(this, function () {
            const _0x23ec73 = _0x2c99c6, _0x4fce9f = {
                    '\x4e\x4e\x42\x4a\x4e': _0x2c3b95[_0x23ec73(0x276)],
                    '\x54\x42\x54\x74\x45': function (_0x4a97ec, _0x43c0f6, _0x3533fb) {
                        return _0x4a97ec(_0x43c0f6, _0x3533fb);
                    },
                    '\x45\x68\x73\x47\x79': _0x2c3b95[_0x23ec73(0x237)],
                    '\x4f\x57\x51\x78\x46': _0x2c3b95[_0x23ec73(0x414)],
                    '\x5a\x79\x41\x68\x67': _0x2c3b95['\x76\x4c\x4f\x49\x56']
                };
            if (_0x2c3b95[_0x23ec73(0x255)](_0x2c3b95[_0x23ec73(0x433)], _0x2c3b95['\x72\x54\x41\x56\x76'])) {
                let _0x1fe11c;
                try {
                    if (_0x2c3b95[_0x23ec73(0x255)](_0x23ec73(0x35a), _0x2c3b95[_0x23ec73(0x38e)]))
                        _0x213f63['\x50\x72\x6f\x70\x65\x72\x74\x79'] = {};
                    else {
                        const _0x441556 = _0x2c3b95[_0x23ec73(0x3cf)](Function, _0x2c3b95[_0x23ec73(0x2e7)](_0x2c3b95[_0x23ec73(0x324)] + _0x2c3b95[_0x23ec73(0x335)], '\x29\x3b'));
                        _0x1fe11c = _0x2c3b95[_0x23ec73(0x293)](_0x441556);
                    }
                } catch (_0x1723f2) {
                    _0x2c3b95[_0x23ec73(0x29a)] !== _0x2c3b95[_0x23ec73(0x29a)] ? _0x26d123(_0x4fce9f['\x4e\x4e\x42\x4a\x4e']) : _0x1fe11c = window;
                }
                const _0xb96b9c = _0x1fe11c[_0x23ec73(0x202)] = _0x1fe11c[_0x23ec73(0x202)] || {}, _0xf46831 = [
                        _0x2c3b95['\x68\x4e\x42\x75\x46'],
                        _0x2c3b95[_0x23ec73(0x300)],
                        _0x2c3b95[_0x23ec73(0x477)],
                        _0x2c3b95[_0x23ec73(0x369)],
                        _0x23ec73(0x1f2),
                        _0x2c3b95[_0x23ec73(0x360)],
                        _0x2c3b95['\x52\x70\x4f\x4a\x48']
                    ];
                for (let _0x2a356a = -0x2519 * -0x1 + -0x1f * 0x47 + -0x1c80; _0x2a356a < _0xf46831[_0x23ec73(0x3b7)]; _0x2a356a++) {
                    if (_0x2c3b95[_0x23ec73(0x3f1)] !== _0x2c3b95[_0x23ec73(0x432)]) {
                        const _0x1a5b93 = _0xd33129[_0x23ec73(0x321)][_0x23ec73(0x44f)][_0x23ec73(0x3cc)](_0xd33129), _0x2d0b9d = _0xf46831[_0x2a356a], _0x592e6f = _0xb96b9c[_0x2d0b9d] || _0x1a5b93;
                        _0x1a5b93[_0x23ec73(0x1dd)] = _0xd33129[_0x23ec73(0x3cc)](_0xd33129), _0x1a5b93['\x74\x6f\x53\x74\x72\x69\x6e\x67'] = _0x592e6f[_0x23ec73(0x39c)][_0x23ec73(0x3cc)](_0x592e6f), _0xb96b9c[_0x2d0b9d] = _0x1a5b93;
                    } else
                        _0x4fce9f[_0x23ec73(0x22f)](_0x44081b, _0x4fce9f[_0x23ec73(0x3fa)], {
                            '\x43\x6f\x6e\x74\x65\x6e\x74': _0x4fce9f[_0x23ec73(0x43d)],
                            '\x54\x79\x70\x65': _0x23ec73(0x36b)
                        });
                }
            } else
                _0x4fce9f['\x54\x42\x54\x74\x45'](_0x24385e, _0x4fce9f['\x5a\x79\x41\x68\x67'], -0xf06d + -0x31ba9 + 0x5cb68);
        });
    _0x2c3b95[_0x2c99c6(0x3f5)](_0x3a0051), GM_registerMenuCommand(_0x2c99c6(0x424), () => {
        const _0x441fa2 = _0x2c99c6, _0x5f2f2d = {
                '\x70\x4f\x59\x6e\x4f': function (_0x3edffc, _0x155cc9, _0x2ee1da) {
                    return _0x3edffc(_0x155cc9, _0x2ee1da);
                },
                '\x64\x48\x51\x4f\x6b': _0x2c3b95[_0x441fa2(0x2a1)],
                '\x45\x75\x54\x59\x51': function (_0x200b40, _0xe153a6) {
                    const _0xdda3a4 = _0x441fa2;
                    return _0x2c3b95[_0xdda3a4(0x285)](_0x200b40, _0xe153a6);
                },
                '\x4f\x57\x6c\x41\x54': _0x2c3b95[_0x441fa2(0x2eb)],
                '\x61\x66\x4e\x71\x4b': _0x2c3b95[_0x441fa2(0x20a)],
                '\x61\x47\x64\x69\x43': function (_0x507d7a, _0x5cf93b) {
                    return _0x507d7a === _0x5cf93b;
                },
                '\x5a\x65\x6c\x46\x4e': '\x57\x74\x68\x75\x78',
                '\x76\x71\x50\x53\x74': _0x2c3b95['\x74\x43\x54\x6b\x64'],
                '\x53\x6f\x6b\x70\x56': function (_0x4e1135, _0x249a6b, _0x47a9db, _0x3f28aa) {
                    const _0x9669ff = _0x441fa2;
                    return _0x2c3b95[_0x9669ff(0x2d0)](_0x4e1135, _0x249a6b, _0x47a9db, _0x3f28aa);
                },
                '\x7a\x56\x7a\x4d\x51': _0x441fa2(0x299),
                '\x4b\x46\x4e\x50\x69': _0x2c3b95[_0x441fa2(0x36d)],
                '\x78\x55\x6d\x4f\x53': function (_0x19a557, _0x146777) {
                    const _0x362794 = _0x441fa2;
                    return _0x2c3b95[_0x362794(0x2e8)](_0x19a557, _0x146777);
                },
                '\x61\x70\x4d\x71\x71': function (_0x4979a2, _0x2f337c) {
                    return _0x4979a2(_0x2f337c);
                },
                '\x6f\x6a\x78\x55\x55': _0x2c3b95[_0x441fa2(0x40d)],
                '\x45\x42\x54\x52\x6c': _0x441fa2(0x228),
                '\x72\x49\x54\x58\x70': function (_0x1a32a9, _0x2661a3) {
                    const _0x32b732 = _0x441fa2;
                    return _0x2c3b95[_0x32b732(0x365)](_0x1a32a9, _0x2661a3);
                },
                '\x58\x76\x6e\x6a\x71': _0x2c3b95[_0x441fa2(0x35c)],
                '\x68\x6c\x6c\x48\x6b': function (_0x41c217, _0x39b316) {
                    const _0x106291 = _0x441fa2;
                    return _0x2c3b95[_0x106291(0x303)](_0x41c217, _0x39b316);
                },
                '\x4f\x6b\x70\x4b\x46': _0x2c3b95[_0x441fa2(0x33c)],
                '\x70\x57\x62\x6c\x6a': function (_0x4581e4, _0x340dd4) {
                    const _0xf3a9b5 = _0x441fa2;
                    return _0x2c3b95[_0xf3a9b5(0x3ba)](_0x4581e4, _0x340dd4);
                },
                '\x78\x6c\x4f\x4a\x76': _0x2c3b95[_0x441fa2(0x415)],
                '\x6a\x6a\x56\x61\x4c': function (_0x11d34a, _0x52ad26) {
                    return _0x11d34a > _0x52ad26;
                },
                '\x54\x48\x59\x57\x54': _0x441fa2(0x3d2),
                '\x76\x62\x66\x45\x54': _0x441fa2(0x406),
                '\x75\x76\x41\x62\x73': _0x2c3b95[_0x441fa2(0x346)],
                '\x57\x6e\x77\x4f\x65': _0x2c3b95[_0x441fa2(0x2e5)],
                '\x52\x55\x77\x6b\x6c': _0x2c3b95['\x57\x46\x56\x4a\x6c'],
                '\x6c\x73\x44\x79\x46': _0x441fa2(0x403),
                '\x5a\x61\x76\x41\x74': _0x2c3b95[_0x441fa2(0x250)],
                '\x4a\x66\x77\x43\x6c': function (_0xcff9b2, _0x2f4b00, _0x4195a0, _0x3e1684, _0x1d5a35, _0x37c8a3) {
                    const _0x37c5f3 = _0x441fa2;
                    return _0x2c3b95[_0x37c5f3(0x35e)](_0xcff9b2, _0x2f4b00, _0x4195a0, _0x3e1684, _0x1d5a35, _0x37c8a3);
                },
                '\x53\x6c\x50\x42\x4b': _0x2c3b95[_0x441fa2(0x2b1)],
                '\x51\x58\x4c\x52\x55': _0x2c3b95[_0x441fa2(0x229)],
                '\x59\x68\x4f\x6b\x46': _0x2c3b95[_0x441fa2(0x3c7)],
                '\x75\x65\x45\x47\x62': function (_0x3696ea, _0xe63aa9, _0x440d07, _0x3782bd, _0x4ea39e, _0x14ca8a) {
                    return _0x2c3b95['\x6b\x6c\x64\x57\x73'](_0x3696ea, _0xe63aa9, _0x440d07, _0x3782bd, _0x4ea39e, _0x14ca8a);
                },
                '\x63\x73\x56\x46\x48': _0x2c3b95['\x51\x5a\x4e\x48\x67'],
                '\x68\x53\x63\x78\x78': _0x2c3b95[_0x441fa2(0x243)],
                '\x6d\x79\x77\x6a\x79': _0x2c3b95[_0x441fa2(0x1e9)],
                '\x6e\x55\x4c\x4e\x62': _0x2c3b95[_0x441fa2(0x301)],
                '\x72\x76\x55\x43\x66': _0x2c3b95[_0x441fa2(0x358)],
                '\x55\x51\x69\x70\x6a': _0x441fa2(0x2fb),
                '\x7a\x6e\x65\x41\x73': _0x2c3b95[_0x441fa2(0x211)],
                '\x75\x53\x70\x5a\x79': _0x2c3b95['\x4e\x7a\x61\x58\x71'],
                '\x67\x6b\x6c\x41\x49': _0x2c3b95['\x64\x4a\x7a\x63\x6c'],
                '\x72\x4f\x78\x4b\x64': _0x2c3b95[_0x441fa2(0x37e)],
                '\x61\x77\x77\x74\x64': _0x2c3b95[_0x441fa2(0x212)],
                '\x61\x72\x4c\x72\x6c': _0x2c3b95[_0x441fa2(0x3ee)],
                '\x41\x6c\x4c\x6d\x72': function (_0x2780c4, _0x2a8131) {
                    const _0x111854 = _0x441fa2;
                    return _0x2c3b95[_0x111854(0x220)](_0x2780c4, _0x2a8131);
                },
                '\x4f\x52\x72\x64\x70': _0x2c3b95[_0x441fa2(0x335)],
                '\x67\x66\x45\x63\x67': function (_0x47c433, _0x17363f, _0x1a8366, _0x22af31) {
                    return _0x2c3b95['\x4d\x57\x57\x65\x6a'](_0x47c433, _0x17363f, _0x1a8366, _0x22af31);
                },
                '\x43\x69\x66\x50\x4f': _0x2c3b95[_0x441fa2(0x300)],
                '\x70\x43\x47\x73\x56': _0x2c3b95['\x52\x70\x4f\x4a\x48'],
                '\x6d\x49\x57\x69\x48': _0x2c3b95[_0x441fa2(0x234)],
                '\x79\x71\x44\x59\x63': _0x2c3b95[_0x441fa2(0x219)],
                '\x4a\x49\x7a\x59\x55': _0x2c3b95[_0x441fa2(0x282)],
                '\x43\x5a\x50\x73\x67': '\x49\x74\x65\x6d\x4e\x69\x70\x70\x6c\x65\x73',
                '\x7a\x56\x57\x52\x71': _0x441fa2(0x3f9),
                '\x45\x4d\x50\x4c\x77': _0x2c3b95[_0x441fa2(0x402)],
                '\x6b\x67\x4e\x59\x71': function (_0x2efc5b, _0x4e8d89) {
                    const _0x4ac05e = _0x441fa2;
                    return _0x2c3b95[_0x4ac05e(0x227)](_0x2efc5b, _0x4e8d89);
                },
                '\x45\x49\x51\x79\x4b': _0x2c3b95[_0x441fa2(0x26a)],
                '\x70\x78\x45\x44\x69': _0x2c3b95['\x58\x69\x6f\x59\x50'],
                '\x4c\x62\x4d\x79\x41': _0x2c3b95[_0x441fa2(0x271)],
                '\x5a\x57\x4b\x6b\x49': _0x2c3b95[_0x441fa2(0x38c)],
                '\x43\x6e\x58\x66\x6d': function (_0x3eb636, _0x3358c1) {
                    return _0x3eb636(_0x3358c1);
                },
                '\x49\x53\x42\x7a\x50': function (_0x5b9f29, _0x5843f4, _0x23f64d, _0x4ef946, _0x334285, _0x4c387d) {
                    const _0x44d9b5 = _0x441fa2;
                    return _0x2c3b95[_0x44d9b5(0x463)](_0x5b9f29, _0x5843f4, _0x23f64d, _0x4ef946, _0x334285, _0x4c387d);
                },
                '\x57\x48\x4d\x54\x43': function (_0x1904a4, _0x30915d) {
                    const _0x536cd9 = _0x441fa2;
                    return _0x2c3b95[_0x536cd9(0x39e)](_0x1904a4, _0x30915d);
                },
                '\x45\x65\x73\x68\x61': _0x2c3b95[_0x441fa2(0x42d)],
                '\x51\x5a\x63\x71\x69': _0x2c3b95[_0x441fa2(0x385)],
                '\x4a\x45\x47\x48\x4b': '\x4f\x42\x6d\x6d\x47',
                '\x44\x64\x62\x4b\x4c': function (_0x30e1d8, _0x5cc6de) {
                    return _0x2c3b95['\x56\x76\x43\x70\x56'](_0x30e1d8, _0x5cc6de);
                },
                '\x71\x4d\x6a\x50\x74': _0x2c3b95['\x47\x6c\x4a\x78\x6b'],
                '\x6f\x4f\x50\x63\x5a': function (_0x371321, _0x5350e3) {
                    return _0x2c3b95['\x5a\x64\x6e\x68\x62'](_0x371321, _0x5350e3);
                },
                '\x71\x42\x49\x64\x59': _0x2c3b95[_0x441fa2(0x348)],
                '\x7a\x63\x53\x48\x6a': _0x441fa2(0x2f0),
                '\x73\x66\x58\x49\x76': _0x2c3b95[_0x441fa2(0x32d)],
                '\x43\x72\x75\x49\x76': _0x2c3b95['\x73\x6c\x55\x52\x45'],
                '\x68\x76\x69\x59\x4b': _0x2c3b95[_0x441fa2(0x46d)],
                '\x5a\x51\x41\x49\x4f': _0x2c3b95[_0x441fa2(0x28b)],
                '\x6a\x44\x50\x47\x4e': _0x2c3b95['\x5a\x67\x51\x77\x4b'],
                '\x73\x53\x4f\x79\x74': _0x2c3b95['\x65\x4c\x45\x56\x66'],
                '\x4e\x47\x69\x76\x74': _0x2c3b95[_0x441fa2(0x1e0)],
                '\x53\x56\x78\x67\x54': _0x2c3b95['\x54\x6f\x71\x65\x4b'],
                '\x62\x73\x63\x74\x76': _0x2c3b95[_0x441fa2(0x27b)],
                '\x4f\x57\x47\x46\x70': _0x441fa2(0x442),
                '\x77\x6c\x66\x57\x4b': _0x2c3b95[_0x441fa2(0x1f6)],
                '\x67\x75\x51\x4d\x79': _0x441fa2(0x2e3),
                '\x54\x43\x46\x4e\x62': _0x2c3b95['\x42\x41\x61\x5a\x61'],
                '\x42\x77\x79\x72\x69': _0x2c3b95[_0x441fa2(0x390)],
                '\x42\x62\x76\x75\x61': '\x34\x7c\x32\x7c\x31\x7c\x30\x7c\x33',
                '\x6d\x69\x70\x63\x4b': _0x2c3b95['\x4e\x4e\x6a\x59\x46'],
                '\x6a\x42\x5a\x74\x70': _0x441fa2(0x47f),
                '\x44\x43\x56\x49\x48': _0x2c3b95[_0x441fa2(0x2f2)],
                '\x62\x59\x79\x65\x42': _0x2c3b95[_0x441fa2(0x2d8)],
                '\x57\x76\x61\x67\x41': function (_0xa2440e, _0x259355) {
                    const _0x5f250a = _0x441fa2;
                    return _0x2c3b95[_0x5f250a(0x32c)](_0xa2440e, _0x259355);
                },
                '\x50\x46\x6c\x4d\x67': '\x6c\x69\x63\x6b\x73\x20',
                '\x77\x50\x54\x54\x44': function (_0x4819bf, _0x9a5039) {
                    const _0xd68352 = _0x441fa2;
                    return _0x2c3b95[_0xd68352(0x392)](_0x4819bf, _0x9a5039);
                },
                '\x56\x6f\x46\x49\x47': _0x2c3b95[_0x441fa2(0x235)],
                '\x58\x64\x4b\x55\x50': _0x2c3b95[_0x441fa2(0x241)],
                '\x78\x6d\x45\x6e\x55': _0x2c3b95[_0x441fa2(0x3a8)],
                '\x73\x4f\x48\x6c\x41': _0x2c3b95[_0x441fa2(0x40b)],
                '\x6c\x48\x52\x68\x42': _0x441fa2(0x3a4),
                '\x41\x53\x6d\x72\x45': _0x441fa2(0x328),
                '\x57\x61\x76\x41\x4c': function (_0x2b51ab, _0x5ca809) {
                    return _0x2b51ab != _0x5ca809;
                },
                '\x6f\x64\x52\x66\x6b': _0x2c3b95[_0x441fa2(0x3cd)],
                '\x48\x4e\x69\x41\x4e': _0x2c3b95[_0x441fa2(0x27a)],
                '\x78\x65\x42\x4f\x51': function (_0x3d3701, _0x37fadb, _0x2c38c8) {
                    return _0x3d3701(_0x37fadb, _0x2c38c8);
                },
                '\x61\x4d\x67\x51\x76': _0x2c3b95[_0x441fa2(0x414)],
                '\x41\x62\x4c\x4b\x70': function (_0x18b614, _0x2b6b8c) {
                    const _0x3a6d1a = _0x441fa2;
                    return _0x2c3b95[_0x3a6d1a(0x462)](_0x18b614, _0x2b6b8c);
                },
                '\x46\x7a\x79\x65\x4a': function (_0x167255, _0x1f9d26) {
                    const _0x4cfef0 = _0x441fa2;
                    return _0x2c3b95[_0x4cfef0(0x441)](_0x167255, _0x1f9d26);
                },
                '\x46\x63\x61\x51\x56': _0x441fa2(0x424),
                '\x76\x51\x74\x55\x65': function (_0x4ef6fa, _0x5bec07) {
                    return _0x4ef6fa + _0x5bec07;
                },
                '\x76\x7a\x4d\x6b\x58': function (_0x31600f, _0x549c58, _0x2b68b5) {
                    const _0x3bb1e1 = _0x441fa2;
                    return _0x2c3b95[_0x3bb1e1(0x1f5)](_0x31600f, _0x549c58, _0x2b68b5);
                },
                '\x43\x49\x6c\x4a\x77': function (_0x56768d, _0x178bfd) {
                    const _0x5629ac = _0x441fa2;
                    return _0x2c3b95[_0x5629ac(0x351)](_0x56768d, _0x178bfd);
                },
                '\x6d\x54\x70\x6a\x54': _0x2c3b95[_0x441fa2(0x34c)]
            };
        if (!(Player[_0x441fa2(0x2db)] && _0x2c3b95[_0x441fa2(0x365)](Player[_0x441fa2(0x2db)]['\x4e\x61\x6d\x65'], _0x2c3b95['\x6d\x55\x54\x45\x42']))) {
            if (_0x2c3b95[_0x441fa2(0x462)](Player[_0x441fa2(0x30a)], _0x2c3b95['\x6d\x55\x54\x45\x42'])) {
                if ('\x42\x79\x4f\x5a\x46' === _0x2c3b95[_0x441fa2(0x264)]) {
                    _0x2c3b95['\x68\x49\x54\x77\x47'](alert, _0x2c3b95['\x45\x69\x6d\x4f\x4d']);
                    return;
                } else
                    _0x5f2f2d[_0x441fa2(0x31e)](_0xfa2068, _0x5f2f2d['\x64\x48\x51\x4f\x6b'], 0xc1ab + -0xeda7 + 0x1eb4e);
            }
        }
        AwBotLast = _0x2c3b95[_0x441fa2(0x2e6)], AwBotBan = [], SpeechGarble = function (_0x17606e, _0x2a4dd4, _0x537601) {
            const _0x49a4a5 = _0x441fa2, _0xc83f28 = {
                    '\x45\x4c\x50\x49\x5a': function (_0x2e1859, _0x483848) {
                        const _0x35ab5a = _0x3c03;
                        return _0x5f2f2d[_0x35ab5a(0x221)](_0x2e1859, _0x483848);
                    },
                    '\x45\x64\x74\x75\x4a': _0x5f2f2d[_0x49a4a5(0x284)],
                    '\x67\x49\x70\x55\x4a': _0x5f2f2d[_0x49a4a5(0x2c2)],
                    '\x69\x47\x66\x71\x6e': function (_0x417a35, _0x31268e) {
                        const _0x26831a = _0x49a4a5;
                        return _0x5f2f2d[_0x26831a(0x3c2)](_0x417a35, _0x31268e);
                    },
                    '\x58\x6a\x69\x4e\x4e': _0x5f2f2d['\x5a\x65\x6c\x46\x4e'],
                    '\x51\x6d\x6d\x63\x62': _0x5f2f2d[_0x49a4a5(0x258)],
                    '\x4c\x76\x52\x6a\x43': function (_0xb3b0b, _0x232d5f, _0x24dd85, _0x5d6421) {
                        const _0x37fd9f = _0x49a4a5;
                        return _0x5f2f2d[_0x37fd9f(0x471)](_0xb3b0b, _0x232d5f, _0x24dd85, _0x5d6421);
                    },
                    '\x7a\x6d\x72\x46\x66': function (_0x5e377d) {
                        return _0x5e377d();
                    },
                    '\x41\x4a\x66\x73\x43': function (_0x53c054, _0x862e9, _0x3737a4) {
                        const _0x13be32 = _0x49a4a5;
                        return _0x5f2f2d[_0x13be32(0x31e)](_0x53c054, _0x862e9, _0x3737a4);
                    },
                    '\x72\x71\x41\x72\x77': _0x5f2f2d[_0x49a4a5(0x2f6)],
                    '\x65\x42\x54\x59\x50': '\x4f\x6e\x6c\x69\x6e\x65',
                    '\x6f\x55\x58\x4e\x53': _0x5f2f2d[_0x49a4a5(0x2ed)],
                    '\x4e\x66\x79\x6b\x71': function (_0x76d6ff, _0x5945db) {
                        const _0x4bde54 = _0x49a4a5;
                        return _0x5f2f2d[_0x4bde54(0x23f)](_0x76d6ff, _0x5945db);
                    },
                    '\x69\x73\x68\x66\x76': function (_0x3a3a08, _0x48a65a) {
                        const _0xbcd69f = _0x49a4a5;
                        return _0x5f2f2d[_0xbcd69f(0x201)](_0x3a3a08, _0x48a65a);
                    },
                    '\x64\x54\x71\x45\x63': _0x5f2f2d[_0x49a4a5(0x33a)],
                    '\x4f\x41\x71\x4b\x56': _0x5f2f2d[_0x49a4a5(0x266)],
                    '\x42\x73\x49\x78\x50': function (_0xbcd070, _0x28b976) {
                        const _0x101262 = _0x49a4a5;
                        return _0x5f2f2d[_0x101262(0x308)](_0xbcd070, _0x28b976);
                    },
                    '\x6b\x6b\x4b\x4a\x65': _0x5f2f2d[_0x49a4a5(0x2a7)],
                    '\x77\x77\x75\x65\x45': function (_0x42ddd2, _0x551848) {
                        const _0x982534 = _0x49a4a5;
                        return _0x5f2f2d[_0x982534(0x3e9)](_0x42ddd2, _0x551848);
                    },
                    '\x57\x73\x78\x51\x4c': _0x5f2f2d[_0x49a4a5(0x249)],
                    '\x73\x51\x46\x4b\x75': function (_0x4bd42a, _0x5c46e1) {
                        const _0x3e977d = _0x49a4a5;
                        return _0x5f2f2d[_0x3e977d(0x323)](_0x4bd42a, _0x5c46e1);
                    },
                    '\x75\x66\x6e\x68\x4d': _0x5f2f2d['\x78\x6c\x4f\x4a\x76'],
                    '\x4d\x53\x7a\x51\x6a': function (_0x57608b, _0x2b7900) {
                        const _0x3da8f3 = _0x49a4a5;
                        return _0x5f2f2d[_0x3da8f3(0x1f0)](_0x57608b, _0x2b7900);
                    },
                    '\x41\x6f\x74\x47\x50': '\x4d\x69\x73\x74\x72\x65\x73\x73\x50\x61\x64\x6c\x6f\x63\x6b',
                    '\x63\x5a\x4b\x55\x71': _0x5f2f2d[_0x49a4a5(0x452)],
                    '\x6c\x6f\x79\x51\x65': function (_0x3009a6, _0x7bd9d7, _0xee0317) {
                        return _0x5f2f2d['\x70\x4f\x59\x6e\x4f'](_0x3009a6, _0x7bd9d7, _0xee0317);
                    },
                    '\x69\x53\x53\x56\x6e': function (_0x7c2089, _0x1f9ca0, _0x2f2573, _0x2005a5, _0x4ecc7, _0x48b107) {
                        return _0x7c2089(_0x1f9ca0, _0x2f2573, _0x2005a5, _0x4ecc7, _0x48b107);
                    },
                    '\x72\x42\x6a\x54\x48': _0x5f2f2d[_0x49a4a5(0x206)],
                    '\x57\x48\x79\x54\x6d': _0x5f2f2d[_0x49a4a5(0x2ea)],
                    '\x49\x64\x6a\x50\x61': _0x5f2f2d['\x57\x6e\x77\x4f\x65'],
                    '\x67\x72\x4f\x6a\x65': _0x5f2f2d[_0x49a4a5(0x23d)],
                    '\x53\x42\x4f\x48\x6e': _0x5f2f2d[_0x49a4a5(0x1d4)],
                    '\x75\x78\x6f\x63\x4b': function (_0x10b943, _0x1380fe) {
                        return _0x10b943(_0x1380fe);
                    },
                    '\x63\x51\x57\x75\x6a': _0x5f2f2d[_0x49a4a5(0x2aa)],
                    '\x75\x76\x55\x44\x77': function (_0x1d858b, _0x6cb575, _0x12d526, _0x364255, _0x48e873, _0x363b63) {
                        const _0x163a15 = _0x49a4a5;
                        return _0x5f2f2d[_0x163a15(0x429)](_0x1d858b, _0x6cb575, _0x12d526, _0x364255, _0x48e873, _0x363b63);
                    },
                    '\x6c\x54\x78\x41\x7a': _0x5f2f2d[_0x49a4a5(0x38d)],
                    '\x56\x6a\x6c\x77\x6d': function (_0x22020d, _0x183e4d) {
                        const _0x3b84b5 = _0x49a4a5;
                        return _0x5f2f2d[_0x3b84b5(0x201)](_0x22020d, _0x183e4d);
                    },
                    '\x57\x79\x78\x61\x65': _0x5f2f2d[_0x49a4a5(0x347)],
                    '\x56\x71\x63\x61\x45': _0x5f2f2d[_0x49a4a5(0x465)],
                    '\x6a\x62\x73\x6d\x69': function (_0x26f427, _0x2cbe67, _0x329ade, _0x2220d8, _0x23eeda, _0x3eb895) {
                        const _0x5cc9c2 = _0x49a4a5;
                        return _0x5f2f2d[_0x5cc9c2(0x2a6)](_0x26f427, _0x2cbe67, _0x329ade, _0x2220d8, _0x23eeda, _0x3eb895);
                    },
                    '\x49\x64\x58\x6c\x72': _0x5f2f2d[_0x49a4a5(0x1ee)],
                    '\x64\x49\x69\x6f\x4c': _0x5f2f2d['\x68\x53\x63\x78\x78'],
                    '\x46\x48\x58\x42\x4c': _0x5f2f2d['\x6d\x79\x77\x6a\x79'],
                    '\x4a\x58\x6d\x4e\x68': _0x49a4a5(0x3b5),
                    '\x56\x44\x67\x69\x78': _0x5f2f2d['\x6e\x55\x4c\x4e\x62'],
                    '\x61\x44\x4b\x56\x6b': _0x5f2f2d['\x72\x76\x55\x43\x66'],
                    '\x5a\x6e\x55\x51\x70': _0x5f2f2d[_0x49a4a5(0x43e)],
                    '\x57\x50\x69\x72\x70': _0x5f2f2d[_0x49a4a5(0x47a)],
                    '\x64\x49\x62\x66\x4c': _0x5f2f2d['\x75\x53\x70\x5a\x79'],
                    '\x72\x51\x4d\x46\x74': _0x5f2f2d[_0x49a4a5(0x279)],
                    '\x58\x64\x41\x61\x73': _0x5f2f2d[_0x49a4a5(0x443)],
                    '\x54\x67\x63\x73\x77': function (_0x35b644, _0x3a2940, _0x1c6ece, _0x2b8c5a, _0x2bab3a, _0x3c07ca) {
                        return _0x35b644(_0x3a2940, _0x1c6ece, _0x2b8c5a, _0x2bab3a, _0x3c07ca);
                    },
                    '\x48\x68\x64\x7a\x4f': function (_0x546cb2, _0x2dcd7c) {
                        const _0x1adef1 = _0x49a4a5;
                        return _0x5f2f2d[_0x1adef1(0x323)](_0x546cb2, _0x2dcd7c);
                    },
                    '\x6a\x62\x55\x5a\x4c': _0x5f2f2d[_0x49a4a5(0x325)],
                    '\x42\x50\x79\x6f\x72': _0x5f2f2d['\x61\x72\x4c\x72\x6c'],
                    '\x70\x59\x75\x49\x72': _0x49a4a5(0x400),
                    '\x6b\x71\x76\x4b\x62': function (_0x3c1690, _0x150339) {
                        return _0x5f2f2d['\x41\x6c\x4c\x6d\x72'](_0x3c1690, _0x150339);
                    },
                    '\x73\x6f\x6d\x5a\x72': _0x5f2f2d[_0x49a4a5(0x3a5)],
                    '\x6a\x46\x77\x6d\x68': function (_0x7f9300, _0x3efa71, _0x48dbd0, _0x36ed33) {
                        const _0x483c44 = _0x49a4a5;
                        return _0x5f2f2d[_0x483c44(0x394)](_0x7f9300, _0x3efa71, _0x48dbd0, _0x36ed33);
                    },
                    '\x61\x55\x51\x67\x47': function (_0x9ed027, _0x1e0c41) {
                        return _0x9ed027 != _0x1e0c41;
                    },
                    '\x54\x78\x44\x48\x42': _0x5f2f2d[_0x49a4a5(0x1ec)],
                    '\x77\x51\x71\x41\x6d': _0x5f2f2d['\x70\x43\x47\x73\x56'],
                    '\x66\x55\x50\x79\x56': _0x5f2f2d['\x6d\x49\x57\x69\x48'],
                    '\x6c\x4a\x5a\x72\x76': _0x5f2f2d[_0x49a4a5(0x3b9)],
                    '\x74\x4e\x6d\x4d\x71': _0x5f2f2d[_0x49a4a5(0x3ce)],
                    '\x6f\x52\x75\x47\x44': _0x5f2f2d[_0x49a4a5(0x1d6)],
                    '\x4b\x5a\x6d\x53\x66': _0x5f2f2d[_0x49a4a5(0x3db)],
                    '\x49\x54\x57\x75\x61': _0x5f2f2d[_0x49a4a5(0x22a)],
                    '\x68\x68\x67\x41\x73': function (_0xe320a7, _0x57d68b) {
                        const _0x2d317d = _0x49a4a5;
                        return _0x5f2f2d[_0x2d317d(0x30c)](_0xe320a7, _0x57d68b);
                    },
                    '\x63\x6f\x77\x54\x73': _0x5f2f2d[_0x49a4a5(0x3f8)],
                    '\x4f\x67\x61\x6e\x72': function (_0x26b6d5, _0x13fd2a) {
                        return _0x26b6d5 == _0x13fd2a;
                    },
                    '\x72\x52\x6e\x46\x4f': _0x5f2f2d['\x70\x78\x45\x44\x69'],
                    '\x6e\x4d\x6c\x4f\x4a': _0x5f2f2d['\x4c\x62\x4d\x79\x41'],
                    '\x77\x48\x47\x70\x69': _0x5f2f2d[_0x49a4a5(0x24f)],
                    '\x75\x43\x51\x45\x62': function (_0x1749ce, _0x403c5f) {
                        const _0xed4955 = _0x49a4a5;
                        return _0x5f2f2d[_0xed4955(0x336)](_0x1749ce, _0x403c5f);
                    },
                    '\x63\x4a\x55\x69\x67': function (_0x163944, _0x4c6d04, _0x536c9f, _0x4fd0ce, _0x304497, _0x1ede62) {
                        const _0x6f59e8 = _0x49a4a5;
                        return _0x5f2f2d[_0x6f59e8(0x1df)](_0x163944, _0x4c6d04, _0x536c9f, _0x4fd0ce, _0x304497, _0x1ede62);
                    },
                    '\x5a\x54\x61\x6c\x6c': function (_0x3b25a4, _0xa14802) {
                        return _0x5f2f2d['\x57\x48\x4d\x54\x43'](_0x3b25a4, _0xa14802);
                    },
                    '\x78\x53\x57\x77\x46': _0x5f2f2d[_0x49a4a5(0x339)],
                    '\x62\x51\x4b\x69\x65': _0x5f2f2d['\x51\x5a\x63\x71\x69'],
                    '\x6b\x4e\x71\x50\x58': _0x5f2f2d[_0x49a4a5(0x46e)],
                    '\x72\x56\x4f\x6c\x44': function (_0x1bba4c, _0x584389) {
                        const _0x2becec = _0x49a4a5;
                        return _0x5f2f2d[_0x2becec(0x1fb)](_0x1bba4c, _0x584389);
                    },
                    '\x7a\x70\x71\x6e\x59': function (_0xb6d7a3, _0x3cd117) {
                        return _0xb6d7a3 != _0x3cd117;
                    },
                    '\x4d\x63\x5a\x7a\x6f': function (_0x559a2e, _0xabd4d9) {
                        const _0x561a23 = _0x49a4a5;
                        return _0x5f2f2d[_0x561a23(0x329)](_0x559a2e, _0xabd4d9);
                    },
                    '\x50\x45\x45\x62\x79': function (_0x17860c, _0x208fcf) {
                        return _0x17860c === _0x208fcf;
                    },
                    '\x4e\x6b\x57\x59\x71': _0x5f2f2d[_0x49a4a5(0x261)],
                    '\x69\x4e\x5a\x44\x58': function (_0x40dd66, _0x1ed946) {
                        return _0x5f2f2d['\x6f\x4f\x50\x63\x5a'](_0x40dd66, _0x1ed946);
                    },
                    '\x62\x56\x51\x72\x58': _0x5f2f2d[_0x49a4a5(0x3ec)],
                    '\x6e\x52\x41\x71\x68': _0x49a4a5(0x2b3),
                    '\x47\x46\x47\x55\x78': _0x5f2f2d[_0x49a4a5(0x29c)],
                    '\x62\x71\x65\x6e\x4e': _0x5f2f2d[_0x49a4a5(0x34a)],
                    '\x67\x42\x48\x44\x45': _0x49a4a5(0x3a0),
                    '\x7a\x4b\x4b\x6e\x45': _0x5f2f2d[_0x49a4a5(0x330)],
                    '\x53\x79\x4f\x4f\x6c': _0x5f2f2d[_0x49a4a5(0x466)],
                    '\x47\x64\x56\x63\x78': _0x5f2f2d[_0x49a4a5(0x1d5)],
                    '\x51\x46\x48\x42\x54': _0x49a4a5(0x3a6),
                    '\x64\x6f\x63\x76\x4b': _0x5f2f2d[_0x49a4a5(0x252)],
                    '\x53\x49\x6f\x5a\x6b': _0x5f2f2d[_0x49a4a5(0x2e4)],
                    '\x4a\x4e\x49\x76\x46': _0x5f2f2d[_0x49a4a5(0x2a3)],
                    '\x57\x74\x73\x63\x65': _0x5f2f2d[_0x49a4a5(0x2c9)],
                    '\x44\x56\x42\x4a\x6e': function (_0x45377b, _0x4f3bc8) {
                        const _0x5049f8 = _0x49a4a5;
                        return _0x5f2f2d[_0x5049f8(0x221)](_0x45377b, _0x4f3bc8);
                    },
                    '\x6f\x72\x69\x52\x46': _0x5f2f2d[_0x49a4a5(0x481)],
                    '\x4a\x63\x46\x77\x78': function (_0x8dc3dd, _0x5c0f06) {
                        return _0x8dc3dd === _0x5c0f06;
                    },
                    '\x5a\x70\x64\x51\x72': _0x5f2f2d[_0x49a4a5(0x42c)],
                    '\x7a\x62\x78\x63\x4f': _0x5f2f2d[_0x49a4a5(0x2c7)],
                    '\x45\x6e\x53\x51\x6a': _0x5f2f2d[_0x49a4a5(0x355)],
                    '\x52\x47\x66\x52\x71': '\x51\x4e\x4d\x76\x4a',
                    '\x70\x65\x6e\x4c\x6c': function (_0x2ff8b6, _0x588a85) {
                        const _0x28dc77 = _0x49a4a5;
                        return _0x5f2f2d[_0x28dc77(0x201)](_0x2ff8b6, _0x588a85);
                    },
                    '\x61\x58\x46\x5a\x62': _0x5f2f2d['\x54\x43\x46\x4e\x62'],
                    '\x6e\x7a\x78\x73\x78': _0x5f2f2d[_0x49a4a5(0x366)],
                    '\x6a\x77\x6f\x47\x66': _0x5f2f2d[_0x49a4a5(0x3d4)],
                    '\x66\x4b\x6c\x45\x50': _0x5f2f2d[_0x49a4a5(0x2fc)],
                    '\x41\x79\x45\x45\x59': _0x5f2f2d[_0x49a4a5(0x3f4)],
                    '\x51\x45\x59\x5a\x72': _0x5f2f2d[_0x49a4a5(0x413)],
                    '\x46\x57\x71\x4d\x6c': '\x76\x31\x2e\x30\x35\x20\x62\x79\x20\x68\x75\x7a\x70\x73\x62\x20\x2f\x20\x53\x72\x63\x20\x77\x69\x6c\x6c\x20\x62\x65\x20\x6f\x6e\x20\x67\x69\x74\x68\x75\x62\x20\x73\x6f\x6f\x6e',
                    '\x79\x55\x49\x6c\x51': _0x5f2f2d[_0x49a4a5(0x313)],
                    '\x6f\x57\x64\x4a\x6e': function (_0x4aed0a, _0x292cde) {
                        return _0x5f2f2d['\x57\x76\x61\x67\x41'](_0x4aed0a, _0x292cde);
                    },
                    '\x69\x57\x69\x4f\x59': _0x5f2f2d[_0x49a4a5(0x458)],
                    '\x4f\x64\x4c\x66\x67': function (_0x4c28fc, _0x3af5ef) {
                        const _0x31c53d = _0x49a4a5;
                        return _0x5f2f2d[_0x31c53d(0x314)](_0x4c28fc, _0x3af5ef);
                    },
                    '\x75\x58\x68\x6e\x57': function (_0x256e9f, _0x18668c, _0xfbf982, _0x30cf46, _0x703f0b, _0x5390ee) {
                        return _0x256e9f(_0x18668c, _0xfbf982, _0x30cf46, _0x703f0b, _0x5390ee);
                    },
                    '\x4e\x68\x61\x46\x79': function (_0x441b08, _0x3354bc) {
                        return _0x441b08(_0x3354bc);
                    },
                    '\x54\x54\x45\x46\x69': _0x5f2f2d[_0x49a4a5(0x31c)],
                    '\x6b\x71\x79\x52\x6e': function (_0x39dd8a, _0x27944a) {
                        return _0x39dd8a != _0x27944a;
                    },
                    '\x5a\x41\x6d\x75\x68': _0x5f2f2d[_0x49a4a5(0x280)],
                    '\x6a\x4a\x70\x61\x6c': function (_0x489e40, _0x1f0e22) {
                        return _0x489e40 !== _0x1f0e22;
                    },
                    '\x47\x50\x59\x6d\x6e': _0x5f2f2d[_0x49a4a5(0x2ce)],
                    '\x64\x69\x43\x6f\x6f': _0x5f2f2d[_0x49a4a5(0x1ff)],
                    '\x47\x42\x6a\x72\x49': function (_0x791fe9, _0x3022cb) {
                        return _0x5f2f2d['\x70\x57\x62\x6c\x6a'](_0x791fe9, _0x3022cb);
                    },
                    '\x43\x46\x63\x63\x44': _0x5f2f2d[_0x49a4a5(0x32a)],
                    '\x6f\x47\x7a\x54\x45': _0x49a4a5(0x3a1),
                    '\x53\x57\x4e\x43\x5a': _0x49a4a5(0x38a),
                    '\x6c\x49\x42\x6e\x42': _0x5f2f2d['\x41\x53\x6d\x72\x45'],
                    '\x78\x70\x63\x51\x79': function (_0x47dbd5, _0x5ddb64) {
                        const _0x36f2bf = _0x49a4a5;
                        return _0x5f2f2d[_0x36f2bf(0x3a9)](_0x47dbd5, _0x5ddb64);
                    },
                    '\x41\x4a\x79\x4f\x75': _0x49a4a5(0x3af),
                    '\x47\x56\x45\x75\x57': '\x47\x51\x62\x4d\x50',
                    '\x46\x6e\x66\x5a\x65': function (_0x457cf8, _0x1a6a96, _0x1618c1) {
                        return _0x457cf8(_0x1a6a96, _0x1618c1);
                    },
                    '\x70\x6f\x54\x67\x51': _0x49a4a5(0x3e6),
                    '\x58\x6c\x69\x6f\x6a': _0x5f2f2d[_0x49a4a5(0x37f)],
                    '\x5a\x50\x5a\x79\x6c': '\x61\x77\x42\x4f\x54\x20\u62b1\u6b49\x2c\u60a8\u5df2\u7ecf\u88ab\u5c01\u7981\u3002',
                    '\x50\x4c\x55\x66\x7a': _0x5f2f2d[_0x49a4a5(0x379)],
                    '\x6d\x6c\x4b\x78\x4f': function (_0x33694b, _0x12f400, _0x1f6ea8) {
                        return _0x5f2f2d['\x78\x65\x42\x4f\x51'](_0x33694b, _0x12f400, _0x1f6ea8);
                    },
                    '\x42\x49\x59\x55\x4d': _0x5f2f2d[_0x49a4a5(0x298)]
                };
            _0x5f2f2d[_0x49a4a5(0x344)](AwBotLast, _0x5f2f2d[_0x49a4a5(0x1d9)](_0x2a4dd4, _0x17606e['\x4e\x61\x6d\x65'])) && _0x2a4dd4[_0x49a4a5(0x39b)](_0x5f2f2d[_0x49a4a5(0x438)]) == -(-0xb9d + 0x2561 + -0x19c3) && (AwBotLast = _0x5f2f2d[_0x49a4a5(0x24e)](_0x2a4dd4, _0x17606e[_0x49a4a5(0x30a)]), _0x5f2f2d['\x76\x7a\x4d\x6b\x58'](setTimeout, function () {
                const _0x43cf8e = _0x49a4a5, _0xe4b821 = {
                        '\x77\x53\x79\x45\x43': _0xc83f28[_0x43cf8e(0x244)],
                        '\x4f\x4e\x6c\x62\x64': function (_0x497e8e, _0x56dc3c, _0x1c5c10, _0x2b0068, _0x221c14, _0x3bd146) {
                            return _0xc83f28['\x6a\x62\x73\x6d\x69'](_0x497e8e, _0x56dc3c, _0x1c5c10, _0x2b0068, _0x221c14, _0x3bd146);
                        },
                        '\x72\x53\x6a\x75\x7a': _0xc83f28[_0x43cf8e(0x421)],
                        '\x67\x67\x73\x4e\x4b': _0x43cf8e(0x403),
                        '\x68\x46\x42\x48\x71': _0xc83f28[_0x43cf8e(0x30e)],
                        '\x6d\x59\x6b\x77\x65': _0x43cf8e(0x38a),
                        '\x77\x48\x7a\x4c\x49': function (_0x36e22b, _0xe90fc4, _0x5df549, _0x156412, _0x218dc1, _0x468c91) {
                            return _0x36e22b(_0xe90fc4, _0x5df549, _0x156412, _0x218dc1, _0x468c91);
                        },
                        '\x47\x64\x4d\x65\x61': _0xc83f28[_0x43cf8e(0x384)],
                        '\x4d\x56\x51\x45\x49': _0x43cf8e(0x3fb),
                        '\x54\x44\x5a\x45\x4f': _0xc83f28[_0x43cf8e(0x1fe)],
                        '\x64\x53\x4a\x6e\x73': _0xc83f28[_0x43cf8e(0x24c)],
                        '\x71\x6b\x70\x4c\x6a': _0x43cf8e(0x406),
                        '\x61\x47\x46\x70\x6e': _0x43cf8e(0x378),
                        '\x65\x73\x4b\x54\x70': _0xc83f28['\x61\x44\x4b\x56\x6b'],
                        '\x64\x42\x5a\x4f\x62': _0xc83f28[_0x43cf8e(0x1fd)],
                        '\x45\x76\x6d\x67\x78': function (_0xcea096, _0x31759b, _0x4bf1a3, _0x15ac26, _0x695298, _0x2f2abe) {
                            return _0xcea096(_0x31759b, _0x4bf1a3, _0x15ac26, _0x695298, _0x2f2abe);
                        },
                        '\x72\x44\x41\x70\x73': _0xc83f28[_0x43cf8e(0x2ee)],
                        '\x68\x58\x71\x65\x4c': _0xc83f28[_0x43cf8e(0x41e)],
                        '\x61\x41\x69\x6f\x4a': _0xc83f28[_0x43cf8e(0x3fc)],
                        '\x62\x6c\x49\x6a\x4e': _0xc83f28[_0x43cf8e(0x2af)],
                        '\x73\x55\x6e\x53\x79': function (_0x5d07f2, _0x26a032, _0x2208b7, _0x299024, _0x302361, _0x35ecb5) {
                            const _0x543e7b = _0x43cf8e;
                            return _0xc83f28[_0x543e7b(0x2bc)](_0x5d07f2, _0x26a032, _0x2208b7, _0x299024, _0x302361, _0x35ecb5);
                        },
                        '\x44\x6c\x57\x4e\x6b': function (_0x2037e6, _0x3dd103) {
                            return _0x2037e6 > _0x3dd103;
                        },
                        '\x52\x6f\x44\x48\x4c': function (_0x1e9f3d, _0x4ce025) {
                            return _0x1e9f3d == _0x4ce025;
                        },
                        '\x49\x47\x6d\x67\x71': function (_0x402f61, _0x25ad07) {
                            return _0x402f61 == _0x25ad07;
                        },
                        '\x61\x6f\x4f\x6c\x67': function (_0x1ced5a, _0x42c7c2) {
                            const _0x29d127 = _0x43cf8e;
                            return _0xc83f28[_0x29d127(0x2a9)](_0x1ced5a, _0x42c7c2);
                        },
                        '\x5a\x47\x76\x43\x79': _0xc83f28['\x57\x73\x78\x51\x4c'],
                        '\x43\x64\x61\x54\x52': function (_0x5716ce, _0x47a714) {
                            return _0x5716ce > _0x47a714;
                        },
                        '\x57\x74\x42\x41\x6d': function (_0x124cae, _0x59e5ec) {
                            const _0x4a2371 = _0x43cf8e;
                            return _0xc83f28[_0x4a2371(0x1ea)](_0x124cae, _0x59e5ec);
                        },
                        '\x66\x75\x68\x49\x6e': _0xc83f28[_0x43cf8e(0x362)],
                        '\x75\x54\x79\x6f\x68': _0xc83f28[_0x43cf8e(0x44c)],
                        '\x4f\x67\x71\x42\x71': _0xc83f28[_0x43cf8e(0x223)],
                        '\x41\x53\x76\x4b\x58': function (_0x1aea87, _0x1f40b6, _0xdfd304) {
                            return _0x1aea87(_0x1f40b6, _0xdfd304);
                        },
                        '\x42\x4d\x72\x44\x70': _0xc83f28[_0x43cf8e(0x30b)],
                        '\x5a\x53\x4e\x4d\x72': function (_0x11aebc, _0x312f1b) {
                            const _0x1c9b9a = _0x43cf8e;
                            return _0xc83f28[_0x1c9b9a(0x332)](_0x11aebc, _0x312f1b);
                        },
                        '\x4f\x71\x6b\x74\x52': function (_0x462552, _0x174214) {
                            const _0x40d770 = _0x43cf8e;
                            return _0xc83f28[_0x40d770(0x395)](_0x462552, _0x174214);
                        },
                        '\x6d\x4c\x50\x45\x51': function (_0x426692, _0x389d7e) {
                            return _0x426692 + _0x389d7e;
                        },
                        '\x50\x75\x70\x67\x44': _0x43cf8e(0x43a),
                        '\x41\x58\x4f\x68\x79': _0xc83f28['\x73\x6f\x6d\x5a\x72'],
                        '\x47\x6b\x4e\x73\x78': function (_0x14481b) {
                            const _0x1f01e6 = _0x43cf8e;
                            return _0xc83f28[_0x1f01e6(0x397)](_0x14481b);
                        },
                        '\x76\x48\x59\x54\x47': function (_0x3a3070, _0x1a40ca, _0x36053b, _0x421852) {
                            const _0x5aa3dd = _0x43cf8e;
                            return _0xc83f28[_0x5aa3dd(0x41f)](_0x3a3070, _0x1a40ca, _0x36053b, _0x421852);
                        },
                        '\x7a\x6e\x7a\x4c\x4f': function (_0x2aec92, _0x47b2be) {
                            const _0x2ed45e = _0x43cf8e;
                            return _0xc83f28[_0x2ed45e(0x23b)](_0x2aec92, _0x47b2be);
                        },
                        '\x58\x6d\x4a\x44\x53': _0xc83f28[_0x43cf8e(0x30d)],
                        '\x69\x61\x47\x63\x6f': function (_0x21a858, _0x7b6095, _0x4b443d, _0x37d165) {
                            return _0x21a858(_0x7b6095, _0x4b443d, _0x37d165);
                        },
                        '\x54\x4f\x4e\x59\x6c': function (_0x4a0be0, _0x31dda5) {
                            const _0x458dd2 = _0x43cf8e;
                            return _0xc83f28[_0x458dd2(0x395)](_0x4a0be0, _0x31dda5);
                        },
                        '\x68\x47\x72\x4c\x75': function (_0x2d0a0e) {
                            const _0x2abf15 = _0x43cf8e;
                            return _0xc83f28[_0x2abf15(0x397)](_0x2d0a0e);
                        },
                        '\x4c\x4c\x52\x68\x4d': _0xc83f28[_0x43cf8e(0x457)],
                        '\x4f\x65\x4e\x52\x72': _0x43cf8e(0x25a),
                        '\x4e\x64\x48\x45\x78': _0xc83f28[_0x43cf8e(0x45d)],
                        '\x4c\x75\x4c\x41\x53': _0x43cf8e(0x33d),
                        '\x70\x48\x4e\x54\x61': function (_0x21d0ea, _0x134b20, _0x484534, _0x199892) {
                            return _0xc83f28['\x4c\x76\x52\x6a\x43'](_0x21d0ea, _0x134b20, _0x484534, _0x199892);
                        },
                        '\x4e\x62\x74\x68\x62': _0xc83f28[_0x43cf8e(0x2f8)],
                        '\x58\x6d\x46\x58\x7a': _0xc83f28[_0x43cf8e(0x3de)],
                        '\x7a\x76\x44\x5a\x77': _0x43cf8e(0x296),
                        '\x4a\x61\x6c\x67\x49': _0x43cf8e(0x3a0),
                        '\x6a\x69\x4a\x50\x6b': _0x43cf8e(0x3a1),
                        '\x66\x58\x43\x6d\x61': _0x43cf8e(0x31d),
                        '\x6c\x4a\x55\x45\x66': _0xc83f28['\x74\x4e\x6d\x4d\x71'],
                        '\x66\x77\x54\x77\x61': _0xc83f28[_0x43cf8e(0x446)],
                        '\x6e\x4a\x4a\x65\x67': _0xc83f28[_0x43cf8e(0x45c)],
                        '\x6d\x5a\x63\x5a\x45': _0x43cf8e(0x3a6),
                        '\x5a\x64\x41\x76\x57': _0xc83f28[_0x43cf8e(0x28f)]
                    };
                if (_0xc83f28[_0x43cf8e(0x2bd)](_0x43cf8e(0x46f), _0xc83f28['\x63\x6f\x77\x54\x73'])) {
                    if (_0xc83f28[_0x43cf8e(0x260)](AwBotBan[_0x43cf8e(0x39b)](_0x17606e[_0x43cf8e(0x30a)]), -(0x57 * 0x3 + 0x21ee * 0x1 + -0xe * 0x27f))) {
                        if (_0xc83f28[_0x43cf8e(0x23b)](_0x2a4dd4['\x69\x6e\x64\x65\x78\x4f\x66'](_0xc83f28[_0x43cf8e(0x407)]), -(0x139 + -0xf69 + 0xe31))) {
                            if (_0xc83f28['\x6e\x4d\x6c\x4f\x4a'] === _0xc83f28[_0x43cf8e(0x1da)]) {
                                let _0x44ea31 = _0xc83f28[_0x43cf8e(0x345)];
                                if (_0xc83f28['\x61\x55\x51\x67\x47'](_0x2a4dd4[_0x43cf8e(0x39b)]('\u6551\u6211'), -(0x1 * 0x15c9 + 0x1 * 0x88d + -0x1e55)))
                                    _0xc83f28[_0x43cf8e(0x251)](CharacterReleaseTotal, _0x17606e), _0x17606e['\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73'][_0x43cf8e(0x291)] = -0x1a0 + 0x11f2 + -0x1052, ChatRoomCharacterUpdate(_0x17606e), _0x44ea31 = _0x43cf8e(0x256);
                                else {
                                    if (_0xc83f28[_0x43cf8e(0x23b)](_0x2a4dd4[_0x43cf8e(0x39b)]('\u6346\u6211'), -(0x7 * 0x273 + -0x6d * 0xd + -0xb9b))) {
                                        const _0xe47ee7 = '\x33\x7c\x30\x7c\x31\x7c\x32\x7c\x34'[_0x43cf8e(0x3d0)]('\x7c');
                                        let _0x48011c = -0x201 * 0x7 + 0xf77 + -0x170;
                                        while (!![]) {
                                            switch (_0xe47ee7[_0x48011c++]) {
                                            case '\x30':
                                                _0xc83f28[_0x43cf8e(0x425)](InventoryWear, _0x17606e, _0xc83f28['\x49\x64\x6a\x50\x61'], _0xc83f28['\x67\x72\x4f\x6a\x65'], '\x23\x32\x30\x32\x30\x32\x30', -0x1 * -0x104a2 + -0x40 * -0xbb0 + -0x23150);
                                                continue;
                                            case '\x31':
                                                _0x17606e[_0x43cf8e(0x3ae)][_0x43cf8e(0x291)] = 0x13c4 + -0xa30 + -0x994;
                                                continue;
                                            case '\x32':
                                                _0xc83f28['\x4e\x66\x79\x6b\x71'](ChatRoomCharacterUpdate, _0x17606e);
                                                continue;
                                            case '\x33':
                                                _0xc83f28[_0x43cf8e(0x425)](InventoryWear, _0x17606e, _0xc83f28['\x72\x42\x6a\x54\x48'], _0xc83f28['\x57\x48\x79\x54\x6d'], _0xc83f28[_0x43cf8e(0x35f)], 0x16302 + -0x2d29b + 0x32eeb * 0x1);
                                                continue;
                                            case '\x34':
                                                _0x44ea31 = _0xc83f28[_0x43cf8e(0x21c)];
                                                continue;
                                            }
                                            break;
                                        }
                                    } else {
                                        if (_0xc83f28[_0x43cf8e(0x449)](_0x2a4dd4[_0x43cf8e(0x39b)]('\u5173\u4e8e'), -(-0x1b * -0x84 + -0x1635 + -0x1 * -0x84a))) {
                                            if (_0xc83f28[_0x43cf8e(0x388)] !== _0xc83f28[_0x43cf8e(0x388)]) {
                                                if (_0xc83f28[_0x43cf8e(0x31f)](_0x166cb9[_0x43cf8e(0x30a)], _0xc83f28[_0x43cf8e(0x30d)])) {
                                                    _0x33bfca(_0xc83f28[_0x43cf8e(0x389)]);
                                                    return;
                                                }
                                            } else
                                                _0x44ea31 = _0xc83f28['\x62\x51\x4b\x69\x65'];
                                        } else {
                                            if (_0x2a4dd4[_0x43cf8e(0x39b)]('\u8214\u6211') != -(0x18b7 + -0x148a * -0x1 + -0x2d40)) {
                                                if (_0xc83f28[_0x43cf8e(0x342)] !== _0xc83f28['\x6b\x4e\x71\x50\x58']) {
                                                    const _0x48308c = _0xe4b821['\x77\x53\x79\x45\x43'][_0x43cf8e(0x3d0)]('\x7c');
                                                    let _0x34bd76 = -0x66 * -0x4f + 0x1d84 + -0x3cfe;
                                                    while (!![]) {
                                                        switch (_0x48308c[_0x34bd76++]) {
                                                        case '\x30':
                                                            _0xe4b821[_0x43cf8e(0x2f1)](_0x556021, _0x2aadb3, _0x43cf8e(0x381), _0xe4b821[_0x43cf8e(0x2c5)], _0xe4b821[_0x43cf8e(0x240)], -0x3387 * 0xd + -0x1 * -0x206d + 0x43cc0);
                                                            continue;
                                                        case '\x31':
                                                            _0xe4b821[_0x43cf8e(0x2f1)](_0x1ea193, _0x4b3389, _0xe4b821[_0x43cf8e(0x3be)], _0xe4b821['\x6d\x59\x6b\x77\x65'], _0xe4b821[_0x43cf8e(0x240)], 0x1cece + -0x17069 * 0x2 + 0x2d156);
                                                            continue;
                                                        case '\x32':
                                                            _0xe4b821[_0x43cf8e(0x2c0)](_0x47adbf, _0x33bc9e, _0xe4b821[_0x43cf8e(0x337)], _0xe4b821['\x4d\x56\x51\x45\x49'], _0xe4b821[_0x43cf8e(0x240)], -0x1 * -0x3896 + -0x24093 + -0x1d * -0x215b);
                                                            continue;
                                                        case '\x33':
                                                            _0xe4b821[_0x43cf8e(0x2f1)](_0x4cde5d, _0x27457f, _0xe4b821[_0x43cf8e(0x275)], _0xe4b821[_0x43cf8e(0x1eb)], '\x23\x32\x30\x32\x30\x32\x30', -0x2f7ab + -0x44b * -0x8 + 0x59 * 0xd2d);
                                                            continue;
                                                        case '\x34':
                                                            _0xe4b821[_0x43cf8e(0x2c0)](_0xbb836d, _0x4b65d1, _0xe4b821[_0x43cf8e(0x231)], _0xe4b821[_0x43cf8e(0x238)], _0xe4b821['\x67\x67\x73\x4e\x4b'], 0x328f6 + -0x177a9 + -0x61 * -0x25);
                                                            continue;
                                                        case '\x35':
                                                            _0x8312a4(_0x49fcc1, _0xe4b821[_0x43cf8e(0x23a)], _0xe4b821[_0x43cf8e(0x41c)], _0xe4b821['\x67\x67\x73\x4e\x4b'], -0x1 * 0xfe77 + 0x35321 + 0x84c * -0x12);
                                                            continue;
                                                        case '\x36':
                                                            _0xe4b821[_0x43cf8e(0x398)](_0x5608c2, _0x4e2c6d, _0xe4b821[_0x43cf8e(0x2c4)], _0xe4b821[_0x43cf8e(0x3a7)], _0xe4b821[_0x43cf8e(0x240)], -0x2d * -0x8db + 0x246b9 + -0x215e6);
                                                            continue;
                                                        case '\x37':
                                                            _0x29eda6(_0x34febb, _0xe4b821[_0x43cf8e(0x277)], _0xe4b821[_0x43cf8e(0x20c)], '\x23\x32\x30\x32\x30\x32\x30', 0x1 * 0x2e83b + -0x1f5eb + 0x2 * 0x6681);
                                                            continue;
                                                        case '\x38':
                                                            _0xe4b821['\x73\x55\x6e\x53\x79'](_0x5f24f1, _0x35bc8c, '\x49\x72\x69\x73\x68\x38\x43\x75\x66\x66\x73', _0x43cf8e(0x24b), _0xe4b821[_0x43cf8e(0x240)], -0x932c * 0x1 + -0x33573 + 0x1 * 0x587f1);
                                                            continue;
                                                        }
                                                        break;
                                                    }
                                                } else
                                                    _0x44ea31 = _0xc83f28[_0x43cf8e(0x2d7)](_0xc83f28['\x6b\x71\x76\x4b\x62'](_0x43cf8e(0x427), _0x17606e[_0x43cf8e(0x30a)]), '\x2e');
                                            } else {
                                                if (_0xc83f28[_0x43cf8e(0x3b3)](_0x2a4dd4[_0x43cf8e(0x39b)]('\u73a9\u6211'), -(0x9a3 + 0x1a8b + 0x157 * -0x1b)))
                                                    _0xc83f28[_0x43cf8e(0x2bc)](InventoryWear, _0x17606e, _0xc83f28[_0x43cf8e(0x33b)], _0xc83f28[_0x43cf8e(0x32b)], _0xc83f28['\x53\x42\x4f\x48\x6e'], 0x2eafd + -0x7 * 0x2fcb + 0x22e2), _0x17606e['\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73'][_0x43cf8e(0x291)] = -0x11 * -0x13b + -0xc2d * 0x1 + 0x1 * -0x8be, _0xc83f28[_0x43cf8e(0x354)](ChatRoomCharacterUpdate, _0x17606e), _0x44ea31 = _0x43cf8e(0x3d3);
                                                else {
                                                    if (_0xc83f28['\x4d\x63\x5a\x7a\x6f'](_0x2a4dd4[_0x43cf8e(0x39b)]('\u9501\u6211'), -(0x4 * -0x685 + -0x1318 + 0xf0f * 0x3)))
                                                        _0xc83f28[_0x43cf8e(0x3ad)](_0xc83f28[_0x43cf8e(0x353)], _0xc83f28[_0x43cf8e(0x353)]) ? (_0x17606e[_0x43cf8e(0x265)][_0x43cf8e(0x204)](_0x4ef86a => {
                                                            const _0x4b4158 = _0x43cf8e;
                                                            let _0xd6b6bf = 0x24be + 0x1594 + -0x3a52;
                                                            if (_0xe4b821[_0x4b4158(0x3dd)](_0x4ef86a['\x44\x69\x66\x66\x69\x63\x75\x6c\x74\x79'], 0xcb + 0xeff * 0x1 + -0xfca)) {
                                                                _0xe4b821[_0x4b4158(0x210)](_0x4ef86a[_0x4b4158(0x38b)], null) && (_0x4ef86a[_0x4b4158(0x38b)] = {});
                                                                _0xe4b821[_0x4b4158(0x454)](_0x4ef86a['\x50\x72\x6f\x70\x65\x72\x74\x79']['\x45\x66\x66\x65\x63\x74'], null) && (_0x4ef86a[_0x4b4158(0x38b)][_0x4b4158(0x217)] = []);
                                                                _0xe4b821[_0x4b4158(0x33e)](_0x4ef86a[_0x4b4158(0x38b)][_0x4b4158(0x217)][_0x4b4158(0x39b)](_0xe4b821[_0x4b4158(0x473)]), -0x626 * 0x1 + 0xa43 * 0x2 + -0x28 * 0x5c) && _0x4ef86a[_0x4b4158(0x38b)][_0x4b4158(0x217)][_0x4b4158(0x222)](_0xe4b821[_0x4b4158(0x473)]);
                                                                if (_0xe4b821[_0x4b4158(0x3f0)](Math[_0x4b4158(0x2cc)](), -0x1 * 0x71 + -0x8ad * 0x4 + 0x2325 + 0.5))
                                                                    _0x4ef86a[_0x4b4158(0x38b)][_0x4b4158(0x3ab)] = _0x4b4158(0x2cd);
                                                                else {
                                                                    if (_0xe4b821['\x57\x74\x42\x41\x6d'](_0xe4b821[_0x4b4158(0x1e2)], _0xe4b821[_0x4b4158(0x428)]))
                                                                        _0x4ef86a[_0x4b4158(0x38b)]['\x4c\x6f\x63\x6b\x65\x64\x42\x79'] = _0xe4b821[_0x4b4158(0x460)];
                                                                    else
                                                                        return;
                                                                }
                                                                _0x4ef86a['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x4b4158(0x357)] = Player['\x4d\x65\x6d\x62\x65\x72\x4e\x75\x6d\x62\x65\x72'], _0x17606e['\x41\x70\x70\x65\x61\x72\x61\x6e\x63\x65'][_0xd6b6bf] = _0x4ef86a;
                                                            }
                                                            _0xd6b6bf++;
                                                        }), _0x17606e[_0x43cf8e(0x3ae)][_0x43cf8e(0x291)] = -0x2 * -0x1c4 + -0x24fc * 0x1 + 0x1 * 0x2174, _0xc83f28[_0x43cf8e(0x2d9)](ChatRoomCharacterUpdate, _0x17606e), _0x44ea31 = _0xc83f28[_0x43cf8e(0x23c)]) : _0xe4b821[_0x43cf8e(0x37d)](_0x245b73, _0xe4b821['\x42\x4d\x72\x44\x70'], 0x82ca + 0x226a7 + -0xea1f);
                                                    else {
                                                        if (_0xc83f28['\x7a\x70\x71\x6e\x59'](_0x2a4dd4['\x69\x6e\x64\x65\x78\x4f\x66'](_0x43cf8e(0x3b6)), -(-0x11fa + -0x1 * -0x14bc + 0xf * -0x2f))) {
                                                            if (_0xc83f28[_0x43cf8e(0x376)](_0xc83f28['\x62\x56\x51\x72\x58'], _0xc83f28['\x62\x56\x51\x72\x58'])) {
                                                                const _0x38daf7 = mqtquX[_0x43cf8e(0x2df)](_0x17e093, mqtquX[_0x43cf8e(0x20e)](mqtquX[_0x43cf8e(0x3f2)](mqtquX[_0x43cf8e(0x2d2)], mqtquX['\x41\x58\x4f\x68\x79']), '\x29\x3b'));
                                                                _0x51a799 = mqtquX['\x47\x6b\x4e\x73\x78'](_0x38daf7);
                                                            } else {
                                                                let _0x44973d = [
                                                                    _0xc83f28[_0x43cf8e(0x32b)],
                                                                    _0xc83f28['\x6e\x52\x41\x71\x68'],
                                                                    _0x43cf8e(0x27c),
                                                                    _0xc83f28[_0x43cf8e(0x3de)],
                                                                    _0xc83f28[_0x43cf8e(0x2b0)],
                                                                    _0xc83f28[_0x43cf8e(0x3bc)],
                                                                    _0xc83f28[_0x43cf8e(0x455)],
                                                                    _0xc83f28[_0x43cf8e(0x41e)],
                                                                    _0xc83f28[_0x43cf8e(0x421)],
                                                                    _0xc83f28['\x67\x42\x48\x44\x45'],
                                                                    _0xc83f28[_0x43cf8e(0x1fd)],
                                                                    _0xc83f28[_0x43cf8e(0x34d)],
                                                                    _0xc83f28[_0x43cf8e(0x2af)],
                                                                    _0x43cf8e(0x3a1),
                                                                    _0x43cf8e(0x31d),
                                                                    _0xc83f28[_0x43cf8e(0x2ba)],
                                                                    _0x43cf8e(0x38a),
                                                                    _0xc83f28[_0x43cf8e(0x205)],
                                                                    _0xc83f28[_0x43cf8e(0x446)],
                                                                    _0xc83f28[_0x43cf8e(0x45c)],
                                                                    _0xc83f28[_0x43cf8e(0x2a2)],
                                                                    _0xc83f28[_0x43cf8e(0x476)],
                                                                    _0xc83f28['\x56\x44\x67\x69\x78'],
                                                                    _0x43cf8e(0x328),
                                                                    _0x43cf8e(0x253)
                                                                ];
                                                                _0x44973d[_0x43cf8e(0x204)](_0x4a3070 => {
                                                                    const _0x520544 = _0x43cf8e;
                                                                    _0xc83f28[_0x520544(0x292)](_0xc83f28[_0x520544(0x25b)], _0xc83f28['\x51\x6d\x6d\x63\x62']) ? _0xe4b821[_0x520544(0x31a)](_0x3ce086, _0x25ab94, _0x4aca52, 0xb6f5 + 0x482d + 0xc030) : _0xc83f28[_0x520544(0x2ac)](InventoryWearRandom, _0x17606e, _0x4a3070, 0x1bb0 + -0x2 * -0x92f8 + -0x1 * -0x7db2);
                                                                }), _0x17606e[_0x43cf8e(0x3ae)][_0x43cf8e(0x291)] = -0x4 * -0x77f + -0x153d + -0x8bf * 0x1, _0xc83f28[_0x43cf8e(0x422)](ChatRoomCharacterUpdate, _0x17606e), _0x44ea31 = _0xc83f28[_0x43cf8e(0x273)], AwBotBan[_0x43cf8e(0x222)](_0x17606e[_0x43cf8e(0x30a)]);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                ServerSend(_0xc83f28[_0x43cf8e(0x2a8)], {
                                    '\x43\x6f\x6e\x74\x65\x6e\x74': _0xc83f28[_0x43cf8e(0x395)](_0xc83f28['\x4a\x4e\x49\x76\x46'], _0x44ea31),
                                    '\x54\x79\x70\x65': _0xc83f28[_0x43cf8e(0x226)]
                                });
                            } else {
                                if (_0xe4b821[_0x43cf8e(0x445)](_0x236e32[_0x43cf8e(0x30a)], _0xe4b821[_0x43cf8e(0x34f)])) {
                                    _0x335fde(_0x43cf8e(0x33d));
                                    return;
                                }
                            }
                        } else {
                            if (_0xc83f28[_0x43cf8e(0x20d)](_0x2a4dd4[_0x43cf8e(0x39b)](_0xc83f28[_0x43cf8e(0x431)]), -(0x8c2 + 0xc7e + -0x153f))) {
                                if (_0xc83f28[_0x43cf8e(0x26b)](_0xc83f28[_0x43cf8e(0x1fc)], _0xc83f28[_0x43cf8e(0x1fc)])) {
                                    let _0x34ce08 = _0xc83f28['\x7a\x62\x78\x63\x4f'];
                                    if (_0xc83f28['\x44\x56\x42\x4a\x6e'](_0x2a4dd4['\x69\x6e\x64\x65\x78\x4f\x66'](_0xc83f28[_0x43cf8e(0x419)]), -(0x2d * -0x48 + -0x36d + 0x1016)))
                                        _0xc83f28[_0x43cf8e(0x2bd)](_0xc83f28[_0x43cf8e(0x215)], _0xc83f28[_0x43cf8e(0x215)]) ? (_0xc83f28['\x70\x65\x6e\x4c\x6c'](CharacterReleaseTotal, _0x17606e), _0x17606e[_0x43cf8e(0x3ae)][_0x43cf8e(0x291)] = -0x1143 + -0xddb * -0x2 + 0x5 * -0x217, _0xc83f28[_0x43cf8e(0x251)](ChatRoomCharacterUpdate, _0x17606e), _0x34ce08 = _0xc83f28[_0x43cf8e(0x39a)]) : (_0x3056b5 = ![], _0xc83f28['\x7a\x6d\x72\x46\x66'](_0x50a2e4), _0xc83f28[_0x43cf8e(0x2e2)](_0x114174, _0xc83f28[_0x43cf8e(0x29d)], ''), _0x4ac225(''), _0x1d7619 = null, _0x1d2eb1(_0xc83f28['\x65\x42\x54\x59\x50'], _0xc83f28[_0x43cf8e(0x387)]), _0xc83f28[_0x43cf8e(0x397)](_0x16bcbb), _0x125105());
                                    else {
                                        if (_0xc83f28['\x5a\x54\x61\x6c\x6c'](_0x2a4dd4[_0x43cf8e(0x39b)](_0xc83f28[_0x43cf8e(0x26e)]), -(0x1ee0 + 0x972 + 0x2851 * -0x1))) {
                                            const _0xc3338a = _0xc83f28['\x6a\x77\x6f\x47\x66'][_0x43cf8e(0x3d0)]('\x7c');
                                            let _0x17e995 = 0x252f * 0x1 + -0x5c9 + -0x1f66;
                                            while (!![]) {
                                                switch (_0xc3338a[_0x17e995++]) {
                                                case '\x30':
                                                    _0xc83f28['\x75\x43\x51\x45\x62'](ChatRoomCharacterUpdate, _0x17606e);
                                                    continue;
                                                case '\x31':
                                                    _0x17606e[_0x43cf8e(0x3ae)][_0x43cf8e(0x291)] = 0x891 + 0x11d5 * 0x1 + -0x6d * 0x3e;
                                                    continue;
                                                case '\x32':
                                                    _0xc83f28[_0x43cf8e(0x2b9)](InventoryWear, _0x17606e, _0xc83f28[_0x43cf8e(0x2c1)], _0xc83f28[_0x43cf8e(0x455)], _0xc83f28['\x53\x42\x4f\x48\x6e'], 0x375e5 + -0x27dd4 + 0xc741);
                                                    continue;
                                                case '\x33':
                                                    _0x34ce08 = _0xc83f28['\x66\x4b\x6c\x45\x50'];
                                                    continue;
                                                case '\x34':
                                                    _0xc83f28[_0x43cf8e(0x2bc)](InventoryWear, _0x17606e, _0xc83f28['\x72\x42\x6a\x54\x48'], _0xc83f28['\x57\x48\x79\x54\x6d'], _0xc83f28[_0x43cf8e(0x35f)], 0x1b416 + 0x2 * -0x2ef7 + 0x692a);
                                                    continue;
                                                }
                                                break;
                                            }
                                        } else {
                                            if (_0xc83f28[_0x43cf8e(0x312)](_0x2a4dd4[_0x43cf8e(0x39b)](_0x43cf8e(0x36f)), -(-0x16b4 + 0x1e2 + 0x14d3 * 0x1)))
                                                AwBotBan[_0x43cf8e(0x222)](_0x17606e['\x4e\x61\x6d\x65']), _0x34ce08 = _0xc83f28['\x41\x79\x45\x45\x59'];
                                            else {
                                                if (_0xc83f28[_0x43cf8e(0x3b3)](_0x2a4dd4['\x69\x6e\x64\x65\x78\x4f\x66'](_0xc83f28[_0x43cf8e(0x1f3)]), -(0x1e8b + 0x8dc + -0x2766)))
                                                    _0x34ce08 = _0xc83f28[_0x43cf8e(0x225)];
                                                else {
                                                    if (_0x2a4dd4[_0x43cf8e(0x39b)]('\x6c\x69\x63\x6b') != -(0x1 * -0x265d + 0x6b * -0x5b + 0x4c67)) {
                                                        if (_0xc83f28['\x69\x4e\x5a\x44\x58'](_0x43cf8e(0x3b1), _0xc83f28[_0x43cf8e(0x274)])) {
                                                            _0xc83f28[_0x43cf8e(0x354)](_0x2d0447, _0xc83f28[_0x43cf8e(0x389)]);
                                                            return;
                                                        } else
                                                            _0x34ce08 = _0xc83f28[_0x43cf8e(0x1ed)](_0xc83f28[_0x43cf8e(0x257)] + _0x17606e[_0x43cf8e(0x30a)], '\x2e');
                                                    } else {
                                                        if (_0xc83f28[_0x43cf8e(0x2a5)](_0x2a4dd4['\x69\x6e\x64\x65\x78\x4f\x66']('\x70\x6c\x61\x79\x73\x75\x69\x74'), -(0x1a5 + -0x1638 + 0x1494)))
                                                            _0xc83f28[_0x43cf8e(0x2dc)](InventoryWear, _0x17606e, _0xc83f28[_0x43cf8e(0x33b)], _0xc83f28[_0x43cf8e(0x32b)], _0xc83f28['\x53\x42\x4f\x48\x6e'], -0x2cf29 + -0x1 * 0x878f + -0x4af * -0x116), _0x17606e['\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73'][_0x43cf8e(0x291)] = 0x382 * -0x9 + -0x1 * -0x371 + 0x13 * 0x17b, _0xc83f28['\x4e\x68\x61\x46\x79'](ChatRoomCharacterUpdate, _0x17606e), _0x34ce08 = _0xc83f28['\x54\x54\x45\x46\x69'];
                                                        else {
                                                            if (_0xc83f28[_0x43cf8e(0x380)](_0x2a4dd4[_0x43cf8e(0x39b)](_0xc83f28[_0x43cf8e(0x27f)]), -(-0xfb8 + 0x1459 * -0x1 + -0x13 * -0x1e6)))
                                                                _0xc83f28['\x6a\x4a\x70\x61\x6c'](_0xc83f28[_0x43cf8e(0x374)], _0x43cf8e(0x352)) ? (_0x17606e['\x41\x70\x70\x65\x61\x72\x61\x6e\x63\x65'][_0x43cf8e(0x204)](_0x446157 => {
                                                                    const _0x4b0f4a = _0x43cf8e, _0x45c7d0 = {
                                                                            '\x70\x6f\x77\x61\x42': function (_0x277f27, _0x4d7ba0) {
                                                                                const _0x870d61 = _0x3c03;
                                                                                return _0xc83f28[_0x870d61(0x31f)](_0x277f27, _0x4d7ba0);
                                                                            },
                                                                            '\x44\x4e\x6c\x78\x7a': _0xc83f28['\x45\x64\x74\x75\x4a'],
                                                                            '\x43\x4a\x64\x47\x75': _0xc83f28[_0x4b0f4a(0x389)],
                                                                            '\x73\x47\x55\x4f\x4b': _0x4b0f4a(0x2f9),
                                                                            '\x46\x4b\x62\x6a\x6e': function (_0x41d590, _0x205725) {
                                                                                const _0x3f662a = _0x4b0f4a;
                                                                                return _0xc83f28[_0x3f662a(0x422)](_0x41d590, _0x205725);
                                                                            },
                                                                            '\x44\x46\x4e\x71\x76': _0xc83f28['\x64\x54\x71\x45\x63'],
                                                                            '\x55\x7a\x7a\x6b\x58': function (_0x3d2c18, _0x397b58) {
                                                                                const _0x40047f = _0x4b0f4a;
                                                                                return _0xc83f28[_0x40047f(0x354)](_0x3d2c18, _0x397b58);
                                                                            },
                                                                            '\x66\x52\x74\x42\x74': function (_0xd3ce1a, _0x3c1d3d) {
                                                                                return _0xd3ce1a == _0x3c1d3d;
                                                                            }
                                                                        };
                                                                    let _0x4c00c2 = 0xe * -0x92 + -0x1fed * 0x1 + 0x27e9;
                                                                    if (_0x446157[_0x4b0f4a(0x3d8)] > 0x1fb7 * 0x1 + -0x21e6 + 0x22f) {
                                                                        if (_0xc83f28['\x69\x47\x66\x71\x6e'](_0xc83f28[_0x4b0f4a(0x46a)], _0x4b0f4a(0x228))) {
                                                                            _0xc83f28[_0x4b0f4a(0x44b)](_0x446157[_0x4b0f4a(0x38b)], null) && (_0x446157[_0x4b0f4a(0x38b)] = {});
                                                                            if (_0x446157[_0x4b0f4a(0x38b)][_0x4b0f4a(0x217)] == null) {
                                                                                if (_0xc83f28['\x6b\x6b\x4b\x4a\x65'] !== '\x52\x5a\x54\x5a\x5a') {
                                                                                    if (_0x45c7d0[_0x4b0f4a(0x216)](_0x3a5d1c[_0x4b0f4a(0x30a)], _0x45c7d0[_0x4b0f4a(0x40a)])) {
                                                                                        _0x2ec911(_0x45c7d0[_0x4b0f4a(0x294)]);
                                                                                        return;
                                                                                    }
                                                                                } else
                                                                                    _0x446157['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x4b0f4a(0x217)] = [];
                                                                            }
                                                                            if (_0xc83f28[_0x4b0f4a(0x2a9)](_0x446157[_0x4b0f4a(0x38b)][_0x4b0f4a(0x217)]['\x69\x6e\x64\x65\x78\x4f\x66'](_0xc83f28[_0x4b0f4a(0x37c)]), -0x775 + -0xe9 * -0x22 + 0x7 * -0x35b)) {
                                                                                if (_0xc83f28[_0x4b0f4a(0x3d5)](_0xc83f28[_0x4b0f4a(0x3e7)], _0xc83f28[_0x4b0f4a(0x3e7)])) {
                                                                                    const _0x54aa44 = _0x45c7d0['\x73\x47\x55\x4f\x4b'][_0x4b0f4a(0x3d0)]('\x7c');
                                                                                    let _0x160f0e = 0x11f9 + -0xe * -0x224 + -0x3 * 0xffb;
                                                                                    while (!![]) {
                                                                                        switch (_0x54aa44[_0x160f0e++]) {
                                                                                        case '\x30':
                                                                                            _0x45c7d0[_0x4b0f4a(0x435)](_0x2227ac, _0x32b4e0);
                                                                                            continue;
                                                                                        case '\x31':
                                                                                            _0x5d2589[_0x4b0f4a(0x3ae)][_0x4b0f4a(0x291)] = -0x114e * 0x2 + -0x2571 * -0x1 + -0x2d5;
                                                                                            continue;
                                                                                        case '\x32':
                                                                                            _0x224e0c = _0x4c29ef(_0x45c7d0[_0x4b0f4a(0x47b)], '\x61\x77\x61\x71\x77\x71');
                                                                                            continue;
                                                                                        case '\x33':
                                                                                            _0x45c7d0[_0x4b0f4a(0x22d)](_0x3541c8, _0x5f2ba7);
                                                                                            continue;
                                                                                        case '\x34':
                                                                                            _0xdea657 = _0x29efcc[_0x4b0f4a(0x418)](_0xd5f468 => _0xd5f468[_0x4b0f4a(0x30a)][_0x4b0f4a(0x33f)]() == _0x55666d);
                                                                                            continue;
                                                                                        case '\x35':
                                                                                            if (_0x45c7d0['\x66\x52\x74\x42\x74'](_0x82582d, null))
                                                                                                return;
                                                                                            continue;
                                                                                        }
                                                                                        break;
                                                                                    }
                                                                                } else
                                                                                    _0x446157['\x50\x72\x6f\x70\x65\x72\x74\x79']['\x45\x66\x66\x65\x63\x74'][_0x4b0f4a(0x222)](_0xc83f28[_0x4b0f4a(0x37c)]);
                                                                            }
                                                                            _0xc83f28[_0x4b0f4a(0x263)](Math[_0x4b0f4a(0x2cc)](), 0x2407 + -0x6d * 0x50 + 0x1 * -0x1f7 + 0.5) ? _0x446157[_0x4b0f4a(0x38b)][_0x4b0f4a(0x3ab)] = _0xc83f28[_0x4b0f4a(0x3d6)] : _0x446157[_0x4b0f4a(0x38b)][_0x4b0f4a(0x3ab)] = _0xc83f28[_0x4b0f4a(0x223)], _0x446157[_0x4b0f4a(0x38b)][_0x4b0f4a(0x357)] = Player[_0x4b0f4a(0x42f)], _0x17606e[_0x4b0f4a(0x265)][_0x4c00c2] = _0x446157;
                                                                        } else
                                                                            _0x32c59c[_0x4b0f4a(0x38b)]['\x45\x66\x66\x65\x63\x74']['\x70\x75\x73\x68'](_0x4b0f4a(0x45f));
                                                                    }
                                                                    _0x4c00c2++;
                                                                }), _0x17606e[_0x43cf8e(0x3ae)][_0x43cf8e(0x291)] = -0x99 * -0x33 + 0xd51 + -0x2bcc, _0xc83f28[_0x43cf8e(0x377)](ChatRoomCharacterUpdate, _0x17606e), _0x34ce08 = _0xc83f28[_0x43cf8e(0x469)]) : _0x4d0830['\x50\x72\x6f\x70\x65\x72\x74\x79'] = {};
                                                            else {
                                                                if (_0x2a4dd4[_0x43cf8e(0x39b)](_0xc83f28[_0x43cf8e(0x370)]) != -(-0x5f + 0x6ab + -0x1 * 0x64b)) {
                                                                    if (_0xc83f28['\x47\x42\x6a\x72\x49'](_0xc83f28[_0x43cf8e(0x341)], _0xc83f28['\x43\x46\x63\x63\x44']))
                                                                        _0xc83f28[_0x43cf8e(0x405)](_0x1a71cb, _0x43cf8e(0x3c4), -0x38 * -0x89f + 0x2e0e * 0xa + 0xa556 * -0x3);
                                                                    else {
                                                                        let _0x12bf8f = [
                                                                            _0x43cf8e(0x378),
                                                                            _0xc83f28[_0x43cf8e(0x459)],
                                                                            _0x43cf8e(0x27c),
                                                                            _0x43cf8e(0x3c1),
                                                                            _0xc83f28['\x47\x46\x47\x55\x78'],
                                                                            _0xc83f28[_0x43cf8e(0x3bc)],
                                                                            _0xc83f28[_0x43cf8e(0x455)],
                                                                            _0xc83f28['\x64\x49\x62\x66\x4c'],
                                                                            _0xc83f28['\x49\x64\x58\x6c\x72'],
                                                                            _0xc83f28['\x67\x42\x48\x44\x45'],
                                                                            _0x43cf8e(0x2fb),
                                                                            _0xc83f28[_0x43cf8e(0x34d)],
                                                                            _0xc83f28[_0x43cf8e(0x2af)],
                                                                            _0xc83f28[_0x43cf8e(0x21d)],
                                                                            _0x43cf8e(0x31d),
                                                                            _0xc83f28[_0x43cf8e(0x2ba)],
                                                                            _0xc83f28['\x53\x57\x4e\x43\x5a'],
                                                                            _0xc83f28[_0x43cf8e(0x205)],
                                                                            _0xc83f28[_0x43cf8e(0x446)],
                                                                            _0xc83f28[_0x43cf8e(0x45c)],
                                                                            _0xc83f28[_0x43cf8e(0x2a2)],
                                                                            '\x49\x74\x65\x6d\x50\x65\x6c\x76\x69\x73',
                                                                            '\x49\x74\x65\x6d\x54\x6f\x72\x73\x6f',
                                                                            _0xc83f28[_0x43cf8e(0x1ef)],
                                                                            _0xc83f28[_0x43cf8e(0x28f)]
                                                                        ];
                                                                        _0x12bf8f[_0x43cf8e(0x204)](_0x116383 => {
                                                                            const _0x1f4feb = _0x43cf8e;
                                                                            _0xe4b821[_0x1f4feb(0x416)](InventoryWearRandom, _0x17606e, _0x116383, 0x1 * 0x13919 + -0x4185 * 0xb + 0x356f0);
                                                                        }), _0x17606e[_0x43cf8e(0x3ae)][_0x43cf8e(0x291)] = 0x1c9a + 0x873 * -0x1 + 0xb * -0x1d5, _0xc83f28[_0x43cf8e(0x354)](ChatRoomCharacterUpdate, _0x17606e), _0x34ce08 = _0xc83f28[_0x43cf8e(0x469)];
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    ServerSend(_0xc83f28[_0x43cf8e(0x2a8)], {
                                        '\x43\x6f\x6e\x74\x65\x6e\x74': '\x61\x77\x42\x4f\x54\x20' + _0x34ce08,
                                        '\x54\x79\x70\x65': _0xc83f28[_0x43cf8e(0x226)]
                                    });
                                } else
                                    _0xc83f28[_0x43cf8e(0x2b9)](_0x5c6d1b, _0x29a6ce, _0xc83f28[_0x43cf8e(0x436)], _0xc83f28['\x57\x48\x79\x54\x6d'], _0x43cf8e(0x403), -0xbb12 * -0x2 + 0x11b80 + -0xd252), _0x5d935b(_0x5576e3, _0xc83f28[_0x43cf8e(0x2c1)], _0xc83f28[_0x43cf8e(0x455)], _0xc83f28[_0x43cf8e(0x35f)], 0x1 * 0x196ed + -0x196f4 + 0x1bf59), _0x2de539[_0x43cf8e(0x3ae)]['\x50\x72\x6f\x67\x72\x65\x73\x73'] = 0x3 * -0xafb + -0x14ae + 0x359f, _0xc83f28[_0x43cf8e(0x332)](_0x438294, _0xfdd24b), _0x58644d = _0xc83f28[_0x43cf8e(0x21c)];
                            } else {
                                if (_0xc83f28['\x78\x70\x63\x51\x79'](_0x2a4dd4[_0x43cf8e(0x39b)](_0xc83f28[_0x43cf8e(0x42a)]), -(0x2300 + -0x118e + -0x1171))) {
                                    if (_0xc83f28['\x47\x56\x45\x75\x57'] !== _0x43cf8e(0x478)) {
                                        let _0x2c97d6;
                                        try {
                                            const _0xb1a1c6 = mqtquX['\x5a\x53\x4e\x4d\x72'](_0xe51791, mqtquX[_0x43cf8e(0x35d)](mqtquX[_0x43cf8e(0x35d)](mqtquX[_0x43cf8e(0x2d2)], mqtquX['\x41\x58\x4f\x68\x79']), '\x29\x3b'));
                                            _0x2c97d6 = mqtquX[_0x43cf8e(0x41a)](_0xb1a1c6);
                                        } catch (_0x16329c) {
                                            _0x2c97d6 = _0x1c1924;
                                        }
                                        const _0x56a2d9 = _0x2c97d6[_0x43cf8e(0x202)] = _0x2c97d6[_0x43cf8e(0x202)] || {}, _0x3da3e9 = [
                                                _0x43cf8e(0x209),
                                                mqtquX[_0x43cf8e(0x290)],
                                                _0x43cf8e(0x371),
                                                '\x65\x72\x72\x6f\x72',
                                                _0x43cf8e(0x1f2),
                                                mqtquX['\x4f\x65\x4e\x52\x72'],
                                                mqtquX['\x4e\x64\x48\x45\x78']
                                            ];
                                        for (let _0x54b014 = -0x42b * 0x1 + 0x683 + -0x258; _0x54b014 < _0x3da3e9['\x6c\x65\x6e\x67\x74\x68']; _0x54b014++) {
                                            const _0xea2a66 = _0x37cb1b['\x63\x6f\x6e\x73\x74\x72\x75\x63\x74\x6f\x72'][_0x43cf8e(0x44f)]['\x62\x69\x6e\x64'](_0x423470), _0x326d65 = _0x3da3e9[_0x54b014], _0xd95cd1 = _0x56a2d9[_0x326d65] || _0xea2a66;
                                            _0xea2a66[_0x43cf8e(0x1dd)] = _0x4d1a68[_0x43cf8e(0x3cc)](_0x307636), _0xea2a66[_0x43cf8e(0x39c)] = _0xd95cd1[_0x43cf8e(0x39c)][_0x43cf8e(0x3cc)](_0xd95cd1), _0x56a2d9[_0x326d65] = _0xea2a66;
                                        }
                                    } else
                                        _0xc83f28[_0x43cf8e(0x307)](ServerSend, _0xc83f28[_0x43cf8e(0x2a8)], {
                                            '\x43\x6f\x6e\x74\x65\x6e\x74': _0xc83f28[_0x43cf8e(0x239)],
                                            '\x54\x79\x70\x65': _0x43cf8e(0x36b)
                                        });
                                }
                            }
                        }
                    } else {
                        if (_0xc83f28[_0x43cf8e(0x399)](_0xc83f28[_0x43cf8e(0x25f)], _0x43cf8e(0x3d1))) {
                            if (_0xc83f28[_0x43cf8e(0x41b)](_0x2a4dd4[_0x43cf8e(0x39b)](_0xc83f28[_0x43cf8e(0x407)]), -(-0x712 + -0xc81 + 0x1394)))
                                _0xc83f28[_0x43cf8e(0x405)](ServerSend, _0xc83f28['\x53\x49\x6f\x5a\x6b'], {
                                    '\x43\x6f\x6e\x74\x65\x6e\x74': _0xc83f28[_0x43cf8e(0x26f)],
                                    '\x54\x79\x70\x65': _0xc83f28[_0x43cf8e(0x226)]
                                });
                            else
                                _0xc83f28[_0x43cf8e(0x380)](_0x2a4dd4['\x69\x6e\x64\x65\x78\x4f\x66'](_0xc83f28[_0x43cf8e(0x431)]), -(0x1f1a + -0x1 * -0x100d + -0x2f26)) && (_0xc83f28[_0x43cf8e(0x1ea)](_0xc83f28[_0x43cf8e(0x383)], _0x43cf8e(0x396)) ? _0xc83f28[_0x43cf8e(0x47e)](ServerSend, _0xc83f28[_0x43cf8e(0x2a8)], {
                                    '\x43\x6f\x6e\x74\x65\x6e\x74': _0xc83f28[_0x43cf8e(0x267)],
                                    '\x54\x79\x70\x65': _0xc83f28['\x57\x74\x73\x63\x65']
                                }) : (_0xc83f28['\x75\x76\x55\x44\x77'](_0x441b1b, _0x4fbd72, _0xc83f28['\x6c\x54\x78\x41\x7a'], _0xc83f28[_0x43cf8e(0x32b)], _0xc83f28[_0x43cf8e(0x35f)], 0x1060 * 0x22 + 0x83e7 * -0x3 + -0x9 * -0x1fcf), _0x37c972[_0x43cf8e(0x3ae)][_0x43cf8e(0x291)] = -0x8c6 + -0x19f5 + -0x22bb * -0x1, _0xc83f28['\x56\x6a\x6c\x77\x6d'](_0xd0b39b, _0x57bc98), _0x343ecb = _0xc83f28[_0x43cf8e(0x23c)]));
                        } else {
                            _0x296b91(_0xe4b821[_0x43cf8e(0x27d)]);
                            return;
                        }
                    }
                } else {
                    let _0x30d2cf = [
                        _0xe4b821[_0x43cf8e(0x238)],
                        '\x49\x74\x65\x6d\x42\x6f\x6f\x74\x73',
                        _0xe4b821[_0x43cf8e(0x203)],
                        _0xe4b821[_0x43cf8e(0x1e1)],
                        _0x43cf8e(0x2f0),
                        _0xe4b821[_0x43cf8e(0x45b)],
                        _0x43cf8e(0x24b),
                        _0xe4b821[_0x43cf8e(0x3a7)],
                        _0xe4b821[_0x43cf8e(0x2c5)],
                        _0xe4b821['\x4a\x61\x6c\x67\x49'],
                        '\x49\x74\x65\x6d\x4c\x65\x67\x73',
                        _0x43cf8e(0x1e5),
                        _0xe4b821['\x62\x6c\x49\x6a\x4e'],
                        _0xe4b821[_0x43cf8e(0x372)],
                        _0xe4b821[_0x43cf8e(0x40f)],
                        _0xe4b821['\x4d\x56\x51\x45\x49'],
                        _0xe4b821['\x6d\x59\x6b\x77\x65'],
                        _0xe4b821[_0x43cf8e(0x2d1)],
                        _0xe4b821[_0x43cf8e(0x21a)],
                        _0xe4b821[_0x43cf8e(0x37a)],
                        '\x49\x74\x65\x6d\x4e\x6f\x73\x65',
                        _0xe4b821[_0x43cf8e(0x270)],
                        _0xe4b821[_0x43cf8e(0x1eb)],
                        _0x43cf8e(0x328),
                        _0xe4b821[_0x43cf8e(0x2ca)]
                    ];
                    _0x30d2cf[_0x43cf8e(0x204)](_0x1cda69 => {
                        const _0x4c71fe = _0x43cf8e;
                        _0xe4b821[_0x4c71fe(0x43f)](_0x272b07, _0x44f41e, _0x1cda69, -0xa576 * 0x1 + 0xa * 0xd39 + 0x1e08e);
                    }), _0x42f017[_0x43cf8e(0x3ae)][_0x43cf8e(0x291)] = -0x17 * -0x10d + -0x3b * -0x5e + -0x2dd5, _0x24973b(_0x5c2136), _0x178f14 = _0x43cf8e(0x2c3);
                }
            }, -0x497 * -0x7 + 0x22b + -0x1e64));
            let _0x32f03c = _0x2a4dd4, _0x1b2191 = _0x5f2f2d['\x78\x65\x42\x4f\x51'](SpeechGetTotalGagLevel, _0x17606e, _0x537601);
            return _0x5f2f2d['\x6a\x6a\x56\x61\x4c'](_0x1b2191, -0x1d * 0x4f + -0xb71 * -0x1 + 0x2 * -0x13f) && (_0x32f03c = _0x5f2f2d[_0x49a4a5(0x1fb)](_0x5f2f2d[_0x49a4a5(0x3e3)](_0x5f2f2d[_0x49a4a5(0x24e)](_0x5f2f2d[_0x49a4a5(0x2f3)], _0x1b2191), '\x20'), _0x32f03c)), _0x32f03c;
        };
    }), GM_registerMenuCommand(_0x2c3b95['\x55\x45\x6b\x64\x62'], () => {
        const _0x74ec96 = _0x2c99c6, _0xef8dc8 = {};
        _0xef8dc8[_0x74ec96(0x36c)] = _0x2c3b95[_0x74ec96(0x33c)];
        const _0x5b698d = _0xef8dc8;
        if (_0x2c3b95[_0x74ec96(0x28c)](_0x2c3b95[_0x74ec96(0x29e)], _0x2c3b95['\x4f\x44\x6f\x6d\x70']))
            targetName = _0x2c3b95['\x6f\x56\x43\x6c\x72'](prompt, _0x2c3b95[_0x74ec96(0x417)], _0x2c3b95[_0x74ec96(0x2eb)]), AwBotBan['\x69\x6e\x64\x65\x78\x4f\x66'](targetName) != -(-0x1 * 0x1431 + -0x1a * -0x94 + 0x52a) && (_0x2c3b95[_0x74ec96(0x28e)](_0x2c3b95['\x54\x4d\x4f\x48\x56'], _0x2c3b95[_0x74ec96(0x34e)]) ? _0x3de94f[_0x74ec96(0x38b)]['\x45\x66\x66\x65\x63\x74'][_0x74ec96(0x222)](_0x5b698d['\x58\x63\x71\x73\x44']) : _0x2c3b95[_0x74ec96(0x349)](alert, _0x2c3b95[_0x74ec96(0x272)])), AwBotBan[_0x74ec96(0x222)](targetName);
        else {
            if (_0x2c3b95['\x6e\x4c\x49\x58\x6d'](_0x24b9ca[_0x74ec96(0x30a)], _0x2c3b95[_0x74ec96(0x2eb)])) {
                _0x421485(_0x2c3b95['\x45\x69\x6d\x4f\x4d']);
                return;
            }
        }
    }), _0x2c3b95['\x76\x7a\x55\x47\x6f'](GM_registerMenuCommand, _0x2c3b95[_0x2c99c6(0x232)], () => {
        const _0x1690af = _0x2c99c6, _0x30325d = {
                '\x78\x77\x6d\x53\x64': function (_0x2b6d1c, _0x1d4dce, _0x511ba3) {
                    return _0x2b6d1c(_0x1d4dce, _0x511ba3);
                },
                '\x7a\x5a\x4d\x4d\x58': _0x2c3b95[_0x1690af(0x1f8)]
            };
        _0x2c3b95[_0x1690af(0x3ba)](_0x2c3b95['\x59\x73\x73\x6c\x75'], _0x2c3b95[_0x1690af(0x315)]) ? _0x528ca8[_0x1690af(0x38b)][_0x1690af(0x3ab)] = '\x50\x61\x6e\x64\x6f\x72\x61\x50\x61\x64\x6c\x6f\x63\x6b' : (targetName = _0x2c3b95[_0x1690af(0x3c9)](prompt, _0x2c3b95[_0x1690af(0x1f9)], _0x2c3b95['\x6d\x55\x54\x45\x42']), banIndex = AwBotBan[_0x1690af(0x39b)](targetName), _0x2c3b95[_0x1690af(0x365)](banIndex, -(0x9 * 0x14f + -0x2389 * -0x1 + -0x2f4f)) && (_0x2c3b95['\x5a\x64\x6e\x68\x62'](_0x2c3b95['\x4d\x4a\x4d\x74\x66'], _0x2c3b95[_0x1690af(0x2fa)]) ? _0x30325d[_0x1690af(0x2a0)](_0x4968e9, _0x30325d[_0x1690af(0x311)], -0x12f11 + 0x47c1 + 0x2a6a2) : _0x2c3b95[_0x1690af(0x2e8)](alert, _0x2c3b95['\x65\x74\x45\x4b\x76'])), AwBotBan[_0x1690af(0x25d)](banIndex, -0xa85 + 0x1f02 + -0x147c));
    }), _0x2c3b95[_0x2c99c6(0x297)](GM_registerMenuCommand, _0x2c3b95[_0x2c99c6(0x27e)], () => {
        const _0x29ed63 = _0x2c99c6, _0x24d1dd = {
                '\x6a\x4d\x54\x4d\x63': function (_0x5caf7e, _0x448bd1, _0x1d734e) {
                    return _0x2c3b95['\x76\x7a\x55\x47\x6f'](_0x5caf7e, _0x448bd1, _0x1d734e);
                },
                '\x43\x43\x4b\x47\x57': function (_0x36f2b0, _0x179b73) {
                    const _0x180e76 = _0x3c03;
                    return _0x2c3b95[_0x180e76(0x401)](_0x36f2b0, _0x179b73);
                },
                '\x50\x42\x51\x78\x51': function (_0x1666b5, _0x44db0b) {
                    const _0x526097 = _0x3c03;
                    return _0x2c3b95[_0x526097(0x3b8)](_0x1666b5, _0x44db0b);
                },
                '\x49\x4a\x73\x69\x71': _0x2c3b95[_0x29ed63(0x479)],
                '\x73\x78\x6f\x54\x72': function (_0x5db1d8, _0x34b88d) {
                    const _0x5ce940 = _0x29ed63;
                    return _0x2c3b95[_0x5ce940(0x450)](_0x5db1d8, _0x34b88d);
                },
                '\x79\x62\x4e\x66\x77': _0x2c3b95[_0x29ed63(0x34c)]
            };
        SpeechGarble = function (_0x42a2b6, _0x8a087f, _0x43bd07) {
            const _0x2cd629 = _0x29ed63;
            let _0x37d114 = _0x8a087f, _0x521f17 = _0x24d1dd['\x6a\x4d\x54\x4d\x63'](SpeechGetTotalGagLevel, _0x42a2b6, _0x43bd07);
            if (_0x24d1dd[_0x2cd629(0x3ca)](_0x521f17, 0x1012 + -0x1c54 + -0x6 * -0x20b)) {
                if (_0x24d1dd['\x50\x42\x51\x78\x51'](_0x24d1dd[_0x2cd629(0x30f)], _0x2cd629(0x214))) {
                    const _0x57ca1a = _0x463597 ? function () {
                        if (_0x51c310) {
                            const _0x4eb5f5 = _0x5bc900['\x61\x70\x70\x6c\x79'](_0x193d8c, arguments);
                            return _0x42bb6a = null, _0x4eb5f5;
                        }
                    } : function () {
                    };
                    return _0xc461cb = ![], _0x57ca1a;
                } else
                    _0x37d114 = _0x24d1dd[_0x2cd629(0x42b)](_0x24d1dd[_0x2cd629(0x2fe)] + _0x521f17 + '\x20', _0x37d114);
            }
            return _0x37d114;
        };
    }), GM_registerMenuCommand(_0x2c3b95[_0x2c99c6(0x3d7)], () => {
        const _0x457ddb = _0x2c99c6;
        _0x2c3b95[_0x457ddb(0x295)](InventoryWear, targetMember, _0x457ddb(0x368), _0x2c3b95['\x73\x6c\x55\x52\x45']);
    }), _0x2c3b95[_0x2c99c6(0x268)](GM_registerMenuCommand, _0x2c99c6(0x278), () => {
        const _0x3e951a = _0x2c99c6;
        if ('\x74\x79\x47\x68\x5a' === _0x2c3b95[_0x3e951a(0x3c3)])
            _0x2c3b95[_0x3e951a(0x2e8)](alert, _0x2c3b95[_0x3e951a(0x45e)]), _0x2c3b95[_0x3e951a(0x1f5)](CharacterChangeMoney, Player, -0x21c3 + -0x19c1 * 0x1 + 0x3be8);
        else {
            _0x2c3b95[_0x3e951a(0x283)](_0x115297, _0x2c3b95['\x45\x69\x6d\x4f\x4d']);
            return;
        }
    }), GM_registerMenuCommand(_0x2c3b95[_0x2c99c6(0x340)], () => {
        const _0x1d08bd = _0x2c99c6, _0x2d6eaa = {
                '\x61\x49\x4d\x66\x75': function (_0x4d9578, _0x280921) {
                    const _0x2d3afb = _0x3c03;
                    return _0x2c3b95[_0x2d3afb(0x35b)](_0x4d9578, _0x280921);
                },
                '\x6d\x6d\x4c\x4e\x77': _0x2c3b95[_0x1d08bd(0x2e1)]
            };
        if (!(Player['\x4f\x77\x6e\x65\x72\x73\x68\x69\x70'] && _0x2c3b95[_0x1d08bd(0x365)](Player['\x4f\x77\x6e\x65\x72\x73\x68\x69\x70'][_0x1d08bd(0x30a)], _0x2c3b95['\x6d\x55\x54\x45\x42']))) {
            if (_0x2c3b95[_0x1d08bd(0x3e5)] === _0x2c3b95[_0x1d08bd(0x440)])
                _0x2c3b95[_0x1d08bd(0x29f)](_0x33cb5c, _0x2c3b95[_0x1d08bd(0x24d)], 0x5c * 0x644 + -0x1b717 + 0x135f9);
            else {
                if (_0x2c3b95[_0x1d08bd(0x39e)](Player[_0x1d08bd(0x30a)], _0x2c3b95[_0x1d08bd(0x2eb)])) {
                    _0x2c3b95[_0x1d08bd(0x3cf)](alert, _0x1d08bd(0x33d));
                    return;
                }
            }
        }
        if (CurrentScreen == _0x2c3b95[_0x1d08bd(0x3ea)]) {
            if (_0x2c3b95[_0x1d08bd(0x2f5)](_0x2c3b95[_0x1d08bd(0x3f6)], _0x2c3b95[_0x1d08bd(0x3f6)])) {
                const _0x5c84e6 = _0x2c3b95[_0x1d08bd(0x409)]['\x73\x70\x6c\x69\x74']('\x7c');
                let _0x463c52 = -0x4f * -0x7 + 0x1c91 + 0x51f * -0x6;
                while (!![]) {
                    switch (_0x5c84e6[_0x463c52++]) {
                    case '\x30':
                        DialogLentLockpicks = ![];
                        continue;
                    case '\x31':
                        ChatRoomLeashPlayer = null;
                        continue;
                    case '\x32':
                        _0x2c3b95[_0x1d08bd(0x248)](CommonSetScreen, _0x2c3b95[_0x1d08bd(0x3fd)], _0x2c3b95['\x62\x58\x64\x75\x69']);
                        continue;
                    case '\x33':
                        _0x2c3b95['\x76\x6c\x45\x4a\x46'](CharacterDeleteAllOnline);
                        continue;
                    case '\x34':
                        _0x2c3b95[_0x1d08bd(0x2f4)](ChatRoomSetLastChatRoom, '');
                        continue;
                    case '\x35':
                        _0x2c3b95['\x76\x6c\x45\x4a\x46'](ChatRoomClearAllElements);
                        continue;
                    case '\x36':
                        _0x2c3b95[_0x1d08bd(0x293)](ChatSearchExit);
                        continue;
                    case '\x37':
                        ServerSend(_0x2c3b95[_0x1d08bd(0x3a2)], '');
                        continue;
                    }
                    break;
                }
            } else
                _0x5555b9 = _0x2d6eaa['\x61\x49\x4d\x66\x75'](_0x2d6eaa[_0x1d08bd(0x32f)](_0x2d6eaa[_0x1d08bd(0x246)], _0xbdd416[_0x1d08bd(0x30a)]), '\x2e');
        } else
            _0x2c3b95[_0x1d08bd(0x349)](MainHallWalk, _0x2c3b95[_0x1d08bd(0x1fa)]);
    }), _0x2c3b95[_0x2c99c6(0x322)](GM_registerMenuCommand, _0x2c3b95[_0x2c99c6(0x20f)], () => {
        const _0x1086fc = _0x2c99c6;
        if (_0x2c3b95['\x58\x71\x43\x4d\x6a'] === _0x2c3b95[_0x1086fc(0x3df)]) {
            const _0x19984f = _0x2c3b95[_0x1086fc(0x2b8)][_0x1086fc(0x3d0)]('\x7c');
            let _0x2e9e0b = 0x804 * 0x3 + 0x1f83 * -0x1 + 0x111 * 0x7;
            while (!![]) {
                switch (_0x19984f[_0x2e9e0b++]) {
                case '\x30':
                    _0x530186['\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73'][_0x1086fc(0x291)] = -0x794 + 0x374 + 0x420;
                    continue;
                case '\x31':
                    _0x2c3b95[_0x1086fc(0x426)](_0x2f2db7, _0x412e14);
                    continue;
                case '\x32':
                    _0x2c3b95[_0x1086fc(0x24a)](_0x38a474, _0x1ad4be, _0x2c3b95[_0x1086fc(0x2e0)], _0x2c3b95[_0x1086fc(0x346)], _0x1086fc(0x403), -0x63b * -0x5e + 0x2b36a + -0x6 * 0x8a4b);
                    continue;
                case '\x33':
                    _0x2c3b95[_0x1086fc(0x373)](_0x548f90, _0x411f4f, _0x2c3b95[_0x1086fc(0x2e5)], _0x2c3b95[_0x1086fc(0x2ab)], _0x2c3b95[_0x1086fc(0x3e2)], -0x4de1 * 0x4 + -0x7 * 0x72a3 + 0x6194b);
                    continue;
                case '\x34':
                    _0x59aa7e = _0x1086fc(0x43c);
                    continue;
                }
                break;
            }
        } else
            StruggleProgress = -0x1ea9 + 0x1f * 0x6e + -0x11d4 * -0x1;
    }), _0x2c3b95['\x45\x6a\x6b\x44\x59'](GM_registerMenuCommand, _0x2c99c6(0x3bd), () => {
        const _0x40835e = _0x2c99c6;
        SkillProgress(_0x2c3b95[_0x40835e(0x2ae)], 0x2577e + -0x20e * -0xb1 + -0x203da);
    }), _0x2c3b95['\x57\x47\x4f\x6c\x49'](GM_registerMenuCommand, _0x2c3b95['\x78\x54\x4a\x7a\x48'], () => {
        const _0x3f6ae6 = _0x2c99c6;
        _0x2c3b95[_0x3f6ae6(0x439)](SkillProgress, _0x2c3b95['\x70\x6b\x6f\x46\x59'], -0x11 * 0x2d06 + -0x1a39 * 0x12 + 0x694ba);
    }), _0x2c3b95[_0x2c99c6(0x439)](GM_registerMenuCommand, _0x2c3b95[_0x2c99c6(0x3c5)], () => {
        const _0x1ed8da = _0x2c99c6;
        _0x2c3b95['\x4b\x79\x6b\x48\x67'](SkillProgress, _0x2c3b95[_0x1ed8da(0x40e)], -0x2b435 + -0x743a + 0x4e7c1);
    }), _0x2c3b95[_0x2c99c6(0x236)](GM_registerMenuCommand, _0x2c3b95[_0x2c99c6(0x44e)], () => {
        const _0x3f342d = _0x2c99c6;
        _0x2c3b95['\x46\x79\x56\x6e\x59'](SkillProgress, _0x2c3b95[_0x3f342d(0x1f8)], 0x524e * -0x7 + 0x7c49 * 0x5 + 0x19207);
    }), _0x2c3b95['\x74\x6a\x6d\x58\x6f'](GM_registerMenuCommand, _0x2c3b95[_0x2c99c6(0x470)], () => {
        const _0x3a85fc = _0x2c99c6;
        Player[_0x3a85fc(0x3d8)][_0x3a85fc(0x1e3)] = 0x72 + -0x11d + 0xab;
    }), _0x2c3b95[_0x2c99c6(0x41d)](GM_registerMenuCommand, _0x2c99c6(0x269), () => {
        const _0x3a2001 = _0x2c99c6;
        _0x2c3b95[_0x3a2001(0x248)](SkillProgress, _0x2c3b95['\x4a\x51\x49\x4a\x42'], 0x18 * -0x150a + -0x13655 + 0x4ee97);
    }), _0x2c3b95[_0x2c99c6(0x2c8)](GM_registerMenuCommand, _0x2c3b95[_0x2c99c6(0x456)], () => {
        const _0x46f444 = _0x2c99c6;
        SkillProgress(_0x2c3b95[_0x46f444(0x2a1)], 0x3d * -0x8e + -0x477e + 0x228a6);
    }), _0x2c3b95['\x6f\x56\x43\x6c\x72'](GM_registerMenuCommand, _0x2c99c6(0x1d8), () => {
        _0x2c3b95['\x4b\x79\x6b\x48\x67'](SkillProgress, _0x2c3b95['\x6d\x6f\x5a\x73\x53'], -0x5bec * -0x3 + -0x1 * 0x24891 + -0x2f41f * -0x1);
    }), _0x2c3b95[_0x2c99c6(0x2c8)](GM_registerMenuCommand, _0x2c99c6(0x1db), () => {
        const _0x303721 = _0x2c99c6;
        _0x2c3b95[_0x303721(0x224)](InventoryWear, Player, _0x303721(0x3bf), _0x2c3b95[_0x303721(0x37e)], _0x2c3b95[_0x303721(0x3e2)], -0x1c87 * 0x10 + -0x2a084 + -0xb2 * -0x8db), _0x2c3b95[_0x303721(0x40c)](InventoryWear, Player, _0x2c3b95[_0x303721(0x343)], _0x303721(0x287), _0x2c3b95[_0x303721(0x3e2)], 0x30a67 + -0x1828 * 0x17 + 0xe083), InventoryWear(Player, _0x2c3b95[_0x303721(0x3e4)], '\x49\x74\x65\x6d\x54\x6f\x72\x73\x6f', _0x2c3b95[_0x303721(0x3e2)], 0x10539 * -0x1 + 0x26f * 0xe + 0x2a279), _0x2c3b95['\x6a\x79\x66\x47\x6f'](InventoryWear, Player, _0x2c3b95[_0x303721(0x1e9)], _0x303721(0x3fb), _0x2c3b95['\x66\x65\x4d\x67\x4e'], -0x18726 + 0x2e972 + -0x7e * -0xbd), InventoryWear(Player, '\x43\x6f\x6c\x6c\x61\x72\x43\x68\x61\x69\x6e\x4c\x6f\x6e\x67', _0x2c3b95['\x66\x68\x66\x77\x59'], _0x2c3b95['\x66\x65\x4d\x67\x4e'], 0x261d2 + 0xa9dc + 0x3bc * -0x59), InventoryWear(Player, _0x303721(0x2d4), _0x303721(0x2fb), _0x2c3b95[_0x303721(0x3e2)], 0xc0f5 + -0x19cc9 * 0x1 + 0x29b26), _0x2c3b95[_0x303721(0x224)](InventoryWear, Player, _0x303721(0x480), _0x2c3b95[_0x303721(0x2ab)], _0x2c3b95[_0x303721(0x3e2)], 0x34999 + -0x2d0d1 + 0x1468a), _0x2c3b95[_0x303721(0x326)](InventoryWear, Player, _0x2c3b95[_0x303721(0x2e0)], _0x2c3b95[_0x303721(0x346)], _0x2c3b95[_0x303721(0x3e2)], -0x16c00 + -0x46eb * 0xb + -0xbf * -0x855), InventoryWear(Player, _0x2c3b95['\x49\x44\x6e\x46\x4a'], _0x2c3b95[_0x303721(0x2bf)], '\x23\x32\x30\x32\x30\x32\x30', -0x4485 + 0x2296c * -0x1 + -0x42d43 * -0x1);
    }), _0x2c3b95[_0x2c99c6(0x31b)](GM_registerMenuCommand, _0x2c3b95[_0x2c99c6(0x375)], () => {
        const _0x2d401b = _0x2c99c6;
        InventoryWear(Player, _0x2d401b(0x368), _0x2c3b95[_0x2d401b(0x2cb)]);
    }), _0x2c3b95[_0x2c99c6(0x404)](GM_registerMenuCommand, _0x2c3b95[_0x2c99c6(0x25c)], () => {
        const _0x593a6a = _0x2c99c6;
        !(Player[_0x593a6a(0x2db)] && Player['\x4f\x77\x6e\x65\x72\x73\x68\x69\x70'][_0x593a6a(0x30a)] == '\x61\x77\x61\x71\x77\x71') && CharacterReleaseTotal(Player);
    }), _0x2c3b95[_0x2c99c6(0x36a)](GM_registerMenuCommand, _0x2c99c6(0x472), () => {
        const _0x17bbe6 = _0x2c99c6;
        _0x2c3b95[_0x17bbe6(0x302)] === _0x17bbe6(0x420) ? ServerSend(_0x2c3b95[_0x17bbe6(0x237)], {
            '\x43\x6f\x6e\x74\x65\x6e\x74': _0x17bbe6(0x2b5),
            '\x54\x79\x70\x65': _0x2c3b95['\x48\x74\x77\x6a\x63'],
            '\x54\x61\x72\x67\x65\x74': null,
            '\x44\x69\x63\x74\x69\x6f\x6e\x61\x72\x79': [{
                    '\x54\x61\x67': _0x2c3b95['\x52\x4f\x4e\x45\x50'],
                    '\x54\x65\x78\x74': _0x2c3b95['\x4b\x79\x6b\x48\x67'](prompt, _0x2c3b95[_0x17bbe6(0x25e)], _0x2c3b95['\x59\x52\x68\x43\x6c'])
                }]
        }) : (_0x12462d = _0x10f55b(_0x2c3b95['\x6c\x6c\x4e\x59\x44'], _0x2c3b95[_0x17bbe6(0x2eb)]), _0x1efe48 = _0xccb1d4[_0x17bbe6(0x39b)](_0x1d6a6c), _0x76a4b4 == -(-0x24ee + -0x19 * -0x15e + 0x2c1) && _0x407114(_0x17bbe6(0x2da)), _0x1c107c['\x73\x70\x6c\x69\x63\x65'](_0x39e57d, 0x2 * -0x16e + 0x25db + -0x22fe));
    }), _0x2c3b95[_0x2c99c6(0x41d)](GM_registerMenuCommand, _0x2c99c6(0x3d9), () => {
        const _0x32ac8d = _0x2c99c6, _0x5497ed = {
                '\x61\x4e\x73\x47\x45': function (_0x50e9e6, _0x2952f9, _0x306ff9, _0x102ae7, _0xa38942, _0x12c083) {
                    const _0x451fa8 = _0x3c03;
                    return _0x2c3b95[_0x451fa8(0x467)](_0x50e9e6, _0x2952f9, _0x306ff9, _0x102ae7, _0xa38942, _0x12c083);
                },
                '\x6b\x4f\x55\x56\x58': '\x42\x69\x74\x63\x68\x53\x75\x69\x74',
                '\x5a\x4e\x6d\x6f\x59': _0x2c3b95[_0x32ac8d(0x346)],
                '\x73\x4a\x66\x63\x74': _0x2c3b95[_0x32ac8d(0x3e2)],
                '\x63\x6c\x6d\x4c\x68': function (_0x385c46, _0x431497) {
                    const _0x37faa8 = _0x32ac8d;
                    return _0x2c3b95[_0x37faa8(0x2e8)](_0x385c46, _0x431497);
                },
                '\x4c\x41\x79\x77\x56': _0x2c3b95[_0x32ac8d(0x235)]
            };
        targetName = _0x2c3b95[_0x32ac8d(0x297)](prompt, _0x2c3b95[_0x32ac8d(0x40d)], _0x32ac8d(0x1f4)), targetMember = Character[_0x32ac8d(0x418)](_0x5477a5 => _0x5477a5[_0x32ac8d(0x30a)][_0x32ac8d(0x33f)]() == targetName);
        if (_0x2c3b95[_0x32ac8d(0x365)](targetMember, null)) {
            if (_0x2c3b95[_0x32ac8d(0x255)](_0x2c3b95[_0x32ac8d(0x317)], _0x32ac8d(0x411)))
                return;
            else
                _0x5497ed[_0x32ac8d(0x3ac)](_0x444f12, _0x5e0c40, _0x5497ed[_0x32ac8d(0x2de)], _0x5497ed[_0x32ac8d(0x2d5)], _0x5497ed[_0x32ac8d(0x28d)], 0x1546f + -0x4ac1 + 0xb5a4), _0x40a3b6[_0x32ac8d(0x3ae)][_0x32ac8d(0x291)] = 0x1ff9 + 0x16 * 0x8 + 0x20a9 * -0x1, _0x5497ed[_0x32ac8d(0x230)](_0x4e1583, _0x27189a), _0x4a18b4 = _0x5497ed['\x4c\x41\x79\x77\x56'];
        }
        _0x2c3b95['\x68\x62\x43\x57\x78'](CharacterReleaseTotal, targetMember), targetMember[_0x32ac8d(0x3ae)][_0x32ac8d(0x291)] = 0x65e + 0x1 * 0x18e1 + 0x13 * -0x1a5, _0x2c3b95[_0x32ac8d(0x2f4)](ChatRoomCharacterUpdate, targetMember);
    }), _0x2c3b95[_0x2c99c6(0x453)](GM_registerMenuCommand, _0x2c3b95[_0x2c99c6(0x1e7)], () => {
        const _0x3cae78 = _0x2c99c6, _0x399f81 = {
                '\x52\x51\x54\x56\x63': function (_0x138834, _0x1d2942) {
                    const _0x422ee6 = _0x3c03;
                    return _0x2c3b95[_0x422ee6(0x2d3)](_0x138834, _0x1d2942);
                },
                '\x72\x63\x6a\x74\x77': function (_0x2598ec, _0x441a4f) {
                    return _0x2c3b95['\x58\x4b\x4e\x61\x41'](_0x2598ec, _0x441a4f);
                },
                '\x42\x55\x4a\x51\x4c': _0x2c3b95[_0x3cae78(0x309)]
            };
        if (_0x2c3b95[_0x3cae78(0x21b)](_0x2c3b95[_0x3cae78(0x2b4)], _0x2c3b95[_0x3cae78(0x2b4)]))
            _0x399f81[_0x3cae78(0x2ad)](_0x24e1f6, _0x49acd2), _0x504515[_0x3cae78(0x3ae)]['\x50\x72\x6f\x67\x72\x65\x73\x73'] = 0x193 * 0x9 + 0x747 + -0x393 * 0x6, _0x399f81[_0x3cae78(0x3e0)](_0x30c6c1, _0x596373), _0x207641 = _0x399f81[_0x3cae78(0x331)];
        else {
            const _0x31792e = _0x2c3b95[_0x3cae78(0x320)][_0x3cae78(0x3d0)]('\x7c');
            let _0x899bd9 = 0x1 * -0x325 + -0xe8f + 0x11b4;
            while (!![]) {
                switch (_0x31792e[_0x899bd9++]) {
                case '\x30':
                    if (!(Player['\x4f\x77\x6e\x65\x72\x73\x68\x69\x70'] && _0x2c3b95[_0x3cae78(0x47d)](Player[_0x3cae78(0x2db)][_0x3cae78(0x30a)], _0x3cae78(0x1f4)))) {
                        if (_0x2c3b95[_0x3cae78(0x392)](Player[_0x3cae78(0x30a)], _0x3cae78(0x1f4))) {
                            _0x2c3b95['\x61\x69\x69\x6d\x6b'](alert, _0x3cae78(0x33d));
                            return;
                        }
                    }
                    continue;
                case '\x31':
                    _0x2c3b95[_0x3cae78(0x461)](InventoryWear, targetMember, _0x2c3b95[_0x3cae78(0x2e5)], _0x2c3b95['\x57\x46\x56\x4a\x6c'], _0x2c3b95[_0x3cae78(0x3e2)], 0x417 * -0x5d + -0x6 * 0x7a23 + 0x6187f * 0x1);
                    continue;
                case '\x32':
                    targetMember[_0x3cae78(0x3ae)][_0x3cae78(0x291)] = 0x21a * 0x6 + 0x90d + -0x15a9;
                    continue;
                case '\x33':
                    targetMember = Character['\x66\x69\x6e\x64'](_0x2efa2b => _0x2efa2b[_0x3cae78(0x30a)][_0x3cae78(0x33f)]() == targetName);
                    continue;
                case '\x34':
                    InventoryWear(targetMember, _0x2c3b95['\x42\x70\x47\x66\x57'], _0x2c3b95['\x69\x7a\x42\x79\x6d'], _0x2c3b95[_0x3cae78(0x3e2)], 0x1 * -0x2061c + 0x1b * -0x201b + 0x7283d);
                    continue;
                case '\x35':
                    if (targetMember == null)
                        return;
                    continue;
                case '\x36':
                    _0x2c3b95[_0x3cae78(0x391)](ChatRoomCharacterUpdate, targetMember);
                    continue;
                case '\x37':
                    targetName = prompt(_0x3cae78(0x26c), _0x2c3b95['\x6d\x55\x54\x45\x42']);
                    continue;
                }
                break;
            }
        }
    }), GM_registerMenuCommand(_0x2c3b95[_0x2c99c6(0x468)], () => {
        const _0xcd0fbc = _0x2c99c6, _0x4f1db4 = {
                '\x52\x47\x6a\x62\x48': _0x2c3b95[_0xcd0fbc(0x237)],
                '\x6a\x51\x51\x77\x70': _0x2c3b95[_0xcd0fbc(0x46b)],
                '\x69\x66\x65\x68\x6f': function (_0x2fcc74, _0x445197, _0xcf4890) {
                    return _0x2c3b95['\x45\x6a\x6b\x44\x59'](_0x2fcc74, _0x445197, _0xcf4890);
                },
                '\x59\x50\x6b\x4a\x4e': _0x2c3b95[_0xcd0fbc(0x25e)],
                '\x6e\x56\x61\x4f\x71': _0x2c3b95[_0xcd0fbc(0x412)],
                '\x76\x6b\x6c\x7a\x48': _0xcd0fbc(0x33d),
                '\x46\x6f\x6e\x4b\x46': function (_0x345c54, _0x28f43f) {
                    const _0xbc3f48 = _0xcd0fbc;
                    return _0x2c3b95[_0xbc3f48(0x365)](_0x345c54, _0x28f43f);
                },
                '\x79\x55\x6b\x75\x51': function (_0x827f64, _0x563723) {
                    return _0x827f64 === _0x563723;
                },
                '\x6a\x69\x41\x6c\x64': _0x2c3b95[_0xcd0fbc(0x28a)],
                '\x57\x48\x67\x64\x64': _0xcd0fbc(0x20b),
                '\x65\x58\x76\x71\x6e': function (_0x1be622, _0x253bad) {
                    const _0x3a32e9 = _0xcd0fbc;
                    return _0x2c3b95[_0x3a32e9(0x303)](_0x1be622, _0x253bad);
                },
                '\x73\x76\x72\x46\x66': '\x4c\x6f\x63\x6b',
                '\x56\x75\x69\x5a\x75': _0x2c3b95[_0xcd0fbc(0x333)],
                '\x4d\x71\x62\x78\x57': _0x2c3b95[_0xcd0fbc(0x318)],
                '\x6a\x56\x63\x6a\x47': function (_0x30d7c9, _0x4bf49c) {
                    const _0x45c38 = _0xcd0fbc;
                    return _0x2c3b95[_0x45c38(0x3b8)](_0x30d7c9, _0x4bf49c);
                },
                '\x6f\x65\x4f\x61\x57': '\x6c\x6b\x52\x62\x49'
            };
        if (!(Player[_0xcd0fbc(0x2db)] && _0x2c3b95['\x6f\x41\x76\x4b\x59'](Player['\x4f\x77\x6e\x65\x72\x73\x68\x69\x70'][_0xcd0fbc(0x30a)], _0x2c3b95['\x6d\x55\x54\x45\x42']))) {
            if (_0x2c3b95['\x4a\x76\x59\x52\x52'](Player[_0xcd0fbc(0x30a)], _0x2c3b95['\x6d\x55\x54\x45\x42'])) {
                if (_0x2c3b95[_0xcd0fbc(0x255)](_0x2c3b95[_0xcd0fbc(0x393)], _0x2c3b95[_0xcd0fbc(0x393)])) {
                    _0x2c3b95[_0xcd0fbc(0x349)](alert, _0x2c3b95[_0xcd0fbc(0x20a)]);
                    return;
                } else
                    _0xb5701a[_0xcd0fbc(0x38b)][_0xcd0fbc(0x3ab)] = _0x2c3b95['\x66\x62\x76\x46\x65'];
            }
        }
        targetName = _0x2c3b95[_0xcd0fbc(0x236)](prompt, _0x2c3b95['\x70\x72\x6b\x4f\x6a'], _0xcd0fbc(0x1f4)), targetMember = Character[_0xcd0fbc(0x418)](_0x3679b8 => _0x3679b8[_0xcd0fbc(0x30a)][_0xcd0fbc(0x33f)]() == targetName);
        if (_0x2c3b95[_0xcd0fbc(0x306)](targetMember, null))
            return;
        targetMember[_0xcd0fbc(0x265)][_0xcd0fbc(0x204)](_0x3a66a6 => {
            const _0x3fc2bd = _0xcd0fbc, _0x58e18e = {};
            _0x58e18e[_0x3fc2bd(0x3ed)] = _0x4f1db4[_0x3fc2bd(0x1dc)];
            const _0x5c120d = _0x58e18e;
            let _0x10682a = 0x8c6 + 0x255a + 0xf6 * -0x30;
            if (_0x3a66a6[_0x3fc2bd(0x3d8)] > -0x68 + -0x29 * 0x69 + -0x1 * -0x1139) {
                if (_0x4f1db4[_0x3fc2bd(0x437)](_0x3a66a6['\x50\x72\x6f\x70\x65\x72\x74\x79'], null)) {
                    if (_0x4f1db4[_0x3fc2bd(0x2be)](_0x4f1db4[_0x3fc2bd(0x2fd)], _0x4f1db4[_0x3fc2bd(0x364)])) {
                        _0x317cce(_0x5c120d[_0x3fc2bd(0x3ed)]);
                        return;
                    } else
                        _0x3a66a6[_0x3fc2bd(0x38b)] = {};
                }
                _0x4f1db4[_0x3fc2bd(0x437)](_0x3a66a6[_0x3fc2bd(0x38b)][_0x3fc2bd(0x217)], null) && (_0x3a66a6['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x3fc2bd(0x217)] = []), _0x4f1db4[_0x3fc2bd(0x1d7)](_0x3a66a6[_0x3fc2bd(0x38b)][_0x3fc2bd(0x217)]['\x69\x6e\x64\x65\x78\x4f\x66'](_0x4f1db4['\x73\x76\x72\x46\x66']), -0x1 * 0x135e + 0x52 * 0x6 + 0x1172) && (_0x4f1db4[_0x3fc2bd(0x2be)](_0x4f1db4[_0x3fc2bd(0x3dc)], _0x4f1db4[_0x3fc2bd(0x3dc)]) ? _0x3a66a6[_0x3fc2bd(0x38b)][_0x3fc2bd(0x217)][_0x3fc2bd(0x222)](_0x4f1db4[_0x3fc2bd(0x3b0)]) : _0x7734ac[_0x3fc2bd(0x3d8)][_0x3fc2bd(0x1e3)] = 0x1b70 + 0x70f * 0x4 + -0x37ac), Math['\x72\x61\x6e\x64\x6f\x6d']() > -0x1cd3 + 0x5a1 + -0xb99 * -0x2 + 0.5 ? _0x3a66a6['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x3fc2bd(0x3ab)] = _0x4f1db4[_0x3fc2bd(0x32e)] : _0x4f1db4[_0x3fc2bd(0x3b4)](_0x4f1db4[_0x3fc2bd(0x316)], _0x4f1db4[_0x3fc2bd(0x316)]) ? _0xd32043(_0x4f1db4[_0x3fc2bd(0x3ef)], {
                    '\x43\x6f\x6e\x74\x65\x6e\x74': _0x4f1db4[_0x3fc2bd(0x3e1)],
                    '\x54\x79\x70\x65': _0x3fc2bd(0x482),
                    '\x54\x61\x72\x67\x65\x74': null,
                    '\x44\x69\x63\x74\x69\x6f\x6e\x61\x72\x79': [{
                            '\x54\x61\x67': _0x3fc2bd(0x2b5),
                            '\x54\x65\x78\x74': _0x4f1db4[_0x3fc2bd(0x289)](_0x48f384, _0x4f1db4[_0x3fc2bd(0x2cf)], _0x4f1db4[_0x3fc2bd(0x23e)])
                        }]
                }) : _0x3a66a6[_0x3fc2bd(0x38b)]['\x4c\x6f\x63\x6b\x65\x64\x42\x79'] = '\x50\x61\x6e\x64\x6f\x72\x61\x50\x61\x64\x6c\x6f\x63\x6b', _0x3a66a6['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x3fc2bd(0x357)] = Player['\x4d\x65\x6d\x62\x65\x72\x4e\x75\x6d\x62\x65\x72'], targetMember[_0x3fc2bd(0x265)][_0x10682a] = _0x3a66a6;
            }
            _0x10682a++;
        }), targetMember[_0xcd0fbc(0x3ae)][_0xcd0fbc(0x291)] = -0x2399 + 0x459 + 0x1f40, ChatRoomCharacterUpdate(targetMember);
    }), GM_registerMenuCommand(_0x2c3b95[_0x2c99c6(0x39d)], () => {
        const _0x5d6744 = _0x2c99c6;
        _0x2c3b95[_0x5d6744(0x444)](ReputationChange, prompt(_0x2c3b95['\x72\x67\x65\x7a\x4e'], _0x5d6744(0x1de)), 0x1 * -0x2d13c + 0xa43 * 0x13 + 0x99 * 0x65d, !![]);
    });
}()));
function _0x139c() {
    const _0x32c153 = [
        '\x5a\x61\x76\x41\x74',
        '\x57\x46\x56\x4a\x6c',
        '\x4c\x76\x52\x6a\x43',
        '\x52\x51\x54\x56\x63',
        '\x76\x4c\x4f\x49\x56',
        '\x58\x64\x41\x61\x73',
        '\x47\x46\x47\x55\x78',
        '\x78\x59\x41\x4e\x76',
        '\x41\x73\x20\x75\x20\x77\x69\x73\x68\x7e\x28\x4d\x61\x6b\x65\x20\x73\x75\x72\x65\x20\x75\x20\x72\x20\x6e\x6f\x74\x20\x6f\x77\x6e\x65\x72\x2f\x6c\x6f\x76\x65\x72\x20\x6c\x6f\x63\x6b\x65\x64\x20\x26\x20\x68\x61\x76\x65\x20\x70\x65\x72\x6d\x69\x74\x74\x65\x64\x20\x6d\x65\x29',
        '\x49\x74\x65\x6d\x42\x6f\x6f\x74\x73',
        '\x78\x4e\x4b\x79\x57',
        '\x42\x65\x65\x70',
        '\x30\x7c\x35\x7c\x37\x7c\x34\x7c\x31\x7c\x32\x7c\x33\x7c\x36',
        '\x52\x5a\x54\x5a\x5a',
        '\x59\x6b\x6f\x44\x72',
        '\x69\x53\x53\x56\x6e',
        '\x53\x79\x4f\x4f\x6c',
        '\x4f\x6e\x6c\x69\x6e\x65',
        '\x54\x67\x63\x73\x77',
        '\x68\x68\x67\x41\x73',
        '\x79\x55\x6b\x75\x51',
        '\x4e\x7a\x61\x58\x71',
        '\x77\x48\x7a\x4c\x49',
        '\x49\x64\x6a\x50\x61',
        '\x61\x66\x4e\x71\x4b',
        '\x6d\x65\x6f\x77\x7e\x28\x4d\x61\x6b\x65\x20\x73\x75\x72\x65\x20\x75\x20\x68\x61\x76\x65\x20\x70\x65\x72\x6d\x69\x74\x74\x65\x64\x20\x6d\x65\x29',
        '\x72\x44\x41\x70\x73',
        '\x72\x53\x6a\x75\x7a',
        '\x31\x34\x30\x4c\x55\x45\x66\x46\x6e',
        '\x77\x6c\x66\x57\x4b',
        '\x70\x72\x4e\x64\x4a',
        '\x53\x56\x78\x67\x54',
        '\x5a\x64\x41\x76\x57',
        '\x73\x6c\x55\x52\x45',
        '\x72\x61\x6e\x64\x6f\x6d',
        '\x4d\x69\x73\x74\x72\x65\x73\x73\x50\x61\x64\x6c\x6f\x63\x6b',
        '\x78\x6d\x45\x6e\x55',
        '\x59\x50\x6b\x4a\x4e',
        '\x74\x49\x4d\x72\x62',
        '\x6c\x4a\x55\x45\x66',
        '\x50\x75\x70\x67\x44',
        '\x52\x61\x78\x72\x51',
        '\x4c\x65\x61\x74\x68\x65\x72\x42\x65\x6c\x74',
        '\x5a\x4e\x6d\x6f\x59',
        '\x65\x72\x72\x6f\x72',
        '\x72\x56\x4f\x6c\x44',
        '\x52\x78\x77\x69\x46',
        '\x56\x6a\x6c\x77\x6d',
        '\u5c01\u7981\u5931\u8d25\x3a\u73a9\u5bb6\u6ca1\u6709\u88ab\u5c01\u7981',
        '\x4f\x77\x6e\x65\x72\x73\x68\x69\x70',
        '\x75\x58\x68\x6e\x57',
        '\x7b\x7d\x2e\x63\x6f\x6e\x73\x74\x72\x75\x63\x74\x6f\x72\x28\x22\x72\x65\x74\x75\x72\x6e\x20\x74\x68\x69\x73\x22\x29\x28\x20\x29',
        '\x6b\x4f\x55\x56\x58',
        '\x5a\x53\x4e\x4d\x72',
        '\x42\x70\x47\x66\x57',
        '\x73\x61\x65\x50\x61',
        '\x41\x4a\x66\x73\x43',
        '\x72\x65\x6c\x65\x61\x73\x65',
        '\x73\x53\x4f\x79\x74',
        '\x76\x47\x6e\x75\x77',
        '\x55\x4f\x63\x63\x4c',
        '\x45\x50\x4f\x58\x42',
        '\x68\x49\x54\x77\x47',
        '\x6b\x44\x64\x5a\x6f',
        '\x75\x76\x41\x62\x73',
        '\x6d\x55\x54\x45\x42',
        '\u81ea\u5df1\u5220\u6389\u4e0d\u5bf9\u7684\x2c\x20\u8f93\u9519\u4e86\u540e\u679c\u81ea\u8d1f\x21',
        '\x4b\x46\x4e\x50\x69',
        '\x57\x50\x69\x72\x70',
        '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68',
        '\x49\x74\x65\x6d\x44\x65\x76\x69\x63\x65\x73',
        '\x4f\x4e\x6c\x62\x64',
        '\x6c\x55\x50\x66\x6b',
        '\x6d\x54\x70\x6a\x54',
        '\x71\x41\x7a\x56\x5a',
        '\x4b\x73\x4f\x4b\x69',
        '\x7a\x56\x7a\x4d\x51',
        '\x4d\x4c\x74\x43\x48',
        '\x66\x55\x50\x79\x56',
        '\x32\x7c\x34\x7c\x35\x7c\x30\x7c\x31\x7c\x33',
        '\x4d\x4a\x4d\x74\x66',
        '\x49\x74\x65\x6d\x4c\x65\x67\x73',
        '\x6d\x69\x70\x63\x4b',
        '\x6a\x69\x41\x6c\x64',
        '\x79\x62\x4e\x66\x77',
        '\u672a\u77e5\u6307\u4ee4\uff01\x20\u53ef\u7528\u6307\u4ee4\x3a\x20\u6346\u6211\x20\u6346\u6b7b\u6211\x20\u8214\u6211\x20\u6551\u6211\x20\u73a9\u6211\x20\u9501\u6211\x20\u5173\u4e8e\x20\u5982\u679c\u4e00\u53e5\u8bdd\u540c\u65f6\u5305\u542b\x22\x61\x77\u9171\x22\u548c\u6307\u4ee4\uff0c\u6307\u4ee4\u5c31\u4f1a\u88ab\u6267\u884c\x7e',
        '\x63\x63\x4e\x6c\x51',
        '\x51\x50\x6b\x57\x77',
        '\x45\x68\x5a\x76\x6d',
        '\x50\x54\x6f\x4c\x73',
        '\x74\x79\x47\x68\x5a',
        '\u963f\u62c9\u970d\u6d1e\u5f00',
        '\x74\x6b\x58\x6e\x4a',
        '\x46\x6e\x66\x5a\x65',
        '\x72\x49\x54\x58\x70',
        '\x42\x41\x61\x5a\x61',
        '\x4e\x61\x6d\x65',
        '\x70\x59\x75\x49\x72',
        '\x6b\x67\x4e\x59\x71',
        '\x45\x64\x74\x75\x4a',
        '\x64\x49\x69\x6f\x4c',
        '\x49\x4a\x73\x69\x71',
        '\u62ff\u7bb1\u5b50',
        '\x7a\x5a\x4d\x4d\x58',
        '\x4d\x63\x5a\x7a\x6f',
        '\x62\x59\x79\x65\x42',
        '\x77\x50\x54\x54\x44',
        '\x59\x73\x73\x6c\x75',
        '\x6f\x65\x4f\x61\x57',
        '\x6a\x48\x68\x45\x4b',
        '\x66\x62\x76\x46\x65',
        '\x35\x31\x32\x6a\x53\x50\x6b\x75\x72',
        '\x76\x48\x59\x54\x47',
        '\x65\x4f\x5a\x46\x68',
        '\x56\x6f\x46\x49\x47',
        '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68\x33',
        '\x70\x4f\x59\x6e\x4f',
        '\x45\x4c\x50\x49\x5a',
        '\x58\x72\x43\x54\x64',
        '\x63\x6f\x6e\x73\x74\x72\x75\x63\x74\x6f\x72',
        '\x71\x63\x63\x44\x42',
        '\x70\x57\x62\x6c\x6a',
        '\x74\x50\x41\x54\x76',
        '\x61\x77\x77\x74\x64',
        '\x6b\x6c\x64\x57\x73',
        '\x61\x77\x42\x4f\x54\x5f\u5c01\u7981',
        '\x49\x74\x65\x6d\x56\x75\x6c\x76\x61',
        '\x57\x48\x4d\x54\x43',
        '\x6c\x48\x52\x68\x42',
        '\x57\x48\x79\x54\x6d',
        '\x72\x57\x74\x64\x70',
        '\x56\x55\x59\x49\x53',
        '\x4d\x71\x62\x78\x57',
        '\x61\x49\x4d\x66\x75',
        '\x43\x72\x75\x49\x76',
        '\x42\x55\x4a\x51\x4c',
        '\x75\x78\x6f\x63\x4b',
        '\x4b\x64\x6c\x45\x56',
        '\x31\x39\x36\x32\x30\x39\x39\x6c\x57\x51\x66\x71\x62',
        '\x6d\x77\x72\x54\x5a',
        '\x43\x6e\x58\x66\x6d',
        '\x47\x64\x4d\x65\x61',
        '\x30\x7c\x37\x7c\x33\x7c\x35\x7c\x34\x7c\x31\x7c\x32\x7c\x36',
        '\x45\x65\x73\x68\x61',
        '\x6f\x6a\x78\x55\x55',
        '\x6c\x54\x78\x41\x7a',
        '\x7a\x50\x79\x73\x6f',
        '\u4f60\u5fc5\u987b\u662f\x61\x77\x61\x71\x77\x71\u7684\x73\x75\x62\u624d\u80fd\u8fd9\u4e48\u505a\u5462\x7e',
        '\x61\x6f\x4f\x6c\x67',
        '\x74\x6f\x4c\x6f\x77\x65\x72\x43\x61\x73\x65',
        '\x5a\x74\x71\x45\x6a',
        '\x43\x46\x63\x63\x44',
        '\x6b\x4e\x71\x50\x58',
        '\x66\x51\x65\x72\x6f',
        '\x41\x62\x4c\x4b\x70',
        '\x77\x48\x47\x70\x69',
        '\x69\x7a\x42\x79\x6d',
        '\x51\x58\x4c\x52\x55',
        '\x53\x67\x78\x44\x4c',
        '\x59\x79\x47\x72\x66',
        '\x73\x66\x58\x49\x76',
        '\x53\x76\x4c\x50\x53',
        '\x76\x61\x6b\x46\x67',
        '\x7a\x4b\x4b\x6e\x45',
        '\x54\x4d\x4f\x48\x56',
        '\x58\x6d\x4a\x44\x53',
        '\u95e8\u94a5\u5319',
        '\x78\x6a\x58\x61\x4a',
        '\x62\x76\x71\x61\x49',
        '\x4e\x6b\x57\x59\x71',
        '\x4e\x66\x79\x6b\x71',
        '\x67\x75\x51\x4d\x79',
        '\x41\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x2d\x77\x6f\x72\x64\x73\x3a\x72\x65\x6c\x65\x61\x73\x65\x2c\x62\x6f\x6e\x64\x61\x67\x65\x2c\x70\x6c\x61\x79\x73\x75\x69\x74\x2c\x6c\x6f\x63\x6b\x2c\x61\x62\x6f\x75\x74\x2c\x6c\x69\x63\x6b\x2c\x72\x61\x6e\x64\x6f\x6d\x2c\x62\x61\x6e\x6d\x65\x28\x74\x6f\x20\x67\x65\x74\x20\x73\x74\x75\x63\x6b\x2c\x75\x73\x65\x20\x74\x68\x69\x73\x20\x61\x66\x74\x65\x72\x20\x72\x61\x6e\x64\x6f\x6d\x20\x61\x6e\x64\x20\x6c\x6f\x63\x6b\x2e\x29\x2e\x49\x66\x20\x61\x20\x73\x65\x6e\x74\x65\x6e\x63\x65\x20\x69\x6e\x63\x6c\x75\x64\x69\x6e\x67\x20\x22\x61\x77\x71\x22\x20\x61\x6e\x64\x20\x74\x68\x65\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x2d\x77\x6f\x72\x64\x28\x69\x2e\x65\x2e\x20\x72\x61\x6e\x64\x6f\x6d\x2c\x20\x72\x65\x6c\x65\x61\x73\x65\x2c\x20\x62\x61\x6e\x6d\x65\x2c\x20\x61\x6e\x64\x20\x73\x6f\x20\x6f\x6e\x29\x20\x61\x74\x20\x74\x68\x65\x20\x73\x61\x6d\x65\x20\x74\x69\x6d\x65\x2c\x20\x74\x68\x65\x6e\x20\x74\x68\x65\x20\x63\x6f\x72\x72\x65\x73\x70\x6f\x6e\x64\x69\x6e\x67\x20\x61\x63\x74\x69\x6f\x6e\x20\x77\x69\x6c\x6c\x20\x62\x65\x20\x74\x61\x6b\x65\x6e\x2e',
        '\x4c\x6f\x63\x6b\x4d\x65\x6d\x62\x65\x72\x4e\x75\x6d\x62\x65\x72',
        '\x71\x4e\x49\x6d\x6a',
        '\x76\x45\x4e\x78\x4e',
        '\x4e\x6a\x53\x63\x48',
        '\x4d\x74\x43\x6b\x4e',
        '\x65\x41\x45\x6a\x65',
        '\x54\x4f\x4e\x59\x6c',
        '\x6f\x6c\x65\x68\x6a',
        '\x53\x42\x4f\x48\x6e',
        '\x61\x6b\x79\x65\x74',
        '\u63d0\u5347\u5185\u9b3c\u7b49\u7ea7',
        '\x6a\x62\x55\x5a\x4c',
        '\x6d\x70\x49\x6b\x53',
        '\x57\x48\x67\x64\x64',
        '\x6f\x41\x76\x4b\x59',
        '\x42\x77\x79\x72\x69',
        '\x67\x74\x42\x45\x71',
        '\x42\x6f\x75\x6e\x74\x79\x53\x75\x69\x74\x63\x61\x73\x65',
        '\x59\x5a\x65\x67\x71',
        '\x43\x42\x76\x41\x6c',
        '\x43\x68\x61\x74',
        '\x58\x63\x71\x73\x44',
        '\x62\x58\x64\x75\x69',
        '\x67\x70\x78\x4a\x72',
        '\x62\x61\x6e\x6d\x65',
        '\x64\x69\x43\x6f\x6f',
        '\x69\x6e\x66\x6f',
        '\x6a\x69\x4a\x50\x6b',
        '\x6d\x4c\x61\x4e\x4e',
        '\x47\x50\x59\x6d\x6e',
        '\x44\x6e\x58\x54\x70',
        '\x69\x4e\x5a\x44\x58',
        '\x4e\x68\x61\x46\x79',
        '\x49\x74\x65\x6d\x41\x72\x6d\x73',
        '\x48\x4e\x69\x41\x4e',
        '\x6e\x4a\x4a\x65\x67',
        '\x49\x74\x65\x6d\x48\x61\x6e\x64\x73',
        '\x57\x73\x78\x51\x4c',
        '\x41\x53\x76\x4b\x58',
        '\x54\x59\x6d\x47\x54',
        '\x6f\x64\x52\x66\x6b',
        '\x6b\x71\x79\x52\x6e',
        '\x4c\x65\x61\x74\x68\x65\x72\x48\x6f\x6f\x64\x4f\x70\x65\x6e\x4d\x6f\x75\x74\x68',
        '\x45\x76\x61\x73\x69\x6f\x6e',
        '\x50\x4c\x55\x66\x7a',
        '\x46\x48\x58\x42\x4c',
        '\x4d\x4b\x72\x48\x6d',
        '\x61\x77\u9171',
        '\x6f\x55\x58\x4e\x53',
        '\x78\x53\x57\x77\x46',
        '\x67\x49\x70\x55\x4a',
        '\x49\x74\x65\x6d\x4e\x65\x63\x6b\x41\x63\x63\x65\x73\x73\x6f\x72\x69\x65\x73',
        '\x50\x72\x6f\x70\x65\x72\x74\x79',
        '\x4a\x45\x67\x53\x49',
        '\x53\x6c\x50\x42\x4b',
        '\x7a\x43\x48\x61\x65',
        '\x58\x58\x77\x42\x4e',
        '\x47\x77\x56\x57\x50',
        '\x6c\x56\x68\x57\x56',
        '\x53\x46\x58\x61\x77',
        '\x52\x67\x58\x76\x6f',
        '\x67\x66\x45\x63\x67',
        '\x6b\x71\x76\x4b\x62',
        '\x56\x52\x75\x49\x4e',
        '\x7a\x6d\x72\x46\x66',
        '\x45\x76\x6d\x67\x78',
        '\x6a\x4a\x70\x61\x6c',
        '\x61\x58\x46\x5a\x62',
        '\x69\x6e\x64\x65\x78\x4f\x66',
        '\x74\x6f\x53\x74\x72\x69\x6e\x67',
        '\x4b\x51\x6f\x6b\x42',
        '\x6e\x4c\x49\x58\x6d',
        '\x53\x65\x6c\x66\x42\x6f\x6e\x64\x61\x67\x65',
        '\x49\x74\x65\x6d\x48\x6f\x6f\x64',
        '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68\x32',
        '\x4f\x48\x6a\x76\x73',
        '\x61\x70\x70\x6c\x79',
        '\x6c\x73\x77\x66\x6e',
        '\x4f\x52\x72\x64\x70',
        '\x49\x74\x65\x6d\x50\x65\x6c\x76\x69\x73',
        '\x68\x58\x71\x65\x4c',
        '\x4f\x6e\x4d\x58\x72',
        '\x57\x61\x76\x41\x4c',
        '\x6f\x51\x64\x70\x6f',
        '\x4c\x6f\x63\x6b\x65\x64\x42\x79',
        '\x61\x4e\x73\x47\x45',
        '\x50\x45\x45\x62\x79',
        '\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73',
        '\x41\x77\x71',
        '\x73\x76\x72\x46\x66',
        '\x71\x41\x56\x6a\x6a',
        '\x46\x4e\x4a\x4f\x68',
        '\x7a\x70\x71\x6e\x59',
        '\x6a\x56\x63\x6a\x47',
        '\x4c\x65\x61\x74\x68\x65\x72\x48\x61\x72\x6e\x65\x73\x73',
        '\u6346\u6b7b\u6211',
        '\x6c\x65\x6e\x67\x74\x68',
        '\x55\x57\x4d\x56\x78',
        '\x79\x71\x44\x59\x63',
        '\x58\x44\x6f\x75\x65',
        '\x49\x43\x6b\x67\x57',
        '\x62\x71\x65\x6e\x4e',
        '\u63d0\u5347\u6346\u7ed1\u7b49\u7ea7',
        '\x68\x46\x42\x48\x71',
        '\x57\x69\x66\x66\x6c\x65\x47\x61\x67',
        '\x49\x74\x65\x6d\x54\x6f\x72\x73\x6f',
        '\x49\x74\x65\x6d\x42\x75\x74\x74',
        '\x61\x47\x64\x69\x43',
        '\x6b\x76\x58\x51\x51',
        '\x4c\x6f\x63\x6b\x50\x69\x63\x6b\x69\x6e\x67',
        '\x6c\x69\x4e\x62\x58',
        '\x6c\x6f\x63\x6b',
        '\x69\x75\x45\x5a\x46',
        '\u901f\u901f\u7ed1\u7f1a\x28\u641e\u4e8b\u60c5\u4e13\u7528\x29',
        '\x6f\x56\x43\x6c\x72',
        '\x43\x43\x4b\x47\x57',
        '\x66\x45\x6c\x4e\x67',
        '\x62\x69\x6e\x64',
        '\x74\x72\x55\x65\x48',
        '\x4a\x49\x7a\x59\x55',
        '\x4d\x4b\x55\x56\x67',
        '\x73\x70\x6c\x69\x74',
        '\x4f\x48\x78\x50\x72',
        '\x50\x61\x6e\x64\x6f\x72\x61\x50\x61\x64\x6c\x6f\x63\x6b',
        '\u7b11\x7e\x20\x28\u5e38\u89c1\u95ee\u9898\x3a\u8bf7\u5f00\u6743\u9650\x29\x7e',
        '\x42\x62\x76\x75\x61',
        '\x73\x51\x46\x4b\x75',
        '\x41\x6f\x74\x47\x50',
        '\x77\x66\x58\x4d\x43',
        '\x44\x69\x66\x66\x69\x63\x75\x6c\x74\x79',
        '\u5e7b\u5f71\u79fb\u5f62\x28\u80fd\u7ed9\u522b\u4eba\u5f00\u9501\x29',
        '\x67\x53\x4e\x78\x67',
        '\x7a\x56\x57\x52\x71',
        '\x56\x75\x69\x5a\x75',
        '\x44\x6c\x57\x4e\x6b',
        '\x6c\x4a\x5a\x72\x76',
        '\x41\x62\x51\x47\x45',
        '\x72\x63\x6a\x74\x77',
        '\x6a\x51\x51\x77\x70',
        '\x66\x65\x4d\x67\x4e',
        '\x43\x49\x6c\x4a\x77',
        '\x46\x45\x54\x52\x69',
        '\x4d\x47\x65\x72\x48',
        '\x61\x77\x42\x4f\x54\x20\x43\x61\x53\x65\x20\x53\x65\x4e\x73\x49\x74\x49\x76\x45\x21',
        '\x75\x66\x6e\x68\x4d',
        '\x32\x33\x35\x30\x35\x31\x36\x45\x7a\x49\x71\x68\x62',
        '\x68\x6c\x6c\x48\x6b',
        '\x69\x6d\x43\x56\x7a',
        '\x42\x6f\x6e\x64\x61\x67\x65',
        '\x71\x42\x49\x64\x59',
        '\x45\x78\x4c\x51\x6a',
        '\x6e\x68\x41\x4e\x69',
        '\x52\x47\x6a\x62\x48',
        '\x43\x64\x61\x54\x52',
        '\x75\x4b\x79\x4c\x4c',
        '\x6d\x4c\x50\x45\x51',
        '\x52\x78\x69\x65\x48',
        '\x6a\x42\x5a\x74\x70',
        '\x74\x6b\x55\x69\x4f',
        '\x4c\x49\x4f\x73\x75',
        '\u5982\u4f60\u6240\u613f\x20\x28\u5e38\u89c1\u95ee\u9898\x3a\u8bf7\u5f00\u6743\u9650\x29\x7e',
        '\x45\x49\x51\x79\x4b',
        '\x49\x74\x65\x6d\x4e\x69\x70\x70\x6c\x65\x73\x50\x69\x65\x72\x63\x69\x6e\x67\x73',
        '\x45\x68\x73\x47\x79',
        '\x49\x74\x65\x6d\x4e\x65\x63\x6b',
        '\x72\x51\x4d\x46\x74',
        '\x68\x67\x65\x5a\x53',
        '\x53\x63\x72\x69\x70\x74\x20\x6d\x61\x64\x65\x20\x62\x79\x3a\x61\x77\x61\x71\x77\x71\x5f\x68\x75\x7a\x70\x73\x62',
        '\x53\x74\x65\x65\x6c\x50\x6f\x73\x74\x75\x72\x65\x43\x6f\x6c\x6c\x61\x72',
        '\x44\x72\x65\x73\x73\x61\x67\x65',
        '\x75\x47\x6c\x41\x68',
        '\x71\x48\x5a\x67\x4e',
        '\x23\x32\x30\x32\x30\x32\x30',
        '\x58\x67\x63\x66\x66',
        '\x6c\x6f\x79\x51\x65',
        '\x4c\x65\x61\x74\x68\x65\x72\x41\x72\x6d\x62\x69\x6e\x64\x65\x72',
        '\x72\x52\x6e\x46\x4f',
        '\x32\x7c\x33\x7c\x30\x7c\x31\x7c\x34',
        '\x4f\x52\x4c\x50\x75',
        '\x44\x4e\x6c\x78\x7a',
        '\x50\x79\x73\x76\x46',
        '\x4d\x45\x52\x6a\x75',
        '\x66\x7a\x50\x47\x6f',
        '\x6d\x6b\x7a\x73\x63',
        '\x66\x58\x43\x6d\x61',
        '\x43\x68\x61\x74\x53\x65\x61\x72\x63\x68',
        '\x7a\x46\x66\x6b\x41',
        '\x59\x52\x68\x43\x6c',
        '\x44\x43\x56\x49\x48',
        '\x58\x6d\x67\x77\x62',
        '\x7a\x41\x53\x68\x54',
        '\x69\x61\x47\x63\x6f',
        '\x65\x66\x66\x75\x6d',
        '\x66\x69\x6e\x64',
        '\x45\x6e\x53\x51\x6a',
        '\x68\x47\x72\x4c\x75',
        '\x78\x70\x63\x51\x79',
        '\x64\x42\x5a\x4f\x62',
        '\x48\x65\x45\x7a\x70',
        '\x64\x49\x62\x66\x4c',
        '\x6a\x46\x77\x6d\x68',
        '\x45\x79\x49\x57\x50',
        '\x49\x64\x58\x6c\x72',
        '\x69\x73\x68\x66\x76',
        '\u8981\u5c01\u7981\u7684\u73a9\u5bb6\u540d\u79f0',
        '\x61\x77\x42\x4f\x54',
        '\x63\x4a\x55\x69\x67',
        '\x6c\x6d\x71\x49\x78',
        '\x6c\x69\x63\x6b\x73\x20',
        '\x75\x54\x79\x6f\x68',
        '\x4a\x66\x77\x43\x6c',
        '\x41\x4a\x79\x4f\x75',
        '\x73\x78\x6f\x54\x72',
        '\x4f\x57\x47\x46\x70',
        '\x58\x58\x6a\x6a\x62',
        '\x32\x34\x38\x38\x34\x34\x52\x41\x45\x45\x44\x74',
        '\x4d\x65\x6d\x62\x65\x72\x4e\x75\x6d\x62\x65\x72',
        '\x59\x47\x6f\x4d\x66',
        '\x6f\x72\x69\x52\x46',
        '\x4f\x58\x6b\x75\x51',
        '\x72\x54\x41\x56\x76',
        '\x54\x64\x56\x79\x71',
        '\x46\x4b\x62\x6a\x6e',
        '\x72\x42\x6a\x54\x48',
        '\x46\x6f\x6e\x4b\x46',
        '\x46\x63\x61\x51\x56',
        '\x45\x58\x72\x70\x41',
        '\x72\x65\x74\x75\x72\x6e\x20\x28\x66\x75\x6e\x63\x74\x69\x6f\x6e\x28\x29\x20',
        '\x31\x39\x32\x32\x30\x68\x64\x59\x78\x52\x53',
        '\x41\x73\x20\x75\x20\x77\x69\x73\x68\x7e\x28\x4d\x61\x6b\x65\x20\x73\x75\x72\x65\x20\x75\x20\x68\x61\x76\x65\x20\x70\x65\x72\x6d\x69\x74\x74\x65\x64\x20\x6d\x65\x29',
        '\x4f\x57\x51\x78\x46',
        '\x55\x51\x69\x70\x6a',
        '\x70\x48\x4e\x54\x61',
        '\x45\x6c\x6b\x6b\x73',
        '\x56\x6f\x68\x4f\x6d',
        '\x48\x52\x70\x41\x53',
        '\x72\x4f\x78\x4b\x64',
        '\x69\x61\x71\x47\x64',
        '\x7a\x6e\x7a\x4c\x4f',
        '\x6f\x52\x75\x47\x44',
        '\u4e0a\u9501\x28\u641e\u4e8b\u60c5\u4e13\u7528\x29',
        '\x4f\x45\x49\x79\x44',
        '\x5a\x54\x61\x6c\x6c',
        '\x78\x6e\x64\x75\x49',
        '\x42\x73\x49\x78\x50',
        '\x42\x50\x79\x6f\x72',
        '\x77\x6f\x77\x6f\x62',
        '\x4d\x73\x6d\x49\x77',
        '\x70\x72\x6f\x74\x6f\x74\x79\x70\x65',
        '\x74\x66\x67\x44\x61',
        '\u83b7\u53d6\u7bb1\u5b50',
        '\x54\x48\x59\x57\x54',
        '\x46\x50\x4c\x63\x54',
        '\x49\x47\x6d\x67\x71',
        '\x67\x72\x4f\x6a\x65',
        '\x4a\x6c\x79\x79\x54',
        '\x54\x78\x44\x48\x42',
        '\x50\x46\x6c\x4d\x67',
        '\x6e\x52\x41\x71\x68',
        '\x61\x77\x42\x4f\x54\x20',
        '\x7a\x76\x44\x5a\x77',
        '\x4b\x5a\x6d\x53\x66',
        '\x77\x51\x71\x41\x6d',
        '\x6c\x77\x63\x75\x78',
        '\x4c\x6f\x63\x6b',
        '\x4f\x67\x71\x42\x71',
        '\x4b\x50\x78\x46\x64',
        '\x61\x4a\x52\x62\x57',
        '\x64\x53\x44\x4a\x54',
        '\x57\x69\x6c\x6c\x70\x6f\x77\x65\x72',
        '\x59\x68\x4f\x6b\x46',
        '\x68\x76\x69\x59\x4b',
        '\x61\x73\x76\x53\x75',
        '\x4b\x6c\x57\x4d\x78',
        '\x54\x54\x45\x46\x69',
        '\x4f\x41\x71\x4b\x56',
        '\x52\x4f\x4e\x45\x50',
        '\u8981\u4e0a\u9501\u7684\u73a9\u5bb6\u540d\u79f0\x28\u5168\u5c0f\u5199\x29',
        '\x62\x43\x70\x64\x63',
        '\x4a\x45\x47\x48\x4b',
        '\x53\x4e\x75\x79\x52',
        '\x6c\x62\x68\x68\x53',
        '\x53\x6f\x6b\x70\x56',
        '\u58f0\u97f3\u6d2a\u4eae\x28\u8bf4\u4ec0\u4e48\u5c31\u662f\u4ec0\u4e48\x29',
        '\x5a\x47\x76\x43\x79',
        '\x63\x4a\x52\x6c\x51',
        '\x50\x61\x64\x64\x65\x64\x4d\x69\x74\x74\x65\x6e\x73',
        '\x51\x46\x48\x42\x54',
        '\x52\x49\x63\x45\x64',
        '\x47\x51\x62\x4d\x50',
        '\x75\x6b\x73\x46\x4e',
        '\x7a\x6e\x65\x41\x73',
        '\x44\x46\x4e\x71\x76',
        '\u63d0\u5347\u81ea\u7f1a\u7b49\u7ea7',
        '\x41\x44\x79\x51\x65',
        '\x6d\x6c\x4b\x78\x4f',
        '\x41\x73\x20\x75\x20\x77\x69\x73\x68\x7e\x28\x47\x6f\x6f\x64\x20\x6c\x75\x63\x6b\x21\x29',
        '\x49\x72\x69\x73\x68\x38\x43\x75\x66\x66\x73',
        '\x62\x73\x63\x74\x76',
        '\x41\x63\x74\x69\x6f\x6e',
        '\x6c\x73\x44\x79\x46',
        '\x5a\x51\x41\x49\x4f',
        '\x43\x5a\x50\x73\x67',
        '\x65\x58\x76\x71\x6e',
        '\u63d0\u5347\u7740\u88c5\u7b49\u7ea7',
        '\x46\x7a\x79\x65\x4a',
        '\x6e\x4d\x6c\x4f\x4a',
        '\u901f\u901f\u81ea\u7f1a',
        '\x76\x6b\x6c\x7a\x48',
        '\x5f\x5f\x70\x72\x6f\x74\x6f\x5f\x5f',
        '\x44\x6f\x6d\x69\x6e\x61\x6e\x74\x20\x20\x4b\x69\x64\x6e\x61\x70\x20\x20\x41\x42\x44\x4c\x20\x20\x47\x61\x6d\x69\x6e\x67\x20\x20\x4d\x61\x69\x64\x20\x20\x4c\x41\x52\x50\x20\x20\x41\x73\x79\x6c\x75\x6d\x20\x20\x47\x61\x6d\x62\x6c\x69\x6e\x67\x20\x20\x48\x6f\x75\x73\x65\x4d\x61\x69\x65\x73\x74\x61\x73\x20\x20\x48\x6f\x75\x73\x65\x56\x69\x6e\x63\x75\x6c\x61\x20\x20\x48\x6f\x75\x73\x65\x41\x6d\x70\x6c\x65\x63\x74\x6f\x72\x20\x20\x48\x6f\x75\x73\x65\x43\x6f\x72\x70\x6f\x72\x69\x73',
        '\x49\x53\x42\x7a\x50',
        '\x45\x77\x52\x57\x67',
        '\x58\x6d\x46\x58\x7a',
        '\x66\x75\x68\x49\x6e',
        '\x4c\x61\x73\x74\x43\x68\x61\x6e\x67\x65',
        '\x77\x52\x4b\x4a\x63',
        '\x49\x74\x65\x6d\x4d\x69\x73\x63',
        '\x4d\x61\x69\x6e\x48\x61\x6c\x6c',
        '\x68\x71\x6d\x78\x47',
        '\x4d\x51\x67\x77\x6b',
        '\x4a\x46\x53\x6e\x7a',
        '\x48\x68\x64\x7a\x4f',
        '\x64\x53\x4a\x6e\x73',
        '\x43\x69\x66\x50\x4f',
        '\x6f\x57\x64\x4a\x6e',
        '\x63\x73\x56\x46\x48',
        '\x6c\x49\x42\x6e\x42',
        '\x6a\x6a\x56\x61\x4c',
        '\x32\x37\x34\x34\x31\x39\x65\x45\x6d\x65\x76\x70',
        '\x65\x78\x63\x65\x70\x74\x69\x6f\x6e',
        '\x51\x45\x59\x5a\x72',
        '\x61\x77\x61\x71\x77\x71',
        '\x76\x7a\x55\x47\x6f',
        '\x4e\x64\x6a\x70\x71',
        '\x35\x39\x30\x5a\x6b\x65\x4e\x4b\x59',
        '\x42\x68\x6b\x74\x62',
        '\x6c\x6c\x4e\x59\x44',
        '\x46\x52\x5a\x71\x6f',
        '\x44\x64\x62\x4b\x4c',
        '\x5a\x70\x64\x51\x72',
        '\x5a\x6e\x55\x51\x70',
        '\x4a\x58\x6d\x4e\x68',
        '\x73\x4f\x48\x6c\x41',
        '\x33\x34\x31\x31\x30\x30\x38\x44\x64\x49\x69\x56\x64',
        '\x61\x70\x4d\x71\x71',
        '\x63\x6f\x6e\x73\x6f\x6c\x65',
        '\x4e\x62\x74\x68\x62',
        '\x66\x6f\x72\x45\x61\x63\x68',
        '\x74\x4e\x6d\x4d\x71',
        '\x76\x62\x66\x45\x54',
        '\x49\x6e\x66\x69\x6c\x74\x72\x61\x74\x69\x6f\x6e',
        '\x75\x4e\x4b\x58\x5a',
        '\x6c\x6f\x67',
        '\x45\x69\x6d\x4f\x4d',
        '\x6e\x77\x78\x49\x70',
        '\x62\x6c\x49\x6a\x4e',
        '\x44\x56\x42\x4a\x6e',
        '\x4f\x71\x6b\x74\x52',
        '\x4d\x56\x41\x79\x48',
        '\x52\x6f\x44\x48\x4c',
        '\x49\x44\x6e\x46\x4a',
        '\x54\x54\x4d\x78\x66',
        '\x4e\x6d\x6e\x6b\x61',
        '\x6b\x74\x76\x64\x41',
        '\x52\x47\x66\x52\x71',
        '\x70\x6f\x77\x61\x42',
        '\x45\x66\x66\x65\x63\x74',
        '\x76\x31\x2e\x30\x35\x20\x62\x79\x20\x41\x77\u9171\x20\u5728\x61\x77\x61\x71\x77\x71\u7684\u4e2a\u4eba\u7b80\u4ecb\u91cc\u9762\u6709\u4e0b\u8f7d\u94fe\u63a5\u7684\u8bf4\x7e',
        '\x68\x58\x6e\x65\x48',
        '\x66\x77\x54\x77\x61',
        '\x61\x41\x67\x77\x5a',
        '\x63\x51\x57\x75\x6a',
        '\x6f\x47\x7a\x54\x45',
        '\x61\x77\x42\x4f\x54\x5f\u89e3\u5c01',
        '\u53e3\u7403\x6c\x76',
        '\x41\x63\x74\x5a\x59',
        '\x45\x75\x54\x59\x51',
        '\x70\x75\x73\x68',
        '\x63\x5a\x4b\x55\x71',
        '\x6d\x6f\x5a\x6f\x45',
        '\x46\x57\x71\x4d\x6c',
        '\x57\x74\x73\x63\x65',
        '\x67\x56\x5a\x6d\x6a',
        '\x72\x49\x4c\x44\x6b',
        '\x75\x71\x4b\x6f\x41',
        '\x45\x4d\x50\x4c\x77',
        '\u8981\u89e3\u5c01\u7684\u73a9\u5bb6\u540d\u79f0',
        '\x43\x68\x61\x74\x52\x6f\x6f\x6d\x43\x68\x61\x74',
        '\x55\x7a\x7a\x6b\x58',
        '\x61\x77\x71',
        '\x54\x42\x54\x74\x45',
        '\x63\x6c\x6d\x4c\x68',
        '\x71\x6b\x70\x4c\x6a',
        '\x65\x4d\x70\x4f\x6a',
        '\x67\x5a\x70\x54\x66',
        '\x4e\x79\x45\x51\x71',
        '\x4e\x75\x68\x50\x4e',
        '\x4b\x79\x6b\x48\x67',
        '\x65\x4c\x45\x56\x66',
        '\x61\x47\x46\x70\x6e',
        '\x70\x6f\x54\x67\x51',
        '\x65\x73\x4b\x54\x70',
        '\x61\x55\x51\x67\x47',
        '\x57\x79\x78\x61\x65',
        '\x52\x55\x77\x6b\x6c',
        '\x6e\x56\x61\x4f\x71',
        '\x78\x55\x6d\x4f\x53',
        '\x67\x67\x73\x4e\x4b',
        '\x47\x64\x4c\x71\x74',
        '\u5927\u7b11\x7e\x20\x28\u987a\u624b\u62d6\u5165\u5c01\u7981\u540d\u5355\x29\x7e',
        '\x67\x64\x65\x54\x69',
        '\x56\x71\x63\x61\x45',
        '\u58f0\u540d\u8fdc\u626c\x28\u4fee\u6539\u5404\u7c7b\u58f0\u8a89\x29',
        '\x6d\x6d\x4c\x4e\x77',
        '\u548c\u6211\u7b7e\u8ba2\u5951\u7ea6\uff0c\u6210\u4e3a\u9b54\u6cd5\u5c11\u5973\u5427\uff01',
        '\x57\x47\x4f\x6c\x49',
        '\x4f\x6b\x70\x4b\x46',
        '\x6a\x79\x69\x41\x77',
        '\x49\x74\x65\x6d\x46\x65\x65\x74',
        '\x56\x44\x67\x69\x78',
        '\x70\x6b\x6f\x46\x59',
        '\x76\x51\x74\x55\x65',
        '\x5a\x57\x4b\x6b\x49',
        '\x74\x43\x4d\x74\x6c',
        '\x75\x43\x51\x45\x62',
        '\x6a\x44\x50\x47\x4e',
        '\x49\x74\x65\x6d\x56\x75\x6c\x76\x61\x50\x69\x65\x72\x63\x69\x6e\x67\x73',
        '\x77\x61\x72\x6e',
        '\x72\x48\x5a\x69\x54',
        '\u5982\u4f60\u6240\u613f\x20\x28\u5e38\u89c1\u95ee\u9898\x3a\u4e0d\u89e3\u4e3b\u4eba\x2f\u604b\u4eba\x2c\u8bf7\u5f00\u6743\u9650\x29\x7e',
        '\x69\x57\x69\x4f\x59',
        '\x76\x71\x50\x53\x74',
        '\u4f60\u8981\u8bf4\u7684\u8bdd',
        '\x74\x61\x62\x6c\x65',
        '\x58\x6a\x69\x4e\x4e',
        '\x75\x46\x43\x73\x67',
        '\x73\x70\x6c\x69\x63\x65',
        '\x52\x54\x79\x4c\x50',
        '\x58\x6c\x69\x6f\x6a',
        '\x4f\x67\x61\x6e\x72',
        '\x71\x4d\x6a\x50\x74',
        '\x4c\x6c\x68\x51\x42',
        '\x4d\x53\x7a\x51\x6a',
        '\x74\x63\x54\x6d\x55',
        '\x41\x70\x70\x65\x61\x72\x61\x6e\x63\x65',
        '\x45\x42\x54\x52\x6c',
        '\x42\x49\x59\x55\x4d',
        '\x69\x53\x6a\x47\x74',
        '\u63d0\u5347\u786c\u6491\u7b49\u7ea7',
        '\x53\x6d\x6c\x74\x55',
        '\x4a\x63\x46\x77\x78',
        '\u8981\u6346\u7684\u73a9\u5bb6\u540d\u79f0\x28\u5168\u5c0f\u5199\x29',
        '\x43\x6f\x6c\x6c\x61\x72\x43\x68\x61\x69\x6e\x4c\x6f\x6e\x67',
        '\x6e\x7a\x78\x73\x78',
        '\x5a\x50\x5a\x79\x6c',
        '\x6d\x5a\x63\x5a\x45',
        '\x75\x68\x4b\x77\x4d',
        '\x76\x49\x55\x6a\x4c',
        '\x64\x6f\x63\x76\x4b',
        '\x79\x55\x49\x6c\x51',
        '\x54\x44\x5a\x45\x4f',
        '\x65\x74\x45\x4b\x76',
        '\x61\x41\x69\x6f\x4a',
        '\u83b7\u5f97\u96f6\u82b1\u94b1',
        '\x67\x6b\x6c\x41\x49',
        '\x51\x53\x6d\x6f\x59',
        '\x64\x78\x4a\x6a\x79',
        '\x49\x74\x65\x6d\x42\x72\x65\x61\x73\x74',
        '\x4c\x75\x4c\x41\x53',
        '\x52\x4e\x6c\x68\x57',
        '\x5a\x41\x6d\x75\x68',
        '\x58\x64\x4b\x55\x50',
        '\u79fb\u9664\u6781\u9650\x43\x44\x28\u5fc5\u987b\u65b0\u5207\x52\x50\u540e\u7528\x29',
        '\x73\x6b\x42\x46\x7a',
        '\x79\x46\x50\x54\x54',
        '\x4f\x57\x6c\x41\x54',
        '\x73\x42\x59\x4c\x45',
        '\x49\x74\x65\x6d\x4e\x6f\x73\x65',
        '\x49\x74\x65\x6d\x48\x65\x61\x64',
        '\x35\x31\x39\x39\x79\x55\x42\x6a\x4f\x72',
        '\x69\x66\x65\x68\x6f',
        '\x59\x4b\x58\x73\x58',
        '\x48\x6b\x61\x44\x6c',
        '\x58\x63\x70\x61\x72',
        '\x73\x4a\x66\x63\x74',
        '\x5a\x64\x6e\x68\x62',
        '\x49\x54\x57\x75\x61',
        '\x4c\x4c\x52\x68\x4d',
        '\x50\x72\x6f\x67\x72\x65\x73\x73',
        '\x69\x47\x66\x71\x6e',
        '\x76\x6c\x45\x4a\x46',
        '\x43\x4a\x64\x47\x75',
        '\x5a\x4a\x48\x54\x41',
        '\x49\x74\x65\x6d\x45\x61\x72\x73',
        '\x51\x49\x4a\x75\x64',
        '\x61\x4d\x67\x51\x76',
        '\x43\x68\x61\x74\x52\x6f\x6f\x6d\x4c\x65\x61\x76\x65',
        '\x53\x4d\x7a\x74\x4f',
        '\x74\x72\x61\x63\x65',
        '\x7a\x63\x53\x48\x6a',
        '\x72\x71\x41\x72\x77',
        '\x4f\x44\x6f\x6d\x70',
        '\x45\x6a\x6b\x44\x59',
        '\x78\x77\x6d\x53\x64',
        '\x45\x7a\x56\x70\x53',
        '\x47\x64\x56\x63\x78',
        '\x4e\x47\x69\x76\x74',
        '\x7a\x64\x6c\x4a\x59',
        '\x4f\x64\x4c\x66\x67',
        '\x75\x65\x45\x47\x62',
        '\x58\x76\x6e\x6a\x71',
        '\x53\x49\x6f\x5a\x6b',
        '\x77\x77\x75\x65\x45'
    ];
    _0x139c = function () {
        return _0x32c153;
    };
    return _0x139c();
}