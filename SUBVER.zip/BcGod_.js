// ==UserScript==
// @name BcGod_
// @description BC RP模式增强~
// @version 1.07a
// @namespace awaqwq_huzpsb
// @match *://*/*BondageClub*
// @grant GM_registerMenuCommand
// ==/UserScript==
(function (_0x393dd2, _0xd0a782) {
    const _0x49273a = _0x11fe, _0x2e1db7 = _0x393dd2();
    while (!![]) {
        try {
            const _0x49a3fd = parseInt(_0x49273a(0x2cb)) / (0x20ce + -0x1 * 0x4a6 + -0x1 * 0x1c27) + -parseInt(_0x49273a(0x3f2)) / (-0x7 * -0x347 + -0x7 * -0x247 + -0x2 * 0x1370) + -parseInt(_0x49273a(0x207)) / (0xc * -0xe5 + -0x3de + 0x3 * 0x4df) + -parseInt(_0x49273a(0x251)) / (0x1 * 0x78d + 0x207 * -0xd + -0x16 * -0xdb) + parseInt(_0x49273a(0x349)) / (-0x144 * 0xd + -0x2 * 0x959 + 0x232b) * (-parseInt(_0x49273a(0x3b8)) / (-0x58 * 0x12 + 0x3 * 0xbb9 + 0x7 * -0x423)) + parseInt(_0x49273a(0x3eb)) / (-0x304 * 0x5 + -0xef4 + 0x1e0f) + -parseInt(_0x49273a(0x348)) / (0x22ef + -0x2 * -0x713 + -0x310d);
            if (_0x49a3fd === _0xd0a782)
                break;
            else
                _0x2e1db7['push'](_0x2e1db7['shift']());
        } catch (_0x26c337) {
            _0x2e1db7['push'](_0x2e1db7['shift']());
        }
    }
}(_0xbe11, -0x4 * -0x42787 + 0x771c8 + 0xe6d5e * -0x1), (function () {
    const _0x38d56a = _0x11fe, _0x14ee2f = {
            '\x4d\x76\x50\x64\x51': function (_0x1b5b11, _0x32f4e6) {
                return _0x1b5b11(_0x32f4e6);
            },
            '\x6d\x58\x6c\x72\x58': function (_0x8fff90, _0x3262d8) {
                return _0x8fff90(_0x3262d8);
            },
            '\x50\x4c\x44\x49\x4c': '\x41\x73\x20\x75\x20\x77\x69\x73\x68\x7e\x28\x4d\x61\x6b\x65\x20\x73\x75\x72\x65\x20\x75\x20\x72\x20\x6e\x6f\x74\x20\x6f\x77\x6e\x65\x72\x2f\x6c\x6f\x76\x65\x72\x20\x6c\x6f\x63\x6b\x65\x64\x20\x26\x20\x68\x61\x76\x65\x20\x70\x65\x72\x6d\x69\x74\x74\x65\x64\x20\x6d\x65\x29',
            '\x6c\x69\x75\x65\x44': _0x38d56a(0x1e7),
            '\x5a\x42\x66\x59\x4a': _0x38d56a(0x183),
            '\x73\x62\x55\x52\x4c': function (_0x262367, _0x238570) {
                return _0x262367 !== _0x238570;
            },
            '\x71\x45\x54\x63\x66': function (_0x169968, _0x5d93ca) {
                return _0x169968 !== _0x5d93ca;
            },
            '\x69\x78\x61\x69\x6b': _0x38d56a(0x17f),
            '\x77\x4a\x63\x48\x43': function (_0x4c87cb, _0x1b4a60) {
                return _0x4c87cb(_0x1b4a60);
            },
            '\x79\x47\x45\x78\x47': function (_0x18084f, _0x17cbef) {
                return _0x18084f + _0x17cbef;
            },
            '\x52\x75\x44\x41\x49': _0x38d56a(0x1ee),
            '\x5a\x49\x74\x47\x58': _0x38d56a(0x3e8),
            '\x6e\x44\x48\x4e\x53': '\x4f\x53\x44\x73\x70',
            '\x69\x75\x77\x79\x71': _0x38d56a(0x276),
            '\x6f\x76\x48\x4c\x6f': function (_0x53c268) {
                return _0x53c268();
            },
            '\x46\x50\x75\x48\x6c': _0x38d56a(0x30f),
            '\x55\x68\x4b\x6a\x43': _0x38d56a(0x1b3),
            '\x4e\x75\x77\x76\x57': _0x38d56a(0x324),
            '\x52\x65\x45\x78\x6c': _0x38d56a(0x34a),
            '\x77\x63\x67\x6e\x68': _0x38d56a(0x3ec),
            '\x46\x79\x4d\x78\x67': function (_0x7ec515, _0x563ca4, _0xe51366) {
                return _0x7ec515(_0x563ca4, _0xe51366);
            },
            '\x4d\x4c\x61\x78\x4c': _0x38d56a(0x1bf),
            '\x4f\x49\x78\x51\x6c': _0x38d56a(0x294),
            '\x4e\x65\x77\x43\x53': function (_0x5ba532) {
                return _0x5ba532();
            },
            '\x61\x74\x64\x4e\x6e': function (_0x122f98, _0x397957) {
                return _0x122f98 != _0x397957;
            },
            '\x53\x43\x50\x50\x41': _0x38d56a(0x36a),
            '\x4b\x75\x72\x76\x73': function (_0x57126c, _0x518d24) {
                return _0x57126c > _0x518d24;
            },
            '\x77\x41\x72\x62\x62': function (_0x526b75, _0x500cc1) {
                return _0x526b75 === _0x500cc1;
            },
            '\x42\x58\x44\x43\x6f': function (_0x70d891, _0x5d3811) {
                return _0x70d891 == _0x5d3811;
            },
            '\x7a\x62\x44\x50\x42': _0x38d56a(0x1f5),
            '\x6f\x61\x45\x58\x75': function (_0x48d9d0, _0x37fe13) {
                return _0x48d9d0 == _0x37fe13;
            },
            '\x48\x5a\x74\x51\x68': _0x38d56a(0x1e3),
            '\x76\x53\x69\x66\x6f': _0x38d56a(0x208),
            '\x54\x51\x58\x54\x4c': '\x49\x43\x56\x41\x59',
            '\x45\x59\x53\x56\x72': _0x38d56a(0x283),
            '\x69\x66\x6e\x78\x6d': function (_0x537d74, _0x5c884a) {
                return _0x537d74(_0x5c884a);
            },
            '\x44\x42\x55\x72\x6f': '\x76\x31\x2e\x30\x37\x20\x62\x79\x20\x41\x77\u9171\x20\u5728\x61\x77\x61\x71\x77\x71\u7684\u4e2a\u4eba\u7b80\u4ecb\u91cc\u9762\u6709\u4e0b\u8f7d\u94fe\u63a5\u7684\u8bf4\x7e',
            '\x67\x63\x4a\x69\x6a': function (_0x3bf84b, _0x5e4e60) {
                return _0x3bf84b > _0x5e4e60;
            },
            '\x5a\x74\x49\x76\x5a': _0x38d56a(0x310),
            '\x6f\x68\x76\x58\x63': _0x38d56a(0x260),
            '\x6c\x4b\x6c\x74\x71': _0x38d56a(0x1a4),
            '\x54\x6b\x57\x4f\x64': '\x49\x74\x65\x6d\x4d\x69\x73\x63',
            '\x43\x61\x4e\x4c\x51': _0x38d56a(0x2e2),
            '\x53\x46\x6d\x4a\x62': _0x38d56a(0x290),
            '\x4e\x50\x7a\x65\x70': function (_0xea2be, _0x4693fe) {
                return _0xea2be == _0x4693fe;
            },
            '\x77\x50\x58\x6e\x77': '\x6b\x4d\x41\x72\x55',
            '\x43\x6f\x5a\x64\x77': _0x38d56a(0x34c),
            '\x73\x6b\x59\x61\x4c': function (_0x14d0d2, _0x5afbca, _0x1712d4, _0x14c66d, _0x3b6637, _0x2a5aba) {
                return _0x14d0d2(_0x5afbca, _0x1712d4, _0x14c66d, _0x3b6637, _0x2a5aba);
            },
            '\x66\x63\x59\x42\x61': _0x38d56a(0x3db),
            '\x75\x55\x43\x6b\x78': _0x38d56a(0x2ab),
            '\x44\x56\x77\x62\x54': _0x38d56a(0x1e1),
            '\x4a\x45\x46\x4f\x50': _0x38d56a(0x22d),
            '\x70\x6c\x6f\x77\x64': '\x6c\x69\x63\x6b\x73\x20',
            '\x61\x43\x79\x67\x6a': '\x79\x53\x4e\x72\x4f',
            '\x72\x47\x42\x68\x47': _0x38d56a(0x29f),
            '\x69\x46\x4e\x69\x4f': '\u5982\u4f60\u6240\u613f\x20\x28\u5e38\u89c1\u95ee\u9898\x3a\u4e0d\u89e3\u4e3b\u4eba\x2f\u604b\u4eba\x2c\u8bf7\u5f00\u6743\u9650\x29\x7e',
            '\x67\x49\x59\x49\x64': _0x38d56a(0x33f),
            '\x59\x59\x4a\x4f\x4a': _0x38d56a(0x344),
            '\x4e\x6e\x6b\x59\x50': function (_0x5954cb, _0xde9bc7) {
                return _0x5954cb != _0xde9bc7;
            },
            '\x53\x6d\x58\x4d\x65': _0x38d56a(0x1be),
            '\x52\x76\x6f\x6e\x6c': function (_0x3bbd71, _0x575e79) {
                return _0x3bbd71 + _0x575e79;
            },
            '\x72\x51\x72\x67\x4e': function (_0x19fbed, _0x1f60e1, _0x12f99, _0x18ae46, _0x20df96, _0x50cac9) {
                return _0x19fbed(_0x1f60e1, _0x12f99, _0x18ae46, _0x20df96, _0x50cac9);
            },
            '\x62\x6d\x4b\x7a\x78': _0x38d56a(0x2e1),
            '\x42\x51\x66\x49\x71': function (_0x303a04, _0x1bce0a) {
                return _0x303a04 != _0x1bce0a;
            },
            '\x6d\x73\x4a\x49\x67': _0x38d56a(0x30b),
            '\x76\x42\x73\x46\x66': '\x49\x74\x65\x6d\x42\x72\x65\x61\x73\x74',
            '\x56\x48\x64\x65\x56': _0x38d56a(0x206),
            '\x55\x5a\x79\x6f\x63': _0x38d56a(0x3fb),
            '\x77\x57\x73\x59\x54': '\x49\x74\x65\x6d\x4c\x65\x67\x73',
            '\x6f\x52\x43\x75\x4d': _0x38d56a(0x28b),
            '\x73\x71\x6a\x4b\x6d': _0x38d56a(0x231),
            '\x54\x73\x42\x45\x6e': _0x38d56a(0x334),
            '\x49\x45\x49\x49\x64': _0x38d56a(0x191),
            '\x73\x6f\x6f\x57\x78': _0x38d56a(0x27a),
            '\x58\x47\x72\x43\x45': _0x38d56a(0x323),
            '\x47\x69\x69\x4a\x6e': _0x38d56a(0x274),
            '\x43\x58\x75\x71\x69': _0x38d56a(0x3e6),
            '\x75\x68\x4d\x47\x4b': _0x38d56a(0x26e),
            '\x70\x68\x71\x62\x6a': _0x38d56a(0x309),
            '\x63\x69\x4c\x68\x5a': _0x38d56a(0x1aa),
            '\x64\x48\x54\x46\x76': _0x38d56a(0x254),
            '\x42\x52\x49\x45\x78': '\x61\x77\x71',
            '\x57\x66\x6f\x73\x7a': _0x38d56a(0x213),
            '\x4e\x53\x48\x49\x69': function (_0x264f55, _0x1d4ca5) {
                return _0x264f55 === _0x1d4ca5;
            },
            '\x49\x57\x70\x5a\x6e': _0x38d56a(0x282),
            '\x50\x41\x71\x4d\x42': _0x38d56a(0x33e),
            '\x4a\x6e\x73\x53\x6c': _0x38d56a(0x19c),
            '\x48\x69\x54\x42\x54': _0x38d56a(0x3fc),
            '\x46\x78\x74\x66\x61': '\x76\x31\x2e\x30\x37\x20\x62\x79\x20\x68\x75\x7a\x70\x73\x62\x20\x2f\x20\x53\x72\x63\x20\x77\x69\x6c\x6c\x20\x62\x65\x20\x6f\x6e\x20\x67\x69\x74\x68\x75\x62\x20\x73\x6f\x6f\x6e',
            '\x6a\x4e\x7a\x4f\x62': _0x38d56a(0x301),
            '\x4b\x4c\x4e\x4e\x6d': function (_0x98eee3, _0x5323db) {
                return _0x98eee3 + _0x5323db;
            },
            '\x6a\x44\x66\x59\x5a': function (_0x5a4578, _0x33a0ea) {
                return _0x5a4578 != _0x33a0ea;
            },
            '\x6a\x4c\x51\x65\x54': '\x70\x6c\x61\x79\x73\x75\x69\x74',
            '\x4c\x4f\x62\x63\x4e': _0x38d56a(0x271),
            '\x6b\x53\x44\x4f\x6c': _0x38d56a(0x1b4),
            '\x6a\x67\x72\x72\x71': _0x38d56a(0x387),
            '\x64\x48\x4f\x56\x68': '\x49\x74\x65\x6d\x42\x75\x74\x74',
            '\x48\x55\x48\x51\x5a': _0x38d56a(0x3ae),
            '\x49\x72\x47\x72\x4e': _0x38d56a(0x2be),
            '\x42\x62\x61\x48\x78': _0x38d56a(0x371),
            '\x4f\x55\x58\x73\x54': _0x38d56a(0x2a3),
            '\x4f\x56\x6c\x62\x53': function (_0x2dd731, _0x2a2243, _0x1cff4f) {
                return _0x2dd731(_0x2a2243, _0x1cff4f);
            },
            '\x42\x6f\x70\x4f\x4b': function (_0x1972e3, _0x184a3c) {
                return _0x1972e3 != _0x184a3c;
            },
            '\x5a\x51\x52\x71\x6a': _0x38d56a(0x25c),
            '\x41\x59\x65\x49\x58': _0x38d56a(0x268),
            '\x5a\x74\x44\x44\x51': function (_0x468f49, _0x5ab8bf, _0x46e3dc) {
                return _0x468f49(_0x5ab8bf, _0x46e3dc);
            },
            '\x4c\x65\x4e\x53\x64': function (_0x1c5d1e, _0x2efef5) {
                return _0x1c5d1e != _0x2efef5;
            },
            '\x56\x67\x6c\x50\x46': function (_0x1fc4c4, _0x540a33) {
                return _0x1fc4c4 == _0x540a33;
            },
            '\x49\x46\x42\x4e\x74': function (_0x279dae, _0x5175c4, _0x124cd7) {
                return _0x279dae(_0x5175c4, _0x124cd7);
            },
            '\x56\x42\x6c\x66\x46': function (_0xa630ce, _0x240059) {
                return _0xa630ce + _0x240059;
            },
            '\x4f\x45\x6f\x57\x56': '\x78\x6d\x61\x76\x51',
            '\x74\x50\x61\x42\x70': function (_0x20c0af, _0x296260) {
                return _0x20c0af + _0x296260;
            },
            '\x42\x53\x67\x45\x7a': '\u53e3\u7403\x6c\x76',
            '\x4c\x6b\x63\x77\x49': function (_0x194efb, _0x15081d, _0x4b3aea) {
                return _0x194efb(_0x15081d, _0x4b3aea);
            },
            '\x50\x5a\x65\x7a\x6b': '\x61\x77\x42\x4f\x54\x20\x43\x61\x53\x65\x20\x53\x65\x4e\x73\x49\x74\x49\x76\x45\x21',
            '\x41\x6e\x76\x6d\x76': function (_0x457f89, _0x363141) {
                return _0x457f89 === _0x363141;
            },
            '\x64\x65\x4d\x47\x4b': '\x66\x51\x6e\x6d\x62',
            '\x6d\x6f\x71\x75\x5a': function (_0x44b7d8, _0x441889) {
                return _0x44b7d8 != _0x441889;
            },
            '\x5a\x61\x43\x41\x4c': function (_0x4c3922, _0x5d9dc3) {
                return _0x4c3922(_0x5d9dc3);
            },
            '\x61\x74\x67\x75\x68': _0x38d56a(0x21d),
            '\x6d\x58\x43\x70\x65': function (_0x43ae7a, _0xf570ba, _0x1b2d44, _0x4083a2) {
                return _0x43ae7a(_0xf570ba, _0x1b2d44, _0x4083a2);
            },
            '\x6e\x51\x76\x45\x43': _0x38d56a(0x36f),
            '\x46\x48\x47\x44\x71': function (_0x3f6f4f, _0x7b4d78, _0x38c80b) {
                return _0x3f6f4f(_0x7b4d78, _0x38c80b);
            },
            '\x62\x7a\x4c\x58\x79': _0x38d56a(0x1ed),
            '\x6f\x69\x5a\x4c\x42': function (_0x232a89, _0x17e1b6) {
                return _0x232a89 > _0x17e1b6;
            },
            '\x6d\x4b\x48\x63\x6c': _0x38d56a(0x333),
            '\x79\x42\x72\x61\x53': function (_0x2a5e55, _0x4ddf2a) {
                return _0x2a5e55 < _0x4ddf2a;
            },
            '\x61\x70\x41\x6b\x53': _0x38d56a(0x2ae),
            '\x78\x78\x6a\x69\x65': _0x38d56a(0x273),
            '\x78\x65\x78\x58\x53': _0x38d56a(0x2c9),
            '\x79\x67\x74\x57\x62': function (_0x269e90, _0x36fde8) {
                return _0x269e90(_0x36fde8);
            },
            '\x68\x61\x62\x45\x4d': _0x38d56a(0x2bb),
            '\x5a\x63\x5a\x6b\x59': '\x75\x54\x49\x75\x62',
            '\x42\x51\x78\x44\x47': _0x38d56a(0x2d7),
            '\x7a\x74\x45\x6b\x4d': _0x38d56a(0x1a6),
            '\x76\x43\x5a\x4a\x7a': function (_0x5a49e8, _0x26da28) {
                return _0x5a49e8(_0x26da28);
            },
            '\x78\x6c\x6b\x50\x53': function (_0x113327, _0x2554e5, _0x5a8441, _0x20df2a, _0x2b0e2e, _0x209527) {
                return _0x113327(_0x2554e5, _0x5a8441, _0x20df2a, _0x2b0e2e, _0x209527);
            },
            '\x68\x73\x6a\x4f\x72': function (_0x416a4b, _0x493b61, _0x2e312c) {
                return _0x416a4b(_0x493b61, _0x2e312c);
            },
            '\x70\x4e\x69\x79\x4a': _0x38d56a(0x266),
            '\x70\x62\x45\x51\x65': function (_0x280d15, _0x45b45a) {
                return _0x280d15 === _0x45b45a;
            },
            '\x6c\x6e\x58\x43\x6b': '\x68\x77\x70\x56\x69',
            '\x70\x44\x41\x5a\x45': _0x38d56a(0x1b7),
            '\x4b\x54\x76\x64\x77': _0x38d56a(0x403),
            '\x41\x71\x4e\x58\x43': function (_0x417434, _0x2eca2b, _0x2e1b90, _0x2249cb, _0x50bf27, _0x28ef95) {
                return _0x417434(_0x2eca2b, _0x2e1b90, _0x2249cb, _0x50bf27, _0x28ef95);
            },
            '\x66\x55\x6c\x70\x78': _0x38d56a(0x241),
            '\x68\x65\x42\x42\x77': function (_0x3c2f1a, _0x50cd4d, _0x26cb92, _0x4fcba5, _0x3ccdfc, _0x256577) {
                return _0x3c2f1a(_0x50cd4d, _0x26cb92, _0x4fcba5, _0x3ccdfc, _0x256577);
            },
            '\x74\x41\x4c\x61\x4a': function (_0x10723e, _0x2eb528, _0x3f0ff6, _0xed3fd6, _0x32c2eb, _0x2eae09) {
                return _0x10723e(_0x2eb528, _0x3f0ff6, _0xed3fd6, _0x32c2eb, _0x2eae09);
            },
            '\x61\x74\x73\x69\x4d': _0x38d56a(0x3dc),
            '\x69\x59\x44\x57\x70': '\x4c\x65\x61\x74\x68\x65\x72\x48\x61\x72\x6e\x65\x73\x73',
            '\x68\x65\x73\x43\x51': function (_0x48bee2, _0x3edd07, _0x86e52c, _0x40d294, _0x151943, _0x5d328f) {
                return _0x48bee2(_0x3edd07, _0x86e52c, _0x40d294, _0x151943, _0x5d328f);
            },
            '\x68\x59\x54\x72\x72': _0x38d56a(0x296),
            '\x5a\x70\x71\x49\x6d': _0x38d56a(0x23a),
            '\x74\x77\x69\x50\x73': _0x38d56a(0x257),
            '\x74\x4c\x6b\x47\x4f': function (_0x70d485, _0x1fe54e) {
                return _0x70d485 == _0x1fe54e;
            },
            '\x43\x4b\x56\x4f\x4a': function (_0x5752b8, _0x19d8fb) {
                return _0x5752b8 !== _0x19d8fb;
            },
            '\x71\x4a\x54\x49\x6a': _0x38d56a(0x398),
            '\x71\x51\x6e\x6c\x6a': function (_0x228f59, _0x25aab4) {
                return _0x228f59 === _0x25aab4;
            },
            '\x58\x4a\x56\x76\x52': _0x38d56a(0x17c),
            '\x63\x44\x70\x69\x62': function (_0x52139c, _0x4d27aa) {
                return _0x52139c(_0x4d27aa);
            },
            '\x51\x70\x7a\x52\x52': '\x53\x63\x72\x69\x70\x74\x20\x6d\x61\x64\x65\x20\x62\x79\x3a\x61\x77\x61\x71\x77\x71\x5f\x68\x75\x7a\x70\x73\x62',
            '\x63\x61\x4d\x67\x68': function (_0x193051, _0x52b113) {
                return _0x193051(_0x52b113);
            },
            '\x57\x6a\x63\x76\x50': _0x38d56a(0x3bc),
            '\x52\x52\x7a\x50\x75': _0x38d56a(0x2e7),
            '\x5a\x74\x79\x70\x4e': _0x38d56a(0x375),
            '\x50\x51\x69\x62\x4f': _0x38d56a(0x20e),
            '\x59\x4d\x6c\x46\x72': function (_0xf2b673, _0x5ed719) {
                return _0xf2b673(_0x5ed719);
            },
            '\x64\x64\x4e\x78\x69': function (_0x193864, _0x6e26a) {
                return _0x193864 == _0x6e26a;
            },
            '\x72\x4b\x48\x56\x59': function (_0x13cc78, _0x11e30c) {
                return _0x13cc78 === _0x11e30c;
            },
            '\x61\x50\x57\x6a\x67': _0x38d56a(0x2dd),
            '\x53\x41\x73\x49\x77': _0x38d56a(0x322),
            '\x46\x42\x70\x4a\x52': function (_0x661992) {
                return _0x661992();
            },
            '\x54\x61\x62\x53\x76': function (_0xce9920, _0x5456c5) {
                return _0xce9920(_0x5456c5);
            },
            '\x74\x72\x6d\x67\x5a': function (_0x35351f, _0x1bf857, _0x3ace4f) {
                return _0x35351f(_0x1bf857, _0x3ace4f);
            },
            '\x67\x7a\x4b\x72\x43': _0x38d56a(0x400),
            '\x41\x44\x4f\x48\x6b': function (_0x48cc38, _0x58587f) {
                return _0x48cc38 === _0x58587f;
            },
            '\x4c\x6e\x61\x74\x71': _0x38d56a(0x380),
            '\x53\x70\x4e\x71\x5a': function (_0x2e8576, _0xb976dc) {
                return _0x2e8576 === _0xb976dc;
            },
            '\x67\x49\x41\x6b\x63': _0x38d56a(0x194),
            '\x6b\x45\x64\x74\x69': _0x38d56a(0x3ff),
            '\x41\x4f\x45\x74\x50': function (_0x4eea08, _0x19b9ac, _0x2a2932) {
                return _0x4eea08(_0x19b9ac, _0x2a2932);
            },
            '\x4e\x66\x4b\x6e\x74': _0x38d56a(0x3d0),
            '\x75\x58\x72\x6c\x4d': _0x38d56a(0x225),
            '\x78\x4f\x58\x64\x4b': _0x38d56a(0x233),
            '\x54\x65\x66\x47\x59': function (_0x2ed75c, _0x5c7b67) {
                return _0x2ed75c !== _0x5c7b67;
            },
            '\x41\x7a\x63\x78\x59': _0x38d56a(0x3f4),
            '\x50\x45\x47\x4b\x78': function (_0x56563b, _0x321c7f, _0x269825) {
                return _0x56563b(_0x321c7f, _0x269825);
            },
            '\x4a\x63\x59\x66\x6e': _0x38d56a(0x218),
            '\x52\x71\x55\x76\x4a': '\x44\x72\x65\x73\x73\x61\x67\x65',
            '\x4c\x6c\x73\x76\x4b': function (_0x10ed11, _0x29c9b8) {
                return _0x10ed11 === _0x29c9b8;
            },
            '\x57\x4e\x78\x49\x66': _0x38d56a(0x2c7),
            '\x59\x57\x78\x53\x49': function (_0x4d8e7f, _0x4fae6a, _0x3c02a5, _0xa2277, _0x509a61, _0x28c465) {
                return _0x4d8e7f(_0x4fae6a, _0x3c02a5, _0xa2277, _0x509a61, _0x28c465);
            },
            '\x62\x7a\x53\x44\x58': function (_0x2391e0, _0x3333e4, _0x3442cf, _0x3df4f7, _0xaf4902, _0x3a5a45) {
                return _0x2391e0(_0x3333e4, _0x3442cf, _0x3df4f7, _0xaf4902, _0x3a5a45);
            },
            '\x41\x5a\x48\x58\x45': _0x38d56a(0x245),
            '\x6b\x72\x64\x61\x78': function (_0x468184, _0x5ed382, _0x41d1e3, _0x1cde33, _0x5e4863, _0x47f93f) {
                return _0x468184(_0x5ed382, _0x41d1e3, _0x1cde33, _0x5e4863, _0x47f93f);
            },
            '\x66\x52\x46\x66\x68': _0x38d56a(0x1b8),
            '\x4e\x75\x6a\x64\x47': function (_0x24210d, _0x490a3b, _0x1bf1f3, _0x46aac7, _0x303ede, _0x2b3805) {
                return _0x24210d(_0x490a3b, _0x1bf1f3, _0x46aac7, _0x303ede, _0x2b3805);
            },
            '\x63\x74\x54\x54\x44': function (_0x1329f4, _0x5f07e7, _0x3b6970, _0x459616, _0x5d2ac7, _0x5783c) {
                return _0x1329f4(_0x5f07e7, _0x3b6970, _0x459616, _0x5d2ac7, _0x5783c);
            },
            '\x42\x74\x41\x4a\x79': _0x38d56a(0x1e2),
            '\x49\x55\x59\x75\x52': function (_0x18071f, _0x3c3209, _0x59e87c, _0x700325) {
                return _0x18071f(_0x3c3209, _0x59e87c, _0x700325);
            },
            '\x78\x4a\x43\x44\x71': function (_0x1d27be, _0x1b1036, _0x32988b) {
                return _0x1d27be(_0x1b1036, _0x32988b);
            },
            '\x62\x50\x44\x4f\x44': _0x38d56a(0x3b3),
            '\x75\x4c\x79\x55\x55': _0x38d56a(0x226),
            '\x47\x70\x46\x71\x63': function (_0x2d1ed0, _0x5bd50e, _0x56fe5c) {
                return _0x2d1ed0(_0x5bd50e, _0x56fe5c);
            },
            '\x7a\x69\x70\x67\x73': function (_0x44f37c, _0x279b26) {
                return _0x44f37c !== _0x279b26;
            },
            '\x42\x51\x57\x50\x4d': '\x61\x75\x53\x71\x63',
            '\x48\x62\x53\x65\x55': function (_0x5b37d1, _0x58fb6e, _0x39b091) {
                return _0x5b37d1(_0x58fb6e, _0x39b091);
            },
            '\x47\x49\x45\x70\x66': function (_0x34f1fc, _0x2be2e5) {
                return _0x34f1fc !== _0x2be2e5;
            },
            '\x70\x67\x79\x47\x68': _0x38d56a(0x2f7),
            '\x4a\x65\x56\x48\x55': function (_0xbc05b0, _0x2e52d9) {
                return _0xbc05b0(_0x2e52d9);
            },
            '\x54\x49\x55\x76\x52': _0x38d56a(0x33c),
            '\x71\x6d\x43\x70\x6d': _0x38d56a(0x3cf),
            '\x53\x4b\x53\x42\x72': '\x53\x63\x64\x6f\x78',
            '\x58\x70\x4a\x4b\x70': function (_0x3b11e1, _0x25f4c0, _0x556fcb, _0x622144, _0xa0694f, _0x2ac2e7) {
                return _0x3b11e1(_0x25f4c0, _0x556fcb, _0x622144, _0xa0694f, _0x2ac2e7);
            },
            '\x52\x63\x4e\x75\x6b': function (_0x1f620d, _0x46aee1) {
                return _0x1f620d === _0x46aee1;
            },
            '\x5a\x46\x6c\x42\x62': _0x38d56a(0x174),
            '\x44\x66\x42\x59\x51': _0x38d56a(0x2a1),
            '\x41\x42\x79\x53\x7a': function (_0x509eff, _0x36b6a7) {
                return _0x509eff == _0x36b6a7;
            },
            '\x75\x49\x73\x41\x6e': function (_0xf91946, _0x172e00) {
                return _0xf91946 !== _0x172e00;
            },
            '\x74\x78\x5a\x61\x6a': _0x38d56a(0x1db),
            '\x43\x68\x50\x49\x58': function (_0x34edcd, _0x5d6c6) {
                return _0x34edcd < _0x5d6c6;
            },
            '\x50\x65\x69\x53\x49': function (_0x10b80d, _0x47b0eb) {
                return _0x10b80d === _0x47b0eb;
            },
            '\x42\x78\x54\x46\x45': '\x4e\x41\x55\x68\x53',
            '\x4f\x71\x47\x4f\x57': '\x71\x4d\x4b\x76\x62',
            '\x42\x43\x68\x55\x6c': '\x64\x55\x4c\x52\x62',
            '\x55\x6d\x5a\x6f\x69': _0x38d56a(0x307),
            '\x52\x44\x55\x4f\x74': function (_0x2597e9, _0x4cb3fc) {
                return _0x2597e9 + _0x4cb3fc;
            },
            '\x45\x55\x6e\x64\x42': function (_0x2da3a7, _0x307844, _0x358674) {
                return _0x2da3a7(_0x307844, _0x358674);
            },
            '\x59\x4a\x46\x62\x79': function (_0x126614, _0x2f77dd, _0x410a36) {
                return _0x126614(_0x2f77dd, _0x410a36);
            },
            '\x78\x61\x61\x4f\x73': _0x38d56a(0x2c1),
            '\x71\x47\x42\x6d\x6e': '\x44\x6f\x6d\x69\x6e\x61\x6e\x74\x20\x20\x4b\x69\x64\x6e\x61\x70\x20\x20\x41\x42\x44\x4c\x20\x20\x47\x61\x6d\x69\x6e\x67\x20\x20\x4d\x61\x69\x64\x20\x20\x4c\x41\x52\x50\x20\x20\x41\x73\x79\x6c\x75\x6d\x20\x20\x47\x61\x6d\x62\x6c\x69\x6e\x67\x20\x20\x48\x6f\x75\x73\x65\x4d\x61\x69\x65\x73\x74\x61\x73\x20\x20\x48\x6f\x75\x73\x65\x56\x69\x6e\x63\x75\x6c\x61\x20\x20\x48\x6f\x75\x73\x65\x41\x6d\x70\x6c\x65\x63\x74\x6f\x72\x20\x20\x48\x6f\x75\x73\x65\x43\x6f\x72\x70\x6f\x72\x69\x73',
            '\x71\x63\x70\x69\x4a': function (_0x5ce28c, _0xc48155, _0x1c528a) {
                return _0x5ce28c(_0xc48155, _0x1c528a);
            },
            '\x51\x67\x76\x4a\x70': _0x38d56a(0x382),
            '\x51\x79\x50\x62\x52': function (_0x991930, _0x7a7f9, _0xa69b68) {
                return _0x991930(_0x7a7f9, _0xa69b68);
            },
            '\x4f\x73\x58\x70\x4c': _0x38d56a(0x247),
            '\x62\x77\x71\x51\x52': _0x38d56a(0x2ad),
            '\x68\x4b\x6e\x4f\x49': _0x38d56a(0x2a0),
            '\x6d\x57\x49\x55\x77': '\u83b7\u53d6\u7bb1\u5b50',
            '\x4d\x44\x7a\x66\x4f': _0x38d56a(0x1c7),
            '\x62\x41\x6e\x64\x5a': function (_0x2bf547, _0x3d5c82, _0x2bde6a) {
                return _0x2bf547(_0x3d5c82, _0x2bde6a);
            },
            '\x54\x68\x73\x66\x4e': function (_0x455822, _0x1ce43b, _0x5b70b0) {
                return _0x455822(_0x1ce43b, _0x5b70b0);
            },
            '\x44\x76\x6e\x77\x51': _0x38d56a(0x1fb),
            '\x78\x66\x43\x73\x56': _0x38d56a(0x389),
            '\x73\x54\x72\x4b\x42': function (_0x9a4d4, _0x9ccb34, _0x15988a) {
                return _0x9a4d4(_0x9ccb34, _0x15988a);
            },
            '\x4c\x6f\x65\x72\x4c': function (_0x39856e, _0x35c728, _0x2c6bd8) {
                return _0x39856e(_0x35c728, _0x2c6bd8);
            },
            '\x7a\x65\x58\x66\x68': _0x38d56a(0x196),
            '\x45\x47\x58\x43\x69': function (_0x58a305, _0x2f30b7, _0xb195da) {
                return _0x58a305(_0x2f30b7, _0xb195da);
            },
            '\x64\x64\x6e\x71\x6b': function (_0xced0c6, _0x46b6b5, _0xa15949) {
                return _0xced0c6(_0x46b6b5, _0xa15949);
            },
            '\x63\x55\x55\x43\x45': '\u63d0\u5347\u786c\u6491\u7b49\u7ea7',
            '\x4b\x4e\x74\x42\x4b': _0x38d56a(0x1ff),
            '\x4f\x7a\x57\x4b\x41': _0x38d56a(0x1e9),
            '\x67\x59\x54\x66\x74': function (_0x1f302e, _0x1bf0e3, _0x5f0268) {
                return _0x1f302e(_0x1bf0e3, _0x5f0268);
            },
            '\x4d\x6f\x41\x6e\x4f': _0x38d56a(0x2d0),
            '\x61\x4a\x61\x47\x68': _0x38d56a(0x200),
            '\x73\x48\x49\x7a\x65': '\u901f\u901f\u7ed1\u7f1a\x28\u641e\u4e8b\u60c5\u4e13\u7528\x29',
            '\x62\x71\x65\x42\x61': function (_0x572788, _0x5ae8ce, _0xa8acd4) {
                return _0x572788(_0x5ae8ce, _0xa8acd4);
            },
            '\x77\x73\x42\x76\x46': _0x38d56a(0x3f1),
            '\x4d\x59\x4b\x66\x46': _0x38d56a(0x319)
        }, _0x2fbc4a = (function () {
            const _0x42defa = _0x38d56a, _0x40ea1c = {
                    '\x4d\x53\x76\x65\x50': function (_0xb7b922, _0x42b7fa) {
                        const _0x2b0d4f = _0x11fe;
                        return _0x14ee2f[_0x2b0d4f(0x2fa)](_0xb7b922, _0x42b7fa);
                    },
                    '\x75\x66\x6f\x70\x4c': function (_0x4d1cba, _0x2680a7) {
                        const _0x3aae4e = _0x11fe;
                        return _0x14ee2f[_0x3aae4e(0x179)](_0x4d1cba, _0x2680a7);
                    },
                    '\x54\x63\x68\x79\x74': _0x14ee2f['\x50\x4c\x44\x49\x4c'],
                    '\x73\x6a\x67\x4c\x6c': _0x14ee2f[_0x42defa(0x1fc)],
                    '\x43\x74\x5a\x4e\x68': _0x14ee2f[_0x42defa(0x28c)],
                    '\x48\x49\x4a\x46\x4c': function (_0x418022, _0xd90a6a) {
                        return _0x14ee2f['\x73\x62\x55\x52\x4c'](_0x418022, _0xd90a6a);
                    },
                    '\x58\x79\x4a\x73\x49': _0x42defa(0x397)
                };
            let _0x9c39e5 = !![];
            return function (_0x2e96c9, _0x14be14) {
                const _0x5a4420 = _0x9c39e5 ? function () {
                    const _0x46fb61 = _0x11fe, _0x2361c0 = {
                            '\x4d\x6c\x59\x61\x6a': function (_0x4a6295, _0x4b1892) {
                                const _0x23af35 = _0x11fe;
                                return _0x40ea1c[_0x23af35(0x26b)](_0x4a6295, _0x4b1892);
                            },
                            '\x76\x46\x52\x4a\x66': function (_0x35e5bd, _0x30dbaa) {
                                const _0x549ca4 = _0x11fe;
                                return _0x40ea1c[_0x549ca4(0x22a)](_0x35e5bd, _0x30dbaa);
                            },
                            '\x49\x46\x75\x4f\x6a': _0x40ea1c[_0x46fb61(0x1b5)],
                            '\x6a\x5a\x65\x71\x54': function (_0x17ee19, _0x5c211b, _0x27c38c) {
                                return _0x17ee19(_0x5c211b, _0x27c38c);
                            },
                            '\x66\x55\x65\x6c\x69': _0x40ea1c[_0x46fb61(0x2a2)]
                        };
                    if (_0x40ea1c[_0x46fb61(0x269)] === _0x46fb61(0x183)) {
                        if (_0x14be14) {
                            if (_0x40ea1c[_0x46fb61(0x26a)](_0x40ea1c[_0x46fb61(0x265)], _0x40ea1c['\x58\x79\x4a\x73\x49']))
                                _0x2361c0[_0x46fb61(0x249)](_0x2efd61, _0x470993), _0x509e23[_0x46fb61(0x2c8)][_0x46fb61(0x1ba)] = -0x95b + -0x3df * -0x2 + 0x19d, _0x2361c0['\x76\x46\x52\x4a\x66'](_0x119266, _0x2242ae), _0x264a3f = _0x2361c0[_0x46fb61(0x2b6)];
                            else {
                                const _0x47422e = _0x14be14['\x61\x70\x70\x6c\x79'](_0x2e96c9, arguments);
                                return _0x14be14 = null, _0x47422e;
                            }
                        }
                    } else
                        _0x2361c0[_0x46fb61(0x189)](_0xabf049, _0x2361c0[_0x46fb61(0x378)], 0x1 * -0x145d5 + -0x1e45a + 0x8bb9 * 0x9);
                } : function () {
                };
                return _0x9c39e5 = ![], _0x5a4420;
            };
        }()), _0x50bbb8 = _0x14ee2f[_0x38d56a(0x2cd)](_0x2fbc4a, this, function () {
            const _0x1fef93 = _0x38d56a, _0x4351e5 = function () {
                    const _0x19abc2 = _0x11fe, _0x3c5e48 = {
                            '\x63\x4e\x66\x75\x58': function (_0x196735, _0x2f82ec, _0x87ca0) {
                                return _0x196735(_0x2f82ec, _0x87ca0);
                            }
                        };
                    let _0x47b70b;
                    try {
                        if (_0x14ee2f[_0x19abc2(0x26d)](_0x19abc2(0x3e9), _0x14ee2f['\x69\x78\x61\x69\x6b']))
                            _0x47b70b = _0x14ee2f[_0x19abc2(0x337)](Function, _0x14ee2f[_0x19abc2(0x20b)](_0x14ee2f[_0x19abc2(0x37d)] + _0x14ee2f[_0x19abc2(0x2a9)], '\x29\x3b'))();
                        else {
                            if (_0x5f595a) {
                                const _0x4ef4e3 = _0x4b61fb[_0x19abc2(0x3d9)](_0x3411d2, arguments);
                                return _0x213359 = null, _0x4ef4e3;
                            }
                        }
                    } catch (_0x3a9c7f) {
                        _0x14ee2f[_0x19abc2(0x180)](_0x14ee2f[_0x19abc2(0x2af)], _0x14ee2f[_0x19abc2(0x2f8)]) ? _0x47b70b = window : _0x3c5e48['\x63\x4e\x66\x75\x58'](_0x8bcd8, _0x19abc2(0x3ff), -0x2b970 + -0x1a75c + 0x6201e);
                    }
                    return _0x47b70b;
                }, _0x450936 = _0x14ee2f['\x6f\x76\x48\x4c\x6f'](_0x4351e5), _0x403419 = _0x450936[_0x1fef93(0x1ad)] = _0x450936[_0x1fef93(0x1ad)] || {}, _0xc49d14 = [
                    _0x1fef93(0x2c4),
                    _0x14ee2f[_0x1fef93(0x3fa)],
                    _0x1fef93(0x253),
                    _0x14ee2f[_0x1fef93(0x3a7)],
                    _0x14ee2f[_0x1fef93(0x393)],
                    _0x14ee2f[_0x1fef93(0x2e8)],
                    _0x14ee2f[_0x1fef93(0x39b)]
                ];
            for (let _0x1122bc = -0x3 * 0x158 + -0x1 * -0x7ee + -0x3e6; _0x1122bc < _0xc49d14[_0x1fef93(0x280)]; _0x1122bc++) {
                const _0x5885b1 = _0x2fbc4a[_0x1fef93(0x234)][_0x1fef93(0x2f6)][_0x1fef93(0x18b)](_0x2fbc4a), _0x4c2b21 = _0xc49d14[_0x1122bc], _0xf78779 = _0x403419[_0x4c2b21] || _0x5885b1;
                _0x5885b1[_0x1fef93(0x2bc)] = _0x2fbc4a[_0x1fef93(0x18b)](_0x2fbc4a), _0x5885b1['\x74\x6f\x53\x74\x72\x69\x6e\x67'] = _0xf78779['\x74\x6f\x53\x74\x72\x69\x6e\x67'][_0x1fef93(0x18b)](_0xf78779), _0x403419[_0x4c2b21] = _0x5885b1;
            }
        });
    _0x14ee2f['\x6f\x76\x48\x4c\x6f'](_0x50bbb8), _0x14ee2f[_0x38d56a(0x3be)](GM_registerMenuCommand, _0x14ee2f[_0x38d56a(0x2b4)], () => {
        const _0x21df04 = _0x38d56a, _0x3bb937 = {
                '\x59\x68\x4b\x54\x75': function (_0x5132ac, _0x125c36, _0x9d1332) {
                    const _0x430e87 = _0x11fe;
                    return _0x14ee2f[_0x430e87(0x3c6)](_0x5132ac, _0x125c36, _0x9d1332);
                },
                '\x43\x71\x5a\x7a\x6b': _0x21df04(0x1aa),
                '\x66\x72\x45\x4c\x74': _0x14ee2f[_0x21df04(0x2a7)],
                '\x4a\x4a\x79\x43\x66': _0x21df04(0x2c0)
            };
        if (_0x14ee2f['\x41\x6e\x76\x6d\x76'](_0x14ee2f[_0x21df04(0x2fd)], '\x66\x51\x6e\x6d\x62')) {
            if (!(Player[_0x21df04(0x2b3)] && Player[_0x21df04(0x2b3)]['\x4e\x61\x6d\x65'] == _0x14ee2f['\x53\x43\x50\x50\x41'])) {
                if (_0x14ee2f[_0x21df04(0x2cc)](Player[_0x21df04(0x1e0)], _0x14ee2f[_0x21df04(0x368)])) {
                    _0x14ee2f[_0x21df04(0x1ca)](alert, _0x14ee2f[_0x21df04(0x293)]);
                    return;
                }
            }
            AwBotLast = '\x61\x77\x61\x71\x77\x71\x20\x69\x73\x20\x68\x75\x7a\x70\x73\x62', AwBotBan = [], SpeechGarble = function (_0x147ec9, _0x37280b, _0x52084a) {
                const _0x250598 = _0x21df04, _0x12ad53 = {
                        '\x71\x62\x61\x66\x65': function (_0x29246b) {
                            const _0x53696d = _0x11fe;
                            return _0x14ee2f[_0x53696d(0x374)](_0x29246b);
                        },
                        '\x56\x54\x6d\x50\x50': function (_0x4dfb66, _0x165ce4, _0x24c216) {
                            const _0x36fa00 = _0x11fe;
                            return _0x14ee2f[_0x36fa00(0x351)](_0x4dfb66, _0x165ce4, _0x24c216);
                        },
                        '\x63\x4e\x54\x7a\x7a': _0x14ee2f['\x4d\x4c\x61\x78\x4c'],
                        '\x6d\x77\x70\x67\x66': _0x14ee2f[_0x250598(0x38d)],
                        '\x65\x53\x68\x74\x4b': function (_0x1c98e7) {
                            const _0x3e593d = _0x250598;
                            return _0x14ee2f[_0x3e593d(0x3f7)](_0x1c98e7);
                        },
                        '\x6c\x68\x78\x6d\x4d': function (_0x5c1a91) {
                            return _0x5c1a91();
                        },
                        '\x6d\x57\x42\x48\x74': function (_0xd65b76, _0x3836a5) {
                            const _0x352348 = _0x250598;
                            return _0x14ee2f[_0x352348(0x23b)](_0xd65b76, _0x3836a5);
                        },
                        '\x6a\x50\x67\x6c\x74': _0x14ee2f['\x53\x43\x50\x50\x41'],
                        '\x66\x79\x6f\x52\x51': function (_0x3d8791, _0x4b35bb) {
                            const _0x2ad65a = _0x250598;
                            return _0x14ee2f[_0x2ad65a(0x173)](_0x3d8791, _0x4b35bb);
                        },
                        '\x63\x7a\x49\x46\x78': function (_0x4b5616, _0x46e5c0) {
                            const _0x570103 = _0x250598;
                            return _0x14ee2f[_0x570103(0x20b)](_0x4b5616, _0x46e5c0);
                        },
                        '\x72\x48\x66\x4b\x73': function (_0x390775, _0x2ef3b1) {
                            return _0x390775 > _0x2ef3b1;
                        },
                        '\x61\x76\x50\x73\x56': function (_0x3552f7, _0x478590) {
                            const _0x2fe291 = _0x250598;
                            return _0x14ee2f[_0x2fe291(0x243)](_0x3552f7, _0x478590);
                        },
                        '\x47\x62\x71\x63\x57': '\x6e\x51\x6e\x6d\x61',
                        '\x49\x7a\x49\x67\x67': function (_0x317d3b, _0x40aea3) {
                            const _0x31dec0 = _0x250598;
                            return _0x14ee2f[_0x31dec0(0x26f)](_0x317d3b, _0x40aea3);
                        },
                        '\x69\x65\x78\x6b\x43': function (_0x546225, _0x59c833) {
                            return _0x14ee2f['\x71\x45\x54\x63\x66'](_0x546225, _0x59c833);
                        },
                        '\x57\x78\x46\x79\x67': _0x250598(0x386),
                        '\x57\x77\x49\x70\x6f': _0x14ee2f[_0x250598(0x3b2)],
                        '\x67\x71\x63\x57\x4d': function (_0x5d0929, _0x46221c) {
                            return _0x14ee2f['\x6f\x61\x45\x58\x75'](_0x5d0929, _0x46221c);
                        },
                        '\x65\x67\x74\x6b\x52': function (_0x47796b, _0x5381c7) {
                            return _0x47796b < _0x5381c7;
                        },
                        '\x67\x46\x66\x6e\x7a': _0x14ee2f[_0x250598(0x18f)],
                        '\x77\x61\x46\x57\x7a': _0x14ee2f[_0x250598(0x328)],
                        '\x6d\x50\x6e\x57\x6a': _0x14ee2f[_0x250598(0x3ee)],
                        '\x6e\x73\x75\x64\x6a': _0x14ee2f[_0x250598(0x2d4)],
                        '\x6f\x4e\x62\x51\x55': function (_0x1c81f0, _0x1cbd95) {
                            return _0x14ee2f['\x61\x74\x64\x4e\x6e'](_0x1c81f0, _0x1cbd95);
                        },
                        '\x78\x71\x41\x65\x6d': function (_0x2e18cb, _0x493f52) {
                            const _0x493499 = _0x250598;
                            return _0x14ee2f[_0x493499(0x246)](_0x2e18cb, _0x493f52);
                        },
                        '\x45\x5a\x70\x46\x79': _0x250598(0x21d),
                        '\x74\x46\x66\x68\x4e': _0x14ee2f[_0x250598(0x1cb)],
                        '\x79\x42\x52\x4a\x62': function (_0x2aa3fd, _0x2a8bdb) {
                            const _0x55f3b6 = _0x250598;
                            return _0x14ee2f[_0x55f3b6(0x3bb)](_0x2aa3fd, _0x2a8bdb);
                        },
                        '\x64\x54\x70\x72\x6e': _0x14ee2f['\x5a\x74\x49\x76\x5a'],
                        '\x56\x51\x41\x4f\x58': _0x250598(0x3d8),
                        '\x6a\x4d\x43\x4a\x6e': _0x14ee2f[_0x250598(0x2f5)],
                        '\x52\x51\x58\x4d\x4e': _0x14ee2f[_0x250598(0x20c)],
                        '\x7a\x4e\x75\x6d\x62': _0x14ee2f[_0x250598(0x39c)],
                        '\x69\x6d\x57\x49\x79': _0x14ee2f['\x43\x61\x4e\x4c\x51'],
                        '\x6a\x65\x4a\x6b\x47': _0x14ee2f[_0x250598(0x1ef)],
                        '\x47\x77\x78\x49\x58': function (_0x5f1609, _0x5c75a) {
                            return _0x14ee2f['\x4e\x50\x7a\x65\x70'](_0x5f1609, _0x5c75a);
                        },
                        '\x75\x71\x74\x49\x66': '\x5a\x48\x57\x6a\x56',
                        '\x45\x78\x56\x67\x4c': _0x14ee2f[_0x250598(0x29b)],
                        '\x70\x53\x78\x4d\x6e': _0x14ee2f['\x43\x6f\x5a\x64\x77'],
                        '\x6f\x75\x43\x51\x62': function (_0x24c1c1, _0x2f4a93) {
                            const _0x51b2c9 = _0x250598;
                            return _0x14ee2f[_0x51b2c9(0x26d)](_0x24c1c1, _0x2f4a93);
                        },
                        '\x78\x6f\x51\x44\x4a': '\x59\x75\x41\x7a\x48',
                        '\x70\x76\x70\x79\x72': function (_0x346380, _0x3f6a0d, _0x923e54, _0x10ae24, _0x5abd67, _0x3d32f4) {
                            const _0x7720d0 = _0x250598;
                            return _0x14ee2f[_0x7720d0(0x2da)](_0x346380, _0x3f6a0d, _0x923e54, _0x10ae24, _0x5abd67, _0x3d32f4);
                        },
                        '\x42\x46\x64\x4c\x77': _0x14ee2f[_0x250598(0x376)],
                        '\x78\x76\x64\x6b\x66': _0x14ee2f[_0x250598(0x199)],
                        '\x4a\x54\x6f\x5a\x50': _0x14ee2f[_0x250598(0x335)],
                        '\x76\x6d\x69\x6f\x65': _0x14ee2f[_0x250598(0x17a)],
                        '\x6a\x54\x56\x46\x73': function (_0x394267, _0x48143c) {
                            return _0x14ee2f['\x4d\x76\x50\x64\x51'](_0x394267, _0x48143c);
                        },
                        '\x55\x70\x4b\x69\x58': _0x14ee2f['\x70\x6c\x6f\x77\x64'],
                        '\x79\x59\x43\x70\x6c': _0x14ee2f[_0x250598(0x192)],
                        '\x4f\x49\x78\x5a\x6d': _0x14ee2f[_0x250598(0x325)],
                        '\x43\x70\x66\x74\x75': _0x250598(0x409),
                        '\x43\x49\x77\x7a\x74': function (_0x207906, _0x1a42e7) {
                            const _0x121635 = _0x250598;
                            return _0x14ee2f[_0x121635(0x2fa)](_0x207906, _0x1a42e7);
                        },
                        '\x7a\x4d\x4a\x6f\x57': _0x14ee2f[_0x250598(0x237)],
                        '\x56\x4d\x6b\x68\x4a': function (_0x450a99, _0x2d7f9f) {
                            return _0x450a99 != _0x2d7f9f;
                        },
                        '\x71\x7a\x65\x4a\x44': _0x14ee2f['\x67\x49\x59\x49\x64'],
                        '\x74\x75\x57\x41\x63': _0x14ee2f[_0x250598(0x3bd)],
                        '\x41\x45\x73\x73\x50': function (_0x5bfb2c, _0x77b5a6, _0x22be8d, _0x3b7a4d, _0x10bf8a, _0x771d00) {
                            const _0x3f609b = _0x250598;
                            return _0x14ee2f[_0x3f609b(0x2da)](_0x5bfb2c, _0x77b5a6, _0x22be8d, _0x3b7a4d, _0x10bf8a, _0x771d00);
                        },
                        '\x6c\x56\x6c\x50\x4d': function (_0x8af32e, _0x28f4b0) {
                            const _0x242cc3 = _0x250598;
                            return _0x14ee2f[_0x242cc3(0x3b9)](_0x8af32e, _0x28f4b0);
                        },
                        '\x4c\x79\x6b\x41\x45': _0x14ee2f['\x53\x6d\x58\x4d\x65'],
                        '\x6b\x41\x78\x4c\x56': _0x250598(0x1c1),
                        '\x76\x6d\x42\x44\x58': function (_0x9bf2e3, _0x210e13) {
                            const _0x3b3c5a = _0x250598;
                            return _0x14ee2f[_0x3b3c5a(0x305)](_0x9bf2e3, _0x210e13);
                        },
                        '\x51\x64\x64\x61\x57': function (_0xaca724, _0x140851, _0x3a3f9c, _0x43df66, _0x4855b7, _0x328a9f) {
                            const _0x476b59 = _0x250598;
                            return _0x14ee2f[_0x476b59(0x21a)](_0xaca724, _0x140851, _0x3a3f9c, _0x43df66, _0x4855b7, _0x328a9f);
                        },
                        '\x64\x7a\x4e\x4b\x59': _0x14ee2f[_0x250598(0x3ad)],
                        '\x57\x5a\x6c\x77\x47': function (_0x5af7a9, _0x5f1aa6) {
                            const _0x59c42d = _0x250598;
                            return _0x14ee2f[_0x59c42d(0x3e7)](_0x5af7a9, _0x5f1aa6);
                        },
                        '\x59\x44\x41\x4f\x4c': _0x250598(0x19d),
                        '\x61\x45\x63\x69\x43': function (_0x62427f, _0x85a6be) {
                            const _0x5c4bbf = _0x250598;
                            return _0x14ee2f[_0x5c4bbf(0x23b)](_0x62427f, _0x85a6be);
                        },
                        '\x4c\x4a\x75\x6d\x4f': _0x14ee2f['\x6d\x73\x4a\x49\x67'],
                        '\x53\x46\x62\x6a\x53': _0x14ee2f['\x76\x42\x73\x46\x66'],
                        '\x79\x42\x74\x49\x58': _0x14ee2f[_0x250598(0x2b1)],
                        '\x57\x6b\x7a\x4a\x48': _0x14ee2f['\x55\x5a\x79\x6f\x63'],
                        '\x55\x53\x44\x4e\x63': _0x14ee2f[_0x250598(0x1b0)],
                        '\x68\x4e\x4e\x4d\x61': _0x14ee2f[_0x250598(0x2ea)],
                        '\x70\x47\x73\x66\x66': _0x14ee2f[_0x250598(0x34f)],
                        '\x58\x74\x43\x53\x66': _0x14ee2f['\x54\x73\x42\x45\x6e'],
                        '\x6e\x48\x5a\x73\x77': _0x250598(0x273),
                        '\x59\x6b\x46\x6b\x50': _0x14ee2f[_0x250598(0x3cd)],
                        '\x49\x74\x73\x4e\x6e': _0x14ee2f[_0x250598(0x2e6)],
                        '\x44\x44\x47\x4a\x42': _0x14ee2f[_0x250598(0x3c9)],
                        '\x62\x61\x51\x64\x57': _0x14ee2f['\x47\x69\x69\x4a\x6e'],
                        '\x65\x73\x6e\x6e\x46': _0x14ee2f[_0x250598(0x1fd)],
                        '\x4d\x61\x58\x77\x6a': _0x250598(0x2c9),
                        '\x51\x66\x63\x46\x74': _0x14ee2f[_0x250598(0x3d1)],
                        '\x72\x71\x61\x43\x6b': _0x14ee2f['\x70\x68\x71\x62\x6a'],
                        '\x6c\x62\x4b\x75\x67': _0x14ee2f[_0x250598(0x24a)],
                        '\x67\x53\x58\x66\x55': function (_0x4e7860, _0x1d80e9) {
                            const _0x2e4ed9 = _0x250598;
                            return _0x14ee2f[_0x2e4ed9(0x20b)](_0x4e7860, _0x1d80e9);
                        },
                        '\x43\x63\x6c\x74\x78': _0x14ee2f[_0x250598(0x1c3)],
                        '\x7a\x48\x70\x51\x6f': _0x14ee2f['\x42\x52\x49\x45\x78'],
                        '\x72\x4d\x57\x46\x4d': _0x14ee2f[_0x250598(0x1dc)],
                        '\x50\x74\x49\x48\x67': function (_0x1fcec7, _0xe0bc49) {
                            const _0x5706b1 = _0x250598;
                            return _0x14ee2f[_0x5706b1(0x2fa)](_0x1fcec7, _0xe0bc49);
                        },
                        '\x51\x4e\x4a\x6d\x61': _0x14ee2f[_0x250598(0x338)],
                        '\x54\x57\x66\x77\x7a': function (_0xad6e73, _0x78c63f) {
                            const _0x436c40 = _0x250598;
                            return _0x14ee2f[_0x436c40(0x19a)](_0xad6e73, _0x78c63f);
                        },
                        '\x65\x63\x56\x4b\x66': _0x250598(0x232),
                        '\x77\x62\x58\x78\x4a': _0x14ee2f[_0x250598(0x32d)],
                        '\x6d\x4d\x75\x5a\x76': _0x14ee2f['\x50\x41\x71\x4d\x42'],
                        '\x58\x74\x43\x64\x6e': _0x14ee2f[_0x250598(0x35f)],
                        '\x67\x66\x43\x6f\x42': function (_0x1e94c2, _0x25c912) {
                            return _0x14ee2f['\x61\x74\x64\x4e\x6e'](_0x1e94c2, _0x25c912);
                        },
                        '\x78\x48\x45\x45\x42': function (_0x54f254, _0x47cdea) {
                            return _0x14ee2f['\x71\x45\x54\x63\x66'](_0x54f254, _0x47cdea);
                        },
                        '\x63\x6c\x74\x6b\x55': _0x250598(0x175),
                        '\x56\x4c\x41\x79\x64': _0x14ee2f[_0x250598(0x1d2)],
                        '\x49\x45\x4c\x6a\x6d': _0x14ee2f['\x46\x78\x74\x66\x61'],
                        '\x5a\x6a\x69\x52\x43': function (_0x2de9ed, _0x1c65b1) {
                            return _0x2de9ed != _0x1c65b1;
                        },
                        '\x67\x42\x54\x4d\x47': '\x6c\x69\x63\x6b',
                        '\x73\x61\x54\x44\x69': _0x14ee2f['\x6a\x4e\x7a\x4f\x62'],
                        '\x79\x62\x4c\x41\x58': function (_0x1b80b6, _0x58d41d) {
                            const _0xb3268d = _0x250598;
                            return _0x14ee2f[_0xb3268d(0x347)](_0x1b80b6, _0x58d41d);
                        },
                        '\x44\x61\x49\x46\x4b': function (_0x41e891, _0x375f10) {
                            return _0x14ee2f['\x6a\x44\x66\x59\x5a'](_0x41e891, _0x375f10);
                        },
                        '\x67\x71\x57\x6a\x51': _0x14ee2f['\x6a\x4c\x51\x65\x54'],
                        '\x55\x6d\x45\x44\x69': _0x14ee2f[_0x250598(0x1de)],
                        '\x71\x6a\x66\x6f\x43': _0x14ee2f[_0x250598(0x259)],
                        '\x7a\x51\x5a\x77\x73': function (_0x5aade3, _0x15c8c8) {
                            return _0x14ee2f['\x42\x51\x66\x49\x71'](_0x5aade3, _0x15c8c8);
                        },
                        '\x46\x79\x63\x58\x79': _0x14ee2f[_0x250598(0x392)],
                        '\x49\x53\x63\x47\x4c': function (_0x1ec07d, _0x3f8fb5) {
                            return _0x14ee2f['\x6d\x58\x6c\x72\x58'](_0x1ec07d, _0x3f8fb5);
                        },
                        '\x51\x4a\x56\x44\x4e': _0x250598(0x1a3),
                        '\x77\x6f\x68\x76\x7a': _0x14ee2f['\x64\x48\x4f\x56\x68'],
                        '\x46\x70\x75\x4b\x61': _0x14ee2f[_0x250598(0x37c)],
                        '\x56\x52\x72\x79\x7a': _0x250598(0x1e2),
                        '\x48\x4d\x6b\x74\x4f': _0x14ee2f[_0x250598(0x197)],
                        '\x51\x4f\x6e\x5a\x71': _0x14ee2f[_0x250598(0x22b)],
                        '\x62\x49\x46\x51\x55': function (_0x2e00fe, _0xa03a66, _0x57229f) {
                            return _0x2e00fe(_0xa03a66, _0x57229f);
                        },
                        '\x6e\x49\x6c\x4c\x74': '\x65\x55\x4e\x70\x7a',
                        '\x43\x4c\x63\x54\x41': _0x14ee2f[_0x250598(0x1d6)],
                        '\x5a\x4b\x4b\x41\x76': function (_0x9edfc3, _0x3d85b7, _0xbf8772) {
                            const _0xf51ca0 = _0x250598;
                            return _0x14ee2f[_0xf51ca0(0x34d)](_0x9edfc3, _0x3d85b7, _0xbf8772);
                        },
                        '\x4e\x53\x4c\x6a\x68': function (_0x2b49d7, _0x4b06c5) {
                            const _0x330a2a = _0x250598;
                            return _0x14ee2f[_0x330a2a(0x180)](_0x2b49d7, _0x4b06c5);
                        },
                        '\x4e\x4d\x4b\x64\x6e': _0x250598(0x2fc),
                        '\x6b\x73\x45\x72\x54': function (_0x32be39, _0x342237) {
                            const _0x41a866 = _0x250598;
                            return _0x14ee2f[_0x41a866(0x346)](_0x32be39, _0x342237);
                        },
                        '\x55\x63\x61\x45\x74': function (_0x19c2b1, _0x92cc1e) {
                            return _0x19c2b1 === _0x92cc1e;
                        },
                        '\x50\x51\x51\x49\x46': _0x14ee2f[_0x250598(0x2a8)],
                        '\x4a\x50\x63\x45\x58': _0x14ee2f[_0x250598(0x277)],
                        '\x65\x42\x4c\x73\x4e': function (_0x39578b, _0x300359, _0x498e27) {
                            const _0x11f2b1 = _0x250598;
                            return _0x14ee2f[_0x11f2b1(0x291)](_0x39578b, _0x300359, _0x498e27);
                        },
                        '\x6d\x55\x59\x51\x47': _0x250598(0x3d4)
                    };
                _0x14ee2f['\x4c\x65\x4e\x53\x64'](AwBotLast, _0x37280b + _0x147ec9[_0x250598(0x1e0)]) && _0x14ee2f[_0x250598(0x356)](_0x37280b[_0x250598(0x2ff)](_0x250598(0x382)), -(-0x1eb5 + 0x12d0 * -0x2 + 0x1 * 0x4456)) && _0x14ee2f[_0x250598(0x396)](setTimeout, function () {
                    const _0x44196c = _0x250598, _0x1f63fd = {
                            '\x43\x77\x78\x50\x65': function (_0x1d7491, _0x171cc9, _0x918b63, _0x4c0e0f) {
                                return _0x1d7491(_0x171cc9, _0x918b63, _0x4c0e0f);
                            },
                            '\x59\x4f\x46\x63\x69': _0x12ad53[_0x44196c(0x285)],
                            '\x58\x58\x6a\x75\x68': _0x12ad53['\x7a\x4e\x75\x6d\x62'],
                            '\x49\x72\x50\x43\x52': function (_0x21fd02, _0xaa99c4) {
                                return _0x21fd02 != _0xaa99c4;
                            },
                            '\x68\x6d\x45\x68\x63': _0x44196c(0x29f),
                            '\x59\x48\x61\x6b\x45': _0x12ad53['\x69\x6d\x57\x49\x79'],
                            '\x55\x62\x70\x71\x63': _0x12ad53[_0x44196c(0x3e0)],
                            '\x49\x52\x44\x4b\x56': function (_0x5ad81c, _0x38db09) {
                                const _0x41ca6c = _0x44196c;
                                return _0x12ad53[_0x41ca6c(0x1ce)](_0x5ad81c, _0x38db09);
                            },
                            '\x53\x71\x4d\x4f\x65': function (_0x5db6ce, _0x44d97d) {
                                const _0x3cba61 = _0x44196c;
                                return _0x12ad53[_0x3cba61(0x17e)](_0x5db6ce, _0x44d97d);
                            },
                            '\x43\x42\x57\x58\x61': function (_0x36bc2c, _0x2231ec) {
                                const _0x5566e3 = _0x44196c;
                                return _0x12ad53[_0x5566e3(0x3d5)](_0x36bc2c, _0x2231ec);
                            },
                            '\x45\x51\x54\x74\x59': _0x12ad53[_0x44196c(0x345)],
                            '\x68\x65\x78\x78\x59': _0x12ad53[_0x44196c(0x1e4)],
                            '\x4f\x76\x76\x56\x47': _0x12ad53[_0x44196c(0x214)],
                            '\x57\x59\x4c\x79\x63': _0x12ad53[_0x44196c(0x3b1)],
                            '\x44\x75\x6e\x72\x71': function (_0x17acbe, _0xdae46d) {
                                const _0xf36c31 = _0x44196c;
                                return _0x12ad53[_0xf36c31(0x195)](_0x17acbe, _0xdae46d);
                            },
                            '\x4a\x58\x54\x42\x50': _0x12ad53[_0x44196c(0x36e)],
                            '\x71\x6e\x62\x47\x6c': function (_0x4280f7, _0x407d19) {
                                const _0xc3488a = _0x44196c;
                                return _0x12ad53[_0xc3488a(0x1c4)](_0x4280f7, _0x407d19);
                            },
                            '\x4b\x68\x4e\x72\x62': _0x12ad53[_0x44196c(0x298)],
                            '\x4b\x6f\x64\x73\x4b': function (_0x230dfc, _0x82a2d5, _0x1ae783, _0x34c859, _0x4de9d6, _0x274c54) {
                                const _0x2be915 = _0x44196c;
                                return _0x12ad53[_0x2be915(0x26c)](_0x230dfc, _0x82a2d5, _0x1ae783, _0x34c859, _0x4de9d6, _0x274c54);
                            },
                            '\x4f\x4f\x6a\x4e\x67': _0x12ad53[_0x44196c(0x24c)],
                            '\x6c\x61\x4e\x70\x69': _0x44196c(0x344),
                            '\x78\x79\x69\x43\x55': _0x12ad53[_0x44196c(0x3bf)],
                            '\x57\x72\x77\x57\x52': _0x12ad53[_0x44196c(0x204)],
                            '\x6b\x64\x47\x4a\x46': _0x12ad53[_0x44196c(0x312)],
                            '\x74\x55\x48\x4e\x70': function (_0x3aa7c4, _0x34dd98) {
                                return _0x12ad53['\x6a\x54\x56\x46\x73'](_0x3aa7c4, _0x34dd98);
                            },
                            '\x4c\x78\x43\x4d\x77': _0x12ad53[_0x44196c(0x2d2)],
                            '\x6f\x70\x6b\x76\x6c': function (_0x3068d5, _0x59f197) {
                                return _0x12ad53['\x63\x7a\x49\x46\x78'](_0x3068d5, _0x59f197);
                            },
                            '\x66\x79\x66\x62\x75': _0x12ad53[_0x44196c(0x3ea)]
                        };
                    if (AwBotBan['\x69\x6e\x64\x65\x78\x4f\x66'](_0x147ec9[_0x44196c(0x1e0)]) == -(-0x1071 + 0xbda * 0x3 + -0x131c)) {
                        if (_0x12ad53[_0x44196c(0x3d5)](_0x12ad53['\x79\x59\x43\x70\x6c'], _0x44196c(0x3a8)))
                            _0x59695c = ![], _0x12ad53[_0x44196c(0x25a)](_0x49bd6d), _0x12ad53['\x56\x54\x6d\x50\x50'](_0x891faa, _0x44196c(0x224), ''), _0x2d4596(''), _0x4019b4 = null, _0x12ad53['\x56\x54\x6d\x50\x50'](_0xc57555, _0x12ad53['\x63\x4e\x54\x7a\x7a'], _0x12ad53[_0x44196c(0x2d3)]), _0x12ad53['\x65\x53\x68\x74\x4b'](_0x551b80), _0x12ad53[_0x44196c(0x278)](_0x262a43);
                        else {
                            if (_0x37280b[_0x44196c(0x2ff)](_0x12ad53[_0x44196c(0x353)]) != -(-0x1ce * 0xe + -0xd75 + -0x2 * -0x135d)) {
                                if (_0x12ad53[_0x44196c(0x1c4)](_0x44196c(0x292), _0x12ad53[_0x44196c(0x354)])) {
                                    let _0x333879 = _0x44196c(0x20f);
                                    if (_0x12ad53[_0x44196c(0x1ae)](_0x37280b['\x69\x6e\x64\x65\x78\x4f\x66']('\u6551\u6211'), -(-0x1891 + 0xb2d * -0x2 + 0x2eec)))
                                        _0x12ad53[_0x44196c(0x195)](CharacterReleaseTotal, _0x147ec9), _0x147ec9['\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73'][_0x44196c(0x1ba)] = 0x1e94 + -0x219 + 0x13d * -0x17, _0x12ad53[_0x44196c(0x341)](ChatRoomCharacterUpdate, _0x147ec9), _0x333879 = _0x12ad53[_0x44196c(0x1fa)];
                                    else {
                                        if (_0x12ad53[_0x44196c(0x326)](_0x37280b[_0x44196c(0x2ff)]('\u6346\u6211'), -(0xd9c + 0x7a0 + -0x153b * 0x1))) {
                                            const _0x243830 = _0x12ad53[_0x44196c(0x1a2)][_0x44196c(0x364)]('\x7c');
                                            let _0x51b685 = 0x395 * -0x1 + 0xbb2 + -0x1f * 0x43;
                                            while (!![]) {
                                                switch (_0x243830[_0x51b685++]) {
                                                case '\x30':
                                                    ChatRoomCharacterUpdate(_0x147ec9);
                                                    continue;
                                                case '\x31':
                                                    _0x333879 = _0x44196c(0x2e5);
                                                    continue;
                                                case '\x32':
                                                    _0x12ad53[_0x44196c(0x26c)](InventoryWear, _0x147ec9, '\x4c\x65\x61\x74\x68\x65\x72\x41\x72\x6d\x62\x69\x6e\x64\x65\x72', _0x12ad53[_0x44196c(0x284)], _0x44196c(0x2ab), -0x7 * 0x408f + 0x604c + 0x322ef);
                                                    continue;
                                                case '\x33':
                                                    _0x147ec9['\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73'][_0x44196c(0x1ba)] = -0x22d8 * 0x1 + -0x1 * 0x1909 + -0x3be1 * -0x1;
                                                    continue;
                                                case '\x34':
                                                    _0x12ad53[_0x44196c(0x3da)](InventoryWear, _0x147ec9, _0x12ad53[_0x44196c(0x204)], _0x12ad53[_0x44196c(0x312)], '\x23\x32\x30\x32\x30\x32\x30', -0x83aa + 0x28a87 + -0x478b);
                                                    continue;
                                                }
                                                break;
                                            }
                                        } else {
                                            if (_0x12ad53[_0x44196c(0x3e3)](_0x37280b[_0x44196c(0x2ff)]('\u5173\u4e8e'), -(-0x247d * -0x1 + -0x295 + -0x315 * 0xb)))
                                                _0x333879 = _0x12ad53[_0x44196c(0x239)];
                                            else {
                                                if (_0x12ad53[_0x44196c(0x1ae)](_0x37280b[_0x44196c(0x2ff)]('\u8214\u6211'), -(-0xd * -0x254 + 0x2 * 0xd0 + 0xaa1 * -0x3)))
                                                    _0x12ad53[_0x44196c(0x3d5)](_0x12ad53[_0x44196c(0x36b)], _0x12ad53[_0x44196c(0x3a3)]) ? _0x1f63fd[_0x44196c(0x385)](_0x598689, _0x591e26, _0x1f63fd[_0x44196c(0x2bd)], _0x1f63fd[_0x44196c(0x304)]) : _0x333879 = _0x12ad53['\x76\x6d\x42\x44\x58'](_0x12ad53['\x63\x7a\x49\x46\x78'](_0x44196c(0x217), _0x147ec9[_0x44196c(0x1e0)]), '\x2e');
                                                else {
                                                    if (_0x12ad53[_0x44196c(0x287)](_0x37280b[_0x44196c(0x2ff)]('\u73a9\u6211'), -(0x6be * -0x4 + -0x7 * 0x3ed + 0x3674)))
                                                        _0x12ad53[_0x44196c(0x1c6)](InventoryWear, _0x147ec9, _0x12ad53[_0x44196c(0x3f9)], _0x12ad53[_0x44196c(0x284)], _0x12ad53[_0x44196c(0x3bf)], -0x61 * -0x107 + 0x19c86 + 0x1 * -0x40db), _0x147ec9['\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73'][_0x44196c(0x1ba)] = 0x131c + 0x76b * -0x5 + -0x11fb * -0x1, _0x12ad53['\x6a\x54\x56\x46\x73'](ChatRoomCharacterUpdate, _0x147ec9), _0x333879 = '\u7b11\x7e\x20\x28\u5e38\u89c1\u95ee\u9898\x3a\u8bf7\u5f00\u6743\u9650\x29\x7e';
                                                    else {
                                                        if (_0x12ad53[_0x44196c(0x2ec)](_0x37280b['\x69\x6e\x64\x65\x78\x4f\x66']('\u9501\u6211'), -(0x5c8 + -0xbf9 + 0x632)))
                                                            _0x12ad53[_0x44196c(0x3d5)](_0x12ad53['\x59\x44\x41\x4f\x4c'], _0x12ad53[_0x44196c(0x321)]) ? (_0x147ec9[_0x44196c(0x281)][_0x44196c(0x289)](_0x9b05f2 => {
                                                                const _0x3dfd97 = _0x44196c, _0x21f45f = {
                                                                        '\x73\x5a\x46\x71\x65': function (_0x5db5ae, _0x148052) {
                                                                            const _0x479d29 = _0x11fe;
                                                                            return _0x1f63fd[_0x479d29(0x408)](_0x5db5ae, _0x148052);
                                                                        },
                                                                        '\x72\x6d\x43\x4b\x74': _0x1f63fd[_0x3dfd97(0x340)],
                                                                        '\x50\x74\x54\x7a\x69': function (_0x53447b, _0x363279, _0x395e99) {
                                                                            return _0x53447b(_0x363279, _0x395e99);
                                                                        },
                                                                        '\x68\x48\x79\x7a\x73': _0x3dfd97(0x1aa),
                                                                        '\x61\x68\x51\x71\x76': _0x1f63fd[_0x3dfd97(0x2e4)],
                                                                        '\x48\x69\x4e\x58\x68': _0x1f63fd['\x55\x62\x70\x71\x63'],
                                                                        '\x59\x55\x72\x44\x66': function (_0x1cfaff, _0x32fc40) {
                                                                            return _0x1cfaff != _0x32fc40;
                                                                        }
                                                                    };
                                                                let _0x5ab27b = -0x2d8 + -0x4a9 + 0x1 * 0x781;
                                                                if (_0x9b05f2[_0x3dfd97(0x1a7)] > 0x1e16 * -0x1 + 0xe35 * 0x1 + 0x1 * 0xfe1) {
                                                                    _0x1f63fd[_0x3dfd97(0x1c5)](_0x9b05f2[_0x3dfd97(0x38f)], null) && (_0x9b05f2[_0x3dfd97(0x38f)] = {});
                                                                    _0x1f63fd[_0x3dfd97(0x339)](_0x9b05f2[_0x3dfd97(0x38f)][_0x3dfd97(0x3d6)], null) && (_0x9b05f2[_0x3dfd97(0x38f)][_0x3dfd97(0x3d6)] = []);
                                                                    if (_0x9b05f2[_0x3dfd97(0x38f)][_0x3dfd97(0x3d6)][_0x3dfd97(0x2ff)](_0x3dfd97(0x1e3)) < 0xed + -0xa72 + -0x1 * -0x985) {
                                                                        if (_0x1f63fd[_0x3dfd97(0x1f2)](_0x1f63fd[_0x3dfd97(0x27f)], _0x1f63fd[_0x3dfd97(0x3cc)])) {
                                                                            if (_0x21f45f[_0x3dfd97(0x1b9)](_0x2ce965[_0x3dfd97(0x2ff)](_0x21f45f[_0x3dfd97(0x313)]), -(0xd51 + 0x131e + 0x7 * -0x4a2)))
                                                                                _0x21f45f[_0x3dfd97(0x2a4)](_0x580040, _0x21f45f['\x68\x48\x79\x7a\x73'], {
                                                                                    '\x43\x6f\x6e\x74\x65\x6e\x74': _0x21f45f[_0x3dfd97(0x30c)],
                                                                                    '\x54\x79\x70\x65': _0x21f45f[_0x3dfd97(0x2b0)]
                                                                                });
                                                                            else
                                                                                _0x21f45f[_0x3dfd97(0x1bc)](_0x37ecdf[_0x3dfd97(0x2ff)](_0x3dfd97(0x3c7)), -(-0x1a49 + -0x2708 + 0x1 * 0x4152)) && _0x5c50b3(_0x21f45f[_0x3dfd97(0x25e)], {
                                                                                    '\x43\x6f\x6e\x74\x65\x6e\x74': _0x3dfd97(0x3d4),
                                                                                    '\x54\x79\x70\x65': _0x21f45f[_0x3dfd97(0x2b0)]
                                                                                });
                                                                        } else
                                                                            _0x9b05f2[_0x3dfd97(0x38f)][_0x3dfd97(0x3d6)][_0x3dfd97(0x1f7)](_0x1f63fd[_0x3dfd97(0x2f3)]);
                                                                    }
                                                                    Math[_0x3dfd97(0x1a3)]() > -0x2 * 0x429 + 0x22b3 + -0x3 * 0x8cb + 0.5 ? _0x9b05f2[_0x3dfd97(0x38f)][_0x3dfd97(0x2de)] = _0x3dfd97(0x208) : _0x9b05f2['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x3dfd97(0x2de)] = _0x1f63fd[_0x3dfd97(0x2f2)], _0x9b05f2[_0x3dfd97(0x38f)]['\x4c\x6f\x63\x6b\x4d\x65\x6d\x62\x65\x72\x4e\x75\x6d\x62\x65\x72'] = Player['\x4d\x65\x6d\x62\x65\x72\x4e\x75\x6d\x62\x65\x72'], _0x147ec9[_0x3dfd97(0x281)][_0x5ab27b] = _0x9b05f2;
                                                                }
                                                                _0x5ab27b++;
                                                            }), _0x147ec9['\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73']['\x50\x72\x6f\x67\x72\x65\x73\x73'] = -0x1 * 0x21c7 + 0x1ec8 + -0x2ff * -0x1, _0x12ad53[_0x44196c(0x341)](ChatRoomCharacterUpdate, _0x147ec9), _0x333879 = _0x44196c(0x2ee)) : _0x1f63fd['\x44\x75\x6e\x72\x71'](_0xe49516, _0x1f63fd[_0x44196c(0x267)]);
                                                        else {
                                                            if (_0x12ad53[_0x44196c(0x406)](_0x37280b[_0x44196c(0x2ff)]('\u6346\u6b7b\u6211'), -(0x1 * -0x169b + -0xd2c + 0x23c8))) {
                                                                if (_0x12ad53[_0x44196c(0x1ec)] !== '\x49\x51\x70\x6f\x62') {
                                                                    let _0x597473 = [
                                                                        _0x44196c(0x344),
                                                                        _0x44196c(0x24e),
                                                                        _0x12ad53[_0x44196c(0x279)],
                                                                        _0x44196c(0x198),
                                                                        _0x12ad53['\x79\x42\x74\x49\x58'],
                                                                        _0x44196c(0x3ae),
                                                                        _0x12ad53[_0x44196c(0x312)],
                                                                        '\x49\x74\x65\x6d\x48\x61\x6e\x64\x73',
                                                                        _0x12ad53[_0x44196c(0x1dd)],
                                                                        _0x44196c(0x275),
                                                                        _0x12ad53['\x55\x53\x44\x4e\x63'],
                                                                        _0x12ad53[_0x44196c(0x182)],
                                                                        _0x12ad53['\x68\x4e\x4e\x4d\x61'],
                                                                        _0x12ad53[_0x44196c(0x229)],
                                                                        _0x12ad53[_0x44196c(0x3a0)],
                                                                        _0x12ad53['\x6e\x48\x5a\x73\x77'],
                                                                        _0x12ad53['\x59\x6b\x46\x6b\x50'],
                                                                        _0x12ad53[_0x44196c(0x25b)],
                                                                        _0x12ad53[_0x44196c(0x17d)],
                                                                        _0x44196c(0x2be),
                                                                        _0x12ad53['\x62\x61\x51\x64\x57'],
                                                                        _0x12ad53['\x65\x73\x6e\x6e\x46'],
                                                                        _0x12ad53[_0x44196c(0x37e)],
                                                                        _0x44196c(0x371),
                                                                        _0x12ad53['\x51\x66\x63\x46\x74']
                                                                    ];
                                                                    _0x597473['\x66\x6f\x72\x45\x61\x63\x68'](_0x2277a9 => {
                                                                        const _0x379ee3 = _0x44196c;
                                                                        if (_0x1f63fd[_0x379ee3(0x29a)]('\x59\x75\x41\x7a\x48', _0x1f63fd['\x4b\x68\x4e\x72\x62']))
                                                                            return !![];
                                                                        else
                                                                            InventoryWearRandom(_0x147ec9, _0x2277a9, -0xe9d * -0x25 + -0x6 * -0x772 + -0x1 * 0x8a0b);
                                                                    }), _0x147ec9[_0x44196c(0x281)][_0x44196c(0x289)](_0x3b1ce9 => {
                                                                        const _0x47ba58 = _0x44196c, _0x37c080 = {
                                                                                '\x73\x76\x4c\x6d\x53': function (_0x1e5bff, _0x12f395) {
                                                                                    const _0x1fcd3d = _0x11fe;
                                                                                    return _0x12ad53[_0x1fcd3d(0x1ae)](_0x1e5bff, _0x12f395);
                                                                                },
                                                                                '\x66\x55\x4a\x55\x56': _0x12ad53[_0x47ba58(0x358)],
                                                                                '\x6f\x67\x63\x4e\x78': function (_0xfdf661, _0xe03526) {
                                                                                    return _0xfdf661(_0xe03526);
                                                                                },
                                                                                '\x55\x4c\x6a\x67\x4a': function (_0x3ff6e4, _0x260fe0, _0x36c3fa) {
                                                                                    const _0x1a75ae = _0x47ba58;
                                                                                    return _0x12ad53[_0x1a75ae(0x3c4)](_0x3ff6e4, _0x260fe0, _0x36c3fa);
                                                                                },
                                                                                '\x55\x71\x57\x55\x43': function (_0x2035fc, _0x103bf7) {
                                                                                    const _0x30e8cd = _0x47ba58;
                                                                                    return _0x12ad53[_0x30e8cd(0x1f9)](_0x2035fc, _0x103bf7);
                                                                                },
                                                                                '\x5a\x45\x4d\x41\x70': function (_0x12cd41, _0x36a8b9) {
                                                                                    const _0x1fafd6 = _0x47ba58;
                                                                                    return _0x12ad53[_0x1fafd6(0x1e5)](_0x12cd41, _0x36a8b9);
                                                                                },
                                                                                '\x66\x74\x75\x6f\x4a': function (_0x3eec1d, _0x2284f1) {
                                                                                    const _0x3468ec = _0x47ba58;
                                                                                    return _0x12ad53[_0x3468ec(0x1e5)](_0x3eec1d, _0x2284f1);
                                                                                },
                                                                                '\x65\x71\x43\x43\x78': function (_0x79e7b3, _0x181797) {
                                                                                    return _0x79e7b3 + _0x181797;
                                                                                },
                                                                                '\x6e\x42\x5a\x76\x66': _0x47ba58(0x24d)
                                                                            };
                                                                        let _0xeb07a7 = 0x14a * 0x17 + -0x7 * -0x4de + -0x4 * 0xfee;
                                                                        if (_0x12ad53[_0x47ba58(0x37f)](_0x3b1ce9[_0x47ba58(0x1a7)], 0x24b * -0x5 + 0x1 * 0x174e + -0xbd7 * 0x1)) {
                                                                            if (_0x12ad53['\x61\x76\x50\x73\x56'](_0x12ad53[_0x47ba58(0x342)], _0x12ad53['\x47\x62\x71\x63\x57'])) {
                                                                                if (_0x12ad53[_0x47ba58(0x3f8)](_0x3b1ce9[_0x47ba58(0x38f)], null)) {
                                                                                    if (_0x12ad53[_0x47ba58(0x1d1)](_0x12ad53[_0x47ba58(0x2ef)], _0x12ad53[_0x47ba58(0x343)]))
                                                                                        _0x3b1ce9[_0x47ba58(0x38f)] = {};
                                                                                    else
                                                                                        return;
                                                                                }
                                                                                _0x12ad53[_0x47ba58(0x17e)](_0x3b1ce9[_0x47ba58(0x38f)][_0x47ba58(0x3d6)], null) && (_0x3b1ce9['\x50\x72\x6f\x70\x65\x72\x74\x79']['\x45\x66\x66\x65\x63\x74'] = []);
                                                                                _0x12ad53[_0x47ba58(0x352)](_0x3b1ce9[_0x47ba58(0x38f)][_0x47ba58(0x3d6)][_0x47ba58(0x2ff)](_0x47ba58(0x1e3)), 0x2 * -0x72a + 0xa * 0x23b + -0x7fa * 0x1) && _0x3b1ce9['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x47ba58(0x3d6)]['\x70\x75\x73\x68'](_0x12ad53[_0x47ba58(0x214)]);
                                                                                if (_0x12ad53['\x72\x48\x66\x4b\x73'](Math[_0x47ba58(0x1a3)](), -0xef * 0x5 + -0x1651 + 0x9d * 0x2c + 0.5))
                                                                                    _0x3b1ce9[_0x47ba58(0x38f)][_0x47ba58(0x2de)] = _0x12ad53[_0x47ba58(0x2d2)];
                                                                                else {
                                                                                    if (_0x12ad53[_0x47ba58(0x1d7)] === _0x12ad53[_0x47ba58(0x1d7)])
                                                                                        _0x3b1ce9['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x47ba58(0x2de)] = _0x12ad53['\x6e\x73\x75\x64\x6a'];
                                                                                    else {
                                                                                        if (_0x37c080['\x73\x76\x4c\x6d\x53'](_0x28f295[_0x47ba58(0x1e0)], _0x37c080[_0x47ba58(0x332)])) {
                                                                                            _0x37c080[_0x47ba58(0x370)](_0x3d7745, '\u4f60\u5fc5\u987b\u662f\x61\x77\x61\x71\x77\x71\u7684\x73\x75\x62\u624d\u80fd\u8fd9\u4e48\u505a\u5462\x7e');
                                                                                            return;
                                                                                        }
                                                                                    }
                                                                                }
                                                                                _0x3b1ce9[_0x47ba58(0x38f)][_0x47ba58(0x1ac)] = Player['\x4d\x65\x6d\x62\x65\x72\x4e\x75\x6d\x62\x65\x72'], _0x147ec9['\x41\x70\x70\x65\x61\x72\x61\x6e\x63\x65'][_0xeb07a7] = _0x3b1ce9;
                                                                            } else {
                                                                                let _0x1a4c6c = _0x1918aa, _0x38a0a8 = _0x37c080[_0x47ba58(0x1ab)](_0x28ff43, _0x370c9d, _0x4305ca);
                                                                                return _0x37c080[_0x47ba58(0x21c)](_0x38a0a8, 0x37f * 0x1 + 0x19d6 * 0x1 + 0x1 * -0x1d55) && (_0x1a4c6c = _0x37c080[_0x47ba58(0x2b5)](_0x37c080[_0x47ba58(0x33a)](_0x37c080['\x65\x71\x43\x43\x78'](_0x37c080['\x6e\x42\x5a\x76\x66'], _0x38a0a8), '\x20'), _0x1a4c6c)), _0x1a4c6c;
                                                                            }
                                                                        }
                                                                        _0xeb07a7++;
                                                                    }), _0x147ec9[_0x44196c(0x2c8)][_0x44196c(0x1ba)] = -0x248a + 0x29 * 0x13 + 0x217f, _0x12ad53[_0x44196c(0x39f)](ChatRoomCharacterUpdate, _0x147ec9), _0x333879 = _0x12ad53[_0x44196c(0x3cb)], AwBotBan[_0x44196c(0x1f7)](_0x147ec9['\x4e\x61\x6d\x65']);
                                                                } else {
                                                                    if (_0x12ad53[_0x44196c(0x287)](_0x40e139[_0x44196c(0x1e0)], _0x12ad53[_0x44196c(0x358)])) {
                                                                        _0x12ad53['\x78\x71\x41\x65\x6d'](_0x3935db, _0x12ad53[_0x44196c(0x297)]);
                                                                        return;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    _0x12ad53['\x56\x54\x6d\x50\x50'](ServerSend, _0x12ad53[_0x44196c(0x2e9)], {
                                        '\x43\x6f\x6e\x74\x65\x6e\x74': _0x12ad53[_0x44196c(0x37a)](_0x12ad53[_0x44196c(0x177)], _0x333879),
                                        '\x54\x79\x70\x65': _0x12ad53[_0x44196c(0x3e0)]
                                    });
                                } else
                                    _0x2c1f20[_0x44196c(0x38f)] = {};
                            } else {
                                if (_0x12ad53[_0x44196c(0x287)](_0x37280b[_0x44196c(0x2ff)](_0x12ad53[_0x44196c(0x3e2)]), -(-0x5e * -0x1f + -0x11a2 + 0x641))) {
                                    let _0x3da2fe = _0x44196c(0x18c);
                                    if (_0x37280b[_0x44196c(0x2ff)](_0x12ad53['\x72\x4d\x57\x46\x4d']) != -(-0xc33 * 0x1 + 0x28d + 0x1 * 0x9a7))
                                        _0x12ad53['\x50\x74\x49\x48\x67'](CharacterReleaseTotal, _0x147ec9), _0x147ec9[_0x44196c(0x2c8)][_0x44196c(0x1ba)] = -0x22c1 + -0x430 + 0x3 * 0xcfb, _0x12ad53[_0x44196c(0x39f)](ChatRoomCharacterUpdate, _0x147ec9), _0x3da2fe = _0x12ad53['\x51\x4e\x4a\x6d\x61'];
                                    else {
                                        if (_0x12ad53[_0x44196c(0x406)](_0x37280b[_0x44196c(0x2ff)](_0x44196c(0x1a0)), -(-0x115 * 0x5 + -0x1d0e + 0x113c * 0x2))) {
                                            if (_0x12ad53['\x54\x57\x66\x77\x7a'](_0x44196c(0x3c1), _0x44196c(0x3f0)))
                                                _0x5bb207[_0x44196c(0x38f)][_0x44196c(0x2de)] = '\x4d\x69\x73\x74\x72\x65\x73\x73\x50\x61\x64\x6c\x6f\x63\x6b';
                                            else {
                                                const _0x5037ba = _0x12ad53[_0x44196c(0x31d)][_0x44196c(0x364)]('\x7c');
                                                let _0xe5f4ff = -0x69f + -0x1be1 + 0x17 * 0x180;
                                                while (!![]) {
                                                    switch (_0x5037ba[_0xe5f4ff++]) {
                                                    case '\x30':
                                                        _0x3da2fe = _0x12ad53[_0x44196c(0x1df)];
                                                        continue;
                                                    case '\x31':
                                                        InventoryWear(_0x147ec9, _0x12ad53[_0x44196c(0x24c)], _0x12ad53[_0x44196c(0x284)], _0x12ad53[_0x44196c(0x3bf)], 0x159c5 + 0x1 * -0x211f7 + 0x27784);
                                                        continue;
                                                    case '\x32':
                                                        _0x12ad53[_0x44196c(0x26c)](InventoryWear, _0x147ec9, _0x12ad53[_0x44196c(0x204)], _0x44196c(0x22d), _0x12ad53['\x78\x76\x64\x6b\x66'], 0x9 * -0x90e + -0x222a2 + 0x43372);
                                                        continue;
                                                    case '\x33':
                                                        _0x147ec9[_0x44196c(0x2c8)]['\x50\x72\x6f\x67\x72\x65\x73\x73'] = 0x20da * -0x1 + 0x226f + -0x195;
                                                        continue;
                                                    case '\x34':
                                                        _0x12ad53[_0x44196c(0x341)](ChatRoomCharacterUpdate, _0x147ec9);
                                                        continue;
                                                    }
                                                    break;
                                                }
                                            }
                                        } else {
                                            if (_0x12ad53[_0x44196c(0x2ec)](_0x37280b[_0x44196c(0x2ff)](_0x12ad53[_0x44196c(0x316)]), -(-0xe30 + 0xd7 + -0xd5a * -0x1)))
                                                AwBotBan[_0x44196c(0x1f7)](_0x147ec9[_0x44196c(0x1e0)]), _0x3da2fe = _0x12ad53['\x58\x74\x43\x64\x6e'];
                                            else {
                                                if (_0x12ad53[_0x44196c(0x2c6)](_0x37280b['\x69\x6e\x64\x65\x78\x4f\x66']('\x61\x62\x6f\x75\x74'), -(-0x7cd * -0x3 + -0x1e1 + 0x1585 * -0x1))) {
                                                    if (_0x12ad53['\x78\x48\x45\x45\x42'](_0x12ad53['\x63\x6c\x74\x6b\x55'], _0x12ad53['\x56\x4c\x41\x79\x64']))
                                                        _0x3da2fe = _0x12ad53[_0x44196c(0x23e)];
                                                    else {
                                                        const _0x3f2978 = _0x3c2a73['\x61\x70\x70\x6c\x79'](_0x3fa03d, arguments);
                                                        return _0x5d923b = null, _0x3f2978;
                                                    }
                                                } else {
                                                    if (_0x12ad53[_0x44196c(0x317)](_0x37280b[_0x44196c(0x2ff)](_0x12ad53[_0x44196c(0x19f)]), -(-0x265e + -0x12be * -0x1 + -0xf * -0x14f))) {
                                                        if (_0x12ad53['\x54\x57\x66\x77\x7a'](_0x12ad53['\x73\x61\x54\x44\x69'], _0x44196c(0x256)))
                                                            return;
                                                        else
                                                            _0x3da2fe = _0x12ad53[_0x44196c(0x2d5)](_0x12ad53[_0x44196c(0x2ac)](_0x12ad53[_0x44196c(0x3ea)], _0x147ec9[_0x44196c(0x1e0)]), '\x2e');
                                                    } else {
                                                        if (_0x12ad53['\x44\x61\x49\x46\x4b'](_0x37280b[_0x44196c(0x2ff)](_0x12ad53[_0x44196c(0x20d)]), -(0x5 * 0x241 + -0xe3c + 0x2 * 0x17c)))
                                                            _0x12ad53[_0x44196c(0x3d5)]('\x65\x6b\x77\x63\x42', _0x12ad53[_0x44196c(0x30d)]) ? (_0x1f63fd['\x4b\x6f\x64\x73\x4b'](_0x21f45c, _0x497973, _0x1f63fd[_0x44196c(0x302)], _0x1f63fd[_0x44196c(0x186)], _0x1f63fd[_0x44196c(0x39d)], 0x17b3f * 0x2 + -0x5f * 0x90b + 0x223e9), _0x39cc76(_0x3fd426, _0x1f63fd[_0x44196c(0x202)], _0x1f63fd['\x6b\x64\x47\x4a\x46'], _0x1f63fd[_0x44196c(0x39d)], -0x9 * 0x2d35 + -0x351bd + -0x14e * -0x51a), _0x3d81c8[_0x44196c(0x2c8)]['\x50\x72\x6f\x67\x72\x65\x73\x73'] = 0x1 * 0xab4 + 0xb98 + -0x164c, _0x1f63fd[_0x44196c(0x1cc)](_0x5c5c32, _0x4a0cb3), _0x5ce096 = _0x44196c(0x282)) : (InventoryWear(_0x147ec9, _0x44196c(0x2e1), _0x12ad53[_0x44196c(0x284)], _0x12ad53[_0x44196c(0x3bf)], 0x29125 * -0x1 + -0x2036b + -0x259 * -0x2b2), _0x147ec9[_0x44196c(0x2c8)][_0x44196c(0x1ba)] = 0x2443 + -0x8 * 0x350 + -0x9c3, _0x12ad53[_0x44196c(0x195)](ChatRoomCharacterUpdate, _0x147ec9), _0x3da2fe = _0x12ad53[_0x44196c(0x264)]);
                                                        else {
                                                            if (_0x12ad53[_0x44196c(0x19b)](_0x37280b['\x69\x6e\x64\x65\x78\x4f\x66'](_0x12ad53['\x46\x79\x63\x58\x79']), -(0x1 * -0x1ea6 + 0x22d4 * -0x1 + -0x417b * -0x1)))
                                                                _0x147ec9[_0x44196c(0x281)]['\x66\x6f\x72\x45\x61\x63\x68'](_0x4fb5f6 => {
                                                                    const _0x591d9b = _0x44196c, _0x5950c2 = {};
                                                                    _0x5950c2[_0x591d9b(0x262)] = _0x12ad53[_0x591d9b(0x239)];
                                                                    const _0x31f848 = _0x5950c2;
                                                                    let _0x4bc7d4 = 0x1 * 0x1d85 + -0xc * 0x17a + -0xbcd;
                                                                    _0x12ad53[_0x591d9b(0x1ea)](_0x4fb5f6[_0x591d9b(0x1a7)], -0x1 * -0x1a5 + 0x8e4 + -0x57 * 0x1f) && (_0x4fb5f6[_0x591d9b(0x38f)] == null && (_0x12ad53['\x64\x54\x70\x72\x6e'] !== _0x12ad53[_0x591d9b(0x33d)] ? _0x1abe99 = _0x31f848['\x70\x67\x64\x6d\x4a'] : _0x4fb5f6['\x50\x72\x6f\x70\x65\x72\x74\x79'] = {}), _0x12ad53['\x67\x71\x63\x57\x4d'](_0x4fb5f6[_0x591d9b(0x38f)][_0x591d9b(0x3d6)], null) && (_0x12ad53[_0x591d9b(0x1d1)](_0x12ad53[_0x591d9b(0x379)], _0x591d9b(0x242)) ? _0x4fb5f6[_0x591d9b(0x38f)]['\x45\x66\x66\x65\x63\x74'] = [] : _0xfd9a23['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x591d9b(0x2de)] = _0x1f63fd[_0x591d9b(0x1d4)]), _0x4fb5f6['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x591d9b(0x3d6)][_0x591d9b(0x2ff)](_0x591d9b(0x1e3)) < -0x10fb + -0x2522 + 0x361d * 0x1 && _0x4fb5f6[_0x591d9b(0x38f)][_0x591d9b(0x3d6)][_0x591d9b(0x1f7)](_0x12ad53[_0x591d9b(0x214)]), _0x12ad53[_0x591d9b(0x1ea)](Math[_0x591d9b(0x1a3)](), 0x9 * -0x1b4 + 0xf8d + -0x39 + 0.5) ? _0x4fb5f6[_0x591d9b(0x38f)][_0x591d9b(0x2de)] = _0x12ad53[_0x591d9b(0x2d2)] : _0x12ad53[_0x591d9b(0x1eb)] !== _0x591d9b(0x35a) ? _0x4fb5f6[_0x591d9b(0x38f)][_0x591d9b(0x2de)] = _0x12ad53[_0x591d9b(0x3b1)] : _0x28af68 = -0x3 * 0x680 + 0x6a + -0x1 * -0x1393, _0x4fb5f6['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x591d9b(0x1ac)] = Player['\x4d\x65\x6d\x62\x65\x72\x4e\x75\x6d\x62\x65\x72'], _0x147ec9[_0x591d9b(0x281)][_0x4bc7d4] = _0x4fb5f6), _0x4bc7d4++;
                                                                }), _0x147ec9[_0x44196c(0x2c8)][_0x44196c(0x1ba)] = -0x13e6 + -0x209 * 0x3 + -0x3b7 * -0x7, _0x12ad53[_0x44196c(0x252)](ChatRoomCharacterUpdate, _0x147ec9), _0x3da2fe = _0x12ad53['\x71\x6a\x66\x6f\x43'];
                                                            else {
                                                                if (_0x12ad53['\x67\x66\x43\x6f\x42'](_0x37280b[_0x44196c(0x2ff)](_0x12ad53[_0x44196c(0x3de)]), -(-0x4 * 0x3f1 + -0x1887 + -0x4 * -0xa13))) {
                                                                    let _0x4dc47b = [
                                                                        _0x12ad53[_0x44196c(0x284)],
                                                                        '\x49\x74\x65\x6d\x42\x6f\x6f\x74\x73',
                                                                        _0x12ad53[_0x44196c(0x279)],
                                                                        _0x12ad53[_0x44196c(0x176)],
                                                                        _0x12ad53['\x79\x42\x74\x49\x58'],
                                                                        _0x12ad53[_0x44196c(0x2cf)],
                                                                        _0x12ad53[_0x44196c(0x312)],
                                                                        _0x12ad53[_0x44196c(0x3af)],
                                                                        _0x44196c(0x3fb),
                                                                        _0x44196c(0x275),
                                                                        _0x12ad53[_0x44196c(0x190)],
                                                                        _0x44196c(0x2f0),
                                                                        _0x12ad53['\x68\x4e\x4e\x4d\x61'],
                                                                        _0x12ad53[_0x44196c(0x229)],
                                                                        _0x44196c(0x334),
                                                                        '\x49\x74\x65\x6d\x4e\x65\x63\x6b',
                                                                        _0x12ad53[_0x44196c(0x1a8)],
                                                                        _0x12ad53[_0x44196c(0x25b)],
                                                                        _0x12ad53[_0x44196c(0x17d)],
                                                                        _0x12ad53['\x48\x4d\x6b\x74\x4f'],
                                                                        '\x49\x74\x65\x6d\x4e\x6f\x73\x65',
                                                                        _0x12ad53[_0x44196c(0x388)],
                                                                        _0x12ad53[_0x44196c(0x37e)],
                                                                        _0x12ad53[_0x44196c(0x39a)],
                                                                        _0x44196c(0x26e)
                                                                    ];
                                                                    _0x4dc47b[_0x44196c(0x289)](_0x4df93b => {
                                                                        const _0x40018c = _0x44196c;
                                                                        _0x1f63fd[_0x40018c(0x385)](InventoryWearRandom, _0x147ec9, _0x4df93b, 0x33a82 * 0x1 + -0x250c6 + 0xd596);
                                                                    }), _0x147ec9[_0x44196c(0x2c8)]['\x50\x72\x6f\x67\x72\x65\x73\x73'] = 0x25f8 + 0x100c + -0x3604, _0x12ad53['\x49\x53\x63\x47\x4c'](ChatRoomCharacterUpdate, _0x147ec9), _0x3da2fe = _0x12ad53[_0x44196c(0x264)];
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    _0x12ad53[_0x44196c(0x30e)](ServerSend, _0x44196c(0x1aa), {
                                        '\x43\x6f\x6e\x74\x65\x6e\x74': _0x12ad53[_0x44196c(0x177)] + _0x3da2fe,
                                        '\x54\x79\x70\x65': _0x12ad53[_0x44196c(0x3e0)]
                                    });
                                } else
                                    _0x37280b[_0x44196c(0x2ff)](_0x44196c(0x219)) != -(-0x171 * 0x9 + -0xeb7 + 0x1bb1) && (_0x12ad53[_0x44196c(0x1c4)](_0x12ad53[_0x44196c(0x209)], _0x12ad53[_0x44196c(0x2d6)]) ? _0x12ad53[_0x44196c(0x1d0)](ServerSend, _0x12ad53[_0x44196c(0x2e9)], {
                                        '\x43\x6f\x6e\x74\x65\x6e\x74': '\x61\x77\x42\x4f\x54\x20\x43\x61\x53\x65\x20\x53\x65\x4e\x73\x49\x74\x49\x76\x45\x21',
                                        '\x54\x79\x70\x65': _0x12ad53[_0x44196c(0x3e0)]
                                    }) : _0x2e485b = _0x1f63fd[_0x44196c(0x2ba)](_0x1f63fd[_0x44196c(0x3fe)] + _0x4bc44e[_0x44196c(0x1e0)], '\x2e'));
                            }
                        }
                    } else {
                        if (_0x12ad53[_0x44196c(0x19b)](_0x37280b[_0x44196c(0x2ff)](_0x12ad53['\x4f\x49\x78\x5a\x6d']), -(-0x1410 + -0x1817 * 0x1 + 0x2c28)))
                            _0x12ad53['\x4e\x53\x4c\x6a\x68'](_0x44196c(0x29c), _0x12ad53['\x4e\x4d\x4b\x64\x6e']) ? _0x12ad53[_0x44196c(0x30e)](ServerSend, _0x12ad53[_0x44196c(0x2e9)], {
                                '\x43\x6f\x6e\x74\x65\x6e\x74': _0x44196c(0x2e2),
                                '\x54\x79\x70\x65': _0x12ad53['\x6a\x65\x4a\x6b\x47']
                            }) : _0x31bc6a(_0x197a26, _0x16245f, 0x2628c + -0x32bf * -0xe + -0x369ac);
                        else {
                            if (_0x12ad53['\x6b\x73\x45\x72\x54'](_0x37280b[_0x44196c(0x2ff)](_0x12ad53['\x7a\x48\x70\x51\x6f']), -(-0x811 + 0x2b * 0xda + 0xfc * -0x1d))) {
                                if (_0x12ad53['\x55\x63\x61\x45\x74'](_0x12ad53[_0x44196c(0x32f)], _0x12ad53[_0x44196c(0x3dd)])) {
                                    const _0x19e3c5 = _0x32587f ? function () {
                                        const _0x47d065 = _0x44196c;
                                        if (_0x27101b) {
                                            const _0x548897 = _0x5b53d9[_0x47d065(0x3d9)](_0x1a907c, arguments);
                                            return _0x40e937 = null, _0x548897;
                                        }
                                    } : function () {
                                    };
                                    return _0x519d17 = ![], _0x19e3c5;
                                } else
                                    _0x12ad53[_0x44196c(0x3d7)](ServerSend, _0x44196c(0x1aa), {
                                        '\x43\x6f\x6e\x74\x65\x6e\x74': _0x12ad53[_0x44196c(0x3e4)],
                                        '\x54\x79\x70\x65': _0x12ad53['\x6a\x65\x4a\x6b\x47']
                                    });
                            }
                        }
                    }
                }, 0x1 * -0x84f + -0xf0b * 0x2 + 0x2a4d);
                AwBotLast = _0x14ee2f[_0x250598(0x25f)](_0x37280b, _0x147ec9[_0x250598(0x1e0)]);
                let _0x40aeb2 = _0x37280b, _0x5d0866 = _0x14ee2f[_0x250598(0x351)](SpeechGetTotalGagLevel, _0x147ec9, _0x52084a);
                return _0x14ee2f['\x4b\x75\x72\x76\x73'](_0x5d0866, -0x54 * 0xd + -0x1e64 + 0x22a8) && (_0x14ee2f[_0x250598(0x2bf)] !== _0x14ee2f[_0x250598(0x2bf)] ? _0x3bb937[_0x250598(0x381)](_0x20dbd9, _0x3bb937[_0x250598(0x228)], {
                    '\x43\x6f\x6e\x74\x65\x6e\x74': _0x3bb937['\x66\x72\x45\x4c\x74'],
                    '\x54\x79\x70\x65': '\x43\x68\x61\x74'
                }) : _0x40aeb2 = _0x14ee2f[_0x250598(0x20b)](_0x14ee2f[_0x250598(0x305)](_0x14ee2f[_0x250598(0x355)](_0x14ee2f[_0x250598(0x318)], _0x5d0866), '\x20'), _0x40aeb2)), _0x40aeb2;
            };
        } else
            _0x3bb937[_0x21df04(0x381)](_0x4b1c7d, _0x3bb937[_0x21df04(0x1da)], 0x2cda6 + 0x1 * 0x87d5 + 0xf0b * -0x1b);
    }), _0x14ee2f[_0x38d56a(0x215)](GM_registerMenuCommand, _0x14ee2f[_0x38d56a(0x2df)], () => {
        const _0x3e33c7 = _0x38d56a;
        _0x14ee2f[_0x3e33c7(0x240)] !== _0x14ee2f[_0x3e33c7(0x240)] ? _0x14ee2f[_0x3e33c7(0x1d9)](_0x3a06d6, _0x2a677e(_0x14ee2f[_0x3e33c7(0x1cd)], _0x3e33c7(0x210)), 0x1abf0 * 0x2 + -0x11c8b * 0x3 + 0x7 * 0x3f95, !![]) : (AwBotBan = [], ChatRoomNotificationRaiseChatJoin = function (_0x249361) {
            const _0x8b6a1c = _0x3e33c7, _0x30057b = {
                    '\x4d\x5a\x44\x54\x4b': function (_0x246f93, _0x2e236f) {
                        return _0x246f93 == _0x2e236f;
                    },
                    '\x48\x51\x6a\x56\x4b': _0x14ee2f[_0x8b6a1c(0x293)],
                    '\x4c\x57\x57\x70\x7a': function (_0x54f985, _0x4b3d54, _0x311f08) {
                        return _0x14ee2f['\x46\x48\x47\x44\x71'](_0x54f985, _0x4b3d54, _0x311f08);
                    },
                    '\x65\x6e\x62\x63\x6c': _0x14ee2f[_0x8b6a1c(0x1a1)],
                    '\x64\x56\x4c\x63\x6f': _0x8b6a1c(0x2c3),
                    '\x55\x49\x63\x51\x48': function (_0x334948, _0x5e36df) {
                        return _0x14ee2f['\x6f\x69\x5a\x4c\x42'](_0x334948, _0x5e36df);
                    },
                    '\x4b\x74\x58\x41\x79': _0x14ee2f['\x6d\x4b\x48\x63\x6c'],
                    '\x63\x6b\x4a\x6d\x56': function (_0x3195c6, _0xa20d05) {
                        const _0x544f1e = _0x8b6a1c;
                        return _0x14ee2f[_0x544f1e(0x32a)](_0x3195c6, _0xa20d05);
                    },
                    '\x50\x43\x70\x4b\x53': _0x14ee2f[_0x8b6a1c(0x187)],
                    '\x72\x47\x74\x52\x5a': function (_0x42b49d, _0x23020c) {
                        const _0x391229 = _0x8b6a1c;
                        return _0x14ee2f[_0x391229(0x173)](_0x42b49d, _0x23020c);
                    },
                    '\x68\x50\x6c\x71\x57': function (_0x666185, _0x271dfa) {
                        const _0x5c9c83 = _0x8b6a1c;
                        return _0x14ee2f[_0x5c9c83(0x19a)](_0x666185, _0x271dfa);
                    },
                    '\x56\x72\x6c\x64\x41': _0x8b6a1c(0x362),
                    '\x72\x70\x4d\x77\x6f': _0x14ee2f[_0x8b6a1c(0x2d4)],
                    '\x72\x52\x4c\x70\x56': _0x14ee2f[_0x8b6a1c(0x3bd)],
                    '\x77\x79\x78\x75\x67': _0x14ee2f[_0x8b6a1c(0x3c8)],
                    '\x6a\x52\x44\x76\x62': _0x8b6a1c(0x3ae),
                    '\x6b\x4d\x72\x6c\x70': _0x14ee2f[_0x8b6a1c(0x1b0)],
                    '\x6a\x74\x64\x4d\x49': _0x14ee2f[_0x8b6a1c(0x39c)],
                    '\x64\x70\x43\x4c\x6a': _0x14ee2f[_0x8b6a1c(0x34f)],
                    '\x54\x73\x4f\x48\x4f': _0x14ee2f[_0x8b6a1c(0x31f)],
                    '\x72\x4a\x7a\x4a\x7a': _0x14ee2f['\x78\x78\x6a\x69\x65'],
                    '\x41\x75\x50\x4f\x66': _0x14ee2f[_0x8b6a1c(0x3cd)],
                    '\x68\x78\x53\x63\x4c': _0x14ee2f[_0x8b6a1c(0x3c9)],
                    '\x55\x63\x54\x5a\x64': _0x14ee2f['\x49\x72\x47\x72\x4e'],
                    '\x47\x65\x73\x71\x72': _0x14ee2f[_0x8b6a1c(0x1d5)],
                    '\x72\x51\x73\x4a\x7a': _0x8b6a1c(0x371),
                    '\x67\x67\x43\x7a\x6e': function (_0x52fb11, _0xc2c170) {
                        const _0x4fa25c = _0x8b6a1c;
                        return _0x14ee2f[_0x4fa25c(0x38e)](_0x52fb11, _0xc2c170);
                    }
                };
            if ('\x6d\x69\x49\x6c\x54' === _0x14ee2f[_0x8b6a1c(0x1e6)])
                _0x367eed[_0x8b6a1c(0x38f)]['\x45\x66\x66\x65\x63\x74'] = [];
            else
                return setTimeout(function () {
                    const _0x1a2edd = _0x8b6a1c, _0x4ee751 = {
                            '\x54\x57\x67\x4a\x4b': function (_0x56a286, _0x39e870) {
                                const _0x908920 = _0x11fe;
                                return _0x30057b[_0x908920(0x29e)](_0x56a286, _0x39e870);
                            },
                            '\x79\x6e\x73\x56\x79': function (_0x5dc000, _0xcc4c3) {
                                return _0x5dc000(_0xcc4c3);
                            },
                            '\x57\x59\x58\x49\x66': _0x30057b['\x48\x51\x6a\x56\x4b'],
                            '\x4b\x46\x59\x75\x43': function (_0x4dafa1, _0x17d13b, _0xbe0e7e) {
                                return _0x30057b['\x4c\x57\x57\x70\x7a'](_0x4dafa1, _0x17d13b, _0xbe0e7e);
                            },
                            '\x57\x41\x6e\x70\x4c': _0x30057b[_0x1a2edd(0x320)],
                            '\x65\x73\x6e\x47\x6d': _0x30057b[_0x1a2edd(0x27c)],
                            '\x47\x48\x70\x50\x65': function (_0x5d0c6c, _0x53a0fa) {
                                const _0x408d62 = _0x1a2edd;
                                return _0x30057b[_0x408d62(0x18d)](_0x5d0c6c, _0x53a0fa);
                            },
                            '\x62\x52\x4c\x64\x4b': function (_0x106a29, _0x3132d7) {
                                return _0x30057b['\x4d\x5a\x44\x54\x4b'](_0x106a29, _0x3132d7);
                            },
                            '\x6a\x53\x70\x43\x6f': function (_0x1afb24, _0x9eccb9) {
                                return _0x1afb24 === _0x9eccb9;
                            },
                            '\x64\x50\x49\x52\x4c': _0x30057b[_0x1a2edd(0x2dc)],
                            '\x63\x47\x64\x58\x4e': function (_0x36335, _0x4d9373) {
                                return _0x30057b['\x63\x6b\x4a\x6d\x56'](_0x36335, _0x4d9373);
                            },
                            '\x50\x57\x6e\x77\x4c': _0x1a2edd(0x1e3),
                            '\x67\x7a\x69\x77\x79': _0x30057b[_0x1a2edd(0x2b7)],
                            '\x6f\x78\x56\x6c\x58': function (_0x353751, _0x4aa32c) {
                                const _0x59bf42 = _0x1a2edd;
                                return _0x30057b[_0x59bf42(0x21f)](_0x353751, _0x4aa32c);
                            },
                            '\x4f\x64\x4d\x71\x4c': function (_0xff2258, _0x3191d4) {
                                const _0x5e700b = _0x1a2edd;
                                return _0x30057b[_0x5e700b(0x3e5)](_0xff2258, _0x3191d4);
                            },
                            '\x78\x63\x4f\x79\x4e': _0x30057b[_0x1a2edd(0x2ce)],
                            '\x64\x50\x68\x6f\x42': _0x1a2edd(0x193),
                            '\x72\x48\x62\x4c\x77': _0x30057b['\x72\x70\x4d\x77\x6f']
                        };
                    if (_0x30057b[_0x1a2edd(0x3e5)](_0x1a2edd(0x25d), _0x1a2edd(0x329)))
                        !(_0x17ac9a['\x4f\x77\x6e\x65\x72\x73\x68\x69\x70'] && _0x4ee751[_0x1a2edd(0x1b2)](_0x304f24[_0x1a2edd(0x2b3)][_0x1a2edd(0x1e0)], _0x1a2edd(0x36a))) && _0x4ed7cc(_0x10756d);
                    else {
                        if (_0x30057b[_0x1a2edd(0x29e)](AwBotBan[_0x1a2edd(0x2ff)](_0x249361['\x4e\x61\x6d\x65']), -(0x3 * -0x37d + -0x1283 + 0x1cfb))) {
                            let _0x1c4399 = [
                                _0x30057b[_0x1a2edd(0x2b9)],
                                _0x1a2edd(0x24e),
                                '\x49\x74\x65\x6d\x42\x72\x65\x61\x73\x74',
                                _0x30057b[_0x1a2edd(0x211)],
                                _0x1a2edd(0x206),
                                _0x30057b[_0x1a2edd(0x1f6)],
                                _0x1a2edd(0x22d),
                                _0x1a2edd(0x1e2),
                                _0x1a2edd(0x3fb),
                                '\x49\x74\x65\x6d\x48\x6f\x6f\x64',
                                _0x30057b['\x6b\x4d\x72\x6c\x70'],
                                _0x30057b[_0x1a2edd(0x303)],
                                '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68',
                                _0x30057b[_0x1a2edd(0x270)],
                                _0x30057b[_0x1a2edd(0x3df)],
                                _0x30057b['\x72\x4a\x7a\x4a\x7a'],
                                _0x30057b[_0x1a2edd(0x2d8)],
                                '\x49\x74\x65\x6d\x4e\x65\x63\x6b\x52\x65\x73\x74\x72\x61\x69\x6e\x74\x73',
                                _0x30057b['\x68\x78\x53\x63\x4c'],
                                _0x30057b[_0x1a2edd(0x402)],
                                _0x1a2edd(0x274),
                                _0x1a2edd(0x3e6),
                                _0x30057b['\x47\x65\x73\x71\x72'],
                                _0x30057b[_0x1a2edd(0x35d)],
                                _0x1a2edd(0x26e)
                            ];
                            _0x1c4399[_0x1a2edd(0x289)](_0x297b54 => {
                                InventoryWearRandom(_0x249361, _0x297b54, -0x2f2ea + 0x6 * 0x5885 + -0x2 * -0x14f8f);
                            }), _0x249361[_0x1a2edd(0x281)][_0x1a2edd(0x289)](_0x5f1c57 => {
                                const _0x11446a = _0x1a2edd, _0x107b80 = {
                                        '\x54\x59\x77\x66\x4e': function (_0x519b63, _0x459e48) {
                                            const _0x5a9125 = _0x11fe;
                                            return _0x4ee751[_0x5a9125(0x205)](_0x519b63, _0x459e48);
                                        },
                                        '\x6c\x61\x58\x6c\x6b': _0x4ee751['\x57\x59\x58\x49\x66'],
                                        '\x58\x59\x45\x59\x4d': function (_0x2dfc93, _0x563a71, _0x48beef) {
                                            const _0x17218c = _0x11fe;
                                            return _0x4ee751[_0x17218c(0x384)](_0x2dfc93, _0x563a71, _0x48beef);
                                        },
                                        '\x73\x7a\x7a\x61\x6d': _0x4ee751[_0x11446a(0x2fe)],
                                        '\x66\x61\x50\x47\x56': function (_0x3c38cf, _0x271ed4) {
                                            return _0x4ee751['\x79\x6e\x73\x56\x79'](_0x3c38cf, _0x271ed4);
                                        },
                                        '\x50\x4c\x44\x59\x68': function (_0x1741ef, _0x4c28ff) {
                                            return _0x1741ef(_0x4c28ff);
                                        },
                                        '\x51\x4f\x75\x6d\x65': _0x4ee751[_0x11446a(0x33b)]
                                    };
                                let _0x1211e8 = 0x12 * -0x222 + 0x1 * 0x1a5 + 0x24bf;
                                if (_0x4ee751[_0x11446a(0x3ce)](_0x5f1c57[_0x11446a(0x1a7)], 0xc75 + -0xca * -0x5 + -0x1067)) {
                                    _0x4ee751[_0x11446a(0x1b2)](_0x5f1c57[_0x11446a(0x38f)], null) && (_0x5f1c57['\x50\x72\x6f\x70\x65\x72\x74\x79'] = {});
                                    if (_0x4ee751['\x62\x52\x4c\x64\x4b'](_0x5f1c57[_0x11446a(0x38f)]['\x45\x66\x66\x65\x63\x74'], null)) {
                                        if (_0x4ee751[_0x11446a(0x3f5)](_0x4ee751[_0x11446a(0x391)], _0x4ee751[_0x11446a(0x391)]))
                                            _0x5f1c57[_0x11446a(0x38f)][_0x11446a(0x3d6)] = [];
                                        else {
                                            _0x107b80['\x54\x59\x77\x66\x4e'](_0x5dc328, _0x107b80[_0x11446a(0x35e)]);
                                            return;
                                        }
                                    }
                                    _0x4ee751[_0x11446a(0x31a)](_0x5f1c57[_0x11446a(0x38f)][_0x11446a(0x3d6)][_0x11446a(0x2ff)](_0x4ee751['\x50\x57\x6e\x77\x4c']), 0x2001 + 0x1812 + -0x9 * 0x63b) && (_0x4ee751['\x67\x7a\x69\x77\x79'] === _0x4ee751[_0x11446a(0x1bb)] ? _0x5f1c57[_0x11446a(0x38f)][_0x11446a(0x3d6)]['\x70\x75\x73\x68'](_0x4ee751['\x50\x57\x6e\x77\x4c']) : _0x107b80[_0x11446a(0x1c2)](_0x508832, _0x107b80[_0x11446a(0x30a)], 0x11f8 + -0x13930 + 0x2e68a)), _0x4ee751[_0x11446a(0x308)](Math[_0x11446a(0x1a3)](), -0x1a * -0xd + 0x1a42 + -0x1b94 + 0.5) ? _0x5f1c57[_0x11446a(0x38f)]['\x4c\x6f\x63\x6b\x65\x64\x42\x79'] = _0x11446a(0x208) : _0x4ee751['\x4f\x64\x4d\x71\x4c'](_0x4ee751['\x78\x63\x4f\x79\x4e'], _0x4ee751[_0x11446a(0x28e)]) ? (_0x107b80[_0x11446a(0x369)](_0x5513ab, _0x5b3bcb), _0x3f1b38['\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73'][_0x11446a(0x1ba)] = -0xa74 + -0x814 * -0x4 + 0xaee * -0x2, _0x107b80[_0x11446a(0x1c0)](_0x4b549a, _0x54212d), _0x3da3e5 = _0x107b80[_0x11446a(0x3a6)]) : _0x5f1c57[_0x11446a(0x38f)][_0x11446a(0x2de)] = _0x4ee751[_0x11446a(0x3a4)], _0x5f1c57['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x11446a(0x1ac)] = Player[_0x11446a(0x1b1)], _0x249361[_0x11446a(0x281)][_0x1211e8] = _0x5f1c57;
                                }
                                _0x1211e8++;
                            }), _0x249361[_0x1a2edd(0x2c8)][_0x1a2edd(0x1ba)] = 0xa9 * -0x33 + 0x12c + 0x207f, _0x30057b[_0x1a2edd(0x227)](ChatRoomCharacterUpdate, _0x249361), AwBotBan[_0x1a2edd(0x1f7)](_0x249361[_0x1a2edd(0x1e0)]);
                        }
                    }
                }, 0x12 * -0x10f + 0x212 * -0x4 + -0x81 * -0x3e), !![];
        });
    }), _0x14ee2f[_0x38d56a(0x3b5)](GM_registerMenuCommand, _0x14ee2f[_0x38d56a(0x28a)], () => {
        const _0x2267fc = _0x38d56a, _0x56882b = {
                '\x67\x73\x62\x4c\x57': function (_0x466626, _0x117a2b, _0x3a5817, _0x1dcaab, _0x2b9657, _0x511ff5) {
                    return _0x14ee2f['\x72\x51\x72\x67\x4e'](_0x466626, _0x117a2b, _0x3a5817, _0x1dcaab, _0x2b9657, _0x511ff5);
                },
                '\x4f\x54\x71\x64\x59': _0x14ee2f[_0x2267fc(0x3ad)],
                '\x68\x74\x62\x50\x76': _0x2267fc(0x2ab),
                '\x71\x46\x46\x67\x64': function (_0x75ec86, _0x25d7f2) {
                    return _0x14ee2f['\x69\x66\x6e\x78\x6d'](_0x75ec86, _0x25d7f2);
                },
                '\x78\x78\x76\x6a\x70': _0x2267fc(0x1b4),
                '\x52\x72\x55\x6b\x46': function (_0x185189, _0x53c3e5) {
                    const _0x446162 = _0x2267fc;
                    return _0x14ee2f[_0x446162(0x243)](_0x185189, _0x53c3e5);
                },
                '\x70\x61\x6f\x77\x7a': _0x14ee2f[_0x2267fc(0x383)],
                '\x73\x58\x4b\x47\x41': _0x14ee2f[_0x2267fc(0x2a5)]
            };
        ChatRoomNotificationRaiseChatJoin = function (_0x196c1d) {
            const _0x2c732d = _0x2267fc;
            if (_0x56882b[_0x2c732d(0x3d3)](_0x56882b[_0x2c732d(0x1c9)], _0x56882b[_0x2c732d(0x2b8)]))
                _0x56882b[_0x2c732d(0x38a)](_0x55c40c, _0x5e2c85, _0x56882b[_0x2c732d(0x185)], _0x2c732d(0x344), _0x56882b['\x68\x74\x62\x50\x76'], -0x1ab5 + 0x7f * -0x3ac + -0x3ac5b * -0x1), _0x5767c6[_0x2c732d(0x2c8)][_0x2c732d(0x1ba)] = -0x11f * -0x1 + 0x1 * 0x1b52 + 0x3 * -0x97b, _0x56882b['\x71\x46\x46\x67\x64'](_0x1e1641, _0x2da85d), _0x11933e = _0x56882b[_0x2c732d(0x23c)];
            else
                return !![];
        };
    }), _0x14ee2f[_0x38d56a(0x3be)](GM_registerMenuCommand, _0x38d56a(0x184), () => {
        const _0x51ba7a = _0x38d56a, _0x56946b = {
                '\x6f\x47\x78\x74\x67': function (_0x1bca6a, _0x52f397) {
                    return _0x14ee2f['\x76\x43\x5a\x4a\x7a'](_0x1bca6a, _0x52f397);
                },
                '\x71\x50\x47\x51\x7a': function (_0x3a32b9, _0x117589, _0x2e4455, _0x5862d7, _0x473534, _0x1f77cc) {
                    const _0x3ff7fd = _0x11fe;
                    return _0x14ee2f[_0x3ff7fd(0x22c)](_0x3a32b9, _0x117589, _0x2e4455, _0x5862d7, _0x473534, _0x1f77cc);
                },
                '\x6f\x7a\x69\x51\x62': _0x14ee2f[_0x51ba7a(0x335)],
                '\x65\x5a\x71\x68\x61': _0x14ee2f[_0x51ba7a(0x17a)],
                '\x50\x70\x44\x59\x55': function (_0x5b1c33, _0x2e34bd, _0x3f5ae9, _0x407579, _0x17f877, _0xcda5af) {
                    const _0x7717dd = _0x51ba7a;
                    return _0x14ee2f[_0x7717dd(0x22c)](_0x5b1c33, _0x2e34bd, _0x3f5ae9, _0x407579, _0x17f877, _0xcda5af);
                },
                '\x59\x44\x57\x63\x6c': _0x14ee2f['\x66\x63\x59\x42\x61'],
                '\x73\x76\x74\x44\x79': '\x49\x74\x65\x6d\x41\x72\x6d\x73',
                '\x67\x4e\x47\x77\x59': _0x14ee2f[_0x51ba7a(0x199)]
            };
        targetName = _0x14ee2f[_0x51ba7a(0x32e)](prompt, _0x14ee2f['\x70\x4e\x69\x79\x4a'], _0x14ee2f['\x53\x43\x50\x50\x41']);
        if (_0x14ee2f[_0x51ba7a(0x346)](AwBotBan['\x69\x6e\x64\x65\x78\x4f\x66'](targetName), -(0x1 * 0x85d + 0x168 * -0x1a + 0x1c34))) {
            if (_0x14ee2f['\x70\x62\x45\x51\x65'](_0x51ba7a(0x1a5), _0x14ee2f[_0x51ba7a(0x3a1)])) {
                const _0x369fe0 = _0x51ba7a(0x3fd)['\x73\x70\x6c\x69\x74']('\x7c');
                let _0x132a46 = 0x1905 + -0x1 * 0x249b + 0xb96 * 0x1;
                while (!![]) {
                    switch (_0x369fe0[_0x132a46++]) {
                    case '\x30':
                        _0x56946b['\x6f\x47\x78\x74\x67'](_0xa503bf, _0x19b901);
                        continue;
                    case '\x31':
                        _0x56946b[_0x51ba7a(0x29d)](_0x16e40d, _0x18789c, _0x56946b[_0x51ba7a(0x1d8)], _0x56946b[_0x51ba7a(0x394)], _0x51ba7a(0x2ab), 0x1686c + 0x7655 + -0x1f6f * 0x1);
                        continue;
                    case '\x32':
                        _0x3aade1['\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73'][_0x51ba7a(0x1ba)] = -0x1f45 + -0x20f * -0x3 + 0x1918;
                        continue;
                    case '\x33':
                        _0x56946b[_0x51ba7a(0x212)](_0x2de85b, _0x50a329, _0x56946b[_0x51ba7a(0x3f3)], _0x56946b[_0x51ba7a(0x3ac)], _0x56946b['\x67\x4e\x47\x77\x59'], 0x1 * -0xe7cd + 0x28859 + -0x25e * -0xd);
                        continue;
                    case '\x34':
                        _0x56e883 = _0x51ba7a(0x2e5);
                        continue;
                    }
                    break;
                }
            } else
                _0x14ee2f[_0x51ba7a(0x2fa)](alert, _0x14ee2f['\x70\x44\x41\x5a\x45']);
        }
        AwBotBan[_0x51ba7a(0x1f7)](targetName);
    }), _0x14ee2f[_0x38d56a(0x34d)](GM_registerMenuCommand, _0x14ee2f[_0x38d56a(0x2db)], () => {
        const _0x4da716 = _0x38d56a;
        if (_0x14ee2f['\x68\x59\x54\x72\x72'] === _0x14ee2f[_0x4da716(0x1f8)]) {
            const _0x1f0c69 = _0x4da716(0x2b2)[_0x4da716(0x364)]('\x7c');
            let _0x4d6818 = -0x6 * 0x5e6 + -0x240e + 0x4772;
            while (!![]) {
                switch (_0x1f0c69[_0x4d6818++]) {
                case '\x30':
                    _0x14ee2f['\x73\x6b\x59\x61\x4c'](_0xea4f15, _0x4c64ab, _0x4da716(0x1b8), _0x14ee2f[_0x4da716(0x3cd)], _0x14ee2f['\x75\x55\x43\x6b\x78'], 0x14833 + 0x3ed3 + -0x4 * -0xe13);
                    continue;
                case '\x31':
                    _0x14ee2f['\x78\x6c\x6b\x50\x53'](_0x5dba21, _0x451d94, _0x14ee2f[_0x4da716(0x2c2)], _0x4da716(0x28b), _0x14ee2f[_0x4da716(0x199)], -0xc57 * -0x5 + -0x2a7c + 0x1ac1b);
                    continue;
                case '\x32':
                    _0xf29f3f(_0x391058, _0x4da716(0x1fe), '\x49\x74\x65\x6d\x4e\x65\x63\x6b', _0x14ee2f[_0x4da716(0x199)], 0x19516 + -0x6 * 0x979 + -0x3189 * -0x2);
                    continue;
                case '\x33':
                    _0x14ee2f[_0x4da716(0x22c)](_0x2979f6, _0x2dd1bd, _0x4da716(0x3db), _0x4da716(0x344), _0x14ee2f['\x75\x55\x43\x6b\x78'], -0x86b * 0x1f + 0x4f * -0x643 + -0x4 * -0x12cbd);
                    continue;
                case '\x34':
                    _0x14ee2f['\x41\x71\x4e\x58\x43'](_0x310c99, _0x578924, _0x14ee2f[_0x4da716(0x178)], _0x14ee2f['\x77\x57\x73\x59\x54'], _0x4da716(0x2ab), 0x2ec24 + 0x4ed1 * -0x2 + 0x278 * -0x3a);
                    continue;
                case '\x35':
                    _0x14ee2f[_0x4da716(0x32c)](_0x1cb9a5, _0x4c1229, _0x4da716(0x1e1), _0x14ee2f[_0x4da716(0x17a)], _0x4da716(0x2ab), -0x2e * 0x817 + -0x6d6c + 0x3a0e0);
                    continue;
                case '\x36':
                    _0x14ee2f[_0x4da716(0x2e3)](_0xefc9b2, _0x24a40c, _0x14ee2f[_0x4da716(0x1d3)], _0x4da716(0x1e2), _0x14ee2f['\x75\x55\x43\x6b\x78'], -0x1f05a + 0xb03f * 0x1 + 0x2ff6d);
                    continue;
                case '\x37':
                    _0x14ee2f[_0x4da716(0x22c)](_0xf79d74, _0x133eb1, _0x14ee2f['\x69\x59\x44\x57\x70'], _0x4da716(0x2c9), _0x14ee2f[_0x4da716(0x199)], -0x4e * -0xacf + 0x1a5 * -0x14b + -0x9497 * -0x1);
                    continue;
                case '\x38':
                    _0x14ee2f[_0x4da716(0x38b)](_0x288432, _0x5cf520, _0x4da716(0x245), '\x49\x74\x65\x6d\x48\x65\x61\x64', _0x14ee2f[_0x4da716(0x199)], -0xa * -0x5713 + -0x2 * 0x10ae1 + 0x1 * 0x6e56);
                    continue;
                }
                break;
            }
        } else
            targetName = _0x14ee2f[_0x4da716(0x351)](prompt, _0x14ee2f[_0x4da716(0x357)], _0x14ee2f['\x53\x43\x50\x50\x41']), banIndex = AwBotBan['\x69\x6e\x64\x65\x78\x4f\x66'](targetName), _0x14ee2f['\x74\x4c\x6b\x47\x4f'](banIndex, -(-0x28 * 0x61 + 0xe5 * -0x9 + -0x2 * -0xb9b)) && (_0x14ee2f['\x43\x4b\x56\x4f\x4a'](_0x14ee2f[_0x4da716(0x315)], '\x70\x57\x44\x53\x65') ? _0x14ee2f[_0x4da716(0x2fa)](alert, _0x14ee2f['\x43\x6f\x5a\x64\x77']) : _0x37b6a1[_0x4da716(0x38f)][_0x4da716(0x3d6)] = []), AwBotBan[_0x4da716(0x3ca)](banIndex, -0x1535 * 0x1 + 0x56e * -0x2 + -0x2012 * -0x1);
    }), _0x14ee2f[_0x38d56a(0x215)](GM_registerMenuCommand, _0x38d56a(0x1bd), () => {
        const _0x547d88 = {
            '\x56\x71\x71\x44\x76': function (_0x478809, _0x2e5d2e, _0x4240ef) {
                const _0x132abb = _0x11fe;
                return _0x14ee2f[_0x132abb(0x396)](_0x478809, _0x2e5d2e, _0x4240ef);
            },
            '\x4b\x75\x63\x68\x4b': function (_0x3d2725, _0x23411a) {
                const _0x29116a = _0x11fe;
                return _0x14ee2f[_0x29116a(0x173)](_0x3d2725, _0x23411a);
            },
            '\x79\x6e\x76\x4b\x75': function (_0x3db208, _0x418a30) {
                const _0x20917c = _0x11fe;
                return _0x14ee2f[_0x20917c(0x25f)](_0x3db208, _0x418a30);
            },
            '\x48\x50\x64\x6a\x53': function (_0x47d7a5, _0x43b3cc) {
                const _0x1e6911 = _0x11fe;
                return _0x14ee2f[_0x1e6911(0x305)](_0x47d7a5, _0x43b3cc);
            }
        };
        SpeechGarble = function (_0x5a6397, _0x2fdb01, _0x4a8763) {
            const _0x4deb03 = _0x11fe;
            let _0x430083 = _0x2fdb01, _0x2ab68c = _0x547d88['\x56\x71\x71\x44\x76'](SpeechGetTotalGagLevel, _0x5a6397, _0x4a8763);
            return _0x547d88[_0x4deb03(0x390)](_0x2ab68c, -0xeb6 + -0x779 * 0x1 + 0x162f) && (_0x430083 = _0x547d88[_0x4deb03(0x1b6)](_0x547d88[_0x4deb03(0x3b0)](_0x547d88['\x79\x6e\x76\x4b\x75'](_0x4deb03(0x24d), _0x2ab68c), '\x20'), _0x430083)), _0x430083;
        };
    }), GM_registerMenuCommand(_0x14ee2f[_0x38d56a(0x350)], () => {
        const _0x599328 = _0x38d56a;
        _0x14ee2f[_0x599328(0x1d9)](InventoryWear, targetMember, _0x599328(0x1a4), '\x49\x74\x65\x6d\x4d\x69\x73\x63');
    }), _0x14ee2f[_0x38d56a(0x365)](GM_registerMenuCommand, _0x14ee2f[_0x38d56a(0x31c)], () => {
        const _0x38a23e = _0x38d56a, _0x1ae609 = {};
        _0x1ae609[_0x38a23e(0x299)] = _0x14ee2f[_0x38a23e(0x2d4)];
        const _0x47a11e = _0x1ae609;
        _0x14ee2f[_0x38a23e(0x373)](_0x14ee2f[_0x38a23e(0x236)], _0x14ee2f[_0x38a23e(0x236)]) ? (_0x14ee2f[_0x38a23e(0x3b7)](alert, _0x14ee2f[_0x38a23e(0x2a6)]), CharacterChangeMoney(Player, 0x1335 + 0x425 * -0x5 + 0x1e8)) : _0xeb7fea[_0x38a23e(0x38f)][_0x38a23e(0x2de)] = _0x47a11e['\x42\x4d\x51\x43\x45'];
    }), _0x14ee2f[_0x38d56a(0x36d)](GM_registerMenuCommand, _0x38d56a(0x377), () => {
        const _0x3f086a = _0x38d56a, _0x1cbcd5 = {
                '\x6c\x47\x4e\x4a\x72': function (_0x2a3911, _0x5b399b) {
                    const _0x19c8df = _0x11fe;
                    return _0x14ee2f[_0x19c8df(0x24b)](_0x2a3911, _0x5b399b);
                },
                '\x41\x4a\x76\x78\x42': _0x14ee2f[_0x3f086a(0x399)],
                '\x66\x50\x41\x77\x57': _0x14ee2f[_0x3f086a(0x368)],
                '\x59\x4d\x41\x6b\x41': function (_0x1e396e, _0x13b513) {
                    const _0x4d3651 = _0x3f086a;
                    return _0x14ee2f[_0x4d3651(0x1ca)](_0x1e396e, _0x13b513);
                }
            };
        if (_0x14ee2f[_0x3f086a(0x23f)](_0x3f086a(0x1f1), _0x14ee2f[_0x3f086a(0x1cf)]))
            _0x49a068[_0x3f086a(0x38f)] = {};
        else {
            if (!(Player[_0x3f086a(0x2b3)] && _0x14ee2f[_0x3f086a(0x3ed)](Player['\x4f\x77\x6e\x65\x72\x73\x68\x69\x70'][_0x3f086a(0x1e0)], _0x14ee2f[_0x3f086a(0x368)]))) {
                if (Player[_0x3f086a(0x1e0)] != _0x14ee2f[_0x3f086a(0x368)]) {
                    if (_0x14ee2f[_0x3f086a(0x222)](_0x14ee2f[_0x3f086a(0x2e0)], _0x14ee2f[_0x3f086a(0x311)])) {
                        _0x14ee2f[_0x3f086a(0x238)](alert, _0x14ee2f['\x61\x74\x67\x75\x68']);
                        return;
                    } else {
                        _0x1cbcd5[_0x3f086a(0x3c0)](_0x336188, _0x3f086a(0x21d));
                        return;
                    }
                }
            }
            if (_0x14ee2f['\x64\x64\x4e\x78\x69'](CurrentScreen, '\x43\x68\x61\x74\x52\x6f\x6f\x6d')) {
                if (_0x14ee2f[_0x3f086a(0x230)](_0x14ee2f[_0x3f086a(0x223)], _0x14ee2f[_0x3f086a(0x223)])) {
                    const _0x4f8d99 = _0x14ee2f[_0x3f086a(0x255)][_0x3f086a(0x364)]('\x7c');
                    let _0x1bdfe3 = 0x1046 + 0x17b5 + -0x27fb;
                    while (!![]) {
                        switch (_0x4f8d99[_0x1bdfe3++]) {
                        case '\x30':
                            _0x14ee2f[_0x3f086a(0x288)](CharacterDeleteAllOnline);
                            continue;
                        case '\x31':
                            _0x14ee2f[_0x3f086a(0x1f3)](ChatRoomSetLastChatRoom, '');
                            continue;
                        case '\x32':
                            ChatRoomLeashPlayer = null;
                            continue;
                        case '\x33':
                            _0x14ee2f['\x4e\x65\x77\x43\x53'](ChatRoomClearAllElements);
                            continue;
                        case '\x34':
                            _0x14ee2f['\x49\x46\x42\x4e\x74'](ServerSend, _0x3f086a(0x224), '');
                            continue;
                        case '\x35':
                            _0x14ee2f['\x4e\x65\x77\x43\x53'](ChatSearchExit);
                            continue;
                        case '\x36':
                            _0x14ee2f[_0x3f086a(0x27b)](CommonSetScreen, _0x14ee2f[_0x3f086a(0x258)], _0x14ee2f[_0x3f086a(0x38d)]);
                            continue;
                        case '\x37':
                            DialogLentLockpicks = ![];
                            continue;
                        }
                        break;
                    }
                } else {
                    _0x6756a3 = _0x15fd05(_0x1cbcd5[_0x3f086a(0x372)], _0x1cbcd5[_0x3f086a(0x36c)]), _0x2d5bfc = _0x4b04e8[_0x3f086a(0x34b)](_0x2d33a6 => _0x2d33a6['\x4e\x61\x6d\x65'][_0x3f086a(0x220)]() == _0x70dac0);
                    if (_0x192d53 == null)
                        return;
                    _0x1cbcd5[_0x3f086a(0x20a)](_0xe906f6, _0x336e5c), _0x382a69['\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73']['\x50\x72\x6f\x67\x72\x65\x73\x73'] = -0x1bb2 + 0x771 + -0x55 * -0x3d, _0x1cbcd5['\x6c\x47\x4e\x4a\x72'](_0x2291d5, _0x2693b3);
                }
            } else
                _0x14ee2f[_0x3f086a(0x246)](MainHallWalk, _0x14ee2f[_0x3f086a(0x244)]);
        }
    }), _0x14ee2f[_0x38d56a(0x2f1)](GM_registerMenuCommand, _0x14ee2f['\x44\x76\x6e\x77\x51'], () => {
        const _0x555b53 = _0x38d56a, _0x55d1b3 = {};
        _0x55d1b3['\x67\x41\x51\x77\x5a'] = '\x4c\x6f\x63\x6b';
        const _0x3b79bc = _0x55d1b3;
        _0x14ee2f['\x41\x44\x4f\x48\x6b'](_0x14ee2f['\x4c\x6e\x61\x74\x71'], _0x555b53(0x380)) ? StruggleProgress = 0x2466 + 0x6a7 * 0x2 + -0x1 * 0x3137 : _0x2841fa[_0x555b53(0x38f)]['\x45\x66\x66\x65\x63\x74'][_0x555b53(0x1f7)](_0x3b79bc[_0x555b53(0x2c5)]);
    }), _0x14ee2f[_0x38d56a(0x291)](GM_registerMenuCommand, _0x14ee2f[_0x38d56a(0x395)], () => {
        const _0x1246af = _0x38d56a, _0x397ef9 = {
                '\x49\x46\x55\x66\x79': function (_0x5bb9b5, _0x582748, _0x5872aa) {
                    const _0x48b51d = _0x11fe;
                    return _0x14ee2f[_0x48b51d(0x31b)](_0x5bb9b5, _0x582748, _0x5872aa);
                },
                '\x61\x53\x55\x61\x4b': function (_0x38d9eb, _0x219dc3) {
                    return _0x38d9eb + _0x219dc3;
                }
            };
        if (_0x14ee2f[_0x1246af(0x407)](_0x14ee2f[_0x1246af(0x19e)], _0x1246af(0x272))) {
            const _0xaee3c9 = {
                '\x52\x5a\x41\x42\x72': function (_0xae2f1a, _0x96a801, _0x404d18) {
                    const _0x72e861 = _0x1246af;
                    return _0x397ef9[_0x72e861(0x327)](_0xae2f1a, _0x96a801, _0x404d18);
                },
                '\x50\x66\x4b\x53\x48': function (_0x369f8f, _0x59d796) {
                    return _0x397ef9['\x61\x53\x55\x61\x4b'](_0x369f8f, _0x59d796);
                },
                '\x64\x4a\x49\x6f\x46': function (_0x3aafa1, _0x3965e3) {
                    return _0x3aafa1 + _0x3965e3;
                },
                '\x53\x62\x6d\x68\x63': _0x1246af(0x24d)
            };
            _0x377b8b = function (_0x1fa4d9, _0x1832ed, _0x33fcf9) {
                const _0x384d2a = _0x1246af;
                let _0x23c42e = _0x1832ed, _0x42be74 = _0xaee3c9[_0x384d2a(0x306)](_0x1cefe3, _0x1fa4d9, _0x33fcf9);
                return _0x42be74 > -0x257 + -0x1dab + 0x2002 * 0x1 && (_0x23c42e = _0xaee3c9[_0x384d2a(0x31e)](_0xaee3c9[_0x384d2a(0x34e)](_0xaee3c9[_0x384d2a(0x34e)](_0xaee3c9['\x53\x62\x6d\x68\x63'], _0x42be74), '\x20'), _0x23c42e)), _0x23c42e;
            };
        } else
            _0x14ee2f[_0x1246af(0x351)](SkillProgress, _0x1246af(0x1e7), -0x13 * 0x9ec + 0x12c71 + 0x13 * 0x11a7);
    }), _0x14ee2f[_0x38d56a(0x2fb)](GM_registerMenuCommand, _0x38d56a(0x181), () => {
        const _0x252922 = _0x38d56a;
        _0x14ee2f['\x49\x46\x42\x4e\x74'](SkillProgress, _0x14ee2f[_0x252922(0x360)], -0x1fa18 + 0x16bd * 0x1 + -0xa75 * -0x59);
    }), GM_registerMenuCommand(_0x38d56a(0x2ed), () => {
        _0x14ee2f['\x41\x4f\x45\x74\x50'](SkillProgress, _0x14ee2f['\x4e\x66\x4b\x6e\x74'], 0x2b301 + -0x1e103 + 0x13c7 * 0xc);
    }), _0x14ee2f[_0x38d56a(0x367)](GM_registerMenuCommand, _0x14ee2f[_0x38d56a(0x3aa)], () => {
        const _0x565231 = _0x38d56a;
        _0x14ee2f[_0x565231(0x222)](_0x14ee2f[_0x565231(0x1f0)], _0x565231(0x401)) ? _0x14ee2f[_0x565231(0x28f)](SkillProgress, _0x565231(0x1ed), 0x2d3ae + -0x1 * -0xa625 + 0x7 * -0x3f37) : _0x1f51f1[_0x565231(0x38f)][_0x565231(0x2de)] = _0x14ee2f[_0x565231(0x328)];
    }), _0x14ee2f[_0x38d56a(0x22f)](GM_registerMenuCommand, _0x38d56a(0x3b6), () => {
        const _0x40d636 = _0x38d56a;
        Player[_0x40d636(0x1a7)][_0x40d636(0x21b)] = 0x2585 + 0x17f4 + -0x3d79;
    }), _0x14ee2f['\x64\x64\x6e\x71\x6b'](GM_registerMenuCommand, _0x14ee2f['\x63\x55\x55\x43\x45'], () => {
        const _0x268016 = _0x38d56a;
        _0x14ee2f['\x77\x41\x72\x62\x62'](_0x14ee2f['\x78\x4f\x58\x64\x4b'], '\x70\x77\x56\x69\x46') ? _0x14ee2f[_0x268016(0x291)](SkillProgress, _0x268016(0x2c0), -0x3018e + -0x1bc16 * 0x2 + -0x54a * -0x18e) : _0x2e9b4d[_0x268016(0x38f)]['\x45\x66\x66\x65\x63\x74'] = [];
    }), _0x14ee2f['\x4c\x6f\x65\x72\x4c'](GM_registerMenuCommand, _0x14ee2f[_0x38d56a(0x405)], () => {
        const _0x20bc7a = _0x38d56a;
        _0x14ee2f[_0x20bc7a(0x235)](_0x14ee2f[_0x20bc7a(0x3a5)], _0x14ee2f[_0x20bc7a(0x3a5)]) ? _0x1f43c4[_0x20bc7a(0x38f)][_0x20bc7a(0x2de)] = _0x20bc7a(0x208) : _0x14ee2f[_0x20bc7a(0x331)](SkillProgress, _0x14ee2f[_0x20bc7a(0x261)], -0x202ca + -0x1a117 + 0x56333);
    }), _0x14ee2f[_0x38d56a(0x2f1)](GM_registerMenuCommand, _0x14ee2f['\x4f\x7a\x57\x4b\x41'], () => {
        SkillProgress(_0x14ee2f['\x52\x71\x55\x76\x4a'], -0x1 * 0x31d3 + 0x2d6e1 + -0xe5bc);
    }), _0x14ee2f['\x68\x73\x6a\x4f\x72'](GM_registerMenuCommand, _0x38d56a(0x3ab), () => {
        const _0x3b73ab = _0x38d56a;
        _0x14ee2f[_0x3b73ab(0x1a9)](_0x3b73ab(0x2d1), _0x14ee2f[_0x3b73ab(0x359)]) ? _0x1b4bae[_0x3b73ab(0x38f)][_0x3b73ab(0x3d6)][_0x3b73ab(0x1f7)](_0x3b73ab(0x1e3)) : (_0x14ee2f[_0x3b73ab(0x3c2)](InventoryWear, Player, _0x3b73ab(0x403), _0x3b73ab(0x28b), _0x14ee2f['\x75\x55\x43\x6b\x78'], -0xa905 * 0x2 + -0x1 * 0xaae4 + -0x990 * -0x64), _0x14ee2f[_0x3b73ab(0x2aa)](InventoryWear, Player, _0x14ee2f[_0x3b73ab(0x32b)], _0x14ee2f['\x55\x5a\x79\x6f\x63'], _0x14ee2f[_0x3b73ab(0x199)], -0x2 * -0x15352 + 0x28bcd * -0x1 + 0x1a47b), _0x14ee2f[_0x3b73ab(0x18a)](InventoryWear, Player, _0x14ee2f[_0x3b73ab(0x3d2)], _0x14ee2f[_0x3b73ab(0x1d5)], _0x14ee2f['\x75\x55\x43\x6b\x78'], -0x189ee + 0x3974 + 0x30fcc), _0x14ee2f[_0x3b73ab(0x3c2)](InventoryWear, Player, _0x3b73ab(0x1fe), _0x14ee2f[_0x3b73ab(0x3ba)], _0x3b73ab(0x2ab), 0xba * -0x4cf + 0x29b2a + 0x2a28e), InventoryWear(Player, _0x14ee2f[_0x3b73ab(0x203)], _0x3b73ab(0x191), _0x14ee2f['\x75\x55\x43\x6b\x78'], -0x2 * -0x5adc + 0x2cc7c + -0x1c2e2), _0x14ee2f[_0x3b73ab(0x404)](InventoryWear, Player, _0x14ee2f['\x66\x55\x6c\x70\x78'], _0x14ee2f[_0x3b73ab(0x1b0)], _0x14ee2f[_0x3b73ab(0x199)], -0x1 * 0x31f7 + 0xf373 * 0x2 + -0x1 * -0xa63), _0x14ee2f[_0x3b73ab(0x250)](InventoryWear, Player, _0x14ee2f['\x44\x56\x77\x62\x54'], _0x14ee2f[_0x3b73ab(0x17a)], _0x14ee2f[_0x3b73ab(0x199)], -0x3 * -0xb799 + 0xa6c9 * 0x3 + -0x25bd4), _0x14ee2f[_0x3b73ab(0x2da)](InventoryWear, Player, _0x14ee2f[_0x3b73ab(0x376)], _0x14ee2f[_0x3b73ab(0x3bd)], _0x14ee2f[_0x3b73ab(0x199)], -0x2fb00 + -0x1 * 0xe59 + 0x4c8ab), InventoryWear(Player, _0x14ee2f[_0x3b73ab(0x1d3)], _0x14ee2f[_0x3b73ab(0x201)], _0x3b73ab(0x2ab), 0x7c58 + -0x3 * -0x104c6 + -0x1cb58));
    }), _0x14ee2f['\x67\x59\x54\x66\x74'](GM_registerMenuCommand, _0x38d56a(0x3b4), () => {
        const _0x294eb2 = _0x38d56a;
        _0x14ee2f[_0x294eb2(0x28d)](InventoryWear, Player, _0x14ee2f[_0x294eb2(0x20c)], _0x14ee2f[_0x294eb2(0x39c)]);
    }), GM_registerMenuCommand(_0x14ee2f[_0x38d56a(0x3c5)], () => {
        const _0x33ffe8 = _0x38d56a;
        !(Player[_0x33ffe8(0x2b3)] && Player[_0x33ffe8(0x2b3)]['\x4e\x61\x6d\x65'] == _0x14ee2f['\x53\x43\x50\x50\x41']) && _0x14ee2f[_0x33ffe8(0x3b7)](CharacterReleaseTotal, Player);
    }), _0x14ee2f[_0x38d56a(0x365)](GM_registerMenuCommand, _0x38d56a(0x248), () => {
        const _0x44cfbe = _0x38d56a;
        _0x14ee2f['\x78\x4a\x43\x44\x71'](ServerSend, _0x14ee2f['\x63\x69\x4c\x68\x5a'], {
            '\x43\x6f\x6e\x74\x65\x6e\x74': _0x14ee2f[_0x44cfbe(0x2d9)],
            '\x54\x79\x70\x65': '\x41\x63\x74\x69\x6f\x6e',
            '\x54\x61\x72\x67\x65\x74': null,
            '\x44\x69\x63\x74\x69\x6f\x6e\x61\x72\x79': [{
                    '\x54\x61\x67': _0x14ee2f[_0x44cfbe(0x2d9)],
                    '\x54\x65\x78\x74': prompt(_0x44cfbe(0x366), _0x14ee2f[_0x44cfbe(0x35b)])
                }]
        });
    }), _0x14ee2f[_0x38d56a(0x34d)](GM_registerMenuCommand, _0x14ee2f['\x61\x4a\x61\x47\x68'], () => {
        const _0x45ed21 = _0x38d56a, _0x39d314 = {
                '\x76\x43\x69\x53\x43': function (_0x476a51, _0x4d5ef2, _0x47f8da) {
                    return _0x14ee2f['\x47\x70\x46\x71\x63'](_0x476a51, _0x4d5ef2, _0x47f8da);
                },
                '\x4a\x52\x45\x56\x75': _0x14ee2f[_0x45ed21(0x261)]
            };
        targetName = prompt(_0x14ee2f[_0x45ed21(0x399)], _0x45ed21(0x36a)), targetMember = Character[_0x45ed21(0x34b)](_0x18ca74 => _0x18ca74[_0x45ed21(0x1e0)]['\x74\x6f\x4c\x6f\x77\x65\x72\x43\x61\x73\x65']() == targetName);
        if (targetMember == null) {
            if (_0x14ee2f['\x7a\x69\x70\x67\x73'](_0x14ee2f[_0x45ed21(0x2f4)], _0x45ed21(0x263)))
                _0x39d314['\x76\x43\x69\x53\x43'](_0x545ce2, _0x39d314[_0x45ed21(0x3a2)], -0x1c955 * 0x1 + -0x2189c + 0x5a143);
            else
                return;
        }
        _0x14ee2f[_0x45ed21(0x337)](CharacterReleaseTotal, targetMember), targetMember['\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73']['\x50\x72\x6f\x67\x72\x65\x73\x73'] = 0x1dc8 + 0x1 * -0xf1c + -0x756 * 0x2, ChatRoomCharacterUpdate(targetMember);
    }), _0x14ee2f['\x46\x48\x47\x44\x71'](GM_registerMenuCommand, _0x14ee2f[_0x38d56a(0x1c8)], () => {
        const _0x1ebc54 = _0x38d56a, _0x83682a = {
                '\x42\x53\x62\x6d\x4c': function (_0x4539c8, _0x15b930, _0x53d6bd) {
                    const _0x352b7a = _0x11fe;
                    return _0x14ee2f[_0x352b7a(0x300)](_0x4539c8, _0x15b930, _0x53d6bd);
                },
                '\x54\x59\x52\x4c\x48': _0x14ee2f[_0x1ebc54(0x330)],
                '\x4a\x4d\x69\x41\x49': _0x14ee2f[_0x1ebc54(0x368)],
                '\x63\x72\x41\x50\x78': function (_0x5602e2, _0x3eee0b) {
                    return _0x5602e2(_0x3eee0b);
                },
                '\x42\x73\x64\x73\x76': _0x1ebc54(0x1b7)
            };
        if (_0x14ee2f['\x47\x49\x45\x70\x66'](_0x1ebc54(0x3c3), '\x41\x79\x58\x69\x41'))
            _0x577907(_0x1ebc54(0x3d0), 0x3ba6 + -0x10c9 * 0x13 + 0x2c297);
        else {
            if (!(Player[_0x1ebc54(0x2b3)] && Player[_0x1ebc54(0x2b3)][_0x1ebc54(0x1e0)] == _0x14ee2f[_0x1ebc54(0x368)])) {
                if (Player[_0x1ebc54(0x1e0)] != _0x14ee2f[_0x1ebc54(0x368)]) {
                    if (_0x14ee2f[_0x1ebc54(0x3f6)](_0x14ee2f['\x70\x67\x79\x47\x68'], _0x14ee2f[_0x1ebc54(0x216)])) {
                        _0x14ee2f[_0x1ebc54(0x37b)](alert, _0x14ee2f[_0x1ebc54(0x293)]);
                        return;
                    } else
                        _0x45731f = _0x83682a[_0x1ebc54(0x2f9)](_0xf9d90d, _0x83682a[_0x1ebc54(0x361)], _0x83682a[_0x1ebc54(0x1f4)]), _0x47e0a3[_0x1ebc54(0x2ff)](_0x3dc324) != -(0x49 * 0x62 + -0x22fd + 0x70c) && _0x83682a[_0x1ebc54(0x27e)](_0x12a033, _0x83682a[_0x1ebc54(0x3ef)]), _0x58eb30[_0x1ebc54(0x1f7)](_0x531c5a);
                }
            }
            targetName = prompt(_0x14ee2f[_0x1ebc54(0x2eb)], _0x14ee2f['\x53\x43\x50\x50\x41']), targetMember = Character[_0x1ebc54(0x34b)](_0x47b987 => _0x47b987[_0x1ebc54(0x1e0)][_0x1ebc54(0x220)]() == targetName);
            if (_0x14ee2f[_0x1ebc54(0x363)](targetMember, null)) {
                if (_0x14ee2f['\x71\x6d\x43\x70\x6d'] !== _0x14ee2f['\x53\x4b\x53\x42\x72'])
                    return;
                else
                    _0x2e01d4[_0x1ebc54(0x38f)][_0x1ebc54(0x3d6)] = [];
            }
            _0x14ee2f[_0x1ebc54(0x27d)](InventoryWear, targetMember, _0x14ee2f['\x66\x63\x59\x42\x61'], _0x14ee2f[_0x1ebc54(0x3bd)], _0x1ebc54(0x2ab), -0x3736 + -0x11f7b + -0x3 * -0x10753), InventoryWear(targetMember, _0x14ee2f[_0x1ebc54(0x335)], _0x14ee2f[_0x1ebc54(0x17a)], _0x14ee2f[_0x1ebc54(0x199)], 0x85a5 + -0x34555 + -0x588a * -0xd), targetMember[_0x1ebc54(0x2c8)][_0x1ebc54(0x1ba)] = 0x7 * -0x175 + 0xf * 0x26d + 0x4 * -0x68c, ChatRoomCharacterUpdate(targetMember);
        }
    }), _0x14ee2f[_0x38d56a(0x336)](GM_registerMenuCommand, _0x14ee2f[_0x38d56a(0x22e)], () => {
        const _0x284e5c = _0x38d56a, _0x306da6 = {
                '\x66\x62\x46\x4b\x65': function (_0x5d49cc, _0x1d2687) {
                    return _0x14ee2f['\x52\x76\x6f\x6e\x6c'](_0x5d49cc, _0x1d2687);
                },
                '\x49\x42\x63\x41\x59': function (_0x56f800, _0x30e3f3) {
                    return _0x14ee2f['\x52\x44\x55\x4f\x74'](_0x56f800, _0x30e3f3);
                },
                '\x77\x52\x49\x56\x5a': function (_0xa69579, _0x177eac, _0x375880) {
                    const _0x3aa2e4 = _0x11fe;
                    return _0x14ee2f[_0x3aa2e4(0x3be)](_0xa69579, _0x177eac, _0x375880);
                },
                '\x49\x42\x45\x6b\x55': _0x14ee2f[_0x284e5c(0x17b)]
            };
        if (!(Player[_0x284e5c(0x2b3)] && _0x14ee2f[_0x284e5c(0x26f)](Player['\x4f\x77\x6e\x65\x72\x73\x68\x69\x70'][_0x284e5c(0x1e0)], _0x14ee2f[_0x284e5c(0x368)]))) {
            if (_0x14ee2f[_0x284e5c(0x3b9)](Player['\x4e\x61\x6d\x65'], _0x14ee2f[_0x284e5c(0x368)])) {
                alert(_0x284e5c(0x21d));
                return;
            }
        }
        targetName = _0x14ee2f[_0x284e5c(0x3b5)](prompt, _0x14ee2f[_0x284e5c(0x39e)], _0x14ee2f['\x53\x43\x50\x50\x41']), targetMember = Character[_0x284e5c(0x34b)](_0x28f2c9 => _0x28f2c9[_0x284e5c(0x1e0)][_0x284e5c(0x220)]() == targetName);
        if (targetMember == null)
            return;
        targetMember[_0x284e5c(0x281)]['\x66\x6f\x72\x45\x61\x63\x68'](_0x44c028 => {
            const _0x4b7725 = _0x284e5c, _0xfb1cc7 = {};
            _0xfb1cc7[_0x4b7725(0x2ca)] = _0x14ee2f[_0x4b7725(0x23d)];
            const _0x248d54 = _0xfb1cc7;
            let _0x100f27 = 0x2e2 * -0x5 + -0xf9b + 0x1e05;
            _0x44c028[_0x4b7725(0x1a7)] > -0x44f * -0x1 + -0xc0f * 0x3 + 0x1fde && (_0x14ee2f[_0x4b7725(0x26f)](_0x44c028['\x50\x72\x6f\x70\x65\x72\x74\x79'], null) && (_0x14ee2f[_0x4b7725(0x221)](_0x14ee2f[_0x4b7725(0x3e1)], _0x14ee2f[_0x4b7725(0x188)]) ? _0x2ed13a[_0x4b7725(0x1a7)]['\x4c\x61\x73\x74\x43\x68\x61\x6e\x67\x65'] = 0x1056 + 0x22bd + -0xa37 * 0x5 : _0x44c028[_0x4b7725(0x38f)] = {}), _0x14ee2f[_0x4b7725(0x314)](_0x44c028['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x4b7725(0x3d6)], null) && (_0x14ee2f['\x75\x49\x73\x41\x6e'](_0x14ee2f['\x74\x78\x5a\x61\x6a'], _0x4b7725(0x24f)) ? _0x44c028['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x4b7725(0x3d6)] = [] : _0x2d01cf = _0x306da6[_0x4b7725(0x1af)](_0x306da6[_0x4b7725(0x295)](_0x4b7725(0x24d), _0x566eca), '\x20') + _0x51b01f), _0x14ee2f[_0x4b7725(0x35c)](_0x44c028[_0x4b7725(0x38f)][_0x4b7725(0x3d6)]['\x69\x6e\x64\x65\x78\x4f\x66']('\x4c\x6f\x63\x6b'), -0xedf + -0x683 * -0x1 + 0x5 * 0x1ac) && (_0x14ee2f[_0x4b7725(0x3a9)](_0x14ee2f[_0x4b7725(0x18e)], _0x14ee2f['\x4f\x71\x47\x4f\x57']) ? _0x409b50 = _0x248d54[_0x4b7725(0x2ca)] : _0x44c028[_0x4b7725(0x38f)][_0x4b7725(0x3d6)]['\x70\x75\x73\x68']('\x4c\x6f\x63\x6b')), _0x14ee2f['\x4b\x75\x72\x76\x73'](Math[_0x4b7725(0x1a3)](), 0x10e + 0x663 + 0x771 * -0x1 + 0.5) ? _0x44c028[_0x4b7725(0x38f)]['\x4c\x6f\x63\x6b\x65\x64\x42\x79'] = _0x14ee2f[_0x4b7725(0x328)] : _0x14ee2f['\x77\x41\x72\x62\x62'](_0x14ee2f['\x42\x43\x68\x55\x6c'], _0x14ee2f[_0x4b7725(0x38c)]) ? _0x306da6['\x77\x52\x49\x56\x5a'](_0x131238, _0x306da6[_0x4b7725(0x21e)], 0x357c9 + -0x1 * 0x1d02 + -0x17b75) : _0x44c028['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x4b7725(0x2de)] = _0x4b7725(0x283), _0x44c028[_0x4b7725(0x38f)][_0x4b7725(0x1ac)] = Player[_0x4b7725(0x1b1)], targetMember['\x41\x70\x70\x65\x61\x72\x61\x6e\x63\x65'][_0x100f27] = _0x44c028), _0x100f27++;
        }), targetMember[_0x284e5c(0x2c8)][_0x284e5c(0x1ba)] = 0x1 * 0x1044 + 0xa * -0x2dd + 0xc5e, _0x14ee2f[_0x284e5c(0x179)](ChatRoomCharacterUpdate, targetMember);
    }), GM_registerMenuCommand(_0x14ee2f[_0x38d56a(0x286)], () => {
        const _0x4f278d = _0x38d56a;
        _0x14ee2f['\x49\x55\x59\x75\x52'](ReputationChange, prompt(_0x14ee2f[_0x4f278d(0x1cd)], _0x14ee2f[_0x4f278d(0x1e8)]), 0x2d2d7 * 0x1 + -0x32dbe + 0x21a39, !![]);
    });
}()));
function _0x11fe(_0x11fe57, _0x52eda3) {
    const _0x3d31d6 = _0xbe11();
    return _0x11fe = function (_0x420d05, _0x516c7a) {
        _0x420d05 = _0x420d05 - (0x148b + 0x36 * -0xb0 + -0x904 * -0x2);
        let _0x40aa5a = _0x3d31d6[_0x420d05];
        return _0x40aa5a;
    }, _0x11fe(_0x11fe57, _0x52eda3);
}
function _0xbe11() {
    const _0x2b4e0c = [
        '\x66\x50\x41\x77\x57',
        '\x62\x41\x6e\x64\x5a',
        '\x70\x53\x78\x4d\x6e',
        '\u81ea\u5df1\u5220\u6389\u4e0d\u5bf9\u7684\x2c\x20\u8f93\u9519\u4e86\u540e\u679c\u81ea\u8d1f\x21',
        '\x6f\x67\x63\x4e\x78',
        '\x49\x74\x65\x6d\x56\x75\x6c\x76\x61',
        '\x41\x4a\x76\x78\x42',
        '\x71\x51\x6e\x6c\x6a',
        '\x6f\x76\x48\x4c\x6f',
        '\x52\x6e\x66\x7a\x7a',
        '\x66\x63\x59\x42\x61',
        '\u95e8\u94a5\u5319',
        '\x66\x55\x65\x6c\x69',
        '\x56\x51\x41\x4f\x58',
        '\x67\x53\x58\x66\x55',
        '\x4a\x65\x56\x48\x55',
        '\x48\x55\x48\x51\x5a',
        '\x52\x75\x44\x41\x49',
        '\x4d\x61\x58\x77\x6a',
        '\x72\x48\x66\x4b\x73',
        '\x66\x66\x6e\x4c\x6e',
        '\x59\x68\x4b\x54\x75',
        '\x61\x77\x42\x4f\x54',
        '\x42\x51\x78\x44\x47',
        '\x4b\x46\x59\x75\x43',
        '\x43\x77\x78\x50\x65',
        '\x46\x49\x61\x41\x68',
        '\x6c\x6f\x63\x6b',
        '\x65\x73\x6e\x6e\x46',
        '\u63d0\u5347\u6346\u7ed1\u7b49\u7ea7',
        '\x67\x73\x62\x4c\x57',
        '\x68\x65\x73\x43\x51',
        '\x55\x6d\x5a\x6f\x69',
        '\x4f\x49\x78\x51\x6c',
        '\x79\x67\x74\x57\x62',
        '\x50\x72\x6f\x70\x65\x72\x74\x79',
        '\x4b\x75\x63\x68\x4b',
        '\x64\x50\x49\x52\x4c',
        '\x6a\x67\x72\x72\x71',
        '\x4e\x75\x77\x76\x57',
        '\x65\x5a\x71\x68\x61',
        '\x78\x66\x43\x73\x56',
        '\x49\x46\x42\x4e\x74',
        '\x46\x4e\x50\x70\x73',
        '\x4e\x70\x71\x62\x4e',
        '\x57\x6a\x63\x76\x50',
        '\x51\x4f\x6e\x5a\x71',
        '\x77\x63\x67\x6e\x68',
        '\x54\x6b\x57\x4f\x64',
        '\x78\x79\x69\x43\x55',
        '\x78\x61\x61\x4f\x73',
        '\x6a\x54\x56\x46\x73',
        '\x58\x74\x43\x53\x66',
        '\x6c\x6e\x58\x43\x6b',
        '\x4a\x52\x45\x56\x75',
        '\x6b\x41\x78\x4c\x56',
        '\x72\x48\x62\x4c\x77',
        '\x41\x7a\x63\x78\x59',
        '\x51\x4f\x75\x6d\x65',
        '\x55\x68\x4b\x6a\x43',
        '\x6d\x47\x49\x78\x78',
        '\x50\x65\x69\x53\x49',
        '\x7a\x65\x58\x66\x68',
        '\u901f\u901f\u81ea\u7f1a',
        '\x73\x76\x74\x44\x79',
        '\x62\x6d\x4b\x7a\x78',
        '\x49\x74\x65\x6d\x45\x61\x72\x73',
        '\x56\x52\x72\x79\x7a',
        '\x48\x50\x64\x6a\x53',
        '\x6e\x73\x75\x64\x6a',
        '\x7a\x62\x44\x50\x42',
        '\x42\x65\x65\x70',
        '\u62ff\u7bb1\u5b50',
        '\x59\x4a\x46\x62\x79',
        '\u79fb\u9664\u6781\u9650\x43\x44\x28\u5fc5\u987b\u65b0\u5207\x52\x50\u540e\u7528\x29',
        '\x63\x44\x70\x69\x62',
        '\x34\x38\x36\x34\x38\x71\x42\x58\x55\x41\x49',
        '\x4e\x6e\x6b\x59\x50',
        '\x78\x78\x6a\x69\x65',
        '\x67\x63\x4a\x69\x6a',
        '\u8981\u89e3\u9501\u7684\u73a9\u5bb6\u540d\u79f0\x28\u5168\u5c0f\u5199\x29',
        '\x59\x59\x4a\x4f\x4a',
        '\x45\x55\x6e\x64\x42',
        '\x78\x76\x64\x6b\x66',
        '\x6c\x47\x4e\x4a\x72',
        '\x4e\x43\x7a\x58\x65',
        '\x59\x57\x78\x53\x49',
        '\x41\x79\x58\x69\x41',
        '\x56\x54\x6d\x50\x50',
        '\x4d\x6f\x41\x6e\x4f',
        '\x4c\x6b\x63\x77\x49',
        '\x61\x77\x71',
        '\x64\x48\x4f\x56\x68',
        '\x58\x47\x72\x43\x45',
        '\x73\x70\x6c\x69\x63\x65',
        '\x72\x71\x61\x43\x6b',
        '\x68\x65\x78\x78\x59',
        '\x49\x45\x49\x49\x64',
        '\x47\x48\x70\x50\x65',
        '\x42\x65\x66\x7a\x49',
        '\x4c\x6f\x63\x6b\x50\x69\x63\x6b\x69\x6e\x67',
        '\x75\x68\x4d\x47\x4b',
        '\x69\x59\x44\x57\x70',
        '\x52\x72\x55\x6b\x46',
        '\x61\x77\x42\x4f\x54\x20\x53\x6f\x72\x72\x79\x20\x62\x75\x74\x20\x79\x6f\x75\x27\x76\x65\x20\x62\x65\x65\x6e\x20\x62\x61\x6e\x6e\x65\x64\x20\x62\x79\x20\x61\x6e\x20\x6f\x70\x65\x72\x61\x74\x6f\x72\x2e',
        '\x61\x76\x50\x73\x56',
        '\x45\x66\x66\x65\x63\x74',
        '\x65\x42\x4c\x73\x4e',
        '\x57\x66\x54\x62\x64',
        '\x61\x70\x70\x6c\x79',
        '\x41\x45\x73\x73\x50',
        '\x4c\x65\x61\x74\x68\x65\x72\x41\x72\x6d\x62\x69\x6e\x64\x65\x72',
        '\x50\x61\x64\x64\x65\x64\x4d\x69\x74\x74\x65\x6e\x73',
        '\x4a\x50\x63\x45\x58',
        '\x51\x4a\x56\x44\x4e',
        '\x54\x73\x4f\x48\x4f',
        '\x6a\x65\x4a\x6b\x47',
        '\x5a\x46\x6c\x42\x62',
        '\x7a\x48\x70\x51\x6f',
        '\x6c\x56\x6c\x50\x4d',
        '\x6d\x55\x59\x51\x47',
        '\x68\x50\x6c\x71\x57',
        '\x49\x74\x65\x6d\x50\x65\x6c\x76\x69\x73',
        '\x42\x51\x66\x49\x71',
        '\x7b\x7d\x2e\x63\x6f\x6e\x73\x74\x72\x75\x63\x74\x6f\x72\x28\x22\x72\x65\x74\x75\x72\x6e\x20\x74\x68\x69\x73\x22\x29\x28\x20\x29',
        '\x6f\x4a\x6e\x64\x6f',
        '\x55\x70\x4b\x69\x58',
        '\x37\x30\x34\x38\x39\x32\x33\x47\x52\x77\x54\x67\x50',
        '\x74\x72\x61\x63\x65',
        '\x74\x4c\x6b\x47\x4f',
        '\x54\x51\x58\x54\x4c',
        '\x42\x73\x64\x73\x76',
        '\x68\x73\x64\x4f\x57',
        '\u4e0a\u9501\x28\u641e\u4e8b\u60c5\u4e13\u7528\x29',
        '\x38\x36\x38\x33\x36\x4c\x4f\x6e\x66\x45\x4d',
        '\x59\x44\x57\x63\x6c',
        '\x76\x6e\x77\x57\x4a',
        '\x6a\x53\x70\x43\x6f',
        '\x41\x6e\x76\x6d\x76',
        '\x4e\x65\x77\x43\x53',
        '\x49\x7a\x49\x67\x67',
        '\x64\x7a\x4e\x4b\x59',
        '\x46\x50\x75\x48\x6c',
        '\x49\x74\x65\x6d\x48\x65\x61\x64',
        '\x78\x51\x4c\x63\x77',
        '\x33\x7c\x31\x7c\x32\x7c\x30\x7c\x34',
        '\x66\x79\x66\x62\x75',
        '\x53\x65\x6c\x66\x42\x6f\x6e\x64\x61\x67\x65',
        '\x4d\x61\x69\x6e\x48\x61\x6c\x6c',
        '\x75\x47\x51\x45\x76',
        '\x55\x63\x54\x5a\x64',
        '\x57\x69\x66\x66\x6c\x65\x47\x61\x67',
        '\x4e\x75\x6a\x64\x47',
        '\x4b\x4e\x74\x42\x4b',
        '\x61\x45\x63\x69\x43',
        '\x53\x70\x4e\x71\x5a',
        '\x49\x72\x50\x43\x52',
        '\x72\x71\x4c\x44\x69',
        '\x4b\x75\x72\x76\x73',
        '\x6d\x4c\x6d\x45\x6d',
        '\x74\x73\x78\x57\x4b',
        '\x77\x6f\x68\x76\x7a',
        '\x43\x63\x6c\x74\x78',
        '\x66\x55\x6c\x70\x78',
        '\x6d\x58\x6c\x72\x58',
        '\x4a\x45\x46\x4f\x50',
        '\x52\x71\x55\x76\x4a',
        '\x6b\x4b\x71\x62\x6d',
        '\x44\x44\x47\x4a\x42',
        '\x67\x71\x63\x57\x4d',
        '\x49\x44\x41\x64\x46',
        '\x73\x62\x55\x52\x4c',
        '\u63d0\u5347\u81ea\u7f1a\u7b49\u7ea7',
        '\x7a\x4e\x75\x6d\x62',
        '\x78\x54\x46\x72\x62',
        '\x61\x77\x42\x4f\x54\x5f\u5c01\u7981',
        '\x4f\x54\x71\x64\x59',
        '\x6c\x61\x4e\x70\x69',
        '\x61\x70\x41\x6b\x53',
        '\x44\x66\x42\x59\x51',
        '\x6a\x5a\x65\x71\x54',
        '\x6b\x72\x64\x61\x78',
        '\x62\x69\x6e\x64',
        '\x41\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x2d\x77\x6f\x72\x64\x73\x3a\x72\x65\x6c\x65\x61\x73\x65\x2c\x62\x6f\x6e\x64\x61\x67\x65\x2c\x70\x6c\x61\x79\x73\x75\x69\x74\x2c\x6c\x6f\x63\x6b\x2c\x61\x62\x6f\x75\x74\x2c\x6c\x69\x63\x6b\x2c\x72\x61\x6e\x64\x6f\x6d\x2c\x62\x61\x6e\x6d\x65\x28\x74\x6f\x20\x67\x65\x74\x20\x73\x74\x75\x63\x6b\x2c\x75\x73\x65\x20\x74\x68\x69\x73\x20\x61\x66\x74\x65\x72\x20\x72\x61\x6e\x64\x6f\x6d\x20\x61\x6e\x64\x20\x6c\x6f\x63\x6b\x2e\x29\x2e\x49\x66\x20\x61\x20\x73\x65\x6e\x74\x65\x6e\x63\x65\x20\x69\x6e\x63\x6c\x75\x64\x69\x6e\x67\x20\x22\x61\x77\x71\x22\x20\x68\x61\x73\x20\x61\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x2d\x77\x6f\x72\x64\x20\x61\x74\x20\x74\x68\x65\x20\x73\x61\x6d\x65\x20\x74\x69\x6d\x65\x2c\x20\x74\x68\x65\x6e\x20\x74\x68\x65\x20\x63\x6f\x72\x72\x65\x73\x70\x6f\x6e\x64\x69\x6e\x67\x20\x61\x63\x74\x69\x6f\x6e\x20\x77\x69\x6c\x6c\x20\x62\x65\x20\x74\x61\x6b\x65\x6e\x2e',
        '\x55\x49\x63\x51\x48',
        '\x42\x78\x54\x46\x45',
        '\x48\x5a\x74\x51\x68',
        '\x55\x53\x44\x4e\x63',
        '\x49\x74\x65\x6d\x4e\x65\x63\x6b\x41\x63\x63\x65\x73\x73\x6f\x72\x69\x65\x73',
        '\x61\x43\x79\x67\x6a',
        '\x53\x42\x52\x4f\x59',
        '\x68\x48\x48\x71\x4a',
        '\x78\x71\x41\x65\x6d',
        '\u63d0\u5347\u6323\u624e\u7b49\u7ea7',
        '\x49\x72\x47\x72\x4e',
        '\x49\x74\x65\x6d\x42\x75\x74\x74',
        '\x75\x55\x43\x6b\x78',
        '\x4e\x53\x48\x49\x69',
        '\x7a\x51\x5a\x77\x73',
        '\x41\x73\x20\x75\x20\x77\x69\x73\x68\x7e\x28\x47\x6f\x6f\x64\x20\x6c\x75\x63\x6b\x21\x29',
        '\x72\x41\x4a\x71\x71',
        '\x67\x49\x41\x6b\x63',
        '\x67\x42\x54\x4d\x47',
        '\x62\x6f\x6e\x64\x61\x67\x65',
        '\x62\x7a\x4c\x58\x79',
        '\x71\x7a\x65\x4a\x44',
        '\x72\x61\x6e\x64\x6f\x6d',
        '\x42\x6f\x75\x6e\x74\x79\x53\x75\x69\x74\x63\x61\x73\x65',
        '\x76\x4b\x62\x57\x67',
        '\x47\x79\x62\x4d\x42',
        '\x44\x69\x66\x66\x69\x63\x75\x6c\x74\x79',
        '\x59\x6b\x46\x6b\x50',
        '\x4c\x6c\x73\x76\x4b',
        '\x43\x68\x61\x74\x52\x6f\x6f\x6d\x43\x68\x61\x74',
        '\x55\x4c\x6a\x67\x4a',
        '\x4c\x6f\x63\x6b\x4d\x65\x6d\x62\x65\x72\x4e\x75\x6d\x62\x65\x72',
        '\x63\x6f\x6e\x73\x6f\x6c\x65',
        '\x6d\x57\x42\x48\x74',
        '\x66\x62\x46\x4b\x65',
        '\x77\x57\x73\x59\x54',
        '\x4d\x65\x6d\x62\x65\x72\x4e\x75\x6d\x62\x65\x72',
        '\x54\x57\x67\x4a\x4b',
        '\x65\x72\x72\x6f\x72',
        '\x6d\x65\x6f\x77\x7e\x28\x4d\x61\x6b\x65\x20\x73\x75\x72\x65\x20\x75\x20\x68\x61\x76\x65\x20\x70\x65\x72\x6d\x69\x74\x74\x65\x64\x20\x6d\x65\x29',
        '\x54\x63\x68\x79\x74',
        '\x79\x6e\x76\x4b\x75',
        '\u5c01\u7981\u5931\u8d25\x3a\u73a9\u5bb6\u5df2\u7ecf\u88ab\u5c01\u7981',
        '\x43\x6f\x6c\x6c\x61\x72\x43\x68\x61\x69\x6e\x4c\x6f\x6e\x67',
        '\x73\x5a\x46\x71\x65',
        '\x50\x72\x6f\x67\x72\x65\x73\x73',
        '\x67\x7a\x69\x77\x79',
        '\x59\x55\x72\x44\x66',
        '\u53e3\u7403\u7834\u8bd1',
        '\x61\x74\x75\x74\x45',
        '\x4f\x6e\x6c\x69\x6e\x65',
        '\x50\x4c\x44\x59\x68',
        '\x62\x74\x4e\x52\x78',
        '\x58\x59\x45\x59\x4d',
        '\x64\x48\x54\x46\x76',
        '\x6f\x75\x43\x51\x62',
        '\x49\x52\x44\x4b\x56',
        '\x51\x64\x64\x61\x57',
        '\u83b7\u5f97\u96f6\u82b1\u94b1',
        '\x73\x48\x49\x7a\x65',
        '\x70\x61\x6f\x77\x7a',
        '\x5a\x61\x43\x41\x4c',
        '\x44\x42\x55\x72\x6f',
        '\x74\x55\x48\x4e\x70',
        '\x6e\x51\x76\x45\x43',
        '\x47\x77\x78\x49\x58',
        '\x52\x52\x7a\x50\x75',
        '\x5a\x4b\x4b\x41\x76',
        '\x69\x65\x78\x6b\x43',
        '\x48\x69\x54\x42\x54',
        '\x61\x74\x73\x69\x4d',
        '\x4c\x78\x43\x4d\x77',
        '\x78\x65\x78\x58\x53',
        '\x4f\x55\x58\x73\x54',
        '\x6d\x50\x6e\x57\x6a',
        '\x6f\x7a\x69\x51\x62',
        '\x6d\x58\x43\x70\x65',
        '\x4a\x4a\x79\x43\x66',
        '\x6d\x79\x72\x4c\x44',
        '\x57\x66\x6f\x73\x7a',
        '\x57\x6b\x7a\x4a\x48',
        '\x4c\x4f\x62\x63\x4e',
        '\x77\x62\x58\x78\x4a',
        '\x4e\x61\x6d\x65',
        '\x49\x72\x69\x73\x68\x38\x43\x75\x66\x66\x73',
        '\x49\x74\x65\x6d\x48\x61\x6e\x64\x73',
        '\x4c\x6f\x63\x6b',
        '\x45\x78\x56\x67\x4c',
        '\x63\x7a\x49\x46\x78',
        '\x68\x61\x62\x45\x4d',
        '\x42\x6f\x6e\x64\x61\x67\x65',
        '\x71\x47\x42\x6d\x6e',
        '\u63d0\u5347\u7740\u88c5\u7b49\u7ea7',
        '\x79\x42\x52\x4a\x62',
        '\x6a\x4d\x43\x4a\x6e',
        '\x4c\x4a\x75\x6d\x4f',
        '\x45\x76\x61\x73\x69\x6f\x6e',
        '\x72\x65\x74\x75\x72\x6e\x20\x28\x66\x75\x6e\x63\x74\x69\x6f\x6e\x28\x29\x20',
        '\x53\x46\x6d\x4a\x62',
        '\x75\x58\x72\x6c\x4d',
        '\x46\x45\x4c\x51\x65',
        '\x43\x42\x57\x58\x61',
        '\x54\x61\x62\x53\x76',
        '\x4a\x4d\x69\x41\x49',
        '\x4a\x41\x51\x79\x77',
        '\x6a\x52\x44\x76\x62',
        '\x70\x75\x73\x68',
        '\x5a\x70\x71\x49\x6d',
        '\x66\x79\x6f\x52\x51',
        '\x7a\x4d\x4a\x6f\x57',
        '\u529b\u5927\u65e0\u7a77\x28\u77ac\u95f4\u6323\u8131\x29',
        '\x6c\x69\x75\x65\x44',
        '\x43\x58\x75\x71\x69',
        '\x53\x74\x65\x65\x6c\x50\x6f\x73\x74\x75\x72\x65\x43\x6f\x6c\x6c\x61\x72',
        '\u63d0\u5347\u5185\u9b3c\u7b49\u7ea7',
        '\u5e7b\u5f71\u79fb\u5f62\x28\u80fd\u7ed9\u522b\u4eba\u5f00\u9501\x29',
        '\x42\x74\x41\x4a\x79',
        '\x57\x72\x77\x57\x52',
        '\x66\x52\x46\x66\x68',
        '\x4a\x54\x6f\x5a\x50',
        '\x79\x6e\x73\x56\x79',
        '\x49\x74\x65\x6d\x44\x65\x76\x69\x63\x65\x73',
        '\x35\x37\x33\x39\x4e\x50\x49\x72\x68\x45',
        '\x4d\x69\x73\x74\x72\x65\x73\x73\x50\x61\x64\x6c\x6f\x63\x6b',
        '\x6e\x49\x6c\x4c\x74',
        '\x59\x4d\x41\x6b\x41',
        '\x79\x47\x45\x78\x47',
        '\x6c\x4b\x6c\x74\x71',
        '\x67\x71\x57\x6a\x51',
        '\x68\x53\x6a\x43\x63',
        '\u672a\u77e5\u6307\u4ee4\uff01\x20\u53ef\u7528\u6307\u4ee4\x3a\x20\u6346\u6211\x20\u6346\u6b7b\u6211\x20\u8214\u6211\x20\u6551\u6211\x20\u73a9\u6211\x20\u9501\u6211\x20\u5173\u4e8e\x20\u5982\u679c\u4e00\u53e5\u8bdd\u540c\u65f6\u5305\u542b\x22\x61\x77\u9171\x22\u548c\u6307\u4ee4\uff0c\u6307\u4ee4\u5c31\u4f1a\u88ab\u6267\u884c\x7e',
        '\x44\x6f\x6d\x69\x6e\x61\x6e\x74\x20\x20\x4b\x69\x64\x6e\x61\x70\x20\x20\x41\x42\x44\x4c\x20\x20\x47\x61\x6d\x69\x6e\x67\x20\x20\x4d\x61\x69\x64\x20\x20\x4c\x41\x52\x50\x20\x20\x41\x73\x79\x6c\x75\x6d\x20\x20\x47\x61\x6d\x62\x6c\x69\x6e\x67\x20\x20\x48\x6f\x75\x73\x65\x4d\x61\x69\x65\x73\x74\x61\x73\x20\x20\x48\x6f\x75\x73\x65\x56\x69\x6e\x63\x75\x6c\x61\x20\x20\x48\x6f\x75\x73\x65\x41\x6d\x70\x6c\x65\x63\x74\x6f\x72\x20\x20\x48\x6f\x75\x73\x65\x43\x6f\x72\x70\x6f\x72\x69\x73',
        '\x77\x79\x78\x75\x67',
        '\x50\x70\x44\x59\x55',
        '\x72\x65\x6c\x65\x61\x73\x65',
        '\x67\x46\x66\x6e\x7a',
        '\x51\x79\x50\x62\x52',
        '\x70\x67\x79\x47\x68',
        '\x6c\x69\x63\x6b\x73\x20',
        '\x49\x6e\x66\x69\x6c\x74\x72\x61\x74\x69\x6f\x6e',
        '\x41\x77\x71',
        '\x72\x51\x72\x67\x4e',
        '\x4c\x61\x73\x74\x43\x68\x61\x6e\x67\x65',
        '\x55\x71\x57\x55\x43',
        '\u4f60\u5fc5\u987b\u662f\x61\x77\x61\x71\x77\x71\u7684\x73\x75\x62\u624d\u80fd\u8fd9\u4e48\u505a\u5462\x7e',
        '\x49\x42\x45\x6b\x55',
        '\x72\x47\x74\x52\x5a',
        '\x74\x6f\x4c\x6f\x77\x65\x72\x43\x61\x73\x65',
        '\x52\x63\x4e\x75\x6b',
        '\x43\x4b\x56\x4f\x4a',
        '\x61\x50\x57\x6a\x67',
        '\x43\x68\x61\x74\x52\x6f\x6f\x6d\x4c\x65\x61\x76\x65',
        '\x68\x78\x77\x61\x6a',
        '\u548c\u6211\u7b7e\u8ba2\u5951\u7ea6\uff0c\u6210\u4e3a\u9b54\u6cd5\u5c11\u5973\u5427\uff01',
        '\x67\x67\x43\x7a\x6e',
        '\x43\x71\x5a\x7a\x6b',
        '\x70\x47\x73\x66\x66',
        '\x75\x66\x6f\x70\x4c',
        '\x42\x62\x61\x48\x78',
        '\x78\x6c\x6b\x50\x53',
        '\x49\x74\x65\x6d\x46\x65\x65\x74',
        '\x77\x73\x42\x76\x46',
        '\x45\x47\x58\x43\x69',
        '\x72\x4b\x48\x56\x59',
        '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68\x32',
        '\x31\x7c\x32\x7c\x33\x7c\x34\x7c\x30',
        '\x70\x77\x56\x69\x46',
        '\x63\x6f\x6e\x73\x74\x72\x75\x63\x74\x6f\x72',
        '\x54\x65\x66\x47\x59',
        '\x58\x4a\x56\x76\x52',
        '\x69\x46\x4e\x69\x4f',
        '\x59\x4d\x6c\x46\x72',
        '\x74\x46\x66\x68\x4e',
        '\x6f\x55\x70\x6e\x4c',
        '\x61\x74\x64\x4e\x6e',
        '\x78\x78\x76\x6a\x70',
        '\x46\x78\x74\x66\x61',
        '\x49\x45\x4c\x6a\x6d',
        '\x70\x62\x45\x51\x65',
        '\x5a\x63\x5a\x6b\x59',
        '\x4c\x65\x61\x74\x68\x65\x72\x42\x65\x6c\x74',
        '\x6e\x49\x58\x67\x72',
        '\x77\x41\x72\x62\x62',
        '\x67\x7a\x4b\x72\x43',
        '\x4c\x65\x61\x74\x68\x65\x72\x48\x6f\x6f\x64\x4f\x70\x65\x6e\x4d\x6f\x75\x74\x68',
        '\x69\x66\x6e\x78\x6d',
        '\x61\x77\x42\x4f\x54\x5f\u9677\u9631\u5c4b',
        '\u58f0\u97f3\u6d2a\u4eae\x28\u8bf4\u4ec0\u4e48\u5c31\u662f\u4ec0\u4e48\x29',
        '\x4d\x6c\x59\x61\x6a',
        '\x63\x69\x4c\x68\x5a',
        '\x63\x61\x4d\x67\x68',
        '\x42\x46\x64\x4c\x77',
        '\u53e3\u7403\x6c\x76',
        '\x49\x74\x65\x6d\x42\x6f\x6f\x74\x73',
        '\x6d\x61\x78\x62\x58',
        '\x63\x74\x54\x54\x44',
        '\x34\x30\x39\x32\x34\x30\x48\x4e\x6d\x67\x64\x47',
        '\x49\x53\x63\x47\x4c',
        '\x69\x6e\x66\x6f',
        '\x61\x77\x42\x4f\x54\x20',
        '\x53\x41\x73\x49\x77',
        '\x67\x65\x4c\x73\x78',
        '\u8981\u89e3\u5c01\u7684\u73a9\u5bb6\u540d\u79f0',
        '\x4d\x4c\x61\x78\x4c',
        '\x6b\x53\x44\x4f\x6c',
        '\x71\x62\x61\x66\x65',
        '\x49\x74\x73\x4e\x6e',
        '\x48\x5a\x71\x65\x68',
        '\x4e\x4f\x61\x7a\x6b',
        '\x68\x48\x79\x7a\x73',
        '\x56\x42\x6c\x66\x46',
        '\x4c\x73\x52\x46\x42',
        '\x4a\x63\x59\x66\x6e',
        '\x70\x67\x64\x6d\x4a',
        '\x61\x75\x53\x71\x63',
        '\x71\x6a\x66\x6f\x43',
        '\x58\x79\x4a\x73\x49',
        '\u8981\u5c01\u7981\u7684\u73a9\u5bb6\u540d\u79f0',
        '\x4a\x58\x54\x42\x50',
        '\x68\x43\x44\x41\x70',
        '\x43\x74\x5a\x4e\x68',
        '\x48\x49\x4a\x46\x4c',
        '\x4d\x53\x76\x65\x50',
        '\x70\x76\x70\x79\x72',
        '\x71\x45\x54\x63\x66',
        '\x49\x74\x65\x6d\x56\x75\x6c\x76\x61\x50\x69\x65\x72\x63\x69\x6e\x67\x73',
        '\x42\x58\x44\x43\x6f',
        '\x64\x70\x43\x4c\x6a',
        '\x4d\x71\x6b\x57\x43',
        '\x56\x5a\x44\x56\x6a',
        '\x49\x74\x65\x6d\x4e\x65\x63\x6b',
        '\x49\x74\x65\x6d\x4e\x6f\x73\x65',
        '\x49\x74\x65\x6d\x48\x6f\x6f\x64',
        '\x57\x63\x6f\x46\x4d',
        '\x41\x59\x65\x49\x58',
        '\x6c\x68\x78\x6d\x4d',
        '\x53\x46\x62\x6a\x53',
        '\x49\x74\x65\x6d\x4e\x65\x63\x6b\x52\x65\x73\x74\x72\x61\x69\x6e\x74\x73',
        '\x74\x72\x6d\x67\x5a',
        '\x64\x56\x4c\x63\x6f',
        '\x58\x70\x4a\x4b\x70',
        '\x63\x72\x41\x50\x78',
        '\x45\x51\x54\x74\x59',
        '\x6c\x65\x6e\x67\x74\x68',
        '\x41\x70\x70\x65\x61\x72\x61\x6e\x63\x65',
        '\x41\x73\x20\x75\x20\x77\x69\x73\x68\x7e\x28\x4d\x61\x6b\x65\x20\x73\x75\x72\x65\x20\x75\x20\x68\x61\x76\x65\x20\x70\x65\x72\x6d\x69\x74\x74\x65\x64\x20\x6d\x65\x29',
        '\x50\x61\x6e\x64\x6f\x72\x61\x50\x61\x64\x6c\x6f\x63\x6b',
        '\x74\x75\x57\x41\x63',
        '\x52\x51\x58\x4d\x4e',
        '\x4d\x59\x4b\x66\x46',
        '\x6f\x4e\x62\x51\x55',
        '\x46\x42\x70\x4a\x52',
        '\x66\x6f\x72\x45\x61\x63\x68',
        '\x62\x77\x71\x51\x52',
        '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68',
        '\x5a\x42\x66\x59\x4a',
        '\x49\x55\x59\x75\x52',
        '\x64\x50\x68\x6f\x42',
        '\x41\x4f\x45\x74\x50',
        '\x43\x68\x61\x74',
        '\x5a\x74\x44\x44\x51',
        '\x75\x62\x52\x6d\x6e',
        '\x61\x74\x67\x75\x68',
        '\x43\x68\x61\x74\x53\x65\x61\x72\x63\x68',
        '\x49\x42\x63\x41\x59',
        '\x42\x54\x4e\x6e\x6d',
        '\x45\x5a\x70\x46\x79',
        '\x78\x6f\x51\x44\x4a',
        '\x42\x4d\x51\x43\x45',
        '\x71\x6e\x62\x47\x6c',
        '\x77\x50\x58\x6e\x77',
        '\x59\x49\x6d\x59\x4e',
        '\x71\x50\x47\x51\x7a',
        '\x4d\x5a\x44\x54\x4b',
        '\x61\x77\u9171',
        '\x61\x77\x42\x4f\x54\x5f\u89e3\u5c01',
        '\x5a\x59\x73\x41\x4e',
        '\x73\x6a\x67\x4c\x6c',
        '\x63\x57\x43\x43\x6e',
        '\x50\x74\x54\x7a\x69',
        '\x7a\x74\x45\x6b\x4d',
        '\x51\x70\x7a\x52\x52',
        '\x50\x5a\x65\x7a\x6b',
        '\x5a\x51\x52\x71\x6a',
        '\x5a\x49\x74\x47\x58',
        '\x62\x7a\x53\x44\x58',
        '\x23\x32\x30\x32\x30\x32\x30',
        '\x79\x62\x4c\x41\x58',
        '\x61\x77\x42\x4f\x54\x5f\u5173\u95ed\u9677\u9631\u5c4b',
        '\x6d\x6d\x4d\x4b\x4c',
        '\x6e\x44\x48\x4e\x53',
        '\x48\x69\x4e\x58\x68',
        '\x56\x48\x64\x65\x56',
        '\x31\x7c\x38\x7c\x37\x7c\x32\x7c\x30\x7c\x34\x7c\x35\x7c\x33\x7c\x36',
        '\x4f\x77\x6e\x65\x72\x73\x68\x69\x70',
        '\x51\x67\x76\x4a\x70',
        '\x5a\x45\x4d\x41\x70',
        '\x49\x46\x75\x4f\x6a',
        '\x50\x43\x70\x4b\x53',
        '\x73\x58\x4b\x47\x41',
        '\x72\x52\x4c\x70\x56',
        '\x6f\x70\x6b\x76\x6c',
        '\x48\x79\x4c\x61\x48',
        '\x5f\x5f\x70\x72\x6f\x74\x6f\x5f\x5f',
        '\x59\x4f\x46\x63\x69',
        '\x49\x74\x65\x6d\x4e\x69\x70\x70\x6c\x65\x73\x50\x69\x65\x72\x63\x69\x6e\x67\x73',
        '\x4f\x45\x6f\x57\x56',
        '\x57\x69\x6c\x6c\x70\x6f\x77\x65\x72',
        '\u8981\u4e0a\u9501\u7684\u73a9\u5bb6\u540d\u79f0\x28\u5168\u5c0f\u5199\x29',
        '\x4b\x54\x76\x64\x77',
        '\u5982\u4f60\u6240\u613f\x20\x28\u5e38\u89c1\u95ee\u9898\x3a\u4e0d\u89e3\u4e3b\u4eba\x2f\u604b\u4eba\x2c\u8bf7\u5f00\u6743\u9650\x29\x7e',
        '\x6c\x6f\x67',
        '\x67\x41\x51\x77\x5a',
        '\x67\x66\x43\x6f\x42',
        '\x56\x73\x70\x6f\x61',
        '\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73',
        '\x49\x74\x65\x6d\x54\x6f\x72\x73\x6f',
        '\x6e\x6c\x4d\x64\x4e',
        '\x34\x30\x39\x35\x34\x32\x78\x69\x78\x51\x70\x73',
        '\x6d\x6f\x71\x75\x5a',
        '\x71\x63\x70\x69\x4a',
        '\x56\x72\x6c\x64\x41',
        '\x46\x70\x75\x4b\x61',
        '\u963f\u62c9\u970d\u6d1e\u5f00',
        '\x75\x78\x6b\x76\x42',
        '\x77\x61\x46\x57\x7a',
        '\x6d\x77\x70\x67\x66',
        '\x45\x59\x53\x56\x72',
        '\x76\x6d\x42\x44\x58',
        '\x43\x4c\x63\x54\x41',
        '\x56\x76\x76\x52\x51',
        '\x41\x75\x50\x4f\x66',
        '\x62\x50\x44\x4f\x44',
        '\x73\x6b\x59\x61\x4c',
        '\x68\x4b\x6e\x4f\x49',
        '\x4b\x74\x58\x41\x79',
        '\x64\x6e\x67\x6d\x6f',
        '\x4c\x6f\x63\x6b\x65\x64\x42\x79',
        '\x4f\x73\x58\x70\x4c',
        '\x5a\x74\x79\x70\x4e',
        '\x42\x69\x74\x63\x68\x53\x75\x69\x74',
        '\x61\x77\x42\x4f\x54\x20\u62b1\u6b49\x2c\u60a8\u5df2\u7ecf\u88ab\u5c01\u7981\u3002',
        '\x74\x41\x4c\x61\x4a',
        '\x59\x48\x61\x6b\x45',
        '\u5982\u4f60\u6240\u613f\x20\x28\u5e38\u89c1\u95ee\u9898\x3a\u8bf7\u5f00\u6743\u9650\x29\x7e',
        '\x73\x6f\x6f\x57\x78',
        '\x49\x59\x55\x56\x45',
        '\x52\x65\x45\x78\x6c',
        '\x6c\x62\x4b\x75\x67',
        '\x6f\x52\x43\x75\x4d',
        '\x54\x49\x55\x76\x52',
        '\x57\x5a\x6c\x77\x47',
        '\u63d0\u5347\u64ac\u9501\u7b49\u7ea7',
        '\u7b11\x7e\x20\x28\u5e38\u89c1\u95ee\u9898\x3a\u8bf7\u5f00\u6743\u9650\x29\x7e',
        '\x57\x78\x46\x79\x67',
        '\x49\x74\x65\x6d\x4d\x69\x73\x63',
        '\x54\x68\x73\x66\x4e',
        '\x57\x59\x4c\x79\x63',
        '\x4f\x76\x76\x56\x47',
        '\x42\x51\x57\x50\x4d',
        '\x6f\x68\x76\x58\x63',
        '\x70\x72\x6f\x74\x6f\x74\x79\x70\x65',
        '\x73\x61\x65\x74\x4f',
        '\x69\x75\x77\x79\x71',
        '\x42\x53\x62\x6d\x4c',
        '\x4d\x76\x50\x64\x51',
        '\x73\x54\x72\x4b\x42',
        '\x51\x4b\x46\x68\x44',
        '\x64\x65\x4d\x47\x4b',
        '\x57\x41\x6e\x70\x4c',
        '\x69\x6e\x64\x65\x78\x4f\x66',
        '\x48\x62\x53\x65\x55',
        '\x69\x4d\x57\x78\x4e',
        '\x4f\x4f\x6a\x4e\x67',
        '\x6a\x74\x64\x4d\x49',
        '\x58\x58\x6a\x75\x68',
        '\x52\x76\x6f\x6e\x6c',
        '\x52\x5a\x41\x42\x72',
        '\x41\x71\x6a\x4f\x61',
        '\x6f\x78\x56\x6c\x58',
        '\u5927\u7b11\x7e\x20\x28\u987a\u624b\u62d6\u5165\u5c01\u7981\u540d\u5355\x29\x7e',
        '\x73\x7a\x7a\x61\x6d',
        '\x56\x4f\x57\x70\x68',
        '\x61\x68\x51\x71\x76',
        '\x55\x6d\x45\x44\x69',
        '\x62\x49\x46\x51\x55',
        '\x77\x61\x72\x6e',
        '\x56\x55\x44\x6a\x42',
        '\x50\x51\x69\x62\x4f',
        '\x76\x6d\x69\x6f\x65',
        '\x72\x6d\x43\x4b\x74',
        '\x41\x42\x79\x53\x7a',
        '\x71\x4a\x54\x49\x6a',
        '\x6d\x4d\x75\x5a\x76',
        '\x5a\x6a\x69\x52\x43',
        '\x42\x53\x67\x45\x7a',
        '\u58f0\u540d\u8fdc\u626c\x28\u4fee\u6539\u5404\u7c7b\u58f0\u8a89\x29',
        '\x63\x47\x64\x58\x4e',
        '\x46\x48\x47\x44\x71',
        '\x4d\x44\x7a\x66\x4f',
        '\x65\x63\x56\x4b\x66',
        '\x50\x66\x4b\x53\x48',
        '\x54\x73\x42\x45\x6e',
        '\x65\x6e\x62\x63\x6c',
        '\x59\x44\x41\x4f\x4c',
        '\x37\x7c\x33\x7c\x34\x7c\x31\x7c\x32\x7c\x36\x7c\x30\x7c\x35',
        '\x49\x74\x65\x6d\x4e\x69\x70\x70\x6c\x65\x73',
        '\x65\x78\x63\x65\x70\x74\x69\x6f\x6e',
        '\x72\x47\x42\x68\x47',
        '\x56\x4d\x6b\x68\x4a',
        '\x49\x46\x55\x66\x79',
        '\x76\x53\x69\x66\x6f',
        '\x79\x66\x51\x53\x44',
        '\x79\x42\x72\x61\x53',
        '\x41\x5a\x48\x58\x45',
        '\x68\x65\x42\x42\x77',
        '\x49\x57\x70\x5a\x6e',
        '\x68\x73\x6a\x4f\x72',
        '\x50\x51\x51\x49\x46',
        '\x70\x4e\x69\x79\x4a',
        '\x50\x45\x47\x4b\x78',
        '\x66\x55\x4a\x55\x56',
        '\x46\x52\x59\x69\x54',
        '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68\x33',
        '\x44\x56\x77\x62\x54',
        '\x62\x71\x65\x42\x61',
        '\x77\x4a\x63\x48\x43',
        '\x50\x4c\x44\x49\x4c',
        '\x53\x71\x4d\x4f\x65',
        '\x66\x74\x75\x6f\x4a',
        '\x65\x73\x6e\x47\x6d',
        '\u8981\u6346\u7684\u73a9\u5bb6\u540d\u79f0\x28\u5168\u5c0f\u5199\x29',
        '\x64\x54\x70\x72\x6e',
        '\x62\x61\x6e\x6d\x65',
        '\x32\x7c\x34\x7c\x33\x7c\x30\x7c\x31',
        '\x68\x6d\x45\x68\x63',
        '\x43\x49\x77\x7a\x74',
        '\x47\x62\x71\x63\x57',
        '\x57\x77\x49\x70\x6f',
        '\x49\x74\x65\x6d\x41\x72\x6d\x73',
        '\x75\x71\x74\x49\x66',
        '\x42\x6f\x70\x4f\x4b',
        '\x4b\x4c\x4e\x4e\x6d',
        '\x33\x34\x31\x33\x32\x31\x36\x52\x44\x4e\x55\x73\x4a',
        '\x31\x33\x30\x52\x42\x4d\x74\x41\x76',
        '\x74\x61\x62\x6c\x65',
        '\x66\x69\x6e\x64',
        '\u5c01\u7981\u5931\u8d25\x3a\u73a9\u5bb6\u6ca1\u6709\u88ab\u5c01\u7981',
        '\x4f\x56\x6c\x62\x53',
        '\x64\x4a\x49\x6f\x46',
        '\x73\x71\x6a\x4b\x6d',
        '\x6d\x57\x49\x55\x77',
        '\x46\x79\x4d\x78\x67',
        '\x65\x67\x74\x6b\x52',
        '\x4f\x49\x78\x5a\x6d',
        '\x43\x70\x66\x74\x75',
        '\x74\x50\x61\x42\x70',
        '\x56\x67\x6c\x50\x46',
        '\x74\x77\x69\x50\x73',
        '\x6a\x50\x67\x6c\x74',
        '\x57\x4e\x78\x49\x66',
        '\x53\x62\x75\x65\x77',
        '\x75\x4c\x79\x55\x55',
        '\x43\x68\x50\x49\x58',
        '\x72\x51\x73\x4a\x7a',
        '\x6c\x61\x58\x6c\x6b',
        '\x4a\x6e\x73\x53\x6c',
        '\x6b\x45\x64\x74\x69',
        '\x54\x59\x52\x4c\x48',
        '\x4f\x79\x48\x7a\x75',
        '\x64\x64\x4e\x78\x69',
        '\x73\x70\x6c\x69\x74',
        '\x78\x4a\x43\x44\x71',
        '\u4f60\u8981\u8bf4\u7684\u8bdd',
        '\x4c\x6f\x65\x72\x4c',
        '\x53\x43\x50\x50\x41',
        '\x66\x61\x50\x47\x56',
        '\x61\x77\x61\x71\x77\x71',
        '\x4c\x79\x6b\x41\x45'
    ];
    _0xbe11 = function () {
        return _0x2b4e0c;
    };
    return _0xbe11();
}