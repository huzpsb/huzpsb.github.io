// ==UserScript==
// @name BcGod
// @description BC RP模式增强~
// @version Private_5
// @namespace awaqwq_huzpsb
// @match *://*/*BondageClub*
// @grant GM_registerMenuCommand
// ==/UserScript==

(function (_0x48cb6c, _0x1247da) {
    const _0x541e08 = _0x5822, _0x3ce49e = _0x48cb6c();
    while (!![]) {
        try {
            const _0x3496e9 = parseInt(_0x541e08(0x3dd)) / (-0x11df + -0x3fa * -0x8 + -0xdf0) + parseInt(_0x541e08(0x365)) / (0x13c * 0x2 + -0x2164 * 0x1 + 0x1eee) + -parseInt(_0x541e08(0x28b)) / (0x2034 + -0x1ef1 + -0x140) * (parseInt(_0x541e08(0x349)) / (-0x2 * 0x914 + 0x5 * 0x327 + 0x269)) + -parseInt(_0x541e08(0x37f)) / (0x1 * -0x1fdd + -0xf51 + -0x2f33 * -0x1) * (-parseInt(_0x541e08(0x2c3)) / (-0x5 * -0x53c + -0x33c + -0x16ea)) + -parseInt(_0x541e08(0x487)) / (-0x2 * 0x62 + 0x262e + -0x2563) + -parseInt(_0x541e08(0x25d)) / (0x104c + 0x23c2 + 0x3406 * -0x1) * (-parseInt(_0x541e08(0x325)) / (0x8d1 + 0x3d * -0x59 + -0x1 * -0xc6d)) + -parseInt(_0x541e08(0x350)) / (0x3 * 0xaf2 + -0x51b * 0x5 + -0x745);
            if (_0x3496e9 === _0x1247da)
                break;
            else
                _0x3ce49e['push'](_0x3ce49e['shift']());
        } catch (_0x262cdd) {
            _0x3ce49e['push'](_0x3ce49e['shift']());
        }
    }
}(_0x29a0, 0x116f50 + -0x4ed * -0x92 + -0x1 * 0x6f947), (function () {
    const _0x4b7c40 = _0x5822, _0x564dbb = {
            '\x72\x70\x74\x74\x48': function (_0x123b14, _0x399b2c, _0x346a17, _0x5cf357) {
                return _0x123b14(_0x399b2c, _0x346a17, _0x5cf357);
            },
            '\x79\x53\x4d\x66\x65': function (_0x421fcb, _0x109721) {
                return _0x421fcb !== _0x109721;
            },
            '\x49\x52\x51\x71\x54': '\x71\x69\x65\x74\x7a',
            '\x79\x69\x6b\x54\x6f': '\x47\x76\x51\x51\x76',
            '\x69\x61\x79\x53\x54': function (_0x7f215c, _0x12de03) {
                return _0x7f215c(_0x12de03);
            },
            '\x58\x69\x46\x43\x70': function (_0x2fbce5, _0x7a1634) {
                return _0x2fbce5 + _0x7a1634;
            },
            '\x43\x51\x5a\x46\x77': _0x4b7c40(0x400),
            '\x4b\x47\x76\x6a\x6e': function (_0x57a37e) {
                return _0x57a37e();
            },
            '\x47\x68\x6d\x5a\x41': _0x4b7c40(0x319),
            '\x62\x53\x44\x59\x6c': _0x4b7c40(0x1a4),
            '\x65\x48\x61\x61\x45': '\x69\x6e\x66\x6f',
            '\x76\x4d\x47\x72\x75': _0x4b7c40(0x3fb),
            '\x65\x4f\x6e\x7a\x69': _0x4b7c40(0x2f0),
            '\x46\x61\x6d\x5a\x6f': _0x4b7c40(0x3be),
            '\x52\x56\x68\x6f\x62': function (_0x11b9db, _0x5b07ca) {
                return _0x11b9db < _0x5b07ca;
            },
            '\x73\x66\x79\x4d\x48': function (_0x1371cd, _0x37bd12) {
                return _0x1371cd(_0x37bd12);
            },
            '\x59\x67\x72\x6a\x77': '\u4f60\u5df2\u7ecf\u521d\u59cb\u5316\u8fc7\u4e86\u5462\x7e',
            '\x68\x53\x58\x61\x77': function (_0xd7dd36, _0x4377fe) {
                return _0xd7dd36 === _0x4377fe;
            },
            '\x6f\x42\x70\x44\x58': _0x4b7c40(0x39c),
            '\x77\x58\x4b\x6f\x59': _0x4b7c40(0x252),
            '\x5a\x67\x53\x71\x67': _0x4b7c40(0x1b0),
            '\x76\x4f\x56\x49\x4a': '\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x3a\x20\u7c98\u8d34\x2e',
            '\x70\x49\x63\x7a\x43': '\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x3a\x20\u968f\u673a\x2e',
            '\x45\x49\x6a\x51\x4e': function (_0x14519d, _0xdf84fe, _0x57927d) {
                return _0x14519d(_0xdf84fe, _0x57927d);
            },
            '\x64\x67\x4c\x48\x43': _0x4b7c40(0x21f),
            '\x4f\x42\x4a\x4b\x6c': function (_0x4e6515, _0x56e098, _0x2beb84) {
                return _0x4e6515(_0x56e098, _0x2beb84);
            },
            '\x62\x43\x6c\x72\x77': '\x43\x68\x61\x74\x52\x6f\x6f\x6d\x41\x64\x6d\x69\x6e',
            '\x77\x53\x4e\x76\x58': _0x4b7c40(0x2bd),
            '\x58\x50\x66\x6b\x7a': _0x4b7c40(0x234),
            '\x4d\x43\x6b\x55\x75': _0x4b7c40(0x217),
            '\x7a\x47\x54\x68\x6a': function (_0x427a37, _0x18904f) {
                return _0x427a37 > _0x18904f;
            },
            '\x62\x64\x75\x70\x43': function (_0xee4c5, _0x3c88a1) {
                return _0xee4c5 !== _0x3c88a1;
            },
            '\x6b\x6a\x76\x6d\x48': _0x4b7c40(0x299),
            '\x44\x52\x5a\x73\x78': function (_0xf5c333, _0x164e1a, _0xcb4062) {
                return _0xf5c333(_0x164e1a, _0xcb4062);
            },
            '\x6b\x43\x46\x76\x41': _0x4b7c40(0x2e3),
            '\x6a\x73\x6a\x6a\x64': function (_0x20a487, _0x16e2d0) {
                return _0x20a487 > _0x16e2d0;
            },
            '\x41\x7a\x6b\x43\x78': function (_0x9d8d7a, _0x45b4ea) {
                return _0x9d8d7a !== _0x45b4ea;
            },
            '\x44\x42\x73\x69\x72': '\x4f\x69\x43\x6f\x52',
            '\x73\x58\x68\x46\x41': _0x4b7c40(0x3df),
            '\x53\x66\x75\x4d\x58': _0x4b7c40(0x3b0),
            '\x6f\x78\x6c\x43\x55': function (_0x406712, _0x3c814f, _0x2348df, _0x49bdc7, _0x54a2ac, _0x5961f1) {
                return _0x406712(_0x3c814f, _0x2348df, _0x49bdc7, _0x54a2ac, _0x5961f1);
            },
            '\x4d\x71\x6d\x6e\x70': _0x4b7c40(0x17f),
            '\x73\x76\x52\x78\x48': _0x4b7c40(0x269),
            '\x75\x59\x79\x6e\x43': '\x61\x6b\x78\x7a\x6e',
            '\x6e\x54\x64\x4e\x74': function (_0x58898f, _0x397639) {
                return _0x58898f == _0x397639;
            },
            '\x48\x69\x57\x46\x66': _0x4b7c40(0x1ca),
            '\x47\x78\x73\x48\x7a': _0x4b7c40(0x476),
            '\x70\x4d\x65\x6e\x57': _0x4b7c40(0x1a2),
            '\x54\x56\x42\x54\x4f': function (_0x5de437, _0x50a4f3) {
                return _0x5de437 != _0x50a4f3;
            },
            '\x69\x76\x6e\x43\x44': _0x4b7c40(0x454),
            '\x47\x45\x62\x76\x6b': _0x4b7c40(0x3db),
            '\x64\x73\x6a\x76\x4a': function (_0x580a84, _0x33603b) {
                return _0x580a84 != _0x33603b;
            },
            '\x4a\x69\x55\x46\x43': function (_0x3c04d9, _0x13a719) {
                return _0x3c04d9 != _0x13a719;
            },
            '\x58\x78\x77\x6a\x73': '\x6c\x69\x63\x6b\x73\x20',
            '\x75\x72\x63\x66\x79': _0x4b7c40(0x178),
            '\x76\x50\x4c\x69\x6f': _0x4b7c40(0x334),
            '\x63\x63\x78\x68\x4b': _0x4b7c40(0x42c),
            '\x4f\x6e\x5a\x63\x51': _0x4b7c40(0x2f3),
            '\x72\x74\x50\x42\x6f': _0x4b7c40(0x1b1),
            '\x47\x6e\x4e\x66\x55': _0x4b7c40(0x474),
            '\x58\x47\x6b\x43\x58': _0x4b7c40(0x30c),
            '\x53\x52\x67\x49\x6e': _0x4b7c40(0x3ae),
            '\x44\x72\x6c\x4c\x50': '\x49\x74\x65\x6d\x48\x6f\x6f\x64',
            '\x74\x4c\x74\x5a\x4e': '\x49\x74\x65\x6d\x4c\x65\x67\x73',
            '\x62\x58\x59\x61\x47': _0x4b7c40(0x29e),
            '\x76\x5a\x6f\x70\x6e': '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68\x32',
            '\x73\x44\x4f\x5a\x69': _0x4b7c40(0x2bf),
            '\x4b\x43\x72\x67\x4e': _0x4b7c40(0x3cf),
            '\x4e\x75\x53\x7a\x53': _0x4b7c40(0x3b6),
            '\x68\x67\x48\x74\x73': _0x4b7c40(0x477),
            '\x52\x68\x64\x65\x53': _0x4b7c40(0x31b),
            '\x4e\x52\x4d\x5a\x6e': _0x4b7c40(0x410),
            '\x69\x6c\x6b\x44\x57': _0x4b7c40(0x248),
            '\x78\x4c\x79\x4a\x52': _0x4b7c40(0x26e),
            '\x6b\x53\x4e\x78\x6e': function (_0x30736b, _0x575976) {
                return _0x30736b != _0x575976;
            },
            '\x78\x6f\x50\x75\x55': _0x4b7c40(0x1a7),
            '\x76\x73\x73\x61\x7a': function (_0x3123f4, _0x3a8a5f) {
                return _0x3123f4 !== _0x3a8a5f;
            },
            '\x69\x4f\x6d\x41\x78': _0x4b7c40(0x3c4),
            '\x51\x74\x4d\x69\x53': _0x4b7c40(0x174),
            '\x66\x7a\x79\x73\x66': _0x4b7c40(0x200),
            '\x57\x46\x6c\x79\x65': _0x4b7c40(0x3b5),
            '\x41\x4d\x6d\x6a\x50': function (_0x435bd6, _0xb98c5c) {
                return _0x435bd6 != _0xb98c5c;
            },
            '\x70\x6a\x70\x58\x58': function (_0x652b41, _0x3e6418, _0x10ece9, _0x1fc606, _0x550983, _0x1277c9) {
                return _0x652b41(_0x3e6418, _0x10ece9, _0x1fc606, _0x550983, _0x1277c9);
            },
            '\x65\x79\x4a\x44\x75': '\x41\x73\x20\x75\x20\x77\x69\x73\x68\x7e\x28\x4d\x61\x6b\x65\x20\x73\x75\x72\x65\x20\x75\x20\x68\x61\x76\x65\x20\x70\x65\x72\x6d\x69\x74\x74\x65\x64\x20\x6d\x65\x29',
            '\x51\x74\x52\x48\x57': _0x4b7c40(0x467),
            '\x58\x75\x4c\x43\x55': _0x4b7c40(0x2a8),
            '\x6a\x5a\x69\x42\x72': _0x4b7c40(0x157),
            '\x76\x64\x79\x52\x6c': _0x4b7c40(0x201),
            '\x76\x6b\x6f\x4f\x4c': '\x68\x74\x73\x4f\x4d',
            '\x41\x68\x6b\x6d\x49': '\x49\x74\x65\x6d\x42\x72\x65\x61\x73\x74',
            '\x4d\x6c\x6e\x58\x72': _0x4b7c40(0x189),
            '\x75\x61\x4b\x6b\x42': _0x4b7c40(0x223),
            '\x71\x50\x43\x51\x47': _0x4b7c40(0x2a0),
            '\x4b\x4d\x6e\x61\x46': function (_0x2982f9, _0x3c8b62) {
                return _0x2982f9(_0x3c8b62);
            },
            '\x54\x47\x50\x61\x52': function (_0x5e39ae, _0x10b5db) {
                return _0x5e39ae != _0x10b5db;
            },
            '\x6b\x72\x4e\x4c\x65': _0x4b7c40(0x387),
            '\x6d\x45\x4b\x54\x46': _0x4b7c40(0x170),
            '\x49\x61\x67\x71\x57': _0x4b7c40(0x38c),
            '\x73\x4e\x72\x49\x79': _0x4b7c40(0x1c7),
            '\x54\x6e\x41\x46\x69': _0x4b7c40(0x281),
            '\x42\x59\x72\x42\x4a': _0x4b7c40(0x20e),
            '\x50\x42\x6b\x43\x7a': _0x4b7c40(0x29f),
            '\x50\x50\x69\x62\x4b': _0x4b7c40(0x471),
            '\x6d\x41\x6b\x72\x69': _0x4b7c40(0x1e2),
            '\x45\x62\x6a\x71\x4e': function (_0x453b61, _0xf7273c) {
                return _0x453b61 == _0xf7273c;
            },
            '\x4f\x76\x6c\x5a\x58': function (_0x5ed540, _0x393e4d) {
                return _0x5ed540 == _0x393e4d;
            },
            '\x79\x59\x57\x6f\x66': function (_0xc980f7, _0x88e1e3) {
                return _0xc980f7 !== _0x88e1e3;
            },
            '\x44\x54\x54\x77\x70': '\x48\x4e\x64\x50\x6d',
            '\x4a\x71\x69\x58\x74': _0x4b7c40(0x297),
            '\x4b\x49\x41\x4e\x50': '\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x3a\x20\x45\x6e\x67\x6c\x69\x73\x68\x2e',
            '\x72\x57\x61\x66\x67': _0x4b7c40(0x24e),
            '\x4e\x46\x68\x51\x7a': _0x4b7c40(0x2ba),
            '\x64\x47\x74\x6a\x44': function (_0x58a4c2, _0x24db96) {
                return _0x58a4c2 == _0x24db96;
            },
            '\x69\x68\x5a\x63\x57': _0x4b7c40(0x20f),
            '\x70\x72\x58\x44\x67': _0x4b7c40(0x3f9),
            '\x4d\x6c\x70\x68\x6c': _0x4b7c40(0x3ba),
            '\x6f\x71\x71\x69\x54': _0x4b7c40(0x342),
            '\x68\x43\x76\x72\x67': '\x48\x69\x64\x64\x65\x6e',
            '\x67\x53\x47\x44\x4c': '\x33\x2e\x36\x2e\x31',
            '\x72\x71\x6b\x53\x66': _0x4b7c40(0x2e2),
            '\x57\x52\x70\x48\x62': _0x4b7c40(0x3c9),
            '\x77\x6d\x44\x4e\x77': function (_0x238cff, _0x588e9f) {
                return _0x238cff(_0x588e9f);
            },
            '\x63\x70\x56\x45\x69': '\u81ea\u5df1\u5220\u6389\u4e0d\u5bf9\u7684\x2c\x20\u8f93\u9519\u4e86\u540e\u679c\u81ea\u8d1f\x21',
            '\x55\x65\x4d\x76\x46': function (_0x5119fe, _0x2170d5) {
                return _0x5119fe < _0x2170d5;
            },
            '\x4e\x54\x50\x6e\x54': '\x63\x4f\x44\x48\x54',
            '\x7a\x6e\x53\x62\x4f': _0x4b7c40(0x441),
            '\x71\x57\x71\x50\x6d': _0x4b7c40(0x158),
            '\x70\x61\x4b\x4e\x62': _0x4b7c40(0x227),
            '\x50\x4d\x42\x4f\x72': _0x4b7c40(0x46a),
            '\x6f\x7a\x64\x49\x48': _0x4b7c40(0x207),
            '\x6e\x58\x66\x77\x72': _0x4b7c40(0x1fb),
            '\x70\x51\x6f\x77\x41': _0x4b7c40(0x34c),
            '\x53\x62\x58\x6d\x52': '\x61\x77\x54\x52\x41\x50\x20\x52\x75\x6c\x65\x73\x3a\x31\x2c\x57\x68\x65\x6e\x20\x74\x68\x65\x20\x72\x6f\x6f\x6d\x20\x77\x61\x73\x20\x63\x72\x65\x61\x74\x65\x64\x2c\x61\x20\x74\x69\x6d\x65\x72\x20\x77\x61\x73\x20\x73\x65\x74\x20\x74\x6f\x20\x31\x35\x20\x6d\x69\x6e\x73\x2e\x32\x2c\x42\x65\x66\x6f\x72\x65\x20\x74\x68\x65\x20\x74\x69\x6d\x65\x72\x20\x72\x75\x6e\x73\x20\x6f\x75\x74\x2c\x61\x6e\x79\x6f\x6e\x65\x20\x77\x68\x6f\x20\x63\x6f\x6d\x65\x73\x20\x69\x6e\x74\x6f\x20\x74\x68\x69\x73\x20\x72\x6f\x6f\x6d\x20\x77\x69\x6c\x6c\x20\x67\x65\x74\x20\x74\x72\x61\x70\x70\x65\x64\x2e\x33\x2c\x42\x65\x66\x72\x6f\x65\x20\x74\x68\x65\x20\x74\x69\x6d\x65\x72\x20\x72\x75\x6e\x73\x20\x6f\x75\x74\x2c\x61\x6e\x79\x6f\x6e\x65\x20\x77\x68\x6f\x20\x61\x74\x74\x65\x6d\x70\x74\x73\x20\x74\x6f\x20\x72\x65\x73\x63\x75\x65\x20\x77\x69\x6c\x6c\x20\x62\x65\x20\x62\x61\x6e\x6e\x65\x64\x2e\x34\x2c\x41\x66\x74\x65\x72\x20\x74\x68\x65\x20\x74\x69\x6d\x65\x72\x20\x72\x75\x6e\x73\x20\x6f\x75\x74\x2c\x20\x61\x77\x54\x52\x41\x50\x20\x77\x69\x6c\x6c\x20\x62\x65\x20\x73\x61\x66\x65\x2e\x54\x68\x6f\x73\x65\x20\x77\x68\x6f\x20\x61\x72\x65\x20\x74\x72\x61\x70\x70\x65\x64\x20\x63\x61\x6e\x20\x70\x6c\x65\x61\x64\x20\x70\x61\x73\x73\x65\x72\x2d\x62\x79\x73\x20\x66\x6f\x72\x20\x68\x65\x6c\x70\x20\x74\x68\x65\x6e\x2e',
            '\x69\x64\x78\x63\x62': function (_0x1063c9, _0x252c3c) {
                return _0x1063c9 == _0x252c3c;
            },
            '\x6c\x42\x4d\x67\x64': '\x43\x68\x61\x74\x52\x6f\x6f\x6d\x4d\x65\x73\x73\x61\x67\x65',
            '\x68\x44\x47\x50\x78': _0x4b7c40(0x17b),
            '\x56\x51\x70\x6b\x50': '\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x3a\x20\x44\x69\x73\x61\x62\x6c\x65\x64\x2e',
            '\x6c\x76\x6c\x51\x50': function (_0x36552c, _0x28c1c4) {
                return _0x36552c(_0x28c1c4);
            },
            '\x6d\x6e\x6b\x4b\x43': function (_0x2bdcc3, _0x18708e, _0x22cda6) {
                return _0x2bdcc3(_0x18708e, _0x22cda6);
            },
            '\x6d\x77\x52\x50\x71': _0x4b7c40(0x2dc),
            '\x57\x6e\x4a\x49\x45': function (_0x343c97, _0x14956) {
                return _0x343c97 === _0x14956;
            },
            '\x75\x65\x57\x71\x51': _0x4b7c40(0x25c),
            '\x68\x68\x55\x44\x70': '\x49\x6e\x66\x69\x6c\x74\x72\x61\x74\x69\x6f\x6e',
            '\x48\x44\x78\x4b\x43': function (_0x29c900, _0x63b12f, _0x4896d3) {
                return _0x29c900(_0x63b12f, _0x4896d3);
            },
            '\x62\x51\x68\x58\x67': '\x44\x72\x65\x73\x73\x61\x67\x65',
            '\x64\x6c\x62\x46\x65': function (_0x1263a6, _0x383745) {
                return _0x1263a6 !== _0x383745;
            },
            '\x7a\x6e\x68\x43\x68': '\x48\x53\x69\x7a\x58',
            '\x46\x78\x42\x6b\x4c': _0x4b7c40(0x2e9),
            '\x45\x4c\x66\x69\x4d': '\x35\x7c\x37\x7c\x33\x7c\x32\x7c\x30\x7c\x36\x7c\x31\x7c\x34\x7c\x38',
            '\x75\x77\x76\x57\x6a': function (_0x3eda82, _0x40c38f, _0x55347a, _0x2c4090, _0x393202, _0x25abe7) {
                return _0x3eda82(_0x40c38f, _0x55347a, _0x2c4090, _0x393202, _0x25abe7);
            },
            '\x4b\x49\x73\x5a\x47': _0x4b7c40(0x466),
            '\x75\x64\x79\x45\x61': function (_0x2c53b6, _0x2ababc, _0x3d12a0, _0x4f25c6, _0x626876, _0x228466) {
                return _0x2c53b6(_0x2ababc, _0x3d12a0, _0x4f25c6, _0x626876, _0x228466);
            },
            '\x63\x58\x51\x42\x66': '\x53\x74\x65\x65\x6c\x50\x6f\x73\x74\x75\x72\x65\x43\x6f\x6c\x6c\x61\x72',
            '\x42\x69\x58\x73\x4c': function (_0x46d2eb, _0x2e44d4, _0x45e677, _0x402af8, _0x46abeb, _0x2e18f7) {
                return _0x46d2eb(_0x2e44d4, _0x45e677, _0x402af8, _0x46abeb, _0x2e18f7);
            },
            '\x71\x52\x43\x54\x55': _0x4b7c40(0x3c8),
            '\x56\x4a\x62\x59\x4c': _0x4b7c40(0x431),
            '\x4e\x56\x70\x6b\x70': _0x4b7c40(0x3f1),
            '\x57\x4b\x45\x4a\x65': '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68',
            '\x56\x6d\x44\x6e\x4b': _0x4b7c40(0x305),
            '\x58\x72\x6e\x46\x59': function (_0x23edb2, _0x4ba8ef, _0x18898c, _0x4c133f, _0x2c273a, _0xa17e67) {
                return _0x23edb2(_0x4ba8ef, _0x18898c, _0x4c133f, _0x2c273a, _0xa17e67);
            },
            '\x7a\x4c\x44\x5a\x51': '\x50\x61\x64\x64\x65\x64\x4d\x69\x74\x74\x65\x6e\x73',
            '\x56\x43\x7a\x44\x78': _0x4b7c40(0x3e9),
            '\x55\x6c\x43\x6d\x41': function (_0x18122a, _0x1a3858, _0x452a96, _0x3827aa) {
                return _0x18122a(_0x1a3858, _0x452a96, _0x3827aa);
            },
            '\x6c\x69\x44\x75\x71': _0x4b7c40(0x3da),
            '\x58\x4b\x6d\x67\x62': _0x4b7c40(0x2e1),
            '\x4d\x44\x47\x42\x63': function (_0x11db3b, _0x17510b, _0x224b7f) {
                return _0x11db3b(_0x17510b, _0x224b7f);
            },
            '\x77\x66\x52\x58\x4d': _0x4b7c40(0x2ee),
            '\x76\x4c\x71\x53\x48': _0x4b7c40(0x296),
            '\x61\x49\x72\x53\x4c': _0x4b7c40(0x3d0),
            '\x64\x78\x43\x76\x67': '\x56\x75\x73\x59\x51',
            '\x4b\x78\x53\x65\x4e': function (_0x6c8513, _0x375cf0, _0x5d848d, _0x33d8fb) {
                return _0x6c8513(_0x375cf0, _0x5d848d, _0x33d8fb);
            },
            '\x58\x62\x4a\x4a\x79': _0x4b7c40(0x278),
            '\x6c\x54\x56\x46\x62': _0x4b7c40(0x416),
            '\x45\x4c\x4b\x62\x46': _0x4b7c40(0x402),
            '\x47\x71\x72\x4f\x79': '\x43\x68\x61\x74\x53\x65\x61\x72\x63\x68',
            '\x44\x77\x4f\x4f\x72': _0x4b7c40(0x231),
            '\x73\x71\x76\x53\x71': _0x4b7c40(0x3fc),
            '\x6c\x71\x62\x4b\x58': function (_0x25f79c, _0x1e29da) {
                return _0x25f79c === _0x1e29da;
            },
            '\x55\x61\x43\x54\x54': _0x4b7c40(0x41d),
            '\x51\x4c\x6f\x61\x51': _0x4b7c40(0x30a),
            '\x7a\x59\x6b\x73\x74': '\x51\x68\x42\x47\x79',
            '\x74\x52\x6e\x6f\x59': function (_0x536b36, _0x4ab432, _0x390aa1) {
                return _0x536b36(_0x4ab432, _0x390aa1);
            },
            '\x45\x41\x7a\x68\x6f': function (_0x913e25, _0x4965dd) {
                return _0x913e25(_0x4965dd);
            },
            '\x6e\x54\x44\x4a\x6b': _0x4b7c40(0x34b),
            '\x64\x58\x6c\x4c\x4d': function (_0x5bf1a1, _0x290b40) {
                return _0x5bf1a1 + _0x290b40;
            },
            '\x47\x63\x6b\x53\x4e': _0x4b7c40(0x395),
            '\x51\x50\x58\x64\x68': function (_0x12bd58, _0x1e5fd2) {
                return _0x12bd58 == _0x1e5fd2;
            },
            '\x41\x76\x6d\x57\x74': function (_0x1fef44, _0xcb3a0c) {
                return _0x1fef44 === _0xcb3a0c;
            },
            '\x6f\x67\x76\x76\x63': _0x4b7c40(0x245),
            '\x73\x58\x4b\x74\x61': _0x4b7c40(0x3e4),
            '\x62\x78\x5a\x4b\x45': function (_0xd10ff8, _0x381cb9) {
                return _0xd10ff8 != _0x381cb9;
            },
            '\x72\x79\x57\x5a\x41': _0x4b7c40(0x23f),
            '\x63\x61\x75\x57\x46': '\x66\x66\x7a\x73\x75',
            '\x44\x45\x56\x54\x5a': function (_0x19af78, _0x365a30) {
                return _0x19af78 + _0x365a30;
            },
            '\x78\x4c\x68\x79\x56': function (_0x20a6dc, _0x1eaebd) {
                return _0x20a6dc + _0x1eaebd;
            },
            '\x6d\x6b\x6c\x79\x77': _0x4b7c40(0x2a5),
            '\x68\x7a\x6b\x75\x4e': '\x41\x63\x74\x69\x6f\x6e\x52\x65\x6d\x6f\x76\x65',
            '\x6e\x55\x68\x59\x44': _0x4b7c40(0x36e),
            '\x58\x67\x47\x45\x4f': '\x54\x68\x58\x79\x54',
            '\x63\x43\x74\x67\x4e': _0x4b7c40(0x3b7),
            '\x65\x79\x57\x55\x59': _0x4b7c40(0x47b),
            '\x62\x77\x4b\x42\x56': function (_0x22a616, _0x2f9d4b) {
                return _0x22a616 != _0x2f9d4b;
            },
            '\x42\x70\x74\x76\x73': _0x4b7c40(0x2ea),
            '\x77\x49\x44\x61\x79': _0x4b7c40(0x291),
            '\x52\x6d\x50\x43\x73': '\x47\x4e\x46\x6b\x50',
            '\x6f\x71\x54\x68\x6d': function (_0x16002b, _0x3a70d1, _0x38af21) {
                return _0x16002b(_0x3a70d1, _0x38af21);
            },
            '\x52\x63\x77\x58\x65': _0x4b7c40(0x282),
            '\x77\x6c\x4f\x6e\x6d': function (_0x580c1e, _0x5d5aff, _0x5ecc25) {
                return _0x580c1e(_0x5d5aff, _0x5ecc25);
            },
            '\x73\x75\x70\x62\x62': function (_0x5e7afb, _0x48e7bf) {
                return _0x5e7afb === _0x48e7bf;
            },
            '\x58\x50\x54\x77\x49': '\x5a\x75\x45\x4b\x56',
            '\x50\x72\x4b\x6f\x44': _0x4b7c40(0x34f),
            '\x59\x58\x4f\x4f\x4b': _0x4b7c40(0x33d),
            '\x79\x53\x69\x7a\x67': _0x4b7c40(0x2b5),
            '\x72\x50\x45\x73\x68': _0x4b7c40(0x440),
            '\x52\x4d\x57\x6c\x6a': '\x6c\x72\x74\x4e\x52',
            '\x50\x77\x59\x43\x43': _0x4b7c40(0x1ef),
            '\x49\x4c\x69\x4c\x4f': _0x4b7c40(0x438),
            '\x68\x45\x41\x7a\x51': _0x4b7c40(0x2fd),
            '\x47\x48\x47\x5a\x76': function (_0x395555, _0x56f2a8, _0x2972ab, _0x47cdf8, _0x5a7a5b, _0xd1968f) {
                return _0x395555(_0x56f2a8, _0x2972ab, _0x47cdf8, _0x5a7a5b, _0xd1968f);
            },
            '\x6a\x6a\x4c\x65\x68': function (_0x5da404, _0xff1a3b, _0x426e21) {
                return _0x5da404(_0xff1a3b, _0x426e21);
            },
            '\x5a\x54\x46\x4f\x56': _0x4b7c40(0x43c),
            '\x42\x50\x58\x53\x6f': _0x4b7c40(0x30d),
            '\x5a\x65\x77\x42\x69': _0x4b7c40(0x268),
            '\x77\x69\x49\x54\x78': _0x4b7c40(0x26f),
            '\x42\x73\x76\x65\x76': '\x59\x4f\x76\x4c\x45',
            '\x79\x42\x7a\x4e\x57': _0x4b7c40(0x2e6),
            '\x6b\x72\x71\x64\x6b': '\x6c\x7a\x4c\x69\x51',
            '\x66\x6f\x6d\x64\x4c': '\u683d\u8d43\x49\x44\x20\x28\u586b\x2d\x31\u9690\u85cf\x29',
            '\x4f\x45\x72\x59\x4d': _0x4b7c40(0x3f3),
            '\x45\x7a\x77\x67\x6b': _0x4b7c40(0x29c),
            '\x68\x65\x68\x50\x64': function (_0x39b13f, _0x30fe3a) {
                return _0x39b13f !== _0x30fe3a;
            },
            '\x72\x41\x73\x66\x4c': _0x4b7c40(0x1ea),
            '\x50\x68\x67\x6e\x66': function (_0x11ce3f, _0x5440fe) {
                return _0x11ce3f(_0x5440fe);
            },
            '\x6d\x4b\x55\x72\x7a': '\u5bc6\u7801\u8bfb\u53d6',
            '\x75\x53\x72\x4f\x62': function (_0xae1efc, _0x4f961c, _0x488b3c) {
                return _0xae1efc(_0x4f961c, _0x488b3c);
            },
            '\x51\x58\x75\x62\x6d': _0x4b7c40(0x39d),
            '\x49\x45\x4d\x61\x79': function (_0x4a81fe, _0x2d1fb2, _0x4b6935) {
                return _0x4a81fe(_0x2d1fb2, _0x4b6935);
            },
            '\x50\x6b\x44\x54\x51': _0x4b7c40(0x371),
            '\x43\x71\x44\x7a\x51': function (_0x13d1e2, _0x3600f6, _0xf34e1c) {
                return _0x13d1e2(_0x3600f6, _0xf34e1c);
            },
            '\x55\x53\x46\x52\x4f': _0x4b7c40(0x374),
            '\x63\x71\x73\x4e\x44': function (_0x37e12e, _0x351d89, _0x9fb922) {
                return _0x37e12e(_0x351d89, _0x9fb922);
            },
            '\x6b\x4a\x49\x4d\x52': function (_0x1689b5, _0x3954e0, _0x3c3fdb) {
                return _0x1689b5(_0x3954e0, _0x3c3fdb);
            },
            '\x78\x74\x4d\x4a\x69': function (_0x11a6f9, _0xb5801f, _0x4a7011) {
                return _0x11a6f9(_0xb5801f, _0x4a7011);
            },
            '\x65\x4e\x4f\x7a\x52': _0x4b7c40(0x267),
            '\x5a\x53\x4a\x74\x53': _0x4b7c40(0x1f9),
            '\x42\x75\x57\x78\x48': function (_0xb40757, _0x4bf799, _0x2e1ca1) {
                return _0xb40757(_0x4bf799, _0x2e1ca1);
            },
            '\x6e\x78\x66\x6f\x44': '\u83b7\u5f97\u96f6\u82b1\u94b1',
            '\x65\x41\x6e\x6a\x64': _0x4b7c40(0x300),
            '\x56\x6b\x6c\x5a\x42': function (_0x4c5779, _0x2e9e88, _0x287333) {
                return _0x4c5779(_0x2e9e88, _0x287333);
            },
            '\x43\x46\x64\x58\x62': _0x4b7c40(0x2a6),
            '\x6c\x62\x49\x61\x49': function (_0x501aaf, _0x11d0af, _0x191c4b) {
                return _0x501aaf(_0x11d0af, _0x191c4b);
            },
            '\x4f\x69\x7a\x55\x70': '\u63d0\u5347\u81ea\u7f1a\u7b49\u7ea7',
            '\x63\x4c\x65\x45\x59': '\u63d0\u5347\u64ac\u9501\u7b49\u7ea7',
            '\x57\x44\x56\x51\x70': _0x4b7c40(0x2de),
            '\x52\x51\x78\x6e\x4f': _0x4b7c40(0x1df),
            '\x4d\x45\x77\x53\x6d': function (_0xbd1a9a, _0x17af16, _0x22e93d) {
                return _0xbd1a9a(_0x17af16, _0x22e93d);
            },
            '\x72\x55\x6f\x5a\x4b': _0x4b7c40(0x407),
            '\x75\x6b\x4d\x45\x4c': _0x4b7c40(0x335),
            '\x4a\x61\x54\x63\x54': function (_0xc009f4, _0x59c707, _0x69314f) {
                return _0xc009f4(_0x59c707, _0x69314f);
            },
            '\x4a\x66\x56\x6d\x52': _0x4b7c40(0x1b3),
            '\x71\x49\x4a\x4c\x6b': _0x4b7c40(0x18b),
            '\x47\x62\x79\x6b\x79': function (_0x51c765, _0x2edc79, _0xa5c714) {
                return _0x51c765(_0x2edc79, _0xa5c714);
            },
            '\x54\x6e\x57\x74\x6d': function (_0x25a9f5, _0x2ecce0, _0x3da111) {
                return _0x25a9f5(_0x2ecce0, _0x3da111);
            },
            '\x55\x64\x6a\x70\x5a': _0x4b7c40(0x3a0),
            '\x6e\x76\x64\x77\x52': _0x4b7c40(0x455),
            '\x6a\x6e\x74\x50\x72': '\u4e0a\u9501\x28\u641e\u4e8b\u60c5\u4e13\u7528\x29',
            '\x73\x69\x4e\x47\x68': function (_0x324117, _0x50ae13, _0x2e08ca) {
                return _0x324117(_0x50ae13, _0x2e08ca);
            },
            '\x62\x6e\x67\x6c\x4d': '\u58f0\u540d\u8fdc\u626c\x28\u4fee\u6539\u5404\u7c7b\u58f0\u8a89\x29',
            '\x76\x78\x52\x56\x46': function (_0x57331e, _0x40f2d5, _0x122e78) {
                return _0x57331e(_0x40f2d5, _0x122e78);
            }
        }, _0x6a0f70 = (function () {
            let _0x21a979 = !![];
            return function (_0x53cf79, _0x1b29c3) {
                const _0x50b0f5 = _0x21a979 ? function () {
                    if (_0x1b29c3) {
                        const _0x4f96ab = _0x1b29c3['\x61\x70\x70\x6c\x79'](_0x53cf79, arguments);
                        return _0x1b29c3 = null, _0x4f96ab;
                    }
                } : function () {
                };
                return _0x21a979 = ![], _0x50b0f5;
            };
        }()), _0x105917 = _0x564dbb[_0x4b7c40(0x361)](_0x6a0f70, this, function () {
            const _0x52a342 = _0x4b7c40, _0x55c084 = {
                    '\x43\x74\x54\x53\x75': function (_0xcab2a9, _0x2c361d, _0x2785ef, _0x38b67e) {
                        const _0x141679 = _0x5822;
                        return _0x564dbb[_0x141679(0x187)](_0xcab2a9, _0x2c361d, _0x2785ef, _0x38b67e);
                    }
                };
            let _0x1e00db;
            try {
                if (_0x564dbb[_0x52a342(0x2e8)](_0x564dbb[_0x52a342(0x36a)], _0x564dbb[_0x52a342(0x34d)])) {
                    const _0x199cd3 = _0x564dbb['\x69\x61\x79\x53\x54'](Function, _0x564dbb[_0x52a342(0x206)](_0x564dbb[_0x52a342(0x206)](_0x564dbb[_0x52a342(0x159)], _0x52a342(0x251)), '\x29\x3b'));
                    _0x1e00db = _0x564dbb[_0x52a342(0x2b8)](_0x199cd3);
                } else
                    _0x55c084[_0x52a342(0x43b)](_0x4048fd, _0x234009, _0x21560c, -0x133 * 0xcf + 0x32ca6 + 0xaa5 * -0xb);
            } catch (_0x210676) {
                _0x1e00db = window;
            }
            const _0x11ea75 = _0x1e00db[_0x52a342(0x1b6)] = _0x1e00db[_0x52a342(0x1b6)] || {}, _0x5716fe = [
                    _0x564dbb[_0x52a342(0x344)],
                    _0x564dbb[_0x52a342(0x236)],
                    _0x564dbb[_0x52a342(0x2c6)],
                    _0x52a342(0x3e4),
                    _0x564dbb[_0x52a342(0x1c1)],
                    _0x564dbb[_0x52a342(0x384)],
                    _0x564dbb[_0x52a342(0x202)]
                ];
            for (let _0x57dba0 = -0x161b * 0x1 + -0x2439 + 0x3a54; _0x564dbb[_0x52a342(0x1e8)](_0x57dba0, _0x5716fe[_0x52a342(0x3a5)]); _0x57dba0++) {
                const _0x1bc558 = _0x6a0f70['\x63\x6f\x6e\x73\x74\x72\x75\x63\x74\x6f\x72']['\x70\x72\x6f\x74\x6f\x74\x79\x70\x65'][_0x52a342(0x239)](_0x6a0f70), _0x1dc1b0 = _0x5716fe[_0x57dba0], _0x1f87fb = _0x11ea75[_0x1dc1b0] || _0x1bc558;
                _0x1bc558[_0x52a342(0x3b2)] = _0x6a0f70[_0x52a342(0x239)](_0x6a0f70), _0x1bc558['\x74\x6f\x53\x74\x72\x69\x6e\x67'] = _0x1f87fb['\x74\x6f\x53\x74\x72\x69\x6e\x67']['\x62\x69\x6e\x64'](_0x1f87fb), _0x11ea75[_0x1dc1b0] = _0x1bc558;
            }
        });
    _0x105917(), AwInit = ![], _0x564dbb[_0x4b7c40(0x367)](GM_registerMenuCommand, _0x4b7c40(0x3a2), () => {
        const _0x4a0cf9 = _0x4b7c40, _0x52a584 = {
                '\x58\x66\x6f\x53\x46': _0x564dbb[_0x4a0cf9(0x46b)],
                '\x61\x61\x7a\x44\x47': function (_0x25ace2) {
                    return _0x25ace2();
                },
                '\x5a\x68\x76\x6f\x56': _0x564dbb[_0x4a0cf9(0x2c2)],
                '\x54\x68\x7a\x57\x44': function (_0x1f3a7b) {
                    const _0x4e851a = _0x4a0cf9;
                    return _0x564dbb[_0x4e851a(0x2b8)](_0x1f3a7b);
                },
                '\x41\x69\x53\x70\x7a': function (_0xf9914c) {
                    const _0x3fa43d = _0x4a0cf9;
                    return _0x564dbb[_0x3fa43d(0x2b8)](_0xf9914c);
                },
                '\x68\x75\x61\x67\x71': function (_0x52066f, _0x5c3a14, _0x4ad631) {
                    return _0x52066f(_0x5c3a14, _0x4ad631);
                },
                '\x46\x6b\x45\x4d\x57': _0x564dbb[_0x4a0cf9(0x2f2)],
                '\x59\x64\x75\x58\x73': _0x564dbb[_0x4a0cf9(0x3aa)],
                '\x4a\x65\x6d\x71\x55': function (_0x4d9ed3, _0x19905a) {
                    return _0x564dbb['\x73\x66\x79\x4d\x48'](_0x4d9ed3, _0x19905a);
                },
                '\x64\x76\x44\x77\x6c': _0x564dbb[_0x4a0cf9(0x45c)],
                '\x69\x48\x50\x58\x65': '\x49\x74\x65\x6d\x42\x72\x65\x61\x73\x74',
                '\x53\x66\x45\x48\x51': _0x564dbb[_0x4a0cf9(0x38b)],
                '\x68\x52\x70\x52\x77': _0x564dbb[_0x4a0cf9(0x3d3)],
                '\x7a\x75\x59\x43\x75': _0x4a0cf9(0x1fe),
                '\x42\x68\x6e\x62\x76': _0x564dbb[_0x4a0cf9(0x205)],
                '\x6c\x48\x4a\x49\x4b': _0x4a0cf9(0x3cf),
                '\x52\x4f\x57\x4e\x76': _0x564dbb['\x68\x67\x48\x74\x73'],
                '\x6d\x6d\x44\x46\x47': _0x4a0cf9(0x410),
                '\x65\x48\x73\x75\x42': _0x4a0cf9(0x2a0),
                '\x72\x56\x57\x4b\x59': _0x4a0cf9(0x248),
                '\x51\x64\x6c\x44\x49': _0x4a0cf9(0x1fb),
                '\x44\x48\x4a\x6f\x4d': _0x4a0cf9(0x157),
                '\x64\x75\x52\x71\x49': _0x564dbb[_0x4a0cf9(0x1f7)],
                '\x43\x49\x43\x41\x5a': function (_0x4f095d, _0x45b709, _0x53e45c, _0x1ca119) {
                    return _0x564dbb['\x4b\x78\x53\x65\x4e'](_0x4f095d, _0x45b709, _0x53e45c, _0x1ca119);
                },
                '\x74\x4e\x54\x49\x6d': function (_0x5c6751, _0x4561b0) {
                    return _0x5c6751 !== _0x4561b0;
                },
                '\x44\x46\x50\x4b\x66': _0x564dbb[_0x4a0cf9(0x479)],
                '\x46\x66\x44\x41\x6d': function (_0x1bb394, _0x5891ab) {
                    const _0x3b45a9 = _0x4a0cf9;
                    return _0x564dbb[_0x3b45a9(0x1d2)](_0x1bb394, _0x5891ab);
                },
                '\x6e\x4e\x58\x79\x4f': _0x564dbb[_0x4a0cf9(0x16c)],
                '\x58\x4a\x76\x64\x69': function (_0x40069a, _0x5111b5) {
                    const _0x128b2d = _0x4a0cf9;
                    return _0x564dbb[_0x128b2d(0x1e0)](_0x40069a, _0x5111b5);
                },
                '\x45\x6e\x71\x45\x64': _0x564dbb[_0x4a0cf9(0x3e3)],
                '\x43\x59\x7a\x64\x63': function (_0x48a163, _0x5eeb89) {
                    const _0x54968b = _0x4a0cf9;
                    return _0x564dbb[_0x54968b(0x206)](_0x48a163, _0x5eeb89);
                },
                '\x45\x6c\x46\x4a\x46': _0x564dbb[_0x4a0cf9(0x44d)],
                '\x64\x6b\x77\x76\x64': function (_0x4f5725, _0x340308) {
                    return _0x4f5725 !== _0x340308;
                },
                '\x6a\x6d\x76\x75\x44': _0x4a0cf9(0x332),
                '\x68\x57\x5a\x6b\x58': function (_0x48edac, _0x3cb0df, _0x3b9cac) {
                    const _0x42d841 = _0x4a0cf9;
                    return _0x564dbb[_0x42d841(0x221)](_0x48edac, _0x3cb0df, _0x3b9cac);
                },
                '\x73\x4c\x50\x67\x61': '\u8981\u8bfb\u53d6\u7684\u73a9\u5bb6\u540d\u79f0\x28\u5168\u5c0f\u5199\x29',
                '\x51\x41\x75\x57\x52': _0x564dbb[_0x4a0cf9(0x3c2)],
                '\x77\x75\x56\x58\x66': function (_0x3a1edf, _0x4be208) {
                    return _0x564dbb['\x69\x64\x78\x63\x62'](_0x3a1edf, _0x4be208);
                },
                '\x69\x64\x76\x6c\x7a': '\x61\x6b\x63\x70\x44',
                '\x48\x4c\x48\x57\x68': _0x564dbb[_0x4a0cf9(0x1f4)],
                '\x42\x48\x49\x58\x59': _0x564dbb[_0x4a0cf9(0x3a9)],
                '\x53\x4a\x68\x5a\x62': _0x564dbb['\x54\x6e\x41\x46\x69'],
                '\x64\x73\x6a\x72\x45': function (_0x20e149, _0x4e3509, _0x1fdc8d) {
                    return _0x564dbb['\x74\x52\x6e\x6f\x59'](_0x20e149, _0x4e3509, _0x1fdc8d);
                },
                '\x6d\x4c\x64\x6d\x52': _0x564dbb[_0x4a0cf9(0x25a)],
                '\x6c\x4c\x73\x56\x47': _0x564dbb[_0x4a0cf9(0x320)],
                '\x4d\x4d\x43\x71\x73': function (_0xf6fb81, _0x41111c) {
                    return _0x564dbb['\x45\x41\x7a\x68\x6f'](_0xf6fb81, _0x41111c);
                },
                '\x46\x43\x53\x69\x7a': _0x564dbb[_0x4a0cf9(0x211)],
                '\x6f\x41\x74\x4b\x4f': function (_0xb606fa, _0x567ae3) {
                    return _0x564dbb['\x64\x58\x6c\x4c\x4d'](_0xb606fa, _0x567ae3);
                },
                '\x44\x59\x72\x4b\x61': _0x564dbb[_0x4a0cf9(0x213)],
                '\x4d\x48\x64\x68\x66': function (_0x32de9b, _0x715df3) {
                    const _0xd92908 = _0x4a0cf9;
                    return _0x564dbb[_0xd92908(0x40f)](_0x32de9b, _0x715df3);
                },
                '\x7a\x65\x6f\x75\x46': _0x564dbb[_0x4a0cf9(0x3bd)],
                '\x66\x59\x50\x50\x55': function (_0x3f22d7, _0x74a633) {
                    const _0x5276c5 = _0x4a0cf9;
                    return _0x564dbb[_0x5276c5(0x289)](_0x3f22d7, _0x74a633);
                },
                '\x56\x77\x53\x6a\x4a': _0x564dbb[_0x4a0cf9(0x283)],
                '\x67\x66\x72\x58\x6a': function (_0x58933a, _0x2404d0) {
                    const _0x3a22fb = _0x4a0cf9;
                    return _0x564dbb[_0x3a22fb(0x25b)](_0x58933a, _0x2404d0);
                },
                '\x45\x6c\x78\x45\x45': function (_0x20d218) {
                    const _0x32ba1e = _0x4a0cf9;
                    return _0x564dbb[_0x32ba1e(0x2b8)](_0x20d218);
                },
                '\x76\x72\x69\x6c\x6b': _0x564dbb[_0x4a0cf9(0x344)],
                '\x62\x55\x4a\x4f\x4d': _0x564dbb['\x62\x53\x44\x59\x6c'],
                '\x55\x56\x46\x49\x67': _0x564dbb[_0x4a0cf9(0x1a1)],
                '\x42\x52\x70\x4e\x59': _0x564dbb[_0x4a0cf9(0x384)],
                '\x75\x6c\x63\x4e\x59': _0x564dbb[_0x4a0cf9(0x1ad)],
                '\x53\x4a\x6d\x71\x74': function (_0x589f4a, _0x1b0027) {
                    const _0x36a2cb = _0x4a0cf9;
                    return _0x564dbb[_0x36a2cb(0x186)](_0x589f4a, _0x1b0027);
                },
                '\x70\x7a\x4b\x67\x4d': function (_0x393852, _0xb964d2) {
                    return _0x393852 == _0xb964d2;
                },
                '\x50\x65\x48\x62\x78': function (_0x350e1e, _0x1ac93a) {
                    const _0x4e0f92 = _0x4a0cf9;
                    return _0x564dbb[_0x4e0f92(0x47e)](_0x350e1e, _0x1ac93a);
                },
                '\x66\x79\x42\x64\x69': _0x564dbb[_0x4a0cf9(0x20b)],
                '\x52\x44\x6b\x4b\x53': function (_0x260486, _0x5299d6) {
                    const _0x345cda = _0x4a0cf9;
                    return _0x564dbb[_0x345cda(0x381)](_0x260486, _0x5299d6);
                },
                '\x48\x54\x75\x50\x78': _0x564dbb[_0x4a0cf9(0x160)],
                '\x4f\x6b\x6d\x4e\x72': function (_0x58f98e, _0x33b11c) {
                    const _0x168462 = _0x4a0cf9;
                    return _0x564dbb[_0x168462(0x40a)](_0x58f98e, _0x33b11c);
                },
                '\x76\x74\x74\x43\x4f': function (_0x108edb, _0x82d801) {
                    const _0x40871f = _0x4a0cf9;
                    return _0x564dbb[_0x40871f(0x310)](_0x108edb, _0x82d801);
                },
                '\x43\x49\x78\x78\x50': function (_0x6c8a83, _0x3352fe) {
                    const _0x33ce80 = _0x4a0cf9;
                    return _0x564dbb[_0x33ce80(0x275)](_0x6c8a83, _0x3352fe);
                },
                '\x6e\x77\x48\x68\x46': _0x564dbb[_0x4a0cf9(0x261)],
                '\x4d\x41\x68\x79\x62': function (_0x5d9194, _0x5a5631) {
                    return _0x5d9194(_0x5a5631);
                },
                '\x55\x70\x52\x43\x50': function (_0x533647, _0x4b31e1) {
                    const _0x3cd684 = _0x4a0cf9;
                    return _0x564dbb[_0x3cd684(0x40f)](_0x533647, _0x4b31e1);
                },
                '\x65\x78\x62\x49\x50': _0x4a0cf9(0x448),
                '\x75\x4e\x6f\x68\x55': _0x564dbb[_0x4a0cf9(0x3bb)],
                '\x59\x59\x71\x6d\x6b': _0x564dbb[_0x4a0cf9(0x356)],
                '\x41\x6c\x52\x56\x5a': _0x564dbb[_0x4a0cf9(0x3dc)],
                '\x41\x55\x79\x68\x66': function (_0x58c771, _0x5d8e77, _0x57faec) {
                    return _0x58c771(_0x5d8e77, _0x57faec);
                },
                '\x79\x6e\x63\x53\x53': _0x564dbb['\x62\x43\x6c\x72\x77'],
                '\x68\x41\x53\x4b\x56': _0x564dbb[_0x4a0cf9(0x462)],
                '\x74\x67\x57\x69\x76': _0x4a0cf9(0x40b),
                '\x52\x53\x4b\x54\x61': function (_0x3d1b00, _0x398543, _0x183540) {
                    return _0x3d1b00(_0x398543, _0x183540);
                },
                '\x79\x6a\x4a\x4f\x58': _0x564dbb[_0x4a0cf9(0x29b)],
                '\x4b\x4e\x66\x68\x70': function (_0x17f235, _0x38c2af) {
                    return _0x564dbb['\x62\x77\x4b\x42\x56'](_0x17f235, _0x38c2af);
                },
                '\x54\x52\x70\x6b\x48': function (_0x27ad6a, _0x17cdb1) {
                    return _0x27ad6a !== _0x17cdb1;
                },
                '\x46\x56\x72\x54\x67': _0x564dbb[_0x4a0cf9(0x1f8)],
                '\x69\x6c\x6c\x73\x50': _0x564dbb[_0x4a0cf9(0x257)],
                '\x67\x4d\x7a\x4c\x4b': _0x564dbb['\x52\x6d\x50\x43\x73'],
                '\x54\x6f\x48\x44\x59': function (_0xaaa787, _0xbbda22) {
                    return _0xaaa787(_0xbbda22);
                },
                '\x53\x47\x53\x6a\x61': function (_0x4176d1, _0x5a69cc, _0x163433) {
                    return _0x564dbb['\x6f\x71\x54\x68\x6d'](_0x4176d1, _0x5a69cc, _0x163433);
                },
                '\x4d\x74\x75\x79\x55': function (_0x59ee5a, _0x4e2dfa, _0x126f59, _0x1b136e) {
                    return _0x59ee5a(_0x4e2dfa, _0x126f59, _0x1b136e);
                },
                '\x54\x7a\x6b\x77\x65': _0x564dbb[_0x4a0cf9(0x312)],
                '\x6b\x67\x55\x56\x59': _0x564dbb[_0x4a0cf9(0x464)],
                '\x73\x50\x57\x62\x43': function (_0x3e28d8, _0x5d8c6e, _0x457866) {
                    const _0x52e2c0 = _0x4a0cf9;
                    return _0x564dbb[_0x52e2c0(0x328)](_0x3e28d8, _0x5d8c6e, _0x457866);
                },
                '\x45\x43\x5a\x73\x61': _0x564dbb['\x51\x74\x52\x48\x57'],
                '\x76\x61\x65\x6f\x71': function (_0x209ec2, _0x5b3e75) {
                    const _0x2575d8 = _0x4a0cf9;
                    return _0x564dbb[_0x2575d8(0x1d6)](_0x209ec2, _0x5b3e75);
                },
                '\x51\x6e\x74\x4c\x79': _0x564dbb[_0x4a0cf9(0x273)],
                '\x67\x50\x4c\x64\x72': _0x564dbb['\x50\x72\x4b\x6f\x44'],
                '\x66\x72\x65\x4e\x51': _0x564dbb[_0x4a0cf9(0x396)],
                '\x71\x71\x73\x65\x65': function (_0x345ed6, _0x42682f, _0x1a95cd) {
                    const _0x2c0d98 = _0x4a0cf9;
                    return _0x564dbb[_0x2c0d98(0x221)](_0x345ed6, _0x42682f, _0x1a95cd);
                },
                '\x72\x61\x44\x6d\x46': function (_0x3a4776, _0x5ba956) {
                    return _0x3a4776 !== _0x5ba956;
                },
                '\x51\x52\x49\x48\x64': _0x564dbb[_0x4a0cf9(0x19d)],
                '\x70\x77\x62\x67\x65': _0x4a0cf9(0x2fb),
                '\x43\x55\x62\x61\x78': function (_0x914627, _0x127057, _0x395207) {
                    return _0x914627(_0x127057, _0x395207);
                },
                '\x62\x69\x54\x70\x4f': _0x564dbb[_0x4a0cf9(0x470)],
                '\x73\x69\x72\x52\x49': _0x564dbb[_0x4a0cf9(0x446)],
                '\x57\x52\x4d\x76\x6a': _0x564dbb[_0x4a0cf9(0x480)],
                '\x71\x6b\x55\x52\x6d': function (_0x526d3c, _0x39bd12) {
                    return _0x564dbb['\x4f\x76\x6c\x5a\x58'](_0x526d3c, _0x39bd12);
                },
                '\x61\x63\x78\x78\x70': _0x564dbb[_0x4a0cf9(0x41a)],
                '\x43\x57\x49\x6e\x53': function (_0x469bb4, _0x3e3f92) {
                    const _0x1acd88 = _0x4a0cf9;
                    return _0x564dbb[_0x1acd88(0x1e6)](_0x469bb4, _0x3e3f92);
                },
                '\x49\x5a\x67\x70\x53': _0x564dbb[_0x4a0cf9(0x360)],
                '\x57\x6c\x77\x74\x5a': function (_0x354227, _0x290641, _0x585e46, _0x55773a, _0x337fdd, _0x574440) {
                    return _0x564dbb['\x47\x48\x47\x5a\x76'](_0x354227, _0x290641, _0x585e46, _0x55773a, _0x337fdd, _0x574440);
                },
                '\x6f\x4c\x54\x58\x54': _0x564dbb[_0x4a0cf9(0x1fa)],
                '\x56\x78\x70\x4c\x6e': function (_0x1dc64a, _0xdf23ec, _0x3d295d) {
                    return _0x564dbb['\x6a\x6a\x4c\x65\x68'](_0x1dc64a, _0xdf23ec, _0x3d295d);
                },
                '\x4e\x43\x65\x52\x75': _0x564dbb[_0x4a0cf9(0x253)],
                '\x4f\x78\x54\x4c\x46': _0x564dbb['\x56\x4a\x62\x59\x4c'],
                '\x69\x69\x66\x6c\x68': function (_0x54b2c8, _0x33672d) {
                    const _0x558807 = _0x4a0cf9;
                    return _0x564dbb[_0x558807(0x2bc)](_0x54b2c8, _0x33672d);
                },
                '\x47\x71\x6f\x48\x6f': _0x564dbb['\x5a\x54\x46\x4f\x56'],
                '\x67\x49\x7a\x54\x45': _0x564dbb[_0x4a0cf9(0x241)],
                '\x75\x61\x4b\x43\x73': _0x564dbb[_0x4a0cf9(0x1f3)],
                '\x4e\x70\x56\x74\x6c': _0x564dbb['\x77\x69\x49\x54\x78'],
                '\x44\x44\x6d\x59\x74': function (_0x37c6ed, _0xeb1e80) {
                    const _0x4cc7fa = _0x4a0cf9;
                    return _0x564dbb[_0x4cc7fa(0x3b3)](_0x37c6ed, _0xeb1e80);
                },
                '\x70\x67\x4f\x69\x51': _0x4a0cf9(0x216),
                '\x51\x50\x7a\x65\x62': function (_0x8db8be, _0xea0df4) {
                    return _0x8db8be == _0xea0df4;
                },
                '\x59\x52\x73\x46\x65': _0x564dbb[_0x4a0cf9(0x19b)],
                '\x43\x57\x54\x5a\x47': _0x4a0cf9(0x391),
                '\x6f\x6f\x53\x41\x6d': function (_0x1ddd99, _0x3d61ab) {
                    return _0x1ddd99 < _0x3d61ab;
                },
                '\x43\x67\x48\x4d\x61': _0x564dbb[_0x4a0cf9(0x392)],
                '\x6d\x66\x49\x54\x79': _0x564dbb[_0x4a0cf9(0x26b)],
                '\x44\x52\x51\x6f\x75': function (_0xa3ca17, _0x23716d) {
                    const _0x16bc15 = _0x4a0cf9;
                    return _0x564dbb[_0x16bc15(0x2bc)](_0xa3ca17, _0x23716d);
                },
                '\x69\x44\x76\x68\x51': _0x564dbb[_0x4a0cf9(0x379)],
                '\x49\x50\x6e\x61\x6b': '\x31\x31\x34\x35\x31\x34',
                '\x65\x50\x41\x6f\x4d': function (_0x151a83, _0x5ba531) {
                    const _0x5a80a1 = _0x4a0cf9;
                    return _0x564dbb[_0x5a80a1(0x3af)](_0x151a83, _0x5ba531);
                }
            };
        if (!(Player[_0x4a0cf9(0x339)] && Player[_0x4a0cf9(0x339)][_0x4a0cf9(0x1e3)] == _0x4a0cf9(0x3b0))) {
            if (_0x564dbb[_0x4a0cf9(0x436)] !== _0x564dbb[_0x4a0cf9(0x436)])
                _0xafa439[_0x4a0cf9(0x2ca)][_0x4a0cf9(0x23d)] = _0x52a584[_0x4a0cf9(0x266)];
            else {
                if (Player['\x4e\x61\x6d\x65'] != _0x564dbb['\x53\x66\x75\x4d\x58'] && _0x564dbb[_0x4a0cf9(0x186)](Player['\x4e\x61\x6d\x65'], '\x51\x69\x6e\x43\x61\x69')) {
                    _0x564dbb['\x4b\x4d\x6e\x61\x46'](alert, _0x564dbb[_0x4a0cf9(0x32c)]);
                    return;
                }
            }
        }
        if (AwInit) {
            if (_0x564dbb[_0x4a0cf9(0x1aa)](_0x564dbb[_0x4a0cf9(0x235)], _0x4a0cf9(0x1ea))) {
                _0x564dbb['\x73\x66\x79\x4d\x48'](_0x349156, _0x564dbb[_0x4a0cf9(0x451)]);
                return;
            } else {
                _0x564dbb['\x50\x68\x67\x6e\x66'](alert, _0x564dbb[_0x4a0cf9(0x451)]);
                return;
            }
        }
        AwInit = !![], _0x564dbb['\x4d\x44\x47\x42\x63'](GM_registerMenuCommand, _0x564dbb[_0x4a0cf9(0x37d)], () => {
            const _0x3b5c5a = _0x4a0cf9, _0x4ead1e = {
                    '\x6d\x54\x43\x4a\x73': _0x52a584[_0x3b5c5a(0x256)],
                    '\x6b\x58\x4c\x6d\x6d': _0x52a584[_0x3b5c5a(0x376)],
                    '\x50\x47\x6b\x44\x62': _0x3b5c5a(0x189),
                    '\x62\x51\x41\x78\x67': _0x3b5c5a(0x46a),
                    '\x52\x53\x5a\x67\x48': _0x3b5c5a(0x207),
                    '\x6c\x53\x46\x69\x74': _0x52a584[_0x3b5c5a(0x329)],
                    '\x4c\x42\x51\x68\x57': _0x52a584[_0x3b5c5a(0x445)],
                    '\x49\x4d\x46\x6d\x63': '\x49\x74\x65\x6d\x4d\x69\x73\x63',
                    '\x6f\x79\x76\x6f\x6d': _0x52a584[_0x3b5c5a(0x486)],
                    '\x4d\x4b\x42\x70\x52': _0x52a584[_0x3b5c5a(0x1cf)],
                    '\x4c\x59\x64\x50\x72': _0x3b5c5a(0x223),
                    '\x53\x4a\x59\x68\x4d': _0x52a584[_0x3b5c5a(0x313)],
                    '\x4d\x59\x44\x4a\x54': _0x3b5c5a(0x3b6),
                    '\x49\x4e\x51\x64\x56': _0x52a584['\x52\x4f\x57\x4e\x76'],
                    '\x71\x79\x59\x6a\x6f': _0x52a584[_0x3b5c5a(0x424)],
                    '\x55\x76\x6a\x74\x78': _0x52a584['\x65\x48\x73\x75\x42'],
                    '\x45\x4d\x64\x44\x53': _0x52a584[_0x3b5c5a(0x1cc)],
                    '\x69\x53\x53\x72\x61': _0x52a584[_0x3b5c5a(0x355)],
                    '\x70\x77\x4f\x65\x78': '\x49\x74\x65\x6d\x56\x75\x6c\x76\x61\x50\x69\x65\x72\x63\x69\x6e\x67\x73',
                    '\x67\x78\x5a\x42\x79': function (_0x228e87, _0x3a8c81) {
                        return _0x228e87(_0x3a8c81);
                    },
                    '\x7a\x71\x6c\x43\x6b': _0x52a584['\x44\x48\x4a\x6f\x4d'],
                    '\x47\x69\x43\x69\x65': _0x52a584[_0x3b5c5a(0x266)],
                    '\x54\x55\x54\x63\x77': _0x52a584[_0x3b5c5a(0x2f7)],
                    '\x44\x45\x6b\x49\x68': function (_0x21daf5, _0x503db9, _0x37276f, _0x1c5f3b) {
                        return _0x52a584['\x43\x49\x43\x41\x5a'](_0x21daf5, _0x503db9, _0x37276f, _0x1c5f3b);
                    },
                    '\x7a\x65\x4c\x4d\x4f': function (_0x582a0c, _0x1e27d4) {
                        const _0x4884ad = _0x3b5c5a;
                        return _0x52a584[_0x4884ad(0x2d1)](_0x582a0c, _0x1e27d4);
                    },
                    '\x61\x67\x4d\x4a\x77': _0x52a584['\x44\x46\x50\x4b\x66'],
                    '\x74\x4b\x44\x76\x64': function (_0x3bac74, _0x4a4831) {
                        const _0x471018 = _0x3b5c5a;
                        return _0x52a584[_0x471018(0x190)](_0x3bac74, _0x4a4831);
                    },
                    '\x55\x74\x77\x65\x43': _0x52a584[_0x3b5c5a(0x260)],
                    '\x6f\x50\x65\x51\x49': '\x64\x63\x70\x71\x7a',
                    '\x79\x47\x42\x54\x77': function (_0x58b1a9, _0x2b0c13) {
                        const _0x2716fd = _0x3b5c5a;
                        return _0x52a584[_0x2716fd(0x408)](_0x58b1a9, _0x2b0c13);
                    },
                    '\x5a\x56\x6e\x6c\x58': _0x52a584[_0x3b5c5a(0x22b)],
                    '\x47\x62\x68\x68\x6b': function (_0x147a5f, _0x56ad39) {
                        return _0x147a5f != _0x56ad39;
                    },
                    '\x52\x75\x73\x6f\x4a': function (_0x56fc6d, _0x50ea5b) {
                        return _0x52a584['\x43\x59\x7a\x64\x63'](_0x56fc6d, _0x50ea5b);
                    },
                    '\x53\x57\x49\x52\x45': _0x52a584[_0x3b5c5a(0x1a8)]
                };
            if (_0x52a584[_0x3b5c5a(0x378)](_0x52a584[_0x3b5c5a(0x375)], _0x52a584[_0x3b5c5a(0x375)]))
                _0x36f514 = _0x33fe89[_0x3b5c5a(0x413)];
            else {
                targetName = _0x52a584['\x68\x57\x5a\x6b\x58'](prompt, _0x52a584[_0x3b5c5a(0x3f5)], _0x52a584[_0x3b5c5a(0x2c7)]), targetMember = Character[_0x3b5c5a(0x15f)](_0x4b543c => _0x4b543c[_0x3b5c5a(0x1e3)][_0x3b5c5a(0x164)]() == targetName);
                if (_0x52a584[_0x3b5c5a(0x177)](targetMember, null)) {
                    if (_0x52a584[_0x3b5c5a(0x408)](_0x52a584[_0x3b5c5a(0x315)], _0x52a584[_0x3b5c5a(0x337)])) {
                        const _0x59d98f = '\x35\x7c\x32\x7c\x31\x7c\x37\x7c\x36\x7c\x34\x7c\x33\x7c\x30'[_0x3b5c5a(0x309)]('\x7c');
                        let _0x28c251 = -0x93a * -0x4 + 0x1f65 + -0x5 * 0xda9;
                        while (!![]) {
                            switch (_0x59d98f[_0x28c251++]) {
                            case '\x30':
                                _0x52a584['\x61\x61\x7a\x44\x47'](_0x5ca1c6);
                                continue;
                            case '\x31':
                                _0xc9ca2f(_0x52a584[_0x3b5c5a(0x295)], '');
                                continue;
                            case '\x32':
                                _0x52a584[_0x3b5c5a(0x32e)](_0x42b35c);
                                continue;
                            case '\x33':
                                _0x52a584[_0x3b5c5a(0x15c)](_0x40983b);
                                continue;
                            case '\x34':
                                _0x52a584['\x68\x75\x61\x67\x71'](_0x28097c, _0x52a584[_0x3b5c5a(0x443)], _0x52a584[_0x3b5c5a(0x233)]);
                                continue;
                            case '\x35':
                                _0x4a54ee = ![];
                                continue;
                            case '\x36':
                                _0x3664f0 = null;
                                continue;
                            case '\x37':
                                _0x52a584[_0x3b5c5a(0x370)](_0x46d38a, '');
                                continue;
                            }
                            break;
                        }
                    } else
                        return;
                }
                targetMember[_0x3b5c5a(0x413)][_0x3b5c5a(0x38f)](_0x5032ee => {
                    const _0x408b51 = _0x3b5c5a, _0x9e5ce4 = {
                            '\x47\x74\x6d\x41\x6d': _0x4ead1e[_0x408b51(0x3c5)],
                            '\x68\x43\x69\x41\x67': _0x4ead1e[_0x408b51(0x22e)],
                            '\x72\x6f\x51\x75\x73': function (_0xdbfae6, _0x24dd32, _0x2f69c2, _0x55c3ff) {
                                const _0x555a9a = _0x408b51;
                                return _0x4ead1e[_0x555a9a(0x35d)](_0xdbfae6, _0x24dd32, _0x2f69c2, _0x55c3ff);
                            }
                        };
                    if (_0x4ead1e[_0x408b51(0x366)]('\x71\x75\x49\x6e\x63', _0x4ead1e['\x61\x67\x4d\x4a\x77'])) {
                        if (_0x4ead1e[_0x408b51(0x32f)](_0x5032ee[_0x408b51(0x3e0)], 0x1 * -0xbe7 + 0x182e + -0xc47) && _0x5032ee[_0x408b51(0x2ca)]) {
                            let _0x73b493 = '\x75\x6e\x6b\x6e\x6f\x77\x6e', _0x54e9af = _0x4ead1e[_0x408b51(0x1b8)];
                            _0x5032ee[_0x408b51(0x2ca)][_0x408b51(0x2ce)] && (_0x4ead1e[_0x408b51(0x3d7)] === _0x408b51(0x393) ? _0x36e645(_0x354c0c, _0x9e5ce4['\x47\x74\x6d\x41\x6d'], _0x9e5ce4[_0x408b51(0x35b)]) : _0x54e9af = _0x5032ee['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x408b51(0x2ce)]);
                            _0x5032ee[_0x408b51(0x2ca)][_0x408b51(0x212)] && (_0x54e9af = _0x5032ee['\x50\x72\x6f\x70\x65\x72\x74\x79']['\x43\x6f\x6d\x62\x69\x6e\x61\x74\x69\x6f\x6e\x4e\x75\x6d\x62\x65\x72']);
                            if (_0x5032ee[_0x408b51(0x417)]['\x4e\x61\x6d\x65']) {
                                if (_0x4ead1e['\x79\x47\x42\x54\x77'](_0x408b51(0x3b1), _0x4ead1e[_0x408b51(0x301)])) {
                                    let _0x5bcae7 = [
                                        _0x4ead1e[_0x408b51(0x254)],
                                        _0x408b51(0x1b1),
                                        _0x4ead1e[_0x408b51(0x1c8)],
                                        _0x4ead1e[_0x408b51(0x390)],
                                        _0x408b51(0x474),
                                        _0x4ead1e[_0x408b51(0x3c6)],
                                        _0x4ead1e['\x52\x53\x5a\x67\x48'],
                                        _0x408b51(0x30c),
                                        _0x408b51(0x3ae),
                                        _0x4ead1e[_0x408b51(0x35f)],
                                        _0x4ead1e[_0x408b51(0x469)],
                                        _0x4ead1e[_0x408b51(0x22e)],
                                        '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68',
                                        _0x4ead1e[_0x408b51(0x1ed)],
                                        _0x4ead1e[_0x408b51(0x191)],
                                        _0x4ead1e[_0x408b51(0x324)],
                                        _0x4ead1e[_0x408b51(0x165)],
                                        _0x4ead1e[_0x408b51(0x44f)],
                                        _0x4ead1e[_0x408b51(0x218)],
                                        _0x408b51(0x31b),
                                        _0x4ead1e[_0x408b51(0x389)],
                                        _0x4ead1e[_0x408b51(0x246)],
                                        _0x4ead1e[_0x408b51(0x27b)],
                                        _0x4ead1e['\x69\x53\x53\x72\x61'],
                                        _0x4ead1e[_0x408b51(0x306)]
                                    ];
                                    _0x5bcae7[_0x408b51(0x38f)](_0x4932f8 => {
                                        const _0x5dc97b = _0x408b51;
                                        _0x9e5ce4[_0x5dc97b(0x35c)](_0x34b3a2, _0x3cf8b2, _0x4932f8, -0x8 * -0x465e + -0x60e9 * -0x2 + -0x13570);
                                    }), _0x2fc72c[_0x408b51(0x481)]['\x50\x72\x6f\x67\x72\x65\x73\x73'] = -0x7 * 0x544 + 0x9f4 + 0x2 * 0xd74, _0x4ead1e['\x67\x78\x5a\x42\x79'](_0x262d76, _0x5d55cd), _0x22a45e = _0x4ead1e[_0x408b51(0x27d)];
                                } else
                                    _0x73b493 = _0x5032ee['\x41\x73\x73\x65\x74'][_0x408b51(0x1e3)];
                            }
                            _0x4ead1e[_0x408b51(0x412)](_0x54e9af, _0x4ead1e['\x55\x74\x77\x65\x43']) && ChatRoomSendLocal(_0x4ead1e['\x52\x75\x73\x6f\x4a'](_0x73b493 + _0x4ead1e[_0x408b51(0x1cd)], _0x54e9af));
                        }
                    } else
                        _0x2051b1[_0x408b51(0x2ca)][_0x408b51(0x23d)] = _0x4ead1e[_0x408b51(0x468)];
                });
            }
        }), _0x564dbb['\x4d\x44\x47\x42\x63'](GM_registerMenuCommand, '\u901f\u901a', () => {
            const _0x74428f = _0x4a0cf9;
            AssetFemale3DCG[_0x74428f(0x38f)](_0x2ffc89 => _0x2ffc89[_0x74428f(0x417)][_0x74428f(0x38f)](_0x1c1691 => InventoryAdd(Player, _0x1c1691[_0x74428f(0x1e3)], _0x2ffc89[_0x74428f(0x1f2)]))), _0x52a584[_0x74428f(0x32e)](ServerPlayerInventorySync);
        }), _0x564dbb[_0x4a0cf9(0x3ac)](GM_registerMenuCommand, _0x564dbb['\x51\x58\x75\x62\x6d'], () => {
            const _0x152221 = _0x4a0cf9;
            _0x564dbb[_0x152221(0x47e)](_0x564dbb[_0x152221(0x219)], _0x564dbb[_0x152221(0x219)]) ? (Player[_0x152221(0x31f)] = [], ServerPlayerInventorySync()) : (_0x244e86 = _0x52a584[_0x152221(0x26a)](_0x4fcde0, _0x52a584[_0x152221(0x31d)], _0x52a584['\x53\x4a\x68\x5a\x62']), _0x21aee7 = _0x52a584[_0x152221(0x419)](_0x30adf7, _0x52a584[_0x152221(0x271)], _0x52a584[_0x152221(0x1b9)]));
        }), _0x564dbb[_0x4a0cf9(0x1a9)](GM_registerMenuCommand, _0x564dbb[_0x4a0cf9(0x320)], () => {
            const _0x456736 = _0x4a0cf9, _0x341a52 = {
                    '\x46\x49\x51\x6b\x63': function (_0x4d0d8b, _0x2ddf3f) {
                        const _0x16558a = _0x5822;
                        return _0x564dbb[_0x16558a(0x206)](_0x4d0d8b, _0x2ddf3f);
                    },
                    '\x67\x71\x63\x63\x64': _0x564dbb['\x77\x58\x4b\x6f\x59'],
                    '\x74\x54\x49\x51\x71': function (_0x25eff0, _0x1b400d) {
                        const _0x485407 = _0x5822;
                        return _0x564dbb[_0x485407(0x3af)](_0x25eff0, _0x1b400d);
                    },
                    '\x69\x6e\x48\x41\x70': _0x564dbb['\x5a\x67\x53\x71\x67'],
                    '\x49\x4d\x48\x4a\x4e': _0x564dbb[_0x456736(0x1e1)],
                    '\x6f\x55\x42\x6d\x6a': _0x564dbb[_0x456736(0x3b4)],
                    '\x53\x44\x77\x72\x6c': function (_0x388e52, _0x20d952, _0x2a10d8) {
                        const _0x4264b7 = _0x456736;
                        return _0x564dbb[_0x4264b7(0x28e)](_0x388e52, _0x20d952, _0x2a10d8);
                    },
                    '\x4d\x4b\x6f\x61\x75': _0x456736(0x3ba),
                    '\x47\x61\x72\x55\x51': _0x564dbb['\x64\x67\x4c\x48\x43'],
                    '\x48\x78\x67\x46\x66': function (_0x1e5eb0, _0x353503, _0x5d0100) {
                        const _0x4f0eb7 = _0x456736;
                        return _0x564dbb[_0x4f0eb7(0x173)](_0x1e5eb0, _0x353503, _0x5d0100);
                    },
                    '\x6d\x41\x67\x47\x51': _0x564dbb['\x62\x43\x6c\x72\x77'],
                    '\x63\x68\x61\x6f\x73': _0x564dbb[_0x456736(0x31c)],
                    '\x54\x69\x48\x6f\x72': _0x564dbb[_0x456736(0x327)],
                    '\x45\x74\x74\x47\x48': function (_0x3170fb, _0xc5ae75) {
                        return _0x3170fb === _0xc5ae75;
                    },
                    '\x57\x77\x77\x45\x4c': _0x564dbb['\x4d\x43\x6b\x55\x75'],
                    '\x74\x43\x6a\x45\x61': function (_0x3e620a, _0x13dcf7) {
                        const _0x226eb9 = _0x456736;
                        return _0x564dbb[_0x226eb9(0x381)](_0x3e620a, _0x13dcf7);
                    },
                    '\x42\x7a\x58\x55\x4c': function (_0x3a34f5, _0x307587) {
                        const _0x97aea6 = _0x456736;
                        return _0x564dbb[_0x97aea6(0x288)](_0x3a34f5, _0x307587);
                    },
                    '\x57\x77\x46\x4c\x43': _0x456736(0x425),
                    '\x6f\x42\x6b\x6b\x78': _0x564dbb['\x6b\x6a\x76\x6d\x48'],
                    '\x45\x41\x4c\x68\x58': '\x50\x61\x6e\x64\x6f\x72\x61\x50\x61\x64\x6c\x6f\x63\x6b',
                    '\x4e\x4a\x65\x50\x44': function (_0x344f49, _0x692028, _0x27538a, _0x535fbd) {
                        return _0x344f49(_0x692028, _0x27538a, _0x535fbd);
                    },
                    '\x4f\x6d\x7a\x69\x70': function (_0x1e2efe, _0x59c705, _0xa7d479) {
                        const _0x557de3 = _0x456736;
                        return _0x564dbb[_0x557de3(0x287)](_0x1e2efe, _0x59c705, _0xa7d479);
                    },
                    '\x71\x73\x49\x62\x4d': _0x564dbb['\x6b\x43\x46\x76\x41'],
                    '\x42\x4f\x4f\x4c\x75': function (_0x3c3b6e, _0x2d1ee6) {
                        return _0x3c3b6e < _0x2d1ee6;
                    },
                    '\x53\x45\x73\x77\x59': function (_0x3b5323, _0x3b27e9) {
                        return _0x564dbb['\x6a\x73\x6a\x6a\x64'](_0x3b5323, _0x3b27e9);
                    },
                    '\x53\x75\x78\x66\x50': function (_0x1da1d7, _0x53f420) {
                        const _0x56dbec = _0x456736;
                        return _0x564dbb[_0x56dbec(0x36f)](_0x1da1d7, _0x53f420);
                    },
                    '\x61\x78\x4c\x52\x42': _0x564dbb[_0x456736(0x380)],
                    '\x69\x4f\x4d\x45\x69': function (_0x3da9d7, _0x28abf8, _0x2d86d0) {
                        const _0xbf765 = _0x456736;
                        return _0x564dbb[_0xbf765(0x287)](_0x3da9d7, _0x28abf8, _0x2d86d0);
                    },
                    '\x6a\x63\x41\x5a\x6a': _0x564dbb[_0x456736(0x253)],
                    '\x6c\x49\x5a\x6f\x4b': _0x564dbb[_0x456736(0x3c2)],
                    '\x57\x73\x6c\x56\x51': function (_0x307cb8, _0x4c4a1f, _0x1e76ba, _0x35d94b, _0xcb42f1, _0x361665) {
                        const _0x153993 = _0x456736;
                        return _0x564dbb[_0x153993(0x2d0)](_0x307cb8, _0x4c4a1f, _0x1e76ba, _0x35d94b, _0xcb42f1, _0x361665);
                    },
                    '\x4b\x74\x58\x66\x67': _0x564dbb[_0x456736(0x1fa)],
                    '\x6e\x48\x51\x55\x41': _0x564dbb[_0x456736(0x45c)],
                    '\x76\x64\x59\x47\x64': function (_0xaf3d34, _0x23e8a2) {
                        return _0xaf3d34 !== _0x23e8a2;
                    },
                    '\x76\x51\x52\x55\x4a': _0x564dbb['\x75\x59\x79\x6e\x43'],
                    '\x75\x6a\x77\x50\x56': function (_0x1cbc21, _0x257351) {
                        return _0x564dbb['\x6e\x54\x64\x4e\x74'](_0x1cbc21, _0x257351);
                    },
                    '\x63\x6c\x6b\x6a\x67': function (_0x436f0d, _0x484cc1) {
                        return _0x436f0d != _0x484cc1;
                    },
                    '\x66\x64\x51\x62\x78': function (_0x1f0243, _0x1aa5c9) {
                        const _0x1d0279 = _0x456736;
                        return _0x564dbb[_0x1d0279(0x47e)](_0x1f0243, _0x1aa5c9);
                    },
                    '\x72\x6c\x42\x49\x52': '\x6d\x6e\x67\x43\x54',
                    '\x51\x62\x4e\x72\x66': _0x564dbb[_0x456736(0x401)],
                    '\x52\x4d\x59\x51\x66': _0x564dbb['\x47\x78\x73\x48\x7a'],
                    '\x76\x57\x74\x47\x47': _0x564dbb[_0x456736(0x242)],
                    '\x78\x46\x47\x67\x53': function (_0x55e1f9, _0x2cc424) {
                        return _0x55e1f9(_0x2cc424);
                    },
                    '\x6b\x5a\x68\x75\x79': function (_0x2b63fe, _0x5a1916) {
                        const _0x424f1f = _0x456736;
                        return _0x564dbb[_0x424f1f(0x3fe)](_0x2b63fe, _0x5a1916);
                    },
                    '\x6a\x77\x65\x55\x6f': _0x564dbb['\x69\x76\x6e\x43\x44'],
                    '\x4b\x62\x46\x76\x4c': _0x456736(0x28f),
                    '\x64\x58\x48\x62\x6c': function (_0xb4c19c, _0x195464, _0x2d54b9, _0x26d5ca, _0x29233a, _0x387c2d) {
                        const _0x57ff32 = _0x456736;
                        return _0x564dbb[_0x57ff32(0x2d0)](_0xb4c19c, _0x195464, _0x2d54b9, _0x26d5ca, _0x29233a, _0x387c2d);
                    },
                    '\x6d\x6c\x68\x6b\x52': _0x564dbb[_0x456736(0x1e7)],
                    '\x49\x65\x48\x51\x4a': _0x456736(0x207),
                    '\x61\x4b\x75\x45\x65': function (_0x32acfa, _0x1a3baa) {
                        const _0x4d27f2 = _0x456736;
                        return _0x564dbb[_0x4d27f2(0x2b3)](_0x32acfa, _0x1a3baa);
                    },
                    '\x6a\x6e\x65\x44\x64': '\x76\x31\x2e\x30\x37\x20\x62\x79\x20\x41\x77\u9171\x20\u5728\x61\x77\x61\x71\x77\x71\u7684\u4e2a\u4eba\u7b80\u4ecb\u91cc\u9762\u6709\u4e0b\u8f7d\u94fe\u63a5\u7684\u8bf4\x7e',
                    '\x70\x43\x44\x57\x6b': function (_0x6ec85d, _0x2df90f) {
                        return _0x564dbb['\x4a\x69\x55\x46\x43'](_0x6ec85d, _0x2df90f);
                    },
                    '\x4d\x4f\x48\x45\x4e': _0x564dbb[_0x456736(0x1a0)],
                    '\x51\x4c\x69\x6d\x74': _0x564dbb[_0x456736(0x1ee)],
                    '\x76\x41\x58\x66\x47': function (_0x1952ee, _0x3ec195, _0xcb72bb, _0x182cf3, _0x4fb524, _0x5cf345) {
                        const _0x21f598 = _0x456736;
                        return _0x564dbb[_0x21f598(0x2d0)](_0x1952ee, _0x3ec195, _0xcb72bb, _0x182cf3, _0x4fb524, _0x5cf345);
                    },
                    '\x52\x57\x6c\x75\x71': _0x564dbb['\x76\x50\x4c\x69\x6f'],
                    '\x74\x49\x54\x4e\x4b': function (_0x441972, _0x3fa92a) {
                        const _0x2f1846 = _0x456736;
                        return _0x564dbb[_0x2f1846(0x3af)](_0x441972, _0x3fa92a);
                    },
                    '\x77\x44\x64\x79\x75': _0x564dbb['\x63\x63\x78\x68\x4b'],
                    '\x41\x4d\x68\x65\x77': function (_0x17d15b, _0x2bef12) {
                        const _0x1b12bc = _0x456736;
                        return _0x564dbb[_0x1b12bc(0x30b)](_0x17d15b, _0x2bef12);
                    },
                    '\x59\x4e\x63\x45\x4a': _0x564dbb[_0x456736(0x3e6)],
                    '\x4d\x49\x4a\x6e\x6b': _0x564dbb['\x72\x74\x50\x42\x6f'],
                    '\x48\x67\x74\x42\x5a': _0x564dbb[_0x456736(0x433)],
                    '\x42\x67\x53\x51\x4f': _0x564dbb[_0x456736(0x249)],
                    '\x54\x6b\x46\x42\x4a': _0x564dbb[_0x456736(0x185)],
                    '\x53\x51\x78\x44\x69': _0x564dbb[_0x456736(0x38b)],
                    '\x70\x49\x52\x70\x42': _0x564dbb['\x74\x4c\x74\x5a\x4e'],
                    '\x4c\x57\x4d\x56\x6b': _0x564dbb['\x62\x58\x59\x61\x47'],
                    '\x4d\x70\x53\x53\x46': _0x564dbb['\x76\x5a\x6f\x70\x6e'],
                    '\x47\x75\x6d\x57\x4e': _0x564dbb[_0x456736(0x205)],
                    '\x4e\x66\x5a\x64\x55': _0x564dbb[_0x456736(0x43d)],
                    '\x4d\x6d\x63\x72\x64': _0x564dbb[_0x456736(0x372)],
                    '\x6a\x78\x41\x71\x79': _0x564dbb[_0x456736(0x2ec)],
                    '\x56\x4d\x4b\x6f\x44': _0x564dbb[_0x456736(0x311)],
                    '\x6c\x57\x67\x4d\x4c': _0x564dbb[_0x456736(0x28c)],
                    '\x4c\x53\x43\x73\x72': _0x564dbb['\x69\x6c\x6b\x44\x57'],
                    '\x61\x66\x71\x51\x53': _0x456736(0x2a7),
                    '\x6f\x46\x43\x6c\x44': function (_0x529ceb, _0x3e0a92) {
                        const _0x4dfc7f = _0x456736;
                        return _0x564dbb[_0x4dfc7f(0x3af)](_0x529ceb, _0x3e0a92);
                    },
                    '\x6f\x4a\x77\x6a\x52': _0x564dbb[_0x456736(0x44b)],
                    '\x68\x53\x76\x74\x6e': function (_0x344a37, _0x1dfc7a) {
                        return _0x564dbb['\x6b\x53\x4e\x78\x6e'](_0x344a37, _0x1dfc7a);
                    },
                    '\x41\x4f\x44\x75\x52': _0x564dbb[_0x456736(0x386)],
                    '\x67\x6f\x78\x4c\x41': function (_0x3945db, _0x51e8bd) {
                        const _0x4dccc3 = _0x456736;
                        return _0x564dbb[_0x4dccc3(0x2db)](_0x3945db, _0x51e8bd);
                    },
                    '\x70\x4d\x54\x41\x54': _0x456736(0x1dd),
                    '\x6c\x51\x66\x75\x49': _0x564dbb[_0x456736(0x46f)],
                    '\x49\x4e\x68\x74\x76': function (_0x1a8cbc, _0x7ace47) {
                        const _0x3d34b4 = _0x456736;
                        return _0x564dbb[_0x3d34b4(0x2b3)](_0x1a8cbc, _0x7ace47);
                    },
                    '\x69\x4c\x4c\x6b\x49': _0x564dbb[_0x456736(0x34a)],
                    '\x55\x4b\x63\x4e\x49': function (_0x10a37a, _0x1ba864) {
                        const _0x42d718 = _0x456736;
                        return _0x564dbb[_0x42d718(0x47e)](_0x10a37a, _0x1ba864);
                    },
                    '\x63\x4e\x4f\x52\x62': _0x564dbb[_0x456736(0x423)],
                    '\x6f\x42\x42\x6d\x69': _0x564dbb[_0x456736(0x264)],
                    '\x73\x49\x4c\x77\x4a': function (_0x3e5e0c, _0x2a7813) {
                        return _0x564dbb['\x69\x61\x79\x53\x54'](_0x3e5e0c, _0x2a7813);
                    },
                    '\x62\x72\x53\x71\x67': _0x456736(0x3eb),
                    '\x43\x6a\x62\x64\x76': function (_0x3812fb, _0x15e96d) {
                        return _0x564dbb['\x41\x4d\x6d\x6a\x50'](_0x3812fb, _0x15e96d);
                    },
                    '\x68\x53\x79\x4c\x4c': _0x456736(0x2f4),
                    '\x55\x77\x71\x4b\x6d': function (_0x542642, _0x1417b9, _0xea3f5f, _0x25dd34, _0x46840d, _0x35047c) {
                        const _0x53afe6 = _0x456736;
                        return _0x564dbb[_0x53afe6(0x2fc)](_0x542642, _0x1417b9, _0xea3f5f, _0x25dd34, _0x46840d, _0x35047c);
                    },
                    '\x59\x4a\x4a\x41\x4f': _0x456736(0x431),
                    '\x58\x64\x75\x64\x59': _0x564dbb[_0x456736(0x3fd)],
                    '\x67\x52\x50\x58\x71': function (_0x2c320f, _0x4dbc65) {
                        return _0x2c320f != _0x4dbc65;
                    },
                    '\x50\x52\x77\x62\x49': _0x564dbb['\x51\x74\x52\x48\x57'],
                    '\x66\x69\x63\x75\x78': _0x564dbb[_0x456736(0x465)],
                    '\x41\x45\x68\x65\x79': _0x456736(0x3ee),
                    '\x49\x4f\x50\x41\x64': _0x564dbb[_0x456736(0x41f)],
                    '\x61\x6c\x78\x50\x64': function (_0x3a4af7, _0x40464b) {
                        const _0x3e40cd = _0x456736;
                        return _0x564dbb[_0x3e40cd(0x30b)](_0x3a4af7, _0x40464b);
                    },
                    '\x4b\x41\x4f\x58\x4b': _0x564dbb[_0x456736(0x3cd)],
                    '\x79\x44\x6d\x73\x49': function (_0x1a48dc, _0x18099f) {
                        return _0x1a48dc !== _0x18099f;
                    },
                    '\x69\x74\x62\x48\x56': _0x564dbb[_0x456736(0x36b)],
                    '\x54\x50\x78\x61\x4b': _0x564dbb[_0x456736(0x1f1)],
                    '\x57\x4d\x69\x74\x6e': _0x564dbb['\x4d\x6c\x6e\x58\x72'],
                    '\x4a\x6f\x75\x75\x4b': _0x564dbb['\x75\x61\x4b\x6b\x42'],
                    '\x6e\x6d\x77\x74\x77': _0x564dbb['\x71\x50\x43\x51\x47'],
                    '\x73\x6a\x78\x42\x49': _0x456736(0x1fb),
                    '\x41\x4b\x49\x4e\x72': function (_0x10d394, _0x328274) {
                        const _0x3c0055 = _0x456736;
                        return _0x564dbb[_0x3c0055(0x303)](_0x10d394, _0x328274);
                    },
                    '\x6a\x4f\x4c\x74\x55': _0x456736(0x31e),
                    '\x49\x70\x76\x75\x68': function (_0x160c60, _0x1972f2) {
                        const _0xc27944 = _0x456736;
                        return _0x564dbb[_0xc27944(0x21e)](_0x160c60, _0x1972f2);
                    },
                    '\x51\x78\x63\x76\x56': _0x564dbb[_0x456736(0x2d3)],
                    '\x68\x6e\x6b\x6d\x6f': _0x564dbb[_0x456736(0x463)],
                    '\x49\x79\x7a\x6e\x66': _0x456736(0x2b0),
                    '\x6b\x48\x57\x59\x7a': function (_0x14ea85, _0xc4039c, _0x5505cd) {
                        return _0x14ea85(_0xc4039c, _0x5505cd);
                    },
                    '\x4c\x78\x6c\x63\x72': function (_0x350b86, _0x28ad2f) {
                        const _0x298780 = _0x456736;
                        return _0x564dbb[_0x298780(0x484)](_0x350b86, _0x28ad2f);
                    },
                    '\x61\x4a\x58\x75\x52': _0x564dbb[_0x456736(0x21d)]
                };
            _0x564dbb[_0x456736(0x47e)]('\x4c\x4e\x67\x54\x52', _0x564dbb['\x73\x4e\x72\x49\x79']) ? _0x193683 = _0x2b15f6[_0x456736(0x417)][_0x456736(0x1e3)] : (AwNick = _0x564dbb['\x54\x6e\x41\x46\x69'], AwReply = _0x564dbb[_0x456736(0x320)], AwBotLast = _0x564dbb[_0x456736(0x45e)], AwBotBan = [], SpeechGarble = function (_0x4c647e, _0x3621ad, _0x2f233e) {
                const _0x397772 = _0x456736, _0x29b581 = {
                        '\x47\x7a\x43\x62\x64': function (_0x2ca366, _0x4a9d9a) {
                            const _0x95b0fa = _0x5822;
                            return _0x52a584[_0x95b0fa(0x394)](_0x2ca366, _0x4a9d9a);
                        },
                        '\x78\x57\x49\x63\x44': _0x52a584['\x46\x43\x53\x69\x7a'],
                        '\x64\x6c\x62\x74\x6e': function (_0x27ec7b, _0x474f21) {
                            return _0x52a584['\x6f\x41\x74\x4b\x4f'](_0x27ec7b, _0x474f21);
                        },
                        '\x65\x77\x47\x58\x55': _0x397772(0x2dc),
                        '\x73\x47\x4e\x56\x57': function (_0x1d5bbb, _0x45e5ae) {
                            return _0x1d5bbb > _0x45e5ae;
                        },
                        '\x43\x74\x6f\x56\x66': _0x52a584['\x44\x59\x72\x4b\x61'],
                        '\x78\x6f\x54\x47\x62': function (_0x4b4465, _0x474b21) {
                            const _0x255925 = _0x397772;
                            return _0x52a584[_0x255925(0x46c)](_0x4b4465, _0x474b21);
                        },
                        '\x5a\x6f\x78\x53\x44': function (_0x206466, _0x14dde8) {
                            return _0x206466 < _0x14dde8;
                        },
                        '\x71\x42\x79\x65\x65': _0x52a584[_0x397772(0x351)],
                        '\x68\x75\x72\x42\x4d': function (_0x9a7536, _0x5dab12) {
                            return _0x9a7536 > _0x5dab12;
                        },
                        '\x72\x4d\x42\x6f\x55': function (_0x39b43c, _0x414a69) {
                            return _0x52a584['\x66\x59\x50\x50\x55'](_0x39b43c, _0x414a69);
                        },
                        '\x67\x70\x52\x74\x57': '\x6c\x59\x51\x66\x68',
                        '\x41\x53\x68\x49\x57': _0x52a584[_0x397772(0x1ab)],
                        '\x4f\x75\x59\x46\x42': function (_0x58d873, _0x32bce8, _0x438bbb, _0x15b88d) {
                            return _0x58d873(_0x32bce8, _0x438bbb, _0x15b88d);
                        },
                        '\x67\x44\x73\x6c\x52': function (_0x31d2b5, _0x1a6c9a) {
                            return _0x52a584['\x67\x66\x72\x58\x6a'](_0x31d2b5, _0x1a6c9a);
                        },
                        '\x75\x79\x74\x55\x76': _0x397772(0x251),
                        '\x63\x73\x53\x77\x6b': function (_0x2c9da8) {
                            return _0x52a584['\x45\x6c\x78\x45\x45'](_0x2c9da8);
                        },
                        '\x6e\x54\x72\x76\x6e': _0x52a584[_0x397772(0x40c)],
                        '\x65\x4f\x68\x4d\x6f': _0x52a584['\x62\x55\x4a\x4f\x4d'],
                        '\x78\x62\x56\x42\x73': _0x52a584[_0x397772(0x16a)],
                        '\x48\x43\x7a\x54\x67': _0x397772(0x3fb),
                        '\x6e\x5a\x75\x66\x41': _0x52a584[_0x397772(0x229)],
                        '\x61\x43\x44\x4f\x77': function (_0x54ccc3, _0x103ed5) {
                            return _0x54ccc3 < _0x103ed5;
                        },
                        '\x61\x4e\x62\x69\x49': function (_0x584fa1, _0x298cd9) {
                            const _0xb7e40c = _0x397772;
                            return _0x52a584[_0xb7e40c(0x2a1)](_0x584fa1, _0x298cd9);
                        },
                        '\x5a\x62\x55\x62\x6c': _0x52a584[_0x397772(0x38a)]
                    };
                _0x52a584[_0x397772(0x2be)](AwBotLast, _0x52a584['\x67\x66\x72\x58\x6a'](_0x3621ad, _0x4c647e[_0x397772(0x1e3)])) && _0x52a584[_0x397772(0x346)](_0x3621ad[_0x397772(0x2cf)](AwReply), -(-0x1dff * 0x1 + 0x105b * 0x2 + -0x15b * 0x2)) && (_0x52a584[_0x397772(0x1d0)](_0x52a584[_0x397772(0x430)], _0x397772(0x23f)) ? setTimeout(function () {
                    const _0x40b7b4 = _0x397772, _0x3bca22 = {
                            '\x78\x42\x78\x4c\x45': function (_0x12fe3d, _0x22ff69, _0x31964a) {
                                return _0x12fe3d(_0x22ff69, _0x31964a);
                            },
                            '\x61\x7a\x4f\x4b\x59': function (_0x95fcb0, _0x3e08a3) {
                                const _0x2dc000 = _0x5822;
                                return _0x341a52[_0x2dc000(0x2c5)](_0x95fcb0, _0x3e08a3);
                            },
                            '\x62\x46\x68\x4c\x6f': function (_0x3fe35d, _0x3197d2) {
                                const _0x18f0cd = _0x5822;
                                return _0x341a52[_0x18f0cd(0x2c5)](_0x3fe35d, _0x3197d2);
                            },
                            '\x79\x74\x50\x76\x4b': function (_0x4ecc6c, _0x46bef1) {
                                const _0x3d9a8f = _0x5822;
                                return _0x341a52[_0x3d9a8f(0x2c5)](_0x4ecc6c, _0x46bef1);
                            },
                            '\x6a\x52\x64\x70\x76': _0x341a52[_0x40b7b4(0x24d)],
                            '\x68\x4f\x62\x73\x4d': function (_0x39ff16, _0x38deb5) {
                                const _0x577f0 = _0x40b7b4;
                                return _0x341a52[_0x577f0(0x377)](_0x39ff16, _0x38deb5);
                            },
                            '\x56\x42\x56\x58\x49': _0x341a52[_0x40b7b4(0x34e)],
                            '\x72\x4b\x44\x4a\x4e': function (_0x1478c4, _0xdd4350) {
                                return _0x1478c4 == _0xdd4350;
                            },
                            '\x73\x63\x46\x47\x6e': _0x341a52[_0x40b7b4(0x18f)],
                            '\x4e\x4d\x67\x74\x79': _0x341a52[_0x40b7b4(0x1a6)],
                            '\x47\x6f\x43\x58\x51': function (_0x2ca200, _0x317e13, _0x511969) {
                                return _0x341a52['\x53\x44\x77\x72\x6c'](_0x2ca200, _0x317e13, _0x511969);
                            },
                            '\x79\x6c\x62\x43\x54': _0x341a52[_0x40b7b4(0x3c1)],
                            '\x63\x42\x55\x4f\x76': '\x61\x77\x42\x4f\x54\x20\x53\x6f\x72\x72\x79\x20\x62\x75\x74\x20\x79\x6f\x75\x27\x76\x65\x20\x62\x65\x65\x6e\x20\x62\x61\x6e\x6e\x65\x64\x20\x62\x79\x20\x61\x6e\x20\x6f\x70\x65\x72\x61\x74\x6f\x72\x2e',
                            '\x6d\x68\x4d\x46\x45': _0x341a52[_0x40b7b4(0x2d5)],
                            '\x42\x49\x6a\x4a\x6f': function (_0x406362, _0x59b7b4, _0x5d8ee3) {
                                return _0x341a52['\x48\x78\x67\x46\x66'](_0x406362, _0x59b7b4, _0x5d8ee3);
                            },
                            '\x78\x4e\x54\x71\x6b': _0x341a52['\x6d\x41\x67\x47\x51'],
                            '\x69\x49\x6a\x6c\x6a': _0x341a52[_0x40b7b4(0x24f)],
                            '\x77\x67\x44\x75\x79': _0x341a52['\x54\x69\x48\x6f\x72'],
                            '\x4e\x59\x51\x68\x62': function (_0x563118, _0x59073f) {
                                const _0x3d9ea9 = _0x40b7b4;
                                return _0x341a52[_0x3d9ea9(0x3f6)](_0x563118, _0x59073f);
                            },
                            '\x79\x6f\x5a\x62\x77': _0x40b7b4(0x259),
                            '\x68\x64\x72\x65\x70': _0x40b7b4(0x456),
                            '\x6c\x42\x61\x57\x71': _0x341a52[_0x40b7b4(0x2aa)],
                            '\x55\x44\x6d\x41\x63': function (_0x4722d3, _0x59accd) {
                                const _0x2ae7ac = _0x40b7b4;
                                return _0x341a52[_0x2ae7ac(0x23a)](_0x4722d3, _0x59accd);
                            },
                            '\x46\x69\x49\x79\x71': function (_0x5e2d37, _0x5c7e3a) {
                                return _0x341a52['\x42\x7a\x58\x55\x4c'](_0x5e2d37, _0x5c7e3a);
                            },
                            '\x52\x4a\x53\x63\x54': _0x341a52[_0x40b7b4(0x16e)],
                            '\x54\x61\x62\x79\x4a': _0x341a52[_0x40b7b4(0x279)],
                            '\x44\x5a\x45\x44\x57': _0x40b7b4(0x245),
                            '\x49\x74\x50\x7a\x75': _0x341a52[_0x40b7b4(0x3ec)],
                            '\x4f\x55\x49\x6b\x6a': function (_0x3e4523, _0x2f80b5, _0x29e536, _0xf3fe22) {
                                return _0x341a52['\x4e\x4a\x65\x50\x44'](_0x3e4523, _0x2f80b5, _0x29e536, _0xf3fe22);
                            },
                            '\x52\x68\x5a\x6e\x73': function (_0x4714a4, _0x18a427, _0x4f2325) {
                                const _0x3fe39d = _0x40b7b4;
                                return _0x341a52[_0x3fe39d(0x180)](_0x4714a4, _0x18a427, _0x4f2325);
                            },
                            '\x49\x6e\x72\x6c\x53': _0x341a52[_0x40b7b4(0x2ef)],
                            '\x51\x46\x48\x73\x56': function (_0x167d92, _0x1739cc) {
                                const _0x2f6f2f = _0x40b7b4;
                                return _0x341a52[_0x2f6f2f(0x1f6)](_0x167d92, _0x1739cc);
                            },
                            '\x44\x6f\x6d\x43\x42': function (_0x35683d, _0x3a1bc8) {
                                const _0x45efce = _0x40b7b4;
                                return _0x341a52[_0x45efce(0x27c)](_0x35683d, _0x3a1bc8);
                            },
                            '\x67\x70\x5a\x65\x74': function (_0x35815e, _0x389a55) {
                                const _0xd467ff = _0x40b7b4;
                                return _0x341a52[_0xd467ff(0x42b)](_0x35815e, _0x389a55);
                            },
                            '\x4d\x4d\x42\x67\x62': _0x341a52[_0x40b7b4(0x37a)],
                            '\x41\x56\x61\x4b\x4d': function (_0x4fc3bd, _0x23d2a1, _0x576e2f) {
                                const _0xf1b617 = _0x40b7b4;
                                return _0x341a52[_0xf1b617(0x42a)](_0x4fc3bd, _0x23d2a1, _0x576e2f);
                            },
                            '\x76\x78\x51\x71\x4e': _0x341a52[_0x40b7b4(0x3ea)],
                            '\x55\x63\x47\x74\x79': _0x341a52[_0x40b7b4(0x2dd)],
                            '\x79\x4e\x45\x50\x4e': function (_0x16d974, _0x1c6308, _0x3b0573, _0x7bbae3, _0x26e475, _0x2d13c1) {
                                return _0x341a52['\x57\x73\x6c\x56\x51'](_0x16d974, _0x1c6308, _0x3b0573, _0x7bbae3, _0x26e475, _0x2d13c1);
                            },
                            '\x62\x79\x68\x61\x47': _0x40b7b4(0x207),
                            '\x46\x51\x58\x74\x69': _0x341a52[_0x40b7b4(0x1bd)],
                            '\x55\x41\x46\x64\x52': function (_0x6c5bbc, _0x26d317) {
                                const _0x444404 = _0x40b7b4;
                                return _0x341a52[_0x444404(0x377)](_0x6c5bbc, _0x26d317);
                            },
                            '\x55\x49\x7a\x78\x7a': _0x341a52[_0x40b7b4(0x33b)],
                            '\x6e\x5a\x62\x64\x6f': _0x40b7b4(0x485)
                        };
                    if (_0x341a52[_0x40b7b4(0x15b)](_0x40b7b4(0x2b1), _0x341a52[_0x40b7b4(0x240)])) {
                        if (_0x341a52[_0x40b7b4(0x2cc)](AwBotBan[_0x40b7b4(0x2cf)](_0x4c647e[_0x40b7b4(0x1e3)]), -(0x25c3 + 0x701 * -0x5 + -0x2bd))) {
                            if (_0x341a52[_0x40b7b4(0x44e)](_0x3621ad[_0x40b7b4(0x2cf)](AwNick), -(0x1998 + 0x1 * 0x191 + 0x278 * -0xb))) {
                                if (_0x341a52[_0x40b7b4(0x3ce)](_0x341a52[_0x40b7b4(0x482)], _0x341a52['\x51\x62\x4e\x72\x66']))
                                    return;
                                else {
                                    let _0xaca926 = _0x341a52[_0x40b7b4(0x2c5)](_0x341a52[_0x40b7b4(0x166)] + AwNick, _0x341a52[_0x40b7b4(0x36d)]);
                                    if (_0x341a52[_0x40b7b4(0x44e)](_0x3621ad[_0x40b7b4(0x2cf)]('\u6551\u6211'), -(0x13 * 0x59 + 0x26b0 + -0x1 * 0x2d4a)))
                                        _0x341a52[_0x40b7b4(0x358)](CharacterReleaseTotal, _0x4c647e), _0x4c647e[_0x40b7b4(0x481)][_0x40b7b4(0x45b)] = -0x215a * -0x1 + -0x4 * 0x41b + -0x18a * 0xb, ChatRoomCharacterUpdate(_0x4c647e), _0xaca926 = _0x341a52[_0x40b7b4(0x34e)];
                                    else {
                                        if (_0x341a52['\x6b\x5a\x68\x75\x79'](_0x3621ad[_0x40b7b4(0x2cf)]('\u6346\u6211'), -(0x1ac5 + 0x19 * 0x131 + -0x388d))) {
                                            if (_0x341a52['\x66\x64\x51\x62\x78'](_0x40b7b4(0x3cc), '\x55\x54\x43\x72\x79')) {
                                                let _0x1512b6 = _0x1e852d, _0x4e39bb = _0x3bca22[_0x40b7b4(0x39a)](_0x1294b5, _0x15992c, _0x1274fb);
                                                return _0x4e39bb > -0x89e + -0xe * -0x20b + -0x13fc && (_0x1512b6 = _0x3bca22['\x61\x7a\x4f\x4b\x59'](_0x3bca22[_0x40b7b4(0x3a6)](_0x3bca22[_0x40b7b4(0x1ba)](_0x3bca22[_0x40b7b4(0x399)], _0x4e39bb), '\x20'), _0x1512b6)), _0x1512b6;
                                            } else {
                                                const _0x388c2b = _0x341a52[_0x40b7b4(0x2fa)][_0x40b7b4(0x309)]('\x7c');
                                                let _0x72b641 = -0x2559 + -0x3 * -0x28c + -0xc3 * -0x27;
                                                while (!![]) {
                                                    switch (_0x388c2b[_0x72b641++]) {
                                                    case '\x30':
                                                        _0x4c647e[_0x40b7b4(0x481)]['\x50\x72\x6f\x67\x72\x65\x73\x73'] = 0xaf6 + -0x1 * 0x1bfd + 0x1 * 0x1107;
                                                        continue;
                                                    case '\x31':
                                                        _0xaca926 = _0x341a52[_0x40b7b4(0x26c)];
                                                        continue;
                                                    case '\x32':
                                                        _0x341a52[_0x40b7b4(0x2d9)](InventoryWear, _0x4c647e, '\x4c\x65\x61\x74\x68\x65\x72\x41\x72\x6d\x62\x69\x6e\x64\x65\x72', _0x341a52[_0x40b7b4(0x33b)], _0x341a52[_0x40b7b4(0x1bd)], -0x33895 + 0x1104e + -0x3e799 * -0x1);
                                                        continue;
                                                    case '\x33':
                                                        _0x341a52['\x64\x58\x48\x62\x6c'](InventoryWear, _0x4c647e, _0x341a52[_0x40b7b4(0x2d6)], _0x341a52[_0x40b7b4(0x3a1)], _0x341a52[_0x40b7b4(0x1bd)], 0x4a6e * 0x7 + 0x8d38 * -0x6 + 0x305a0);
                                                        continue;
                                                    case '\x34':
                                                        _0x341a52[_0x40b7b4(0x358)](ChatRoomCharacterUpdate, _0x4c647e);
                                                        continue;
                                                    }
                                                    break;
                                                }
                                            }
                                        } else {
                                            if (_0x341a52[_0x40b7b4(0x15e)](_0x3621ad['\x69\x6e\x64\x65\x78\x4f\x66']('\u5173\u4e8e'), -(0x1 * -0x166d + -0x1e7 * 0xe + -0x3110 * -0x1)))
                                                _0xaca926 = _0x341a52[_0x40b7b4(0x15a)];
                                            else {
                                                if (_0x341a52['\x70\x43\x44\x57\x6b'](_0x3621ad['\x69\x6e\x64\x65\x78\x4f\x66']('\u8214\u6211'), -(0x110a + 0x16f0 + -0x27f9)))
                                                    _0xaca926 = _0x341a52['\x46\x49\x51\x6b\x63'](_0x341a52['\x4d\x4f\x48\x45\x4e'], _0x4c647e[_0x40b7b4(0x1e3)]) + '\x2e';
                                                else {
                                                    if (_0x341a52[_0x40b7b4(0x30f)](_0x3621ad['\x69\x6e\x64\x65\x78\x4f\x66']('\u73a9\u6211'), -(-0x1 * 0x1f11 + -0x565 + -0x5 * -0x74b)))
                                                        _0x341a52[_0x40b7b4(0x262)] !== _0x40b7b4(0x363) ? (_0x341a52[_0x40b7b4(0x194)](InventoryWear, _0x4c647e, _0x341a52['\x52\x57\x6c\x75\x71'], _0x40b7b4(0x269), _0x341a52[_0x40b7b4(0x1bd)], 0x72f9 * 0x5 + -0xcf74 * 0x1 + 0x9 * 0x8e1), _0x4c647e[_0x40b7b4(0x481)][_0x40b7b4(0x45b)] = 0x3d6 * -0x6 + 0xbeb + 0xb19, _0x341a52[_0x40b7b4(0x3a4)](ChatRoomCharacterUpdate, _0x4c647e), _0xaca926 = _0x341a52[_0x40b7b4(0x432)]) : _0x29b581['\x47\x7a\x43\x62\x64'](_0x5b9743, _0x29b581[_0x40b7b4(0x181)]);
                                                    else {
                                                        if (_0x341a52[_0x40b7b4(0x44e)](_0x3621ad[_0x40b7b4(0x2cf)]('\u9501\u6211'), -(0x5 * 0x3e4 + -0x176c + -0x9 * -0x71)))
                                                            _0x4c647e[_0x40b7b4(0x413)][_0x40b7b4(0x38f)](_0xb14c67 => {
                                                                const _0xd6e6cb = _0x40b7b4, _0x1a8858 = {
                                                                        '\x71\x6f\x47\x6b\x4f': function (_0x4912ce, _0x229dad, _0x1bdf4b) {
                                                                            const _0xd30197 = _0x5822;
                                                                            return _0x3bca22[_0xd30197(0x33f)](_0x4912ce, _0x229dad, _0x1bdf4b);
                                                                        },
                                                                        '\x78\x77\x78\x6b\x4f': _0x3bca22[_0xd6e6cb(0x330)],
                                                                        '\x56\x6f\x4d\x77\x5a': _0x3bca22['\x69\x49\x6a\x6c\x6a']
                                                                    };
                                                                let _0x24b0dc = 0x242 + 0x1ad3 + -0x1d15;
                                                                _0xb14c67[_0xd6e6cb(0x3e0)] > -0x1e42 + -0x1d * 0x67 + 0x1 * 0x29ed && (_0x3bca22[_0xd6e6cb(0x3b8)] !== _0x3bca22[_0xd6e6cb(0x3b8)] ? (_0x3bca22[_0xd6e6cb(0x30e)](_0x23d183, _0x118617), _0x5f217d['\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73']['\x50\x72\x6f\x67\x72\x65\x73\x73'] = -0x403 + 0x1fbc + -0x1bb9, _0x3bca22['\x68\x4f\x62\x73\x4d'](_0x2a1f80, _0x28dd29), _0x5ad4b0 = _0x3bca22[_0xd6e6cb(0x195)]) : (_0xb14c67[_0xd6e6cb(0x2ca)] == null && (_0x3bca22[_0xd6e6cb(0x175)](_0x3bca22[_0xd6e6cb(0x24a)], _0x3bca22['\x68\x64\x72\x65\x70']) ? _0x3bca22[_0xd6e6cb(0x2cb)](this[_0xd6e6cb(0x224)], ![]) || this[_0xd6e6cb(0x224)] == _0x58f21d ? (this[_0xd6e6cb(0x224)] = !![], _0x3bca22[_0xd6e6cb(0x30e)](_0x5b4000, _0x3bca22['\x73\x63\x46\x47\x6e'])) : (this[_0xd6e6cb(0x224)] = ![], _0x3bca22[_0xd6e6cb(0x30e)](_0x24b08f, _0x3bca22[_0xd6e6cb(0x215)])) : _0xb14c67[_0xd6e6cb(0x2ca)] = {}), _0xb14c67[_0xd6e6cb(0x2ca)][_0xd6e6cb(0x403)] == null && (_0xb14c67[_0xd6e6cb(0x2ca)][_0xd6e6cb(0x403)] = []), _0xb14c67[_0xd6e6cb(0x2ca)][_0xd6e6cb(0x403)][_0xd6e6cb(0x2cf)](_0x3bca22['\x6c\x42\x61\x57\x71']) < 0x1c35 + 0x469 + 0xa * -0x343 && (_0xd6e6cb(0x2a4) === _0xd6e6cb(0x2a4) ? _0xb14c67['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0xd6e6cb(0x403)][_0xd6e6cb(0x1b4)](_0x3bca22['\x6c\x42\x61\x57\x71']) : _0x1a8858[_0xd6e6cb(0x167)](_0x110997, _0x1a8858[_0xd6e6cb(0x2fe)], {
                                                                    '\x4d\x65\x6d\x62\x65\x72\x4e\x75\x6d\x62\x65\x72': _0x3eed15[_0xd6e6cb(0x1e5)],
                                                                    '\x41\x63\x74\x69\x6f\x6e': _0x1a8858[_0xd6e6cb(0x314)]
                                                                })), _0x3bca22[_0xd6e6cb(0x22c)](Math[_0xd6e6cb(0x201)](), 0x3 * -0x8b9 + 0x1ab + -0x20 * -0xc4 + 0.5) ? _0x3bca22[_0xd6e6cb(0x293)](_0x3bca22[_0xd6e6cb(0x397)], _0x3bca22[_0xd6e6cb(0x3ff)]) ? _0xb14c67[_0xd6e6cb(0x2ca)][_0xd6e6cb(0x23d)] = _0x3bca22[_0xd6e6cb(0x179)] : (_0x398a2f[_0xd6e6cb(0x413)] = _0x5b5332, _0x3bca22[_0xd6e6cb(0x30e)](_0x14fa83, _0x57fd0e)) : _0xd6e6cb(0x284) !== _0xd6e6cb(0x2a2) ? _0xb14c67[_0xd6e6cb(0x2ca)][_0xd6e6cb(0x23d)] = _0x3bca22[_0xd6e6cb(0x270)] : _0x3bca22['\x47\x6f\x43\x58\x51'](_0x242893, _0x3bca22[_0xd6e6cb(0x21b)], {
                                                                    '\x43\x6f\x6e\x74\x65\x6e\x74': _0x3bca22['\x63\x42\x55\x4f\x76'],
                                                                    '\x54\x79\x70\x65': _0x3bca22[_0xd6e6cb(0x2e7)]
                                                                }), _0xb14c67['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0xd6e6cb(0x318)] = Player['\x4d\x65\x6d\x62\x65\x72\x4e\x75\x6d\x62\x65\x72'], _0x4c647e[_0xd6e6cb(0x413)][_0x24b0dc] = _0xb14c67)), _0x24b0dc++;
                                                            }), _0x4c647e[_0x40b7b4(0x481)]['\x50\x72\x6f\x67\x72\x65\x73\x73'] = 0x4e0 + -0x462 + -0x1 * 0x7e, _0x341a52[_0x40b7b4(0x348)](ChatRoomCharacterUpdate, _0x4c647e), _0xaca926 = _0x341a52['\x77\x44\x64\x79\x75'];
                                                        else {
                                                            if (_0x3621ad[_0x40b7b4(0x2cf)]('\u6346\u6b7b\u6211') != -(-0xfc + 0x9 * 0x9 + 0xac)) {
                                                                if (_0x40b7b4(0x15d) !== _0x341a52[_0x40b7b4(0x331)]) {
                                                                    let _0x4ce992 = [
                                                                        _0x40b7b4(0x269),
                                                                        _0x341a52['\x4d\x49\x4a\x6e\x6b'],
                                                                        _0x40b7b4(0x442),
                                                                        '\x49\x74\x65\x6d\x42\x75\x74\x74',
                                                                        _0x341a52[_0x40b7b4(0x341)],
                                                                        _0x40b7b4(0x46a),
                                                                        _0x341a52[_0x40b7b4(0x3a1)],
                                                                        _0x341a52[_0x40b7b4(0x473)],
                                                                        _0x341a52[_0x40b7b4(0x208)],
                                                                        _0x341a52[_0x40b7b4(0x31a)],
                                                                        _0x341a52[_0x40b7b4(0x193)],
                                                                        _0x341a52['\x4c\x57\x4d\x56\x6b'],
                                                                        _0x40b7b4(0x383),
                                                                        _0x341a52[_0x40b7b4(0x321)],
                                                                        _0x341a52[_0x40b7b4(0x17e)],
                                                                        _0x40b7b4(0x223),
                                                                        _0x341a52['\x4e\x66\x5a\x64\x55'],
                                                                        _0x341a52[_0x40b7b4(0x23e)],
                                                                        _0x341a52[_0x40b7b4(0x168)],
                                                                        _0x341a52[_0x40b7b4(0x345)],
                                                                        _0x341a52[_0x40b7b4(0x232)],
                                                                        _0x40b7b4(0x2a0),
                                                                        _0x341a52[_0x40b7b4(0x258)],
                                                                        _0x40b7b4(0x1fb),
                                                                        _0x341a52['\x61\x66\x71\x51\x53']
                                                                    ];
                                                                    _0x4ce992[_0x40b7b4(0x38f)](_0x340111 => {
                                                                        const _0x5bbb06 = _0x40b7b4;
                                                                        _0x3bca22[_0x5bbb06(0x472)](InventoryWearRandom, _0x4c647e, _0x340111, 0x7db * 0x1a + -0x29ab2 + 0x552 * 0xab);
                                                                    }), _0x4c647e[_0x40b7b4(0x413)][_0x40b7b4(0x38f)](_0x3ba354 => {
                                                                        const _0x92e909 = _0x40b7b4;
                                                                        let _0x569f7e = 0x30 * -0x89 + -0x2 * 0x332 + -0x2014 * -0x1;
                                                                        _0x3bca22[_0x92e909(0x22c)](_0x3ba354[_0x92e909(0x3e0)], -0x978 * -0x4 + 0x1e8e + -0x13 * 0x39a) && (_0x3ba354['\x50\x72\x6f\x70\x65\x72\x74\x79'] == null && (_0x3ba354['\x50\x72\x6f\x70\x65\x72\x74\x79'] = {}), _0x3bca22[_0x92e909(0x2cb)](_0x3ba354[_0x92e909(0x2ca)][_0x92e909(0x403)], null) && (_0x3ba354[_0x92e909(0x2ca)][_0x92e909(0x403)] = []), _0x3bca22[_0x92e909(0x429)](_0x3ba354['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x92e909(0x403)][_0x92e909(0x2cf)](_0x3bca22[_0x92e909(0x33c)]), -0x1a43 + -0x115 * 0x1 + 0x1b58) && _0x3ba354[_0x92e909(0x2ca)][_0x92e909(0x403)]['\x70\x75\x73\x68']('\x4c\x6f\x63\x6b'), _0x3bca22['\x44\x6f\x6d\x43\x42'](Math[_0x92e909(0x201)](), -0x7b3 + 0x1a35 * 0x1 + -0x1282 + 0.5) ? _0x3ba354[_0x92e909(0x2ca)][_0x92e909(0x23d)] = _0x3bca22[_0x92e909(0x179)] : _0x3bca22['\x67\x70\x5a\x65\x74'](_0x3bca22[_0x92e909(0x1cb)], _0x3bca22[_0x92e909(0x1cb)]) ? _0x3bca22[_0x92e909(0x1bb)](_0x102536, _0x3bca22['\x79\x6c\x62\x43\x54'], {
                                                                            '\x43\x6f\x6e\x74\x65\x6e\x74': _0x3bca22[_0x92e909(0x1fc)],
                                                                            '\x54\x79\x70\x65': _0x92e909(0x21f)
                                                                        }) : _0x3ba354[_0x92e909(0x2ca)][_0x92e909(0x23d)] = _0x3bca22['\x49\x74\x50\x7a\x75'], _0x3ba354[_0x92e909(0x2ca)][_0x92e909(0x318)] = Player[_0x92e909(0x1e5)], _0x4c647e[_0x92e909(0x413)][_0x569f7e] = _0x3ba354), _0x569f7e++;
                                                                    }), _0x4c647e[_0x40b7b4(0x481)]['\x50\x72\x6f\x67\x72\x65\x73\x73'] = -0x479 * 0x7 + 0x19 * 0x6d + -0x17 * -0xe6, _0x341a52[_0x40b7b4(0x220)](ChatRoomCharacterUpdate, _0x4c647e), _0xaca926 = _0x341a52[_0x40b7b4(0x47c)], AwBotBan['\x70\x75\x73\x68'](_0x4c647e[_0x40b7b4(0x1e3)]);
                                                                } else {
                                                                    const _0x57c199 = '\x31\x7c\x35\x7c\x30\x7c\x36\x7c\x32\x7c\x34\x7c\x33'['\x73\x70\x6c\x69\x74']('\x7c');
                                                                    let _0x57a1d1 = 0x6b * 0xe + -0x2 * -0x11 + -0x5fc;
                                                                    while (!![]) {
                                                                        switch (_0x57c199[_0x57a1d1++]) {
                                                                        case '\x30':
                                                                            if (_0x3bca22[_0x40b7b4(0x2cb)](_0x5af17a, null))
                                                                                return;
                                                                            continue;
                                                                        case '\x31':
                                                                            _0x4da806 = _0x3bca22[_0x40b7b4(0x47d)](_0x35e438, _0x3bca22[_0x40b7b4(0x2f5)], _0x3bca22[_0x40b7b4(0x3f7)]);
                                                                            continue;
                                                                        case '\x32':
                                                                            _0x3bca22[_0x40b7b4(0x3d9)](_0x15c05f, _0x57f3bd, _0x40b7b4(0x3db), _0x3bca22['\x62\x79\x68\x61\x47'], _0x3bca22[_0x40b7b4(0x44a)], -0x2ae7 + 0x1e598 + 0x4a1);
                                                                            continue;
                                                                        case '\x33':
                                                                            _0x3bca22[_0x40b7b4(0x37c)](_0x5c8f83, _0x17faf8);
                                                                            continue;
                                                                        case '\x34':
                                                                            _0x577ddc[_0x40b7b4(0x481)][_0x40b7b4(0x45b)] = -0xdc9 * 0x1 + 0x13 * -0x53 + 0x2 * 0x9f9;
                                                                            continue;
                                                                        case '\x35':
                                                                            _0x1a2437 = _0x54ae6f[_0x40b7b4(0x15f)](_0x3e9e48 => _0x3e9e48[_0x40b7b4(0x1e3)][_0x40b7b4(0x164)]() == _0x43e011);
                                                                            continue;
                                                                        case '\x36':
                                                                            _0x3bca22[_0x40b7b4(0x3d9)](_0x5ed1ac, _0x26b52e, _0x40b7b4(0x431), _0x3bca22[_0x40b7b4(0x16f)], _0x3bca22[_0x40b7b4(0x44a)], 0x182 * -0xdb + -0x8b5 * 0x34 + 0x4ce4c);
                                                                            continue;
                                                                        }
                                                                        break;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    ServerSend(_0x341a52['\x4d\x4b\x6f\x61\x75'], {
                                        '\x43\x6f\x6e\x74\x65\x6e\x74': _0x341a52['\x46\x49\x51\x6b\x63'](AwReply + '\x20', _0xaca926),
                                        '\x54\x79\x70\x65': _0x341a52[_0x40b7b4(0x2d5)]
                                    });
                                }
                            } else {
                                if (_0x341a52[_0x40b7b4(0x2e4)](_0x3621ad[_0x40b7b4(0x2cf)](_0x341a52[_0x40b7b4(0x373)]), -(0x58 * -0x11 + 0x12 * -0x17f + 0x20c7))) {
                                    if (_0x341a52[_0x40b7b4(0x3f4)](_0x40b7b4(0x3b9), _0x341a52[_0x40b7b4(0x43a)])) {
                                        let _0x11a633 = _0x341a52[_0x40b7b4(0x418)];
                                        if (_0x341a52[_0x40b7b4(0x3de)](_0x3621ad[_0x40b7b4(0x2cf)](_0x341a52[_0x40b7b4(0x3a3)]), -(0x1a41 + -0x2507 + 0xac7)))
                                            _0x341a52['\x55\x4b\x63\x4e\x49'](_0x341a52[_0x40b7b4(0x2ad)], _0x341a52[_0x40b7b4(0x1d4)]) ? _0x4d51de = _0x29b581['\x64\x6c\x62\x74\x6e'](_0x29b581['\x64\x6c\x62\x74\x6e'](_0x40b7b4(0x184), _0x4d9e6e[_0x40b7b4(0x1e3)]), '\x2e') : (_0x341a52[_0x40b7b4(0x348)](CharacterReleaseTotal, _0x4c647e), _0x4c647e[_0x40b7b4(0x481)]['\x50\x72\x6f\x67\x72\x65\x73\x73'] = 0x1749 + 0x1a06 + 0xd * -0x3cb, _0x341a52[_0x40b7b4(0x203)](ChatRoomCharacterUpdate, _0x4c647e), _0x11a633 = _0x341a52[_0x40b7b4(0x19e)]);
                                        else {
                                            if (_0x341a52[_0x40b7b4(0x338)](_0x3621ad['\x69\x6e\x64\x65\x78\x4f\x66']('\x62\x6f\x6e\x64\x61\x67\x65'), -(0x1b22 * 0x1 + -0xd3 * 0x4 + 0x17d5 * -0x1))) {
                                                const _0x1a44f8 = _0x341a52[_0x40b7b4(0x1a5)][_0x40b7b4(0x309)]('\x7c');
                                                let _0x57ca49 = 0x425 * 0x8 + 0x21ed + -0x4315;
                                                while (!![]) {
                                                    switch (_0x1a44f8[_0x57ca49++]) {
                                                    case '\x30':
                                                        _0x341a52[_0x40b7b4(0x19a)](InventoryWear, _0x4c647e, _0x341a52[_0x40b7b4(0x29d)], _0x40b7b4(0x269), _0x40b7b4(0x17f), -0xb20f * 0x3 + 0x36d4d + 0x2 * 0x3419);
                                                        continue;
                                                    case '\x31':
                                                        _0x4c647e[_0x40b7b4(0x481)][_0x40b7b4(0x45b)] = -0x8cb + -0x22f4 + 0x1 * 0x2bbf;
                                                        continue;
                                                    case '\x32':
                                                        _0x341a52['\x64\x58\x48\x62\x6c'](InventoryWear, _0x4c647e, _0x341a52['\x6d\x6c\x68\x6b\x52'], '\x49\x74\x65\x6d\x46\x65\x65\x74', _0x40b7b4(0x17f), -0xcee7 + -0x30a63 + -0x52c * -0x115);
                                                        continue;
                                                    case '\x33':
                                                        _0x11a633 = _0x341a52[_0x40b7b4(0x2ed)];
                                                        continue;
                                                    case '\x34':
                                                        ChatRoomCharacterUpdate(_0x4c647e);
                                                        continue;
                                                    }
                                                    break;
                                                }
                                            } else {
                                                if (_0x341a52[_0x40b7b4(0x357)](_0x3621ad[_0x40b7b4(0x2cf)](_0x40b7b4(0x340)), -(-0x180c + -0x18a7 + 0x4 * 0xc2d)))
                                                    AwBotBan[_0x40b7b4(0x1b4)](_0x4c647e[_0x40b7b4(0x1e3)]), _0x11a633 = _0x341a52[_0x40b7b4(0x3c0)];
                                                else {
                                                    if (_0x341a52[_0x40b7b4(0x357)](_0x3621ad[_0x40b7b4(0x2cf)](_0x40b7b4(0x39f)), -(-0x3d0 + 0x1 * -0x1e47 + 0x2218)))
                                                        _0x11a633 = _0x341a52[_0x40b7b4(0x2f1)];
                                                    else {
                                                        if (_0x341a52[_0x40b7b4(0x2e4)](_0x3621ad['\x69\x6e\x64\x65\x78\x4f\x66'](_0x40b7b4(0x347)), -(-0x777 + -0x1 * -0x1bed + -0x1475)))
                                                            _0x11a633 = _0x341a52[_0x40b7b4(0x2c5)](_0x341a52[_0x40b7b4(0x2c5)](_0x341a52[_0x40b7b4(0x21c)], _0x4c647e[_0x40b7b4(0x1e3)]), '\x2e');
                                                        else {
                                                            if (_0x341a52[_0x40b7b4(0x3de)](_0x3621ad[_0x40b7b4(0x2cf)](_0x341a52['\x41\x45\x68\x65\x79']), -(0xb4c + 0x1691 + -0x21dc)))
                                                                _0x341a52['\x76\x41\x58\x66\x47'](InventoryWear, _0x4c647e, _0x40b7b4(0x334), _0x341a52['\x6e\x48\x51\x55\x41'], _0x341a52[_0x40b7b4(0x1bd)], -0x42 * -0xd6d + 0x1ffcf * 0x1 + -0x13cdd * 0x3), _0x4c647e[_0x40b7b4(0x481)][_0x40b7b4(0x45b)] = -0x4 * -0x391 + 0x1 * 0x21d1 + -0x3015, _0x341a52[_0x40b7b4(0x3a4)](ChatRoomCharacterUpdate, _0x4c647e), _0x11a633 = _0x341a52['\x49\x4f\x50\x41\x64'];
                                                            else {
                                                                if (_0x341a52[_0x40b7b4(0x338)](_0x3621ad[_0x40b7b4(0x2cf)]('\x6c\x6f\x63\x6b'), -(0x22e2 + 0x3a * -0x57 + -0xf2b)))
                                                                    _0x4c647e[_0x40b7b4(0x413)][_0x40b7b4(0x38f)](_0x11c4cb => {
                                                                        const _0x13fae2 = _0x40b7b4, _0x382e3d = {};
                                                                        _0x382e3d[_0x13fae2(0x308)] = _0x29b581[_0x13fae2(0x3c3)];
                                                                        const _0x2e9125 = _0x382e3d;
                                                                        let _0x2818cf = 0x9b3 + -0xe9 * -0x17 + 0x1 * -0x1ea2;
                                                                        _0x29b581[_0x13fae2(0x435)](_0x11c4cb[_0x13fae2(0x3e0)], -0x2 * 0xbc3 + 0xb06 + -0x280 * -0x5) && (_0x29b581[_0x13fae2(0x316)] !== '\x57\x45\x4d\x69\x6d' ? _0x588420(_0x2e9125[_0x13fae2(0x308)], 0x16d * -0x1d + -0x36fd9 * 0x1 + 0x55884) : (_0x11c4cb[_0x13fae2(0x2ca)] == null && (_0x11c4cb[_0x13fae2(0x2ca)] = {}), _0x29b581[_0x13fae2(0x302)](_0x11c4cb['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x13fae2(0x403)], null) && (_0x11c4cb['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x13fae2(0x403)] = []), _0x29b581[_0x13fae2(0x422)](_0x11c4cb[_0x13fae2(0x2ca)][_0x13fae2(0x403)]['\x69\x6e\x64\x65\x78\x4f\x66'](_0x29b581[_0x13fae2(0x453)]), -0x48 * -0x5f + 0xda3 * -0x2 + 0x2 * 0x47) && _0x11c4cb[_0x13fae2(0x2ca)]['\x45\x66\x66\x65\x63\x74'][_0x13fae2(0x1b4)](_0x29b581['\x71\x42\x79\x65\x65']), _0x29b581[_0x13fae2(0x426)](Math['\x72\x61\x6e\x64\x6f\x6d'](), -0x1 * 0x8cf + -0x5 * -0x346 + -0x78f + 0.5) ? _0x29b581[_0x13fae2(0x1c6)](_0x29b581[_0x13fae2(0x265)], _0x29b581[_0x13fae2(0x265)]) ? _0x11c4cb[_0x13fae2(0x2ca)][_0x13fae2(0x23d)] = _0x29b581[_0x13fae2(0x250)] : _0x500652 = _0x96aec1['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x13fae2(0x212)] : _0x11c4cb[_0x13fae2(0x2ca)][_0x13fae2(0x23d)] = _0x13fae2(0x441), _0x11c4cb[_0x13fae2(0x2ca)][_0x13fae2(0x318)] = Player[_0x13fae2(0x1e5)], _0x4c647e[_0x13fae2(0x413)][_0x2818cf] = _0x11c4cb)), _0x2818cf++;
                                                                    }), _0x4c647e[_0x40b7b4(0x481)][_0x40b7b4(0x45b)] = 0x1 * -0x1ca + 0x450 + -0x286, _0x341a52['\x61\x6c\x78\x50\x64'](ChatRoomCharacterUpdate, _0x4c647e), _0x11a633 = _0x341a52[_0x40b7b4(0x404)];
                                                                else {
                                                                    if (_0x3621ad[_0x40b7b4(0x2cf)](_0x341a52[_0x40b7b4(0x162)]) != -(-0x1 * -0x535 + -0xe72 * -0x2 + -0x2218)) {
                                                                        if (_0x341a52[_0x40b7b4(0x29a)]('\x56\x57\x6e\x77\x68', _0x341a52[_0x40b7b4(0x183)])) {
                                                                            let _0x40d840 = [
                                                                                _0x341a52[_0x40b7b4(0x33b)],
                                                                                _0x341a52[_0x40b7b4(0x415)],
                                                                                _0x341a52['\x54\x50\x78\x61\x4b'],
                                                                                _0x341a52[_0x40b7b4(0x1fd)],
                                                                                _0x341a52[_0x40b7b4(0x341)],
                                                                                '\x49\x74\x65\x6d\x45\x61\x72\x73',
                                                                                _0x341a52[_0x40b7b4(0x3a1)],
                                                                                _0x341a52[_0x40b7b4(0x473)],
                                                                                _0x341a52[_0x40b7b4(0x208)],
                                                                                _0x341a52[_0x40b7b4(0x31a)],
                                                                                _0x341a52['\x70\x49\x52\x70\x42'],
                                                                                _0x341a52[_0x40b7b4(0x1f0)],
                                                                                '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68',
                                                                                _0x341a52['\x4d\x70\x53\x53\x46'],
                                                                                _0x341a52['\x47\x75\x6d\x57\x4e'],
                                                                                _0x341a52['\x4a\x6f\x75\x75\x4b'],
                                                                                _0x341a52['\x4e\x66\x5a\x64\x55'],
                                                                                _0x341a52[_0x40b7b4(0x23e)],
                                                                                _0x341a52[_0x40b7b4(0x168)],
                                                                                _0x40b7b4(0x31b),
                                                                                _0x341a52[_0x40b7b4(0x232)],
                                                                                _0x341a52[_0x40b7b4(0x20c)],
                                                                                _0x341a52[_0x40b7b4(0x258)],
                                                                                _0x341a52[_0x40b7b4(0x2ab)],
                                                                                _0x341a52[_0x40b7b4(0x2e0)]
                                                                            ];
                                                                            _0x40d840['\x66\x6f\x72\x45\x61\x63\x68'](_0x3ad4a3 => {
                                                                                const _0x65a3b5 = _0x40b7b4;
                                                                                _0x29b581[_0x65a3b5(0x17d)](InventoryWearRandom, _0x4c647e, _0x3ad4a3, 0x169ad + -0x2 * -0x1181b + -0x1da91);
                                                                            }), _0x4c647e['\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73'][_0x40b7b4(0x45b)] = -0x116 + -0x6b7 + -0x1 * -0x7cd, _0x341a52[_0x40b7b4(0x3f8)](ChatRoomCharacterUpdate, _0x4c647e), _0x11a633 = _0x341a52[_0x40b7b4(0x404)];
                                                                        } else
                                                                            _0x2992ae(_0x3bca22[_0x40b7b4(0x21b)], {
                                                                                '\x43\x6f\x6e\x74\x65\x6e\x74': _0x3bca22[_0x40b7b4(0x42e)],
                                                                                '\x54\x79\x70\x65': _0x3bca22['\x6d\x68\x4d\x46\x45']
                                                                            });
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        _0x341a52['\x4f\x6d\x7a\x69\x70'](ServerSend, _0x40b7b4(0x3ba), {
                                            '\x43\x6f\x6e\x74\x65\x6e\x74': _0x341a52[_0x40b7b4(0x343)] + _0x11a633,
                                            '\x54\x79\x70\x65': _0x341a52[_0x40b7b4(0x2d5)]
                                        });
                                    } else {
                                        let _0x45336b;
                                        try {
                                            const _0x2ed0de = rjgsHX[_0x40b7b4(0x35e)](_0x2d580e, rjgsHX[_0x40b7b4(0x45a)](rjgsHX[_0x40b7b4(0x263)]('\x72\x65\x74\x75\x72\x6e\x20\x28\x66\x75\x6e\x63\x74\x69\x6f\x6e\x28\x29\x20', rjgsHX[_0x40b7b4(0x421)]), '\x29\x3b'));
                                            _0x45336b = rjgsHX[_0x40b7b4(0x452)](_0x2ed0de);
                                        } catch (_0xe036c2) {
                                            _0x45336b = _0x5a4654;
                                        }
                                        const _0x2539b4 = _0x45336b['\x63\x6f\x6e\x73\x6f\x6c\x65'] = _0x45336b[_0x40b7b4(0x1b6)] || {}, _0x355570 = [
                                                rjgsHX[_0x40b7b4(0x3d5)],
                                                rjgsHX[_0x40b7b4(0x1db)],
                                                '\x69\x6e\x66\x6f',
                                                rjgsHX[_0x40b7b4(0x1e4)],
                                                rjgsHX[_0x40b7b4(0x16b)],
                                                rjgsHX[_0x40b7b4(0x226)],
                                                _0x40b7b4(0x3be)
                                            ];
                                        for (let _0x471106 = 0xa * 0x137 + -0x1fc6 + -0x274 * -0x8; rjgsHX['\x61\x43\x44\x4f\x77'](_0x471106, _0x355570[_0x40b7b4(0x3a5)]); _0x471106++) {
                                            const _0x47915a = _0x4d5b79[_0x40b7b4(0x1da)][_0x40b7b4(0x169)]['\x62\x69\x6e\x64'](_0x4fa17a), _0x3ff3d3 = _0x355570[_0x471106], _0x2b50b1 = _0x2539b4[_0x3ff3d3] || _0x47915a;
                                            _0x47915a[_0x40b7b4(0x3b2)] = _0x1a89a3[_0x40b7b4(0x239)](_0xe15998), _0x47915a[_0x40b7b4(0x1c9)] = _0x2b50b1[_0x40b7b4(0x1c9)]['\x62\x69\x6e\x64'](_0x2b50b1), _0x2539b4[_0x3ff3d3] = _0x47915a;
                                        }
                                    }
                                } else
                                    _0x341a52[_0x40b7b4(0x333)](_0x3621ad['\x69\x6e\x64\x65\x78\x4f\x66'](_0x341a52[_0x40b7b4(0x1d3)]), -(0x430 + -0xb01 * -0x3 + 0xcf * -0x2e)) && _0x341a52[_0x40b7b4(0x199)](ServerSend, _0x341a52[_0x40b7b4(0x3c1)], {
                                        '\x43\x6f\x6e\x74\x65\x6e\x74': _0x341a52[_0x40b7b4(0x3ab)],
                                        '\x54\x79\x70\x65': _0x341a52[_0x40b7b4(0x2d5)]
                                    });
                            }
                        } else {
                            if (_0x341a52[_0x40b7b4(0x44e)](_0x3621ad[_0x40b7b4(0x2cf)](_0x40b7b4(0x281)), -(0x3c6 * -0x4 + 0x34d + 0xbcc))) {
                                if (_0x341a52[_0x40b7b4(0x44c)] === _0x341a52[_0x40b7b4(0x44c)])
                                    _0x341a52[_0x40b7b4(0x307)](ServerSend, _0x341a52[_0x40b7b4(0x3c1)], {
                                        '\x43\x6f\x6e\x74\x65\x6e\x74': _0x341a52[_0x40b7b4(0x2ef)],
                                        '\x54\x79\x70\x65': _0x341a52[_0x40b7b4(0x2d5)]
                                    });
                                else
                                    return;
                            } else
                                _0x341a52[_0x40b7b4(0x3ed)](_0x3621ad[_0x40b7b4(0x2cf)](_0x341a52[_0x40b7b4(0x373)]), -(-0x18f6 + 0x2b * 0x8e + -0x39 * -0x5)) && _0x341a52['\x6b\x48\x57\x59\x7a'](ServerSend, _0x341a52[_0x40b7b4(0x3c1)], {
                                    '\x43\x6f\x6e\x74\x65\x6e\x74': _0x341a52[_0x40b7b4(0x1d8)],
                                    '\x54\x79\x70\x65': _0x40b7b4(0x21f)
                                });
                        }
                    } else
                        _0x4026da = _0x29b581[_0x40b7b4(0x437)](_0x29b581[_0x40b7b4(0x1ec)] + _0x1a0dd5, '\x20') + _0x79b7c8;
                }, 0x1e0b * 0x1 + 0x2564 + 0x9 * -0x70f) : _0xbb05ff[_0x397772(0x2ca)][_0x397772(0x403)] = []);
                AwBotLast = _0x3621ad + _0x4c647e[_0x397772(0x1e3)];
                let _0x449ef3 = _0x3621ad, _0x56df71 = _0x52a584[_0x397772(0x210)](SpeechGetTotalGagLevel, _0x4c647e, _0x2f233e);
                return _0x52a584[_0x397772(0x354)](_0x56df71, -0x14c2 + -0x1 * -0x2099 + -0xbd7 * 0x1) && (_0x52a584[_0x397772(0x3ca)] === _0x52a584[_0x397772(0x3ca)] ? _0x449ef3 = _0x52a584['\x4f\x6b\x6d\x4e\x72'](_0x52a584[_0x397772(0x2b2)](_0x52a584['\x76\x74\x74\x43\x4f'](_0x397772(0x252), _0x56df71), '\x20'), _0x449ef3) : _0x341a52[_0x397772(0x180)](_0x15b1cc, '\x53\x65\x6c\x66\x42\x6f\x6e\x64\x61\x67\x65', -0x11ce5 + 0x19232 + 0x14a05)), _0x449ef3;
            });
        }), _0x564dbb[_0x4a0cf9(0x3d1)](GM_registerMenuCommand, _0x564dbb['\x50\x6b\x44\x54\x51'], () => {
            const _0x28cff0 = _0x4a0cf9;
            _0x564dbb[_0x28cff0(0x238)] === _0x564dbb['\x6d\x41\x6b\x72\x69'] ? _0x1b521b[_0x28cff0(0x2ca)] = {} : _0x564dbb[_0x28cff0(0x1d1)](this[_0x28cff0(0x32b)], ![]) || _0x564dbb['\x4f\x76\x6c\x5a\x58'](this[_0x28cff0(0x32b)], undefined) ? _0x564dbb[_0x28cff0(0x489)](_0x564dbb['\x44\x54\x54\x77\x70'], '\x48\x4e\x64\x50\x6d') ? _0x52a584[_0x28cff0(0x292)](_0xae0c72, _0x52a584[_0x28cff0(0x280)]) : (this['\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x5a\x68'] = !![], _0x564dbb[_0x28cff0(0x3af)](ChatRoomSendLocal, _0x564dbb[_0x28cff0(0x2ff)])) : (this[_0x28cff0(0x32b)] = ![], _0x564dbb[_0x28cff0(0x303)](ChatRoomSendLocal, _0x564dbb[_0x28cff0(0x182)]));
        }), _0x564dbb[_0x4a0cf9(0x28e)](GM_registerMenuCommand, '\x61\x77\x42\x4f\x54\x5f\u5207\u6362\u9677\u9631\u5c4b\u6a21\u5f0f', () => {
            const _0xea7eb = _0x4a0cf9, _0x2e3b10 = {};
            _0x2e3b10[_0xea7eb(0x27a)] = _0x564dbb[_0xea7eb(0x2c1)];
            const _0x18fe41 = _0x2e3b10;
            _0x564dbb[_0xea7eb(0x47e)](_0x564dbb[_0xea7eb(0x45f)], _0x564dbb['\x4e\x46\x68\x51\x7a']) ? _0x564dbb[_0xea7eb(0x304)](this[_0xea7eb(0x224)], ![]) || _0x564dbb[_0xea7eb(0x26d)](this['\x41\x77\x50\x61\x73\x74\x65'], undefined) ? (this[_0xea7eb(0x224)] = !![], _0x564dbb[_0xea7eb(0x30b)](ChatRoomSendLocal, _0x564dbb[_0xea7eb(0x1e1)])) : (this[_0xea7eb(0x224)] = ![], ChatRoomSendLocal(_0x564dbb[_0xea7eb(0x3b4)])) : _0x46d819 = _0x18fe41[_0xea7eb(0x27a)];
        }), _0x564dbb[_0x4a0cf9(0x3d2)](GM_registerMenuCommand, '\x61\x77\x42\x4f\x54\x5f\u8bbe\u7f6e\u6635\u79f0', () => {
            const _0x6881d5 = _0x4a0cf9;
            AwNick = _0x564dbb[_0x6881d5(0x28e)](prompt, _0x564dbb[_0x6881d5(0x3a9)], _0x6881d5(0x281)), AwReply = prompt(_0x564dbb[_0x6881d5(0x25a)], _0x564dbb['\x42\x59\x72\x42\x4a']);
        }), _0x564dbb['\x6a\x6a\x4c\x65\x68'](GM_registerMenuCommand, _0x564dbb['\x55\x53\x46\x52\x4f'], () => {
            const _0x589347 = _0x4a0cf9;
            _0x564dbb[_0x589347(0x28e)](ServerSend, _0x564dbb[_0x589347(0x25f)], {
                '\x43\x6f\x6e\x74\x65\x6e\x74': _0x564dbb[_0x589347(0x40e)],
                '\x54\x79\x70\x65': _0x564dbb[_0x589347(0x1c3)],
                '\x44\x69\x63\x74\x69\x6f\x6e\x61\x72\x79': [{
                        '\x6d\x65\x73\x73\x61\x67\x65': {
                            '\x74\x79\x70\x65': _0x589347(0x427),
                            '\x76\x65\x72\x73\x69\x6f\x6e': _0x564dbb[_0x589347(0x1d9)],
                            '\x61\x6c\x74\x65\x72\x6e\x61\x74\x65\x41\x72\x6f\x75\x73\x61\x6c': !![],
                            '\x72\x65\x70\x6c\x79\x52\x65\x71\x75\x65\x73\x74\x65\x64': ![],
                            '\x63\x61\x70\x61\x62\x69\x6c\x69\x74\x69\x65\x73': [_0x589347(0x19c)],
                            '\x6e\x69\x63\x6b': null
                        }
                    }]
            });
            const _0x2db57a = {};
            _0x2db57a['\x45\x66\x66\x65\x63\x74'] = [], ServerSend(_0x564dbb[_0x589347(0x25f)], {
                '\x43\x6f\x6e\x74\x65\x6e\x74': _0x589347(0x204),
                '\x54\x79\x70\x65': '\x48\x69\x64\x64\x65\x6e',
                '\x44\x69\x63\x74\x69\x6f\x6e\x61\x72\x79': {
                    '\x74\x79\x70\x65': _0x564dbb['\x72\x71\x6b\x53\x66'],
                    '\x6d\x65\x73\x73\x61\x67\x65': {
                        '\x76\x65\x72\x73\x69\x6f\x6e': _0x564dbb[_0x589347(0x2a3)],
                        '\x72\x65\x71\x75\x65\x73\x74': ![],
                        '\x65\x66\x66\x65\x63\x74\x73': _0x2db57a,
                        '\x74\x79\x70\x69\x6e\x67\x49\x6e\x64\x69\x63\x61\x74\x6f\x72\x45\x6e\x61\x62\x6c\x65': ![],
                        '\x73\x63\x72\x65\x65\x6e\x49\x6e\x64\x69\x63\x61\x74\x6f\x72\x45\x6e\x61\x62\x6c\x65': ![]
                    }
                }
            });
        }), GM_registerMenuCommand(_0x4a0cf9(0x3a8), () => {
            const _0x438855 = _0x4a0cf9, _0x3e47b3 = {
                    '\x4e\x51\x75\x75\x62': function (_0x585a4a, _0x3835b1) {
                        return _0x564dbb['\x77\x6d\x44\x4e\x77'](_0x585a4a, _0x3835b1);
                    },
                    '\x54\x41\x53\x6e\x7a': function (_0x4f17d2, _0x1619c4, _0x54fa5c) {
                        const _0x1d3d37 = _0x5822;
                        return _0x564dbb[_0x1d3d37(0x287)](_0x4f17d2, _0x1619c4, _0x54fa5c);
                    },
                    '\x53\x6e\x67\x6c\x42': _0x564dbb['\x63\x70\x56\x45\x69'],
                    '\x46\x7a\x55\x76\x55': function (_0x5be6f9, _0x113231) {
                        const _0x39c92a = _0x5822;
                        return _0x564dbb[_0x39c92a(0x359)](_0x5be6f9, _0x113231);
                    },
                    '\x70\x63\x63\x4c\x41': _0x564dbb['\x4d\x43\x6b\x55\x75'],
                    '\x73\x74\x79\x58\x75': function (_0x46edf3, _0x5178a5) {
                        const _0x4f1624 = _0x5822;
                        return _0x564dbb[_0x4f1624(0x47e)](_0x46edf3, _0x5178a5);
                    },
                    '\x48\x76\x5a\x7a\x47': _0x564dbb['\x4e\x54\x50\x6e\x54'],
                    '\x61\x6e\x6f\x65\x4b': _0x564dbb['\x7a\x6e\x53\x62\x4f'],
                    '\x48\x4c\x79\x59\x72': _0x438855(0x2af),
                    '\x46\x73\x4c\x68\x53': _0x564dbb[_0x438855(0x475)],
                    '\x68\x54\x6f\x46\x62': _0x564dbb[_0x438855(0x1c0)],
                    '\x63\x57\x59\x6b\x54': _0x564dbb[_0x438855(0x45c)],
                    '\x7a\x79\x51\x6b\x67': _0x564dbb['\x41\x68\x6b\x6d\x49'],
                    '\x4a\x61\x48\x64\x44': _0x564dbb[_0x438855(0x433)],
                    '\x78\x6e\x46\x7a\x56': _0x564dbb[_0x438855(0x188)],
                    '\x6c\x76\x51\x6d\x6b': _0x564dbb[_0x438855(0x1ac)],
                    '\x48\x6a\x65\x41\x41': _0x564dbb[_0x438855(0x185)],
                    '\x4e\x4f\x77\x50\x44': _0x564dbb['\x74\x4c\x74\x5a\x4e'],
                    '\x74\x5a\x58\x41\x56': _0x564dbb[_0x438855(0x312)],
                    '\x41\x6b\x62\x42\x68': _0x564dbb['\x76\x5a\x6f\x70\x6e'],
                    '\x45\x55\x4e\x55\x78': _0x564dbb[_0x438855(0x43d)],
                    '\x45\x79\x58\x4f\x51': _0x564dbb[_0x438855(0x372)],
                    '\x66\x5a\x79\x4e\x53': _0x564dbb[_0x438855(0x2ec)],
                    '\x47\x79\x56\x62\x77': _0x564dbb[_0x438855(0x311)],
                    '\x4c\x54\x47\x49\x4b': _0x564dbb[_0x438855(0x28c)],
                    '\x74\x6e\x65\x58\x73': _0x438855(0x2a0),
                    '\x71\x54\x61\x44\x70': _0x564dbb['\x69\x6c\x6b\x44\x57'],
                    '\x42\x6e\x66\x57\x53': _0x564dbb[_0x438855(0x255)],
                    '\x64\x4a\x70\x47\x73': _0x564dbb['\x70\x51\x6f\x77\x41'],
                    '\x78\x53\x74\x68\x7a': _0x438855(0x3ba),
                    '\x64\x6d\x67\x70\x69': _0x564dbb['\x53\x62\x58\x6d\x52'],
                    '\x6a\x68\x62\x42\x72': _0x564dbb[_0x438855(0x1eb)],
                    '\x4d\x65\x43\x79\x46': function (_0x5b777a, _0x4b3672) {
                        return _0x5b777a(_0x4b3672);
                    },
                    '\x71\x6f\x61\x44\x49': function (_0x4b89d1, _0x2322c0) {
                        return _0x564dbb['\x76\x73\x73\x61\x7a'](_0x4b89d1, _0x2322c0);
                    },
                    '\x48\x4c\x5a\x52\x74': _0x438855(0x1c5)
                };
            _0x564dbb['\x69\x64\x78\x63\x62'](this[_0x438855(0x285)], ![]) || _0x564dbb[_0x438855(0x304)](this[_0x438855(0x285)], undefined) ? (this[_0x438855(0x32b)] = !![], this[_0x438855(0x224)] = ![], _0x564dbb[_0x438855(0x3af)](ChatRoomSendLocal, '\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x3a\x20\x52\x65\x61\x64\x79\x2e'), AwAutoKickOn = !![], AwAutoKicker = function (_0x1d67ca) {
                const _0xb355e = _0x438855, _0x15bca1 = {
                        '\x6c\x77\x59\x6b\x6d': function (_0x415018, _0x8db5b9) {
                            const _0x212171 = _0x5822;
                            return _0x52a584[_0x212171(0x2df)](_0x415018, _0x8db5b9);
                        }
                    };
                let _0x4ceeb5 = ChatRoomCharacter[_0xb355e(0x15f)](_0x138eb1 => _0x138eb1[_0xb355e(0x1e5)] === _0x1d67ca[_0xb355e(0x274)]);
                if (_0x52a584[_0xb355e(0x286)](_0x1d67ca['\x54\x79\x70\x65'], '\x41\x63\x74\x69\x6f\x6e') && (_0x1d67ca[_0xb355e(0x197)] == _0x52a584['\x65\x78\x62\x49\x50'] || _0x1d67ca[_0xb355e(0x197)] == _0x52a584[_0xb355e(0x2b7)])) {
                    if (_0x52a584[_0xb355e(0x2d1)](_0x52a584['\x59\x59\x71\x6d\x6b'], _0x52a584['\x41\x6c\x52\x56\x5a'])) {
                        const _0x2e94ec = {};
                        _0x2e94ec[_0xb355e(0x1e5)] = _0x4ceeb5[_0xb355e(0x1e5)], _0x2e94ec[_0xb355e(0x296)] = _0xb355e(0x2bd), _0x52a584[_0xb355e(0x42f)](ServerSend, _0x52a584['\x79\x6e\x63\x53\x53'], _0x2e94ec);
                    } else
                        this[_0xb355e(0x224)] = !![], _0x15bca1['\x6c\x77\x59\x6b\x6d'](_0x5aa5f7, _0xb355e(0x3bc));
                }
                ;
            }, ServerSocket['\x6f\x6e'](_0x564dbb[_0x438855(0x3c7)], AwAutoKicker), AwBotTrap = _0x564dbb[_0x438855(0x39b)], ChatRoomNotificationRaiseChatJoin = function (_0x9bdbed) {
                const _0x2bf0fa = _0x438855, _0x1f0ed6 = {
                        '\x62\x49\x68\x51\x43': function (_0x3b7418, _0x2bd8c1) {
                            const _0x123914 = _0x5822;
                            return _0x3e47b3[_0x123914(0x1ae)](_0x3b7418, _0x2bd8c1);
                        },
                        '\x54\x43\x79\x5a\x61': function (_0x335088, _0x12ec8c, _0xd9af90) {
                            return _0x3e47b3['\x54\x41\x53\x6e\x7a'](_0x335088, _0x12ec8c, _0xd9af90);
                        }
                    };
                if (_0x3e47b3[_0x2bf0fa(0x1dc)]('\x57\x59\x77\x63\x6f', _0x3e47b3[_0x2bf0fa(0x237)]))
                    return setTimeout(function () {
                        const _0x16407e = _0x2bf0fa, _0xdab85e = {
                                '\x54\x73\x4c\x70\x44': function (_0x5e053e, _0x547996) {
                                    const _0x364642 = _0x5822;
                                    return _0x3e47b3[_0x364642(0x18d)](_0x5e053e, _0x547996);
                                },
                                '\x49\x59\x6c\x78\x7a': _0x16407e(0x297),
                                '\x4b\x71\x4a\x70\x46': function (_0x3d1944, _0x2606fa, _0x4c65bb) {
                                    const _0x663b3c = _0x16407e;
                                    return _0x3e47b3[_0x663b3c(0x2da)](_0x3d1944, _0x2606fa, _0x4c65bb);
                                },
                                '\x53\x47\x49\x77\x6e': _0x3e47b3[_0x16407e(0x294)],
                                '\x78\x62\x4d\x49\x6d': _0x16407e(0x278),
                                '\x63\x5a\x46\x66\x4d': function (_0x1b6dac, _0xa19723) {
                                    return _0x1b6dac == _0xa19723;
                                },
                                '\x6b\x75\x6b\x78\x4e': function (_0x4cd09a, _0x50b739) {
                                    return _0x3e47b3['\x46\x7a\x55\x76\x55'](_0x4cd09a, _0x50b739);
                                },
                                '\x48\x79\x58\x7a\x69': _0x3e47b3['\x70\x63\x63\x4c\x41'],
                                '\x75\x4d\x6c\x7a\x6d': function (_0x5398bb, _0x4a3b8d) {
                                    const _0x57b1e3 = _0x16407e;
                                    return _0x3e47b3[_0x57b1e3(0x2e5)](_0x5398bb, _0x4a3b8d);
                                },
                                '\x4f\x4d\x6d\x43\x73': _0x3e47b3[_0x16407e(0x17c)],
                                '\x66\x45\x62\x67\x6c': function (_0x161b7e, _0x2ac265) {
                                    return _0x161b7e > _0x2ac265;
                                },
                                '\x42\x75\x55\x4d\x66': _0x3e47b3[_0x16407e(0x457)]
                            };
                        if (_0x3e47b3[_0x16407e(0x298)] === _0x3e47b3['\x46\x73\x4c\x68\x53'])
                            this['\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x5a\x68'] = !![], _0xdab85e[_0x16407e(0x43f)](_0x2216db, _0xdab85e[_0x16407e(0x483)]);
                        else {
                            if (AwBotTrap != _0x9bdbed['\x4e\x61\x6d\x65']) {
                                if (_0x3e47b3[_0x16407e(0x247)] !== _0x3e47b3['\x68\x54\x6f\x46\x62'])
                                    _0xfe8f04 = _0x101389[_0x16407e(0x2ca)][_0x16407e(0x2ce)];
                                else {
                                    AwBotTrap = _0x9bdbed[_0x16407e(0x1e3)];
                                    if (this[_0x16407e(0x224)])
                                        _0x9bdbed[_0x16407e(0x413)] = clipboard;
                                    else {
                                        let _0x5cc0f1 = [
                                            _0x3e47b3[_0x16407e(0x33a)],
                                            _0x16407e(0x1b1),
                                            _0x3e47b3['\x7a\x79\x51\x6b\x67'],
                                            _0x16407e(0x189),
                                            _0x3e47b3[_0x16407e(0x353)],
                                            _0x3e47b3[_0x16407e(0x322)],
                                            _0x3e47b3[_0x16407e(0x161)],
                                            _0x16407e(0x30c),
                                            _0x3e47b3[_0x16407e(0x42d)],
                                            '\x49\x74\x65\x6d\x48\x6f\x6f\x64',
                                            _0x3e47b3['\x4e\x4f\x77\x50\x44'],
                                            _0x3e47b3[_0x16407e(0x414)],
                                            '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68',
                                            _0x3e47b3[_0x16407e(0x214)],
                                            _0x16407e(0x2bf),
                                            _0x16407e(0x223),
                                            _0x3e47b3[_0x16407e(0x1d5)],
                                            _0x3e47b3[_0x16407e(0x18a)],
                                            _0x3e47b3[_0x16407e(0x244)],
                                            _0x3e47b3['\x47\x79\x56\x62\x77'],
                                            _0x3e47b3[_0x16407e(0x317)],
                                            _0x3e47b3[_0x16407e(0x2d7)],
                                            _0x3e47b3[_0x16407e(0x171)],
                                            _0x3e47b3[_0x16407e(0x2d2)],
                                            _0x16407e(0x2a7)
                                        ];
                                        _0x5cc0f1[_0x16407e(0x38f)](_0x5be19d => {
                                            InventoryWearRandom(_0x9bdbed, _0x5be19d, 0x697 * -0x67 + -0x1 * -0x23aaf + 0x22b64);
                                        }), _0x9bdbed[_0x16407e(0x413)]['\x66\x6f\x72\x45\x61\x63\x68'](_0x299301 => {
                                            const _0x37689b = _0x16407e;
                                            let _0x368ea7 = -0x114e + 0x4b5 * 0x2 + -0x1f9 * -0x4;
                                            _0x299301[_0x37689b(0x3e0)] > 0x1 * 0x69d + -0x5fd + -0xa0 && (_0xdab85e[_0x37689b(0x24b)](_0x299301['\x50\x72\x6f\x70\x65\x72\x74\x79'], null) && (_0x299301[_0x37689b(0x2ca)] = {}), _0x299301['\x50\x72\x6f\x70\x65\x72\x74\x79']['\x45\x66\x66\x65\x63\x74'] == null && (_0x299301[_0x37689b(0x2ca)][_0x37689b(0x403)] = []), _0xdab85e[_0x37689b(0x2ae)](_0x299301[_0x37689b(0x2ca)]['\x45\x66\x66\x65\x63\x74'][_0x37689b(0x2cf)](_0xdab85e[_0x37689b(0x28d)]), -0xd * -0x1a + 0x1 * 0x260b + -0x275d) && (_0xdab85e['\x75\x4d\x6c\x7a\x6d'](_0xdab85e[_0x37689b(0x2d8)], _0x37689b(0x37e)) ? _0x299301[_0x37689b(0x2ca)][_0x37689b(0x403)][_0x37689b(0x1b4)](_0xdab85e[_0x37689b(0x28d)]) : _0xf333b5(_0xdab85e[_0x37689b(0x23c)](_0x2635aa, _0xdab85e['\x53\x47\x49\x77\x6e'], _0xdab85e['\x78\x62\x4d\x49\x6d']), -0x111e * 0x2c + -0x2b5ee + -0x1f5 * -0x3c8, !![])), _0xdab85e['\x66\x45\x62\x67\x6c'](Math['\x72\x61\x6e\x64\x6f\x6d'](), -0x1 * 0x3a8 + -0x833 * 0x4 + -0x2474 * -0x1 + 0.5) ? _0x299301[_0x37689b(0x2ca)][_0x37689b(0x23d)] = _0x37689b(0x245) : _0x299301['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x37689b(0x23d)] = _0xdab85e['\x42\x75\x55\x4d\x66'], _0x299301[_0x37689b(0x2ca)][_0x37689b(0x318)] = Player[_0x37689b(0x1e5)], _0x9bdbed[_0x37689b(0x413)][_0x368ea7] = _0x299301), _0x368ea7++;
                                        }), _0x9bdbed[_0x16407e(0x481)]['\x50\x72\x6f\x67\x72\x65\x73\x73'] = -0x248b + -0x1c20 + -0x5e1 * -0xb;
                                    }
                                    _0x3e47b3[_0x16407e(0x18d)](ChatRoomCharacterUpdate, _0x9bdbed);
                                    if (this[_0x16407e(0x32b)]) {
                                        if ('\x4c\x4f\x6a\x67\x47' !== _0x3e47b3[_0x16407e(0x243)]) {
                                            const _0x2de314 = {};
                                            _0x2de314[_0x16407e(0x197)] = '\x61\x77\u9677\u9631\u5c4b\u89c4\u5219\x3a\x31\x2c\u5f53\u623f\u95f4\u88ab\u521b\u5efa\u65f6\x2c\u6211\u4eec\u4f1a\u5f00\u542f\u4e00\u4e2a\x31\x35\u5206\u949f\u7684\u5012\u8ba1\u65f6\x2e\x32\x2c\u5012\u8ba1\u65f6\u7ed3\u675f\u524d\x2c\u6240\u6709\u8fdb\u5165\u7684\u4eba\u90fd\u4f1a\u88ab\u6346\u7684\u6b7b\u6b7b\u7684\x3b\u4efb\u4f55\u5c1d\u8bd5\u8425\u6551\u7684\u4eba\u90fd\u4f1a\u88ab\u623f\u95f4\u5c01\u7981\x2e\x33\x2c\u5012\u8ba1\u65f6\u7ed3\u675f\u540e\x2c\u8fd9\u4e2a\u623f\u95f4\u5c31\u5b89\u5168\u4e86\x2e\u8def\u4eba\u5c31\u53ef\u4ee5\u8425\x28\x77\x61\x6e\x29\u6551\x28\x6e\x6f\x6e\x67\x29\u91cc\u9762\u7684\u5c0f\u53ef\u7231\u4eec\u4e86\u5462\x7e', _0x2de314[_0x16407e(0x459)] = '\x43\x68\x61\x74', _0x3e47b3[_0x16407e(0x2da)](ServerSend, '\x43\x68\x61\x74\x52\x6f\x6f\x6d\x43\x68\x61\x74', _0x2de314);
                                        } else
                                            _0x1a869b['\x44\x69\x66\x66\x69\x63\x75\x6c\x74\x79'][_0x16407e(0x2eb)] = -0x3 * -0xa22 + -0x1 * 0x1be8 + -0x27e;
                                    } else
                                        _0x3e47b3[_0x16407e(0x2da)](ServerSend, _0x3e47b3[_0x16407e(0x3e2)], {
                                            '\x43\x6f\x6e\x74\x65\x6e\x74': _0x3e47b3['\x64\x6d\x67\x70\x69'],
                                            '\x54\x79\x70\x65': _0x3e47b3[_0x16407e(0x2f8)]
                                        });
                                }
                            }
                        }
                    }, 0x732 + 0x16de + 0x2 * -0xd14), !![];
                else
                    _0x1f0ed6[_0x2bf0fa(0x369)](_0x35420d, _0x2bf0fa(0x282)), _0x1f0ed6[_0x2bf0fa(0x45d)](_0x1544ca, _0x5ce829, -0x23ca + -0x5 * 0x1f + -0x24c9 * -0x1);
            }) : (AwAutoKickOn = ![], ServerSocket[_0x438855(0x230)](_0x564dbb[_0x438855(0x3c7)], AwAutoKicker), _0x564dbb[_0x438855(0x1e6)](ChatRoomSendLocal, _0x564dbb['\x56\x51\x70\x6b\x50']), ChatRoomNotificationRaiseChatJoin = function (_0x23d58f) {
                return !![];
            });
        }), _0x564dbb['\x63\x71\x73\x4e\x44'](GM_registerMenuCommand, '\x61\x77\x42\x4f\x54\x5f\u5c01\u7981', () => {
            const _0xd7c65b = _0x4a0cf9, _0x31afe3 = {
                    '\x59\x49\x43\x78\x48': function (_0x1756ed, _0x44bb86) {
                        return _0x1756ed(_0x44bb86);
                    },
                    '\x6a\x6f\x44\x45\x7a': _0x52a584['\x68\x41\x53\x4b\x56']
                };
            if (_0x52a584['\x74\x67\x57\x69\x76'] === _0x52a584['\x74\x67\x57\x69\x76'])
                targetName = _0x52a584[_0xd7c65b(0x3e7)](prompt, _0x52a584['\x79\x6a\x4a\x4f\x58'], _0x52a584[_0xd7c65b(0x2c7)]), _0x52a584['\x4b\x4e\x66\x68\x70'](AwBotBan[_0xd7c65b(0x2cf)](targetName), -(-0x1 * 0x221b + -0x3 * 0x407 + -0x93d * -0x5)) && (_0x52a584['\x54\x52\x70\x6b\x48'](_0x52a584['\x46\x56\x72\x54\x67'], _0x52a584[_0xd7c65b(0x1be)]) ? _0x31afe3[_0xd7c65b(0x28a)](_0x1768ff, _0x31afe3['\x6a\x6f\x44\x45\x7a']) : _0x52a584[_0xd7c65b(0x370)](alert, _0x52a584[_0xd7c65b(0x488)])), AwBotBan[_0xd7c65b(0x1b4)](targetName);
            else
                return !![];
        }), _0x564dbb['\x6b\x4a\x49\x4d\x52'](GM_registerMenuCommand, '\x61\x77\x42\x4f\x54\x5f\u89e3\u5c01', () => {
            const _0x131dad = _0x4a0cf9, _0x33b106 = {};
            _0x33b106[_0x131dad(0x1c4)] = _0x52a584[_0x131dad(0x266)];
            const _0x51c3fe = _0x33b106;
            targetName = prompt(_0x52a584['\x69\x6c\x6c\x73\x50'], _0x52a584[_0x131dad(0x2c7)]), banIndex = AwBotBan[_0x131dad(0x2cf)](targetName), banIndex == -(-0x8c4 + 0x2 * -0xec6 + 0x2651) && (_0x52a584[_0x131dad(0x40d)](_0x52a584[_0x131dad(0x1b5)], _0x52a584['\x67\x4d\x7a\x4c\x4b']) ? _0xba9d10['\x50\x72\x6f\x70\x65\x72\x74\x79']['\x4c\x6f\x63\x6b\x65\x64\x42\x79'] = _0x51c3fe[_0x131dad(0x1c4)] : _0x52a584[_0x131dad(0x38e)](alert, _0x52a584[_0x131dad(0x478)])), AwBotBan[_0x131dad(0x35a)](banIndex, 0xe91 + -0x11 * -0x1ac + -0x2afc);
        }), _0x564dbb['\x78\x74\x4d\x4a\x69'](GM_registerMenuCommand, _0x4a0cf9(0x32d), () => {
            const _0x4963ad = {
                '\x51\x4f\x58\x5a\x47': function (_0x4973d9, _0x18c938, _0x4576a4) {
                    const _0x3007a5 = _0x5822;
                    return _0x52a584[_0x3007a5(0x38d)](_0x4973d9, _0x18c938, _0x4576a4);
                },
                '\x57\x4d\x75\x4a\x78': function (_0x8b5917, _0x391cdf) {
                    const _0x4e78d3 = _0x5822;
                    return _0x52a584[_0x4e78d3(0x449)](_0x8b5917, _0x391cdf);
                },
                '\x4d\x61\x4d\x73\x68': function (_0x3ef36f, _0x32b7be) {
                    const _0x129036 = _0x5822;
                    return _0x52a584[_0x129036(0x24c)](_0x3ef36f, _0x32b7be);
                }
            };
            SpeechGarble = function (_0x30357a, _0x50b245, _0x5d6bfe) {
                const _0x5689c7 = _0x5822;
                let _0x59e221 = _0x50b245, _0x4ba220 = _0x4963ad[_0x5689c7(0x43e)](SpeechGetTotalGagLevel, _0x30357a, _0x5d6bfe);
                return _0x4ba220 > -0x124a + -0x1e9 * -0xe + -0x874 && (_0x59e221 = _0x4963ad[_0x5689c7(0x290)](_0x4963ad[_0x5689c7(0x209)](_0x5689c7(0x252) + _0x4ba220, '\x20'), _0x59e221)), _0x59e221;
            };
        }), GM_registerMenuCommand(_0x564dbb[_0x4a0cf9(0x2c4)], () => {
            const _0x4f827e = _0x4a0cf9;
            clipboard = CurrentCharacter[_0x4f827e(0x413)];
        }), GM_registerMenuCommand(_0x564dbb[_0x4a0cf9(0x41c)], () => {
            const _0xcd6ad5 = _0x4a0cf9;
            CurrentCharacter['\x41\x70\x70\x65\x61\x72\x61\x6e\x63\x65'] = clipboard, _0x564dbb[_0xcd6ad5(0x275)](ChatRoomCharacterUpdate, CurrentCharacter);
        }), _0x564dbb[_0x4a0cf9(0x3d6)](GM_registerMenuCommand, _0x4a0cf9(0x1b7), () => {
            const _0x287db8 = _0x4a0cf9;
            _0x52a584[_0x287db8(0x406)](InventoryWear, targetMember, _0x52a584[_0x287db8(0x2f7)], _0x52a584[_0x287db8(0x458)]);
        }), GM_registerMenuCommand(_0x564dbb[_0x4a0cf9(0x2c8)], () => {
            const _0x40f185 = _0x4a0cf9;
            alert(_0x52a584[_0x40f185(0x434)]), _0x52a584[_0x40f185(0x22f)](CharacterChangeMoney, Player, 0x6 * -0x601 + 0x21dd * 0x1 + 0x28d);
        }), GM_registerMenuCommand(_0x564dbb['\x65\x41\x6e\x6a\x64'], () => {
            const _0x4024ec = _0x4a0cf9, _0x35a0ae = {};
            _0x35a0ae[_0x4024ec(0x3e1)] = _0x52a584[_0x4024ec(0x196)];
            const _0x4641ef = _0x35a0ae;
            if (_0x52a584['\x76\x61\x65\x6f\x71'](_0x52a584[_0x4024ec(0x22a)], _0x4024ec(0x172))) {
                if (_0x52a584['\x55\x70\x52\x43\x50'](CurrentScreen, _0x52a584[_0x4024ec(0x16d)])) {
                    const _0x509838 = _0x4024ec(0x2cd)[_0x4024ec(0x309)]('\x7c');
                    let _0x2d32f6 = -0x1adc + -0x1 * -0x20ee + -0x612;
                    while (!![]) {
                        switch (_0x509838[_0x2d32f6++]) {
                        case '\x30':
                            CommonSetScreen(_0x52a584[_0x4024ec(0x443)], _0x52a584[_0x4024ec(0x233)]);
                            continue;
                        case '\x31':
                            ChatRoomSetLastChatRoom('');
                            continue;
                        case '\x32':
                            ChatSearchExit();
                            continue;
                        case '\x33':
                            CharacterDeleteAllOnline();
                            continue;
                        case '\x34':
                            ChatRoomClearAllElements();
                            continue;
                        case '\x35':
                            ChatRoomLeashPlayer = null;
                            continue;
                        case '\x36':
                            ServerSend(_0x52a584[_0x4024ec(0x295)], '');
                            continue;
                        case '\x37':
                            DialogLentLockpicks = ![];
                            continue;
                        }
                        break;
                    }
                } else
                    _0x52a584['\x43\x49\x78\x78\x50'](MainHallWalk, _0x52a584['\x6e\x77\x48\x68\x46']);
            } else
                _0x547afe['\x70\x75\x73\x68'](_0x4f673e[_0x4024ec(0x1e3)]), _0xfea358 = _0x4641ef[_0x4024ec(0x3e1)];
        }), GM_registerMenuCommand(_0x4a0cf9(0x3ef), () => {
            StruggleProgress = 0x14f7 + -0x1bb6 + 0x73c;
        }), _0x564dbb['\x56\x6b\x6c\x5a\x42'](GM_registerMenuCommand, _0x564dbb[_0x4a0cf9(0x1de)], () => {
            const _0x483ae3 = _0x4a0cf9;
            SkillProgress(_0x52a584[_0x483ae3(0x3f2)], 0x2896f + 0x30867 + -0x3d284);
        }), _0x564dbb['\x6c\x62\x49\x61\x49'](GM_registerMenuCommand, _0x564dbb[_0x4a0cf9(0x1ce)], () => {
            const _0x4b0c52 = _0x4a0cf9;
            _0x52a584[_0x4b0c52(0x222)](_0x52a584[_0x4b0c52(0x36c)], _0x52a584[_0x4b0c52(0x36c)]) ? _0x52a584[_0x4b0c52(0x385)](_0x58988c, _0x4b0c52(0x440), -0x2e227 * -0x1 + -0x1dea3 * -0x1 + 0x1 * -0x30178) : _0x52a584[_0x4b0c52(0x385)](SkillProgress, _0x52a584[_0x4b0c52(0x32a)], -0x15f30 + -0x2e154 + -0x2ffeb * -0x2);
        }), GM_registerMenuCommand(_0x564dbb[_0x4a0cf9(0x420)], () => {
            const _0x436f8e = _0x4a0cf9;
            _0x564dbb['\x6d\x6e\x6b\x4b\x43'](SkillProgress, _0x564dbb[_0x436f8e(0x41e)], -0x1d338 + -0x1ea46 + 0x57cd0);
        }), GM_registerMenuCommand(_0x564dbb[_0x4a0cf9(0x39e)], () => {
            const _0x2340c1 = _0x4a0cf9;
            _0x564dbb[_0x2340c1(0x3a7)](_0x2340c1(0x461), _0x2340c1(0x461)) ? _0x564dbb[_0x2340c1(0x28e)](SkillProgress, '\x45\x76\x61\x73\x69\x6f\x6e', -0x9 * 0x1b95 + -0x2 * -0x8e90 + 0x1 * 0x19a6f) : _0x3b8db4[_0x2340c1(0x2ca)][_0x2340c1(0x23d)] = '\x4d\x69\x73\x74\x72\x65\x73\x73\x50\x61\x64\x6c\x6f\x63\x6b';
        }), GM_registerMenuCommand(_0x564dbb['\x52\x51\x78\x6e\x4f'], () => {
            const _0x490377 = _0x4a0cf9;
            Player[_0x490377(0x3e0)][_0x490377(0x2eb)] = -0x1dc9 + 0xee1 + 0x35 * 0x48;
        }), _0x564dbb[_0x4a0cf9(0x3d8)](GM_registerMenuCommand, _0x564dbb['\x72\x55\x6f\x5a\x4b'], () => {
            const _0x5ef740 = _0x4a0cf9;
            _0x52a584['\x43\x55\x62\x61\x78'](SkillProgress, _0x52a584[_0x5ef740(0x364)], -0x5 * 0x9a6d + -0x14c34 + -0x60fa7 * -0x1);
        }), GM_registerMenuCommand(_0x564dbb[_0x4a0cf9(0x336)], () => {
            const _0x2c0ab5 = _0x4a0cf9;
            _0x564dbb['\x75\x65\x57\x71\x51'] !== _0x564dbb['\x75\x65\x57\x71\x51'] ? _0x565e4d['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x2c0ab5(0x23d)] = _0x2c0ab5(0x441) : SkillProgress(_0x564dbb[_0x2c0ab5(0x382)], -0xb85c + 0x3671e + 0x9fa * -0x18);
        }), _0x564dbb[_0x4a0cf9(0x367)](GM_registerMenuCommand, _0x564dbb[_0x4a0cf9(0x46d)], () => {
            const _0x3c0dca = _0x4a0cf9;
            _0x564dbb[_0x3c0dca(0x2b9)](SkillProgress, _0x564dbb['\x62\x51\x68\x58\x67'], -0xe5b0 + -0x7243 * -0x4 + 0xdbf6);
        }), _0x564dbb[_0x4a0cf9(0x27f)](GM_registerMenuCommand, _0x4a0cf9(0x1a3), () => {
            const _0x2d33c7 = _0x4a0cf9, _0x34b5e7 = {};
            _0x34b5e7[_0x2d33c7(0x22d)] = _0x564dbb['\x4d\x43\x6b\x55\x75'];
            const _0x2a1352 = _0x34b5e7;
            if (_0x564dbb[_0x2d33c7(0x3b3)](_0x564dbb[_0x2d33c7(0x411)], _0x564dbb[_0x2d33c7(0x1bc)])) {
                const _0x5dc439 = _0x564dbb[_0x2d33c7(0x1bf)][_0x2d33c7(0x309)]('\x7c');
                let _0xbf6f0a = 0x1 * -0x1759 + -0x120f + 0x2968;
                while (!![]) {
                    switch (_0x5dc439[_0xbf6f0a++]) {
                    case '\x30':
                        _0x564dbb['\x75\x77\x76\x57\x6a'](InventoryWear, Player, _0x564dbb[_0x2d33c7(0x176)], _0x564dbb[_0x2d33c7(0x43d)], _0x564dbb[_0x2d33c7(0x1fa)], 0xf337 + 0xb * -0x3391 + 0x30356);
                        continue;
                    case '\x31':
                        _0x564dbb[_0x2d33c7(0x2bb)](InventoryWear, Player, _0x564dbb['\x47\x45\x62\x76\x6b'], _0x564dbb[_0x2d33c7(0x1ac)], _0x564dbb[_0x2d33c7(0x1fa)], 0x1508b + 0x3f89 + -0x1 * -0x2f3e);
                        continue;
                    case '\x32':
                        _0x564dbb[_0x2d33c7(0x41b)](InventoryWear, Player, _0x564dbb[_0x2d33c7(0x276)], _0x564dbb[_0x2d33c7(0x2f6)], _0x564dbb[_0x2d33c7(0x1fa)], -0x1 * -0x11d35 + 0x30c7c + -0x26a5f);
                        continue;
                    case '\x33':
                        _0x564dbb[_0x2d33c7(0x21a)](InventoryWear, Player, _0x564dbb[_0x2d33c7(0x19f)], _0x564dbb['\x69\x6c\x6b\x44\x57'], _0x2d33c7(0x17f), -0x29b5e + -0xe219 + 0x1c87 * 0x2f);
                        continue;
                    case '\x34':
                        _0x564dbb[_0x2d33c7(0x2bb)](InventoryWear, Player, _0x564dbb[_0x2d33c7(0x272)], _0x564dbb[_0x2d33c7(0x45c)], _0x564dbb['\x4d\x71\x6d\x6e\x70'], 0x2c2ab + -0x2f93 * -0xa + 0x33d * -0xe3);
                        continue;
                    case '\x35':
                        _0x564dbb[_0x2d33c7(0x21a)](InventoryWear, Player, _0x564dbb[_0x2d33c7(0x47a)], _0x564dbb[_0x2d33c7(0x1c2)], _0x564dbb[_0x2d33c7(0x1fa)], 0x1d247 + 0x626 * -0x1d + 0x9f59);
                        continue;
                    case '\x36':
                        _0x564dbb[_0x2d33c7(0x2fc)](InventoryWear, Player, _0x564dbb[_0x2d33c7(0x2b4)], _0x564dbb[_0x2d33c7(0x3d3)], _0x564dbb[_0x2d33c7(0x1fa)], 0x31d36 + 0x7 * 0x2a29 + -0x28503);
                        continue;
                    case '\x37':
                        InventoryWear(Player, _0x2d33c7(0x362), _0x564dbb['\x53\x52\x67\x49\x6e'], _0x564dbb[_0x2d33c7(0x1fa)], -0x710f * -0x2 + 0x33e7e * -0x1 + 0xe * 0x4b1f);
                        continue;
                    case '\x38':
                        _0x564dbb['\x58\x72\x6e\x46\x59'](InventoryWear, Player, _0x564dbb[_0x2d33c7(0x225)], _0x564dbb['\x58\x47\x6b\x43\x58'], _0x564dbb[_0x2d33c7(0x1fa)], 0x1968b + -0x1799c + 0x1a263);
                        continue;
                    }
                    break;
                }
            } else
                _0x6b8c67[_0x2d33c7(0x2ca)][_0x2d33c7(0x403)][_0x2d33c7(0x1b4)](_0x2a1352['\x4d\x6c\x52\x6e\x76']);
        }), GM_registerMenuCommand(_0x564dbb[_0x4a0cf9(0x20a)], () => {
            const _0x57110c = _0x4a0cf9;
            _0x564dbb['\x79\x53\x4d\x66\x65'](_0x564dbb[_0x57110c(0x409)], _0x564dbb['\x56\x43\x7a\x44\x78']) ? _0x3bb058[_0x57110c(0x2ca)] = {} : _0x564dbb[_0x57110c(0x27e)](InventoryWear, Player, _0x564dbb[_0x57110c(0x1f7)], _0x564dbb[_0x57110c(0x312)]);
        }), GM_registerMenuCommand(_0x4a0cf9(0x2ac), () => {
            CharacterReleaseTotal(Player);
        }), _0x564dbb[_0x4a0cf9(0x398)](GM_registerMenuCommand, '\u58f0\u97f3\u6d2a\u4eae\x28\u8bf4\u4ec0\u4e48\u5c31\u662f\u4ec0\u4e48\x29', () => {
            const _0x3560be = _0x4a0cf9;
            _0x564dbb[_0x3560be(0x20d)] !== _0x564dbb[_0x3560be(0x20d)] ? _0x1fc656[_0x3560be(0x2ca)][_0x3560be(0x403)] = [] : _0x564dbb[_0x3560be(0x3d1)](ServerSend, _0x564dbb['\x4d\x6c\x70\x68\x6c'], {
                '\x43\x6f\x6e\x74\x65\x6e\x74': _0x564dbb[_0x3560be(0x447)],
                '\x54\x79\x70\x65': _0x564dbb[_0x3560be(0x3fa)],
                '\x44\x69\x63\x74\x69\x6f\x6e\x61\x72\x79': [{
                        '\x54\x61\x67': '\x42\x65\x65\x70',
                        '\x54\x65\x78\x74': _0x564dbb[_0x3560be(0x28e)](prompt, _0x3560be(0x18c), _0x564dbb[_0x3560be(0x2a9)])
                    }]
            });
        }), _0x564dbb['\x54\x6e\x57\x74\x6d'](GM_registerMenuCommand, _0x564dbb[_0x4a0cf9(0x2c9)], () => {
            const _0x2e8419 = _0x4a0cf9;
            if (_0x52a584[_0x2e8419(0x2d1)](_0x2e8419(0x37b), _0x52a584[_0x2e8419(0x47f)])) {
                targetName = _0x52a584[_0x2e8419(0x2f9)](prompt, _0x52a584['\x57\x52\x4d\x76\x6a'], _0x2e8419(0x3b0)), targetMember = Character[_0x2e8419(0x15f)](_0x2dd8b7 => _0x2dd8b7[_0x2e8419(0x1e3)]['\x74\x6f\x4c\x6f\x77\x65\x72\x43\x61\x73\x65']() == targetName);
                if (_0x52a584[_0x2e8419(0x3d4)](targetMember, null)) {
                    if (_0x52a584[_0x2e8419(0x46e)](_0x52a584[_0x2e8419(0x3e8)], _0x2e8419(0x1b2)))
                        return;
                    else
                        return;
                }
                _0x52a584[_0x2e8419(0x370)](CharacterReleaseTotal, targetMember), targetMember['\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73'][_0x2e8419(0x45b)] = 0x1d * 0x11b + -0x1e57 + -0x1b8, _0x52a584[_0x2e8419(0x326)](ChatRoomCharacterUpdate, targetMember);
            } else
                _0x55a83e[_0x2e8419(0x2ca)][_0x2e8419(0x23d)] = _0x52a584['\x56\x77\x53\x6a\x4a'];
        }), _0x564dbb[_0x4a0cf9(0x428)](GM_registerMenuCommand, _0x564dbb['\x6e\x76\x64\x77\x52'], () => {
            const _0x92fb79 = _0x4a0cf9, _0x56c834 = _0x52a584[_0x92fb79(0x3e5)][_0x92fb79(0x309)]('\x7c');
            let _0x1d5b82 = 0x145f + -0x2bb * -0x5 + -0x1103 * 0x2;
            while (!![]) {
                switch (_0x56c834[_0x1d5b82++]) {
                case '\x30':
                    _0x52a584[_0x92fb79(0x1f5)](InventoryWear, targetMember, '\x49\x72\x69\x73\x68\x38\x43\x75\x66\x66\x73', _0x92fb79(0x207), _0x52a584['\x6f\x4c\x54\x58\x54'], 0x1ebdf + 0x334d + -0x1 * 0x5fda);
                    continue;
                case '\x31':
                    targetMember[_0x92fb79(0x481)][_0x92fb79(0x45b)] = -0x22e + -0x8f3 * -0x4 + 0x296 * -0xd;
                    continue;
                case '\x32':
                    targetName = _0x52a584['\x56\x78\x70\x4c\x6e'](prompt, _0x52a584[_0x92fb79(0x18e)], _0x52a584[_0x92fb79(0x2c7)]);
                    continue;
                case '\x33':
                    ChatRoomCharacterUpdate(targetMember);
                    continue;
                case '\x34':
                    _0x52a584['\x57\x6c\x77\x74\x5a'](InventoryWear, targetMember, _0x52a584['\x4f\x78\x54\x4c\x46'], _0x52a584[_0x92fb79(0x256)], _0x52a584[_0x92fb79(0x352)], 0x131fd + 0x1124 * 0x17 + 0xfce7 * -0x1);
                    continue;
                case '\x35':
                    targetMember = Character[_0x92fb79(0x15f)](_0x307412 => _0x307412[_0x92fb79(0x1e3)][_0x92fb79(0x164)]() == targetName);
                    continue;
                case '\x36':
                    if (targetMember == null)
                        return;
                    continue;
                }
                break;
            }
        }), _0x564dbb[_0x4a0cf9(0x25e)](GM_registerMenuCommand, _0x564dbb[_0x4a0cf9(0x444)], () => {
            const _0x335802 = _0x4a0cf9, _0x2f622c = {
                    '\x4b\x74\x79\x6b\x72': function (_0xf6c2cd, _0x25aa05) {
                        return _0xf6c2cd(_0x25aa05);
                    },
                    '\x70\x6e\x50\x44\x64': _0x335802(0x192),
                    '\x6c\x75\x52\x63\x72': _0x52a584[_0x335802(0x351)]
                };
            targetName = prompt(_0x52a584['\x43\x67\x48\x4d\x61'], _0x52a584['\x51\x41\x75\x57\x52']), targetMember = Character[_0x335802(0x15f)](_0x6f2008 => _0x6f2008['\x4e\x61\x6d\x65'][_0x335802(0x164)]() == targetName);
            if (targetMember == null) {
                if (_0x52a584['\x6d\x66\x49\x54\x79'] === _0x52a584[_0x335802(0x228)])
                    return;
                else
                    this[_0x335802(0x224)] = ![], _0x2f622c[_0x335802(0x1ff)](_0x3c006d, _0x335802(0x198));
            }
            var _0x1eebde = _0x52a584[_0x335802(0x439)](parseInt, _0x52a584['\x53\x47\x53\x6a\x61'](prompt, _0x52a584[_0x335802(0x460)], _0x52a584['\x49\x50\x6e\x61\x6b']));
            targetMember['\x41\x70\x70\x65\x61\x72\x61\x6e\x63\x65'][_0x335802(0x38f)](_0x15dfe1 => {
                const _0x4f3ceb = _0x335802, _0x51a8bc = {
                        '\x6a\x6d\x62\x7a\x6a': function (_0x7ff532, _0x27e93e, _0x127e8b, _0x286763) {
                            return _0x7ff532(_0x27e93e, _0x127e8b, _0x286763);
                        },
                        '\x57\x79\x54\x51\x50': function (_0x3c9098, _0x163efd) {
                            const _0x181985 = _0x5822;
                            return _0x52a584[_0x181985(0x2d4)](_0x3c9098, _0x163efd);
                        },
                        '\x58\x57\x52\x68\x62': _0x4f3ceb(0x29c)
                    };
                if (_0x52a584[_0x4f3ceb(0x450)] !== _0x52a584[_0x4f3ceb(0x388)]) {
                    let _0x30a369 = -0x3 * 0x8ab + 0xd05 + 0xcfc;
                    if (_0x15dfe1[_0x4f3ceb(0x3e0)] > -0x1400 + -0x1 * 0x2445 + 0x3845) {
                        if (_0x52a584['\x75\x61\x4b\x43\x73'] !== _0x52a584['\x4e\x70\x56\x74\x6c'])
                            _0x52a584['\x71\x6b\x55\x52\x6d'](_0x15dfe1['\x50\x72\x6f\x70\x65\x72\x74\x79'], null) && (_0x52a584[_0x4f3ceb(0x1d7)](_0x52a584[_0x4f3ceb(0x3ad)], _0x4f3ceb(0x216)) ? _0x3e56d1[_0x4f3ceb(0x2ca)][_0x4f3ceb(0x23d)] = '\x4d\x69\x73\x74\x72\x65\x73\x73\x50\x61\x64\x6c\x6f\x63\x6b' : _0x15dfe1['\x50\x72\x6f\x70\x65\x72\x74\x79'] = {}), _0x52a584['\x51\x50\x7a\x65\x62'](_0x15dfe1[_0x4f3ceb(0x2ca)][_0x4f3ceb(0x403)], null) && (_0x52a584['\x74\x4e\x54\x49\x6d'](_0x52a584[_0x4f3ceb(0x3cb)], _0x52a584['\x43\x57\x54\x5a\x47']) ? _0x15dfe1[_0x4f3ceb(0x2ca)][_0x4f3ceb(0x403)] = [] : _0x51a8bc[_0x4f3ceb(0x368)](_0x536d58, _0x2d15d2, _0xaba4c2, 0x2 * -0x12a27 + -0x2f207 + 0x705a7)), _0x52a584[_0x4f3ceb(0x3f0)](_0x15dfe1['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x4f3ceb(0x403)]['\x69\x6e\x64\x65\x78\x4f\x66'](_0x52a584[_0x4f3ceb(0x351)]), -0x11ae + -0x1c5f + 0x2e0d) && (_0x52a584[_0x4f3ceb(0x378)](_0x4f3ceb(0x277), _0x4f3ceb(0x277)) ? _0x2693e7(_0x2f622c[_0x4f3ceb(0x17a)], -0x1 * 0x217db + -0x4 * -0x49df + 0x2afb1) : _0x15dfe1[_0x4f3ceb(0x2ca)][_0x4f3ceb(0x403)][_0x4f3ceb(0x1b4)](_0x4f3ceb(0x217))), Math[_0x4f3ceb(0x201)]() > 0x199 * -0x2 + 0x1 * 0x9d5 + -0x6a3 + 0.5 ? _0x15dfe1['\x50\x72\x6f\x70\x65\x72\x74\x79'][_0x4f3ceb(0x23d)] = _0x52a584['\x56\x77\x53\x6a\x4a'] : _0x15dfe1[_0x4f3ceb(0x2ca)][_0x4f3ceb(0x23d)] = _0x52a584[_0x4f3ceb(0x266)], _0x15dfe1[_0x4f3ceb(0x2ca)]['\x4c\x6f\x63\x6b\x4d\x65\x6d\x62\x65\x72\x4e\x75\x6d\x62\x65\x72'] = _0x1eebde, targetMember['\x41\x70\x70\x65\x61\x72\x61\x6e\x63\x65'][_0x30a369] = _0x15dfe1;
                        else {
                            _0x51a8bc[_0x4f3ceb(0x2b6)](_0x184970, _0x51a8bc[_0x4f3ceb(0x2c0)]);
                            return;
                        }
                    }
                    _0x30a369++;
                } else
                    _0x48abe7[_0x4f3ceb(0x2ca)][_0x4f3ceb(0x403)][_0x4f3ceb(0x1b4)](_0x2f622c[_0x4f3ceb(0x1af)]);
            }), targetMember['\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73'][_0x335802(0x45b)] = -0x1fc0 + 0x123 * -0x1c + -0x3f94 * -0x1, _0x52a584[_0x335802(0x163)](ChatRoomCharacterUpdate, targetMember);
        }), _0x564dbb[_0x4a0cf9(0x23b)](GM_registerMenuCommand, _0x564dbb[_0x4a0cf9(0x3bf)], () => {
            const _0x5139ab = _0x4a0cf9;
            _0x5139ab(0x33e) === _0x564dbb[_0x5139ab(0x1e9)] ? _0x52a584['\x4a\x65\x6d\x71\x55'](_0x505ce0, _0x5963fb) : _0x564dbb[_0x5139ab(0x323)](ReputationChange, _0x564dbb[_0x5139ab(0x287)](prompt, '\u81ea\u5df1\u5220\u6389\u4e0d\u5bf9\u7684\x2c\x20\u8f93\u9519\u4e86\u540e\u679c\u81ea\u8d1f\x21', _0x564dbb[_0x5139ab(0x405)]), -0x3a07 + 0x30007 + -0x106ae, !![]);
        });
    });
}()));
function _0x5822(_0x582260, _0x2d8e3f) {
    const _0x1e8cd2 = _0x29a0();
    return _0x5822 = function (_0x4300a2, _0x38f590) {
        _0x4300a2 = _0x4300a2 - (-0x2 * -0x607 + -0x7f * 0x27 + 0x8a2);
        let _0x3d3853 = _0x1e8cd2[_0x4300a2];
        return _0x3d3853;
    }, _0x5822(_0x582260, _0x2d8e3f);
}
function _0x29a0() {
    const _0x36319a = [
        '\x71\x6b\x55\x52\x6d',
        '\x6e\x54\x72\x76\x6e',
        '\x42\x75\x57\x78\x48',
        '\x6f\x50\x65\x51\x49',
        '\x4d\x45\x77\x53\x6d',
        '\x79\x4e\x45\x50\x4e',
        '\x42\x6f\x75\x6e\x74\x79\x53\x75\x69\x74\x63\x61\x73\x65',
        '\x49\x72\x69\x73\x68\x38\x43\x75\x66\x66\x73',
        '\x58\x67\x47\x45\x4f',
        '\x31\x36\x39\x37\x36\x39\x75\x59\x77\x75\x4b\x77',
        '\x49\x4e\x68\x74\x76',
        '\u8981\u6346\u7684\u73a9\u5bb6\u540d\u79f0\x28\u5168\u5c0f\u5199\x29',
        '\x44\x69\x66\x66\x69\x63\x75\x6c\x74\x79',
        '\x7a\x51\x73\x63\x54',
        '\x78\x53\x74\x68\x7a',
        '\x55\x61\x43\x54\x54',
        '\x65\x72\x72\x6f\x72',
        '\x49\x5a\x67\x70\x53',
        '\x4f\x6e\x5a\x63\x51',
        '\x52\x53\x4b\x54\x61',
        '\x61\x63\x78\x78\x70',
        '\x67\x42\x68\x74\x44',
        '\x6a\x63\x41\x5a\x6a',
        '\x41\x73\x20\x75\x20\x77\x69\x73\x68\x7e\x28\x4d\x61\x6b\x65\x20\x73\x75\x72\x65\x20\x75\x20\x72\x20\x6e\x6f\x74\x20\x6f\x77\x6e\x65\x72\x2f\x6c\x6f\x76\x65\x72\x20\x6c\x6f\x63\x6b\x65\x64\x20\x26\x20\x68\x61\x76\x65\x20\x70\x65\x72\x6d\x69\x74\x74\x65\x64\x20\x6d\x65\x29',
        '\x45\x41\x4c\x68\x58',
        '\x4c\x78\x6c\x63\x72',
        '\x70\x6c\x61\x79\x73\x75\x69\x74',
        '\u529b\u5927\u65e0\u7a77\x28\u77ac\u95f4\u6323\u8131\x29',
        '\x6f\x6f\x53\x41\x6d',
        '\x57\x69\x66\x66\x6c\x65\x47\x61\x67',
        '\x66\x72\x65\x4e\x51',
        '\x78\x67\x58\x70\x4b',
        '\x67\x6f\x78\x4c\x41',
        '\x73\x4c\x50\x67\x61',
        '\x45\x74\x74\x47\x48',
        '\x55\x63\x47\x74\x79',
        '\x41\x4b\x49\x4e\x72',
        '\x42\x4f\x54\u81ea\u79f0',
        '\x76\x4c\x71\x53\x48',
        '\x65\x78\x63\x65\x70\x74\x69\x6f\x6e',
        '\x75\x6e\x6b\x6e\x6f\x77\x6e',
        '\x65\x79\x4a\x44\x75',
        '\x54\x56\x42\x54\x4f',
        '\x54\x61\x62\x79\x4a',
        '\x72\x65\x74\x75\x72\x6e\x20\x28\x66\x75\x6e\x63\x74\x69\x6f\x6e\x28\x29\x20',
        '\x48\x69\x57\x46\x66',
        '\x4f\x6e\x6c\x69\x6e\x65',
        '\x45\x66\x66\x65\x63\x74',
        '\x49\x4f\x50\x41\x64',
        '\x58\x62\x4a\x4a\x79',
        '\x4d\x74\x75\x79\x55',
        '\u63d0\u5347\u786c\u6491\u7b49\u7ea7',
        '\x58\x4a\x76\x64\x69',
        '\x56\x43\x7a\x44\x78',
        '\x44\x45\x56\x54\x5a',
        '\x41\x68\x51\x6d\x48',
        '\x76\x72\x69\x6c\x6b',
        '\x54\x52\x70\x6b\x48',
        '\x6f\x71\x71\x69\x54',
        '\x51\x50\x58\x64\x68',
        '\x49\x74\x65\x6d\x4e\x6f\x73\x65',
        '\x7a\x6e\x68\x43\x68',
        '\x47\x62\x68\x68\x6b',
        '\x41\x70\x70\x65\x61\x72\x61\x6e\x63\x65',
        '\x74\x5a\x58\x41\x56',
        '\x4d\x49\x4a\x6e\x6b',
        '\x43\x68\x61\x74\x52\x6f\x6f\x6d\x4c\x65\x61\x76\x65',
        '\x41\x73\x73\x65\x74',
        '\x6c\x51\x66\x75\x49',
        '\x64\x73\x6a\x72\x45',
        '\x49\x4c\x69\x4c\x4f',
        '\x75\x64\x79\x45\x61',
        '\x5a\x53\x4a\x74\x53',
        '\x4e\x76\x71\x41\x78',
        '\x6d\x77\x52\x50\x71',
        '\x6a\x5a\x69\x42\x72',
        '\x63\x4c\x65\x45\x59',
        '\x75\x79\x74\x55\x76',
        '\x5a\x6f\x78\x53\x44',
        '\x66\x7a\x79\x73\x66',
        '\x6d\x6d\x44\x46\x47',
        '\x4a\x64\x70\x72\x6a',
        '\x68\x75\x72\x42\x4d',
        '\x48\x65\x6c\x6c\x6f',
        '\x6b\x4a\x49\x4d\x52',
        '\x51\x46\x48\x73\x56',
        '\x69\x4f\x4d\x45\x69',
        '\x53\x75\x78\x66\x50',
        '\u7b11\x7e\x20\x28\u5e38\u89c1\u95ee\u9898\x3a\u8bf7\u5f00\u6743\u9650\x29\x7e',
        '\x48\x6a\x65\x41\x41',
        '\x6e\x5a\x62\x64\x6f',
        '\x41\x55\x79\x68\x66',
        '\x66\x79\x42\x64\x69',
        '\x4c\x65\x61\x74\x68\x65\x72\x41\x72\x6d\x62\x69\x6e\x64\x65\x72',
        '\x77\x44\x64\x79\x75',
        '\x47\x6e\x4e\x66\x55',
        '\x6b\x67\x55\x56\x59',
        '\x73\x47\x4e\x56\x57',
        '\x4f\x45\x72\x59\x4d',
        '\x61\x4e\x62\x69\x49',
        '\x54\x41\x65\x62\x54',
        '\x44\x52\x51\x6f\x75',
        '\x70\x4d\x54\x41\x54',
        '\x43\x74\x54\x53\x75',
        '\x43\x6d\x5a\x6e\x6d',
        '\x4b\x43\x72\x67\x4e',
        '\x51\x4f\x58\x5a\x47',
        '\x54\x73\x4c\x70\x44',
        '\x57\x69\x6c\x6c\x70\x6f\x77\x65\x72',
        '\x50\x61\x6e\x64\x6f\x72\x61\x50\x61\x64\x6c\x6f\x63\x6b',
        '\x49\x74\x65\x6d\x42\x72\x65\x61\x73\x74',
        '\x46\x6b\x45\x4d\x57',
        '\x6a\x6e\x74\x50\x72',
        '\x68\x52\x70\x52\x77',
        '\x52\x4d\x57\x6c\x6a',
        '\x77\x66\x52\x58\x4d',
        '\x41\x63\x74\x69\x6f\x6e\x55\x6e\x6c\x6f\x63\x6b\x41\x6e\x64\x52\x65\x6d\x6f\x76\x65',
        '\x67\x66\x72\x58\x6a',
        '\x46\x51\x58\x74\x69',
        '\x78\x4c\x79\x4a\x52',
        '\x49\x79\x7a\x6e\x66',
        '\x51\x4c\x6f\x61\x51',
        '\x63\x6c\x6b\x6a\x67',
        '\x4d\x59\x44\x4a\x54',
        '\x47\x71\x6f\x48\x6f',
        '\x59\x67\x72\x6a\x77',
        '\x63\x73\x53\x77\x6b',
        '\x71\x42\x79\x65\x65',
        '\x32\x7c\x33\x7c\x30\x7c\x34\x7c\x31',
        '\u901f\u901f\u7ed1\u7f1a\x28\u641e\u4e8b\u60c5\u4e13\u7528\x29',
        '\x66\x77\x4f\x72\x69',
        '\x61\x6e\x6f\x65\x4b',
        '\x54\x7a\x6b\x77\x65',
        '\x54\x79\x70\x65',
        '\x67\x44\x73\x6c\x52',
        '\x50\x72\x6f\x67\x72\x65\x73\x73',
        '\x73\x76\x52\x78\x48',
        '\x54\x43\x79\x5a\x61',
        '\x50\x42\x6b\x43\x7a',
        '\x4e\x46\x68\x51\x7a',
        '\x69\x44\x76\x68\x51',
        '\x6b\x4f\x61\x69\x6b',
        '\x63\x43\x74\x67\x4e',
        '\x6d\x45\x4b\x54\x46',
        '\x52\x63\x77\x58\x65',
        '\x58\x75\x4c\x43\x55',
        '\x43\x6f\x6c\x6c\x61\x72\x43\x68\x61\x69\x6e\x4c\x6f\x6e\x67',
        '\x41\x73\x20\x75\x20\x77\x69\x73\x68\x7e\x28\x47\x6f\x6f\x64\x20\x6c\x75\x63\x6b\x21\x29',
        '\x47\x69\x43\x69\x65',
        '\x4c\x42\x51\x68\x57',
        '\x49\x74\x65\x6d\x45\x61\x72\x73',
        '\x7a\x6e\x53\x62\x4f',
        '\x4d\x48\x64\x68\x66',
        '\x4a\x66\x56\x6d\x52',
        '\x66\x59\x50\x50\x55',
        '\x69\x4f\x6d\x41\x78',
        '\x72\x50\x45\x73\x68',
        '\x72\x4c\x41\x43\x72',
        '\x4f\x55\x49\x6b\x6a',
        '\x42\x67\x53\x51\x4f',
        '\x49\x74\x65\x6d\x44\x65\x76\x69\x63\x65\x73',
        '\x71\x57\x71\x50\x6d',
        '\u672a\u77e5\u6307\u4ee4\uff01\x20\u53ef\u7528\u6307\u4ee4\x3a\x20\u6346\u6211\x20\u6346\u6b7b\u6211\x20\u8214\u6211\x20\u6551\u6211\x20\u73a9\u6211\x20\u9501\u6211\x20\u5173\u4e8e\x20\u5982\u679c\u4e00\u53e5\u8bdd\u540c\u65f6\u5305\u542b\x27',
        '\x49\x74\x65\x6d\x4e\x69\x70\x70\x6c\x65\x73',
        '\x46\x43\x53\x69\x7a',
        '\x44\x77\x4f\x4f\x72',
        '\x4e\x56\x70\x6b\x70',
        '\u8981\u5c01\u7981\u7684\u73a9\u5bb6\u540d\u79f0',
        '\x6f\x4a\x77\x6a\x52',
        '\x41\x56\x61\x4b\x4d',
        '\x68\x53\x58\x61\x77',
        '\x73\x69\x72\x52\x49',
        '\x50\x77\x59\x43\x43',
        '\x41\x72\x6f\x75\x73\x61\x6c\x53\x65\x74\x74\x69\x6e\x67\x73',
        '\x72\x6c\x42\x49\x52',
        '\x49\x59\x6c\x78\x7a',
        '\x6b\x53\x4e\x78\x6e',
        '\x61\x77\x54\x52\x41\x50\x20\x52\x75\x6c\x65\x73\x3a\x31\x2c\x57\x68\x65\x6e\x20\x74\x68\x65\x20\x72\x6f\x6f\x6d\x20\x77\x61\x73\x20\x63\x72\x65\x61\x74\x65\x64\x2c\x61\x20\x74\x69\x6d\x65\x72\x20\x77\x61\x73\x20\x73\x65\x74\x20\x74\x6f\x20\x31\x35\x20\x6d\x69\x6e\x73\x2e\x32\x2c\x42\x65\x66\x6f\x72\x65\x20\x74\x68\x65\x20\x74\x69\x6d\x65\x72\x20\x72\x75\x6e\x73\x20\x6f\x75\x74\x2c\x61\x6e\x79\x6f\x6e\x65\x20\x77\x68\x6f\x20\x63\x6f\x6d\x65\x73\x20\x69\x6e\x74\x6f\x20\x74\x68\x69\x73\x20\x72\x6f\x6f\x6d\x20\x77\x69\x6c\x6c\x20\x67\x65\x74\x20\x74\x72\x61\x70\x70\x65\x64\x2e\x33\x2c\x42\x65\x66\x72\x6f\x65\x20\x74\x68\x65\x20\x74\x69\x6d\x65\x72\x20\x72\x75\x6e\x73\x20\x6f\x75\x74\x2c\x61\x6e\x79\x6f\x6e\x65\x20\x77\x68\x6f\x20\x61\x74\x74\x65\x6d\x70\x74\x73\x20\x74\x6f\x20\x72\x65\x73\x63\x75\x65\x20\x77\x69\x6c\x6c\x20\x62\x65\x20\x62\x61\x6e\x6e\x65\x64\x2e\x34\x2c\x41\x66\x74\x65\x72\x20\x74\x68\x65\x20\x74\x69\x6d\x65\x72\x20\x72\x75\x6e\x73\x20\x6f\x75\x74\x2c\x20\x61\x77\x54\x52\x41\x50\x20\x77\x69\x6c\x6c\x20\x62\x65\x20\x73\x61\x66\x65\x2e\x54\x68\x6f\x73\x65\x20\x77\x68\x6f\x20\x61\x72\x65\x20\x74\x72\x61\x70\x70\x65\x64\x20\x63\x61\x6e\x20\x70\x6c\x65\x61\x64\x20\x70\x61\x73\x73\x65\x72\x2d\x62\x79\x73\x20\x66\x6f\x72\x20\x68\x65\x6c\x70\x20\x74\x68\x65\x6e\x2e',
        '\x7a\x75\x59\x43\x75',
        '\x37\x39\x34\x36\x38\x33\x34\x4c\x6d\x52\x50\x6d\x41',
        '\x68\x41\x53\x4b\x56',
        '\x79\x59\x57\x6f\x66',
        '\x6d\x65\x6f\x77\x7e\x28\x4d\x61\x6b\x65\x20\x73\x75\x72\x65\x20\x75\x20\x68\x61\x76\x65\x20\x70\x65\x72\x6d\x69\x74\x74\x65\x64\x20\x6d\x65\x29',
        '\x73\x56\x46\x78\x4e',
        '\x43\x51\x5a\x46\x77',
        '\x6a\x6e\x65\x44\x64',
        '\x76\x64\x59\x47\x64',
        '\x41\x69\x53\x70\x7a',
        '\x4b\x41\x4f\x41\x57',
        '\x61\x4b\x75\x45\x65',
        '\x66\x69\x6e\x64',
        '\x63\x61\x75\x57\x46',
        '\x6c\x76\x51\x6d\x6b',
        '\x4b\x41\x4f\x58\x4b',
        '\x65\x50\x41\x6f\x4d',
        '\x74\x6f\x4c\x6f\x77\x65\x72\x43\x61\x73\x65',
        '\x53\x4a\x59\x68\x4d',
        '\x52\x4d\x59\x51\x66',
        '\x71\x6f\x47\x6b\x4f',
        '\x6a\x78\x41\x71\x79',
        '\x70\x72\x6f\x74\x6f\x74\x79\x70\x65',
        '\x55\x56\x46\x49\x67',
        '\x48\x43\x7a\x54\x67',
        '\x73\x71\x76\x53\x71',
        '\x67\x50\x4c\x64\x72',
        '\x57\x77\x46\x4c\x43',
        '\x55\x49\x7a\x78\x7a',
        '\x61\x77\x42\x4f\x54\x20\x43\x61\x53\x65\x20\x53\x65\x4e\x73\x49\x74\x49\x76\x45\x21',
        '\x71\x54\x61\x44\x70',
        '\x5a\x75\x45\x4b\x56',
        '\x4f\x42\x4a\x4b\x6c',
        '\x72\x65\x6c\x65\x61\x73\x65',
        '\x4e\x59\x51\x68\x62',
        '\x4b\x49\x73\x5a\x47',
        '\x77\x75\x56\x58\x66',
        '\x6c\x6a\x6a\x6f\x4a',
        '\x44\x5a\x45\x44\x57',
        '\x70\x6e\x50\x44\x64',
        '\x6e\x6f\x6e\x65',
        '\x48\x76\x5a\x7a\x47',
        '\x4f\x75\x59\x46\x42',
        '\x47\x75\x6d\x57\x4e',
        '\x23\x32\x30\x32\x30\x32\x30',
        '\x4f\x6d\x7a\x69\x70',
        '\x78\x57\x49\x63\x44',
        '\x4b\x49\x41\x4e\x50',
        '\x69\x74\x62\x48\x56',
        '\x6c\x69\x63\x6b\x73\x20',
        '\x53\x52\x67\x49\x6e',
        '\x62\x78\x5a\x4b\x45',
        '\x72\x70\x74\x74\x48',
        '\x50\x4d\x42\x4f\x72',
        '\x49\x74\x65\x6d\x42\x75\x74\x74',
        '\x45\x79\x58\x4f\x51',
        '\u62ff\u7bb1\u5b50',
        '\u4f60\u8981\u8bf4\u7684\u8bdd',
        '\x4e\x51\x75\x75\x62',
        '\x4e\x43\x65\x52\x75',
        '\x49\x4d\x48\x4a\x4e',
        '\x46\x66\x44\x41\x6d',
        '\x4d\x4b\x42\x70\x52',
        '\x45\x76\x61\x73\x69\x6f\x6e',
        '\x70\x49\x52\x70\x42',
        '\x76\x41\x58\x66\x47',
        '\x56\x42\x56\x58\x49',
        '\x45\x43\x5a\x73\x61',
        '\x43\x6f\x6e\x74\x65\x6e\x74',
        '\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x3a\x20\u968f\u673a\x2e',
        '\x53\x44\x77\x72\x6c',
        '\x55\x77\x71\x4b\x6d',
        '\x42\x73\x76\x65\x76',
        '\x63\x6c\x75\x62\x73\x6c\x61\x76\x65',
        '\x79\x53\x69\x7a\x67',
        '\x62\x72\x53\x71\x67',
        '\x71\x52\x43\x54\x55',
        '\x58\x78\x77\x6a\x73',
        '\x73\x58\x4b\x74\x61',
        '\x27\u548c\u6307\u4ee4\uff0c\u6307\u4ee4\u5c31\u4f1a\u88ab\u6267\u884c\x7e',
        '\u901f\u901f\u81ea\u7f1a',
        '\x77\x61\x72\x6e',
        '\x68\x53\x79\x4c\x4c',
        '\x6f\x55\x42\x6d\x6a',
        '\x61\x77\x71',
        '\x45\x6c\x46\x4a\x46',
        '\x49\x45\x4d\x61\x79',
        '\x68\x65\x68\x50\x64',
        '\x56\x77\x53\x6a\x4a',
        '\x6f\x7a\x64\x49\x48',
        '\x77\x58\x4b\x6f\x59',
        '\x4d\x65\x43\x79\x46',
        '\x6c\x75\x52\x63\x72',
        '\u5982\u4f60\u6240\u613f\x20\x28\u5e38\u89c1\u95ee\u9898\x3a\u4e0d\u89e3\u4e3b\u4eba\x2f\u604b\u4eba\x2c\u8bf7\u5f00\u6743\u9650\x29\x7e',
        '\x49\x74\x65\x6d\x42\x6f\x6f\x74\x73',
        '\x70\x6f\x59\x72\x66',
        '\u63d0\u5347\u7740\u88c5\u7b49\u7ea7',
        '\x70\x75\x73\x68',
        '\x67\x4d\x7a\x4c\x4b',
        '\x63\x6f\x6e\x73\x6f\x6c\x65',
        '\u83b7\u53d6\u7bb1\u5b50',
        '\x55\x74\x77\x65\x43',
        '\x6c\x4c\x73\x56\x47',
        '\x79\x74\x50\x76\x4b',
        '\x52\x68\x5a\x6e\x73',
        '\x46\x78\x42\x6b\x4c',
        '\x4b\x74\x58\x66\x67',
        '\x46\x56\x72\x54\x67',
        '\x45\x4c\x66\x69\x4d',
        '\x70\x61\x4b\x4e\x62',
        '\x76\x4d\x47\x72\x75',
        '\x57\x4b\x45\x4a\x65',
        '\x68\x43\x76\x72\x67',
        '\x6b\x66\x47\x57\x57',
        '\x44\x42\x4b\x56\x4b',
        '\x72\x4d\x42\x6f\x55',
        '\x7a\x69\x46\x54\x45',
        '\x6b\x58\x4c\x6d\x6d',
        '\x74\x6f\x53\x74\x72\x69\x6e\x67',
        '\x71\x4c\x6a\x55\x66',
        '\x4d\x4d\x42\x67\x62',
        '\x72\x56\x57\x4b\x59',
        '\x53\x57\x49\x52\x45',
        '\x4f\x69\x7a\x55\x70',
        '\x42\x68\x6e\x62\x76',
        '\x50\x65\x48\x62\x78',
        '\x45\x62\x6a\x71\x4e',
        '\x6a\x73\x6a\x6a\x64',
        '\x51\x78\x63\x76\x56',
        '\x6f\x42\x42\x6d\x69',
        '\x45\x55\x4e\x55\x78',
        '\x73\x75\x70\x62\x62',
        '\x44\x44\x6d\x59\x74',
        '\x61\x4a\x58\x75\x52',
        '\x67\x53\x47\x44\x4c',
        '\x63\x6f\x6e\x73\x74\x72\x75\x63\x74\x6f\x72',
        '\x65\x4f\x68\x4d\x6f',
        '\x71\x6f\x61\x44\x49',
        '\x50\x57\x77\x7a\x4f',
        '\x43\x46\x64\x58\x62',
        '\u79fb\u9664\u6781\u9650\x43\x44\x28\u5fc5\u987b\u65b0\u5207\x52\x50\u540e\u7528\x29',
        '\x6c\x71\x62\x4b\x58',
        '\x76\x4f\x56\x49\x4a',
        '\x63\x44\x67\x6e\x51',
        '\x4e\x61\x6d\x65',
        '\x78\x62\x56\x42\x73',
        '\x4d\x65\x6d\x62\x65\x72\x4e\x75\x6d\x62\x65\x72',
        '\x77\x6d\x44\x4e\x77',
        '\x47\x45\x62\x76\x6b',
        '\x52\x56\x68\x6f\x62',
        '\x64\x78\x43\x76\x67',
        '\x6a\x63\x59\x77\x4c',
        '\x64\x67\x4c\x48\x43',
        '\x5a\x62\x55\x62\x6c',
        '\x6f\x79\x76\x6f\x6d',
        '\x75\x72\x63\x66\x79',
        '\u8981\u89e3\u9501\u7684\u73a9\u5bb6\u540d\u79f0\x28\u5168\u5c0f\u5199\x29',
        '\x4c\x57\x4d\x56\x6b',
        '\x41\x68\x6b\x6d\x49',
        '\x47\x72\x6f\x75\x70',
        '\x5a\x65\x77\x42\x69',
        '\x7a\x59\x6b\x73\x74',
        '\x57\x6c\x77\x74\x5a',
        '\x42\x4f\x4f\x4c\x75',
        '\x6c\x69\x44\x75\x71',
        '\x42\x70\x74\x76\x73',
        '\u526a\u5207\u677f\x5f\u7c98\u8d34\u5230\u5f53\u524d\u9009\u62e9\u89d2\u8272',
        '\x4d\x71\x6d\x6e\x70',
        '\x49\x74\x65\x6d\x56\x75\x6c\x76\x61',
        '\x49\x6e\x72\x6c\x53',
        '\x57\x4d\x69\x74\x6e',
        '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68\x32',
        '\x4b\x74\x79\x6b\x72',
        '\x44\x53\x7a\x47\x50',
        '\x72\x61\x6e\x64\x6f\x6d',
        '\x46\x61\x6d\x5a\x6f',
        '\x73\x49\x4c\x77\x4a',
        '\x42\x43\x58\x4d\x73\x67',
        '\x73\x44\x4f\x5a\x69',
        '\x58\x69\x46\x43\x70',
        '\x49\x74\x65\x6d\x46\x65\x65\x74',
        '\x54\x6b\x46\x42\x4a',
        '\x4d\x61\x4d\x73\x68',
        '\x71\x49\x4a\x4c\x6b',
        '\x72\x79\x57\x5a\x41',
        '\x6e\x6d\x77\x74\x77',
        '\x58\x4b\x6d\x67\x62',
        '\x61\x77\x42\x4f\x54',
        '\x42\x4f\x54\u6307\u4ee4\u8bcd',
        '\x68\x57\x5a\x6b\x58',
        '\x6e\x54\x44\x4a\x6b',
        '\x43\x6f\x6d\x62\x69\x6e\x61\x74\x69\x6f\x6e\x4e\x75\x6d\x62\x65\x72',
        '\x47\x63\x6b\x53\x4e',
        '\x41\x6b\x62\x42\x68',
        '\x4e\x4d\x67\x74\x79',
        '\x6f\x4f\x62\x76\x79',
        '\x4c\x6f\x63\x6b',
        '\x49\x4e\x51\x64\x56',
        '\x6f\x42\x70\x44\x58',
        '\x42\x69\x58\x73\x4c',
        '\x79\x6c\x62\x43\x54',
        '\x4d\x4f\x48\x45\x4e',
        '\x49\x61\x67\x71\x57',
        '\x54\x47\x50\x61\x52',
        '\x43\x68\x61\x74',
        '\x6f\x46\x43\x6c\x44',
        '\x6d\x6e\x6b\x4b\x43',
        '\x72\x61\x44\x6d\x46',
        '\x49\x74\x65\x6d\x4e\x65\x63\x6b',
        '\x41\x77\x50\x61\x73\x74\x65',
        '\x7a\x4c\x44\x5a\x51',
        '\x6e\x5a\x75\x66\x41',
        '\x77\x5a\x53\x42\x59',
        '\x6d\x66\x49\x54\x79',
        '\x42\x52\x70\x4e\x59',
        '\x51\x6e\x74\x4c\x79',
        '\x45\x6e\x71\x45\x64',
        '\x55\x44\x6d\x41\x63',
        '\x4d\x6c\x52\x6e\x76',
        '\x49\x4d\x46\x6d\x63',
        '\x73\x50\x57\x62\x43',
        '\x6f\x66\x66',
        '\x6c\x42\x45\x72\x68',
        '\x6c\x57\x67\x4d\x4c',
        '\x59\x64\x75\x58\x73',
        '\x69\x43\x72\x45\x62',
        '\x72\x41\x73\x66\x4c',
        '\x62\x53\x44\x59\x6c',
        '\x48\x4c\x5a\x52\x74',
        '\x50\x50\x69\x62\x4b',
        '\x62\x69\x6e\x64',
        '\x74\x43\x6a\x45\x61',
        '\x73\x69\x4e\x47\x68',
        '\x4b\x71\x4a\x70\x46',
        '\x4c\x6f\x63\x6b\x65\x64\x42\x79',
        '\x4d\x6d\x63\x72\x64',
        '\x50\x4f\x4e\x64\x46',
        '\x76\x51\x52\x55\x4a',
        '\x42\x50\x58\x53\x6f',
        '\x70\x4d\x65\x6e\x57',
        '\x64\x4a\x70\x47\x73',
        '\x66\x5a\x79\x4e\x53',
        '\x4d\x69\x73\x74\x72\x65\x73\x73\x50\x61\x64\x6c\x6f\x63\x6b',
        '\x55\x76\x6a\x74\x78',
        '\x68\x54\x6f\x46\x62',
        '\x49\x74\x65\x6d\x54\x6f\x72\x73\x6f',
        '\x58\x47\x6b\x43\x58',
        '\x79\x6f\x5a\x62\x77',
        '\x63\x5a\x46\x66\x4d',
        '\x4f\x6b\x6d\x4e\x72',
        '\x67\x71\x63\x63\x64',
        '\x76\x31\x2e\x30\x37\x20\x62\x79\x20\x41\x77\u9171\x20\u5728\x61\x77\x61\x71\x77\x71\u7684\u4e2a\u4eba\u7b80\u4ecb\u91cc\u9762\u6709\u4e0b\u8f7d\u94fe\u63a5\u7684\u8bf4\x7e',
        '\x63\x68\x61\x6f\x73',
        '\x41\x53\x68\x49\x57',
        '\x7b\x7d\x2e\x63\x6f\x6e\x73\x74\x72\x75\x63\x74\x6f\x72\x28\x22\x72\x65\x74\x75\x72\x6e\x20\x74\x68\x69\x73\x22\x29\x28\x20\x29',
        '\u53e3\u7403\x6c\x76',
        '\x73\x58\x68\x46\x41',
        '\x6d\x54\x43\x4a\x73',
        '\x6e\x58\x66\x77\x72',
        '\x64\x76\x44\x77\x6c',
        '\x77\x49\x44\x61\x79',
        '\x4c\x53\x43\x73\x72',
        '\x78\x75\x48\x75\x45',
        '\x70\x72\x58\x44\x67',
        '\x64\x58\x6c\x4c\x4d',
        '\x70\x56\x47\x66\x52',
        '\x34\x32\x31\x36\x35\x30\x34\x4b\x65\x47\x7a\x4b\x56',
        '\x56\x6b\x6c\x5a\x42',
        '\x4d\x6c\x70\x68\x6c',
        '\x6e\x4e\x58\x79\x4f',
        '\x6d\x6b\x6c\x79\x77',
        '\x51\x4c\x69\x6d\x74',
        '\x64\x6c\x62\x74\x6e',
        '\x57\x46\x6c\x79\x65',
        '\x67\x70\x52\x74\x57',
        '\x58\x66\x6f\x53\x46',
        '\u526a\u5207\u677f\x5f\u4ece\u5f53\u524d\u9009\u62e9\u89d2\u8272\u590d\u5236',
        '\x53\x6e\x68\x58\x79',
        '\x49\x74\x65\x6d\x41\x72\x6d\x73',
        '\x68\x75\x61\x67\x71',
        '\x6b\x72\x71\x64\x6b',
        '\x4b\x62\x46\x76\x4c',
        '\x64\x47\x74\x6a\x44',
        '\u5927\u7b11\x7e\x20\x28\u987a\u624b\u62d6\u5165\u5c01\u7981\u540d\u5355\x29\x7e',
        '\x57\x79\x62\x70\x56',
        '\x49\x74\x50\x7a\x75',
        '\x6d\x4c\x64\x6d\x52',
        '\x56\x4a\x62\x59\x4c',
        '\x58\x50\x54\x77\x49',
        '\x53\x65\x6e\x64\x65\x72',
        '\x6c\x76\x6c\x51\x50',
        '\x63\x58\x51\x42\x66',
        '\x56\x4a\x71\x7a\x55',
        '\x44\x6f\x6d\x69\x6e\x61\x6e\x74\x20\x20\x4b\x69\x64\x6e\x61\x70\x20\x20\x41\x42\x44\x4c\x20\x20\x47\x61\x6d\x69\x6e\x67\x20\x20\x4d\x61\x69\x64\x20\x20\x4c\x41\x52\x50\x20\x20\x41\x73\x79\x6c\x75\x6d\x20\x20\x47\x61\x6d\x62\x6c\x69\x6e\x67\x20\x20\x48\x6f\x75\x73\x65\x4d\x61\x69\x65\x73\x74\x61\x73\x20\x20\x48\x6f\x75\x73\x65\x56\x69\x6e\x63\x75\x6c\x61\x20\x20\x48\x6f\x75\x73\x65\x41\x6d\x70\x6c\x65\x63\x74\x6f\x72\x20\x20\x48\x6f\x75\x73\x65\x43\x6f\x72\x70\x6f\x72\x69\x73',
        '\x6f\x42\x6b\x6b\x78',
        '\x74\x56\x79\x65\x43',
        '\x45\x4d\x64\x44\x53',
        '\x53\x45\x73\x77\x59',
        '\x7a\x71\x6c\x43\x6b',
        '\x55\x6c\x43\x6d\x41',
        '\x78\x74\x4d\x4a\x69',
        '\x6e\x77\x48\x68\x46',
        '\x61\x77\u9171',
        '\x53\x63\x72\x69\x70\x74\x20\x6d\x61\x64\x65\x20\x62\x79\x3a\x61\x77\x61\x71\x77\x71\x5f\x68\x75\x7a\x70\x73\x62',
        '\x6f\x67\x76\x76\x63',
        '\x4b\x51\x58\x4c\x6f',
        '\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x4f\x6e',
        '\x55\x70\x52\x43\x50',
        '\x44\x52\x5a\x73\x78',
        '\x62\x64\x75\x70\x43',
        '\x41\x76\x6d\x57\x74',
        '\x59\x49\x43\x78\x48',
        '\x31\x39\x30\x39\x38\x49\x54\x57\x71\x6d\x55',
        '\x4e\x52\x4d\x5a\x6e',
        '\x48\x79\x58\x7a\x69',
        '\x45\x49\x6a\x51\x4e',
        '\u5982\u4f60\u6240\u613f\x20\x28\u5e38\u89c1\u95ee\u9898\x3a\u8bf7\u5f00\u6743\u9650\x29\x7e',
        '\x57\x4d\x75\x4a\x78',
        '\u8981\u89e3\u5c01\u7684\u73a9\u5bb6\u540d\u79f0',
        '\x43\x49\x78\x78\x50',
        '\x46\x69\x49\x79\x71',
        '\x53\x6e\x67\x6c\x42',
        '\x5a\x68\x76\x6f\x56',
        '\x41\x63\x74\x69\x6f\x6e',
        '\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x3a\x20\u4e2d\u6587\x2e',
        '\x48\x4c\x79\x59\x72',
        '\x6b\x66\x47\x72\x48',
        '\x79\x44\x6d\x73\x49',
        '\x65\x79\x57\x55\x59',
        '\u4f60\u5fc5\u987b\u662f\x61\x77\x61\x71\x77\x71\u7684\x73\x75\x62\u624d\u80fd\u8fd9\u4e48\u505a\u5462\x7e',
        '\x59\x4a\x4a\x41\x4f',
        '\x49\x74\x65\x6d\x4d\x69\x73\x63',
        '\x61\x77\x61\x71\x77\x71\x20\x69\x73\x20\x68\x75\x7a\x70\x73\x62',
        '\x49\x74\x65\x6d\x50\x65\x6c\x76\x69\x73',
        '\x6f\x41\x74\x4b\x4f',
        '\x58\x49\x50\x48\x66',
        '\x57\x52\x70\x48\x62',
        '\x55\x42\x70\x70\x7a',
        '\x4d\x61\x69\x6e\x48\x61\x6c\x6c',
        '\u63d0\u5347\u6346\u7ed1\u7b49\u7ea7',
        '\x49\x74\x65\x6d\x56\x75\x6c\x76\x61\x50\x69\x65\x72\x63\x69\x6e\x67\x73',
        '\x76\x31\x2e\x30\x37\x20\x62\x79\x20\x68\x75\x7a\x70\x73\x62\x20\x2f\x20\x53\x72\x63\x20\x77\x69\x6c\x6c\x20\x62\x65\x20\x6f\x6e\x20\x67\x69\x74\x68\x75\x62\x20\x73\x6f\x6f\x6e',
        '\x61\x49\x72\x53\x4c',
        '\x57\x77\x77\x45\x4c',
        '\x73\x6a\x78\x42\x49',
        '\u963f\u62c9\u970d\u6d1e\u5f00',
        '\x63\x4e\x4f\x52\x62',
        '\x6b\x75\x6b\x78\x4e',
        '\x54\x53\x58\x44\x62',
        '\x46\x48\x64\x54\x4d',
        '\x45\x49\x79\x43\x44',
        '\x43\x59\x7a\x64\x63',
        '\x64\x73\x6a\x76\x4a',
        '\x56\x6d\x44\x6e\x4b',
        '\x6b\x46\x63\x44\x58',
        '\x57\x79\x54\x51\x50',
        '\x75\x4e\x6f\x68\x55',
        '\x4b\x47\x76\x6a\x6e',
        '\x48\x44\x78\x4b\x43',
        '\x6d\x47\x4b\x48\x4b',
        '\x75\x77\x76\x57\x6a',
        '\x45\x41\x7a\x68\x6f',
        '\x42\x61\x6e',
        '\x53\x4a\x6d\x71\x74',
        '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68\x33',
        '\x58\x57\x52\x68\x62',
        '\x72\x57\x61\x66\x67',
        '\x6c\x54\x56\x46\x62',
        '\x38\x39\x34\x54\x6b\x46\x59\x66\x65',
        '\x65\x4e\x4f\x7a\x52',
        '\x46\x49\x51\x6b\x63',
        '\x65\x48\x61\x61\x45',
        '\x51\x41\x75\x57\x52',
        '\x6e\x78\x66\x6f\x44',
        '\x55\x64\x6a\x70\x5a',
        '\x50\x72\x6f\x70\x65\x72\x74\x79',
        '\x72\x4b\x44\x4a\x4e',
        '\x75\x6a\x77\x50\x56',
        '\x37\x7c\x34\x7c\x36\x7c\x31\x7c\x35\x7c\x30\x7c\x33\x7c\x32',
        '\x50\x61\x73\x73\x77\x6f\x72\x64',
        '\x69\x6e\x64\x65\x78\x4f\x66',
        '\x6f\x78\x6c\x43\x55',
        '\x74\x4e\x54\x49\x6d',
        '\x42\x6e\x66\x57\x53',
        '\x6b\x72\x4e\x4c\x65',
        '\x69\x69\x66\x6c\x68',
        '\x47\x61\x72\x55\x51',
        '\x6d\x6c\x68\x6b\x52',
        '\x74\x6e\x65\x58\x73',
        '\x4f\x4d\x6d\x43\x73',
        '\x57\x73\x6c\x56\x51',
        '\x54\x41\x53\x6e\x7a',
        '\x76\x73\x73\x61\x7a',
        '\x4c\x6f\x63\x6b\x50\x69\x63\x6b\x69\x6e\x67',
        '\x6c\x49\x5a\x6f\x4b',
        '\u63d0\u5347\u6323\u624e\u7b49\u7ea7',
        '\x4d\x41\x68\x79\x62',
        '\x61\x66\x71\x51\x53',
        '\x53\x4b\x51\x4f\x55',
        '\x68\x65\x6c\x6c\x6f',
        '\x61\x77\x42\x4f\x54\x20\u62b1\u6b49\x2c\u60a8\u5df2\u7ecf\u88ab\u5c01\u7981\u3002',
        '\x68\x53\x76\x74\x6e',
        '\x73\x74\x79\x58\x75',
        '\u8981\u4e0a\u9501\u7684\u73a9\u5bb6\u540d\u79f0\x28\u5168\u5c0f\u5199\x29',
        '\x6d\x68\x4d\x46\x45',
        '\x79\x53\x4d\x66\x65',
        '\x54\x4b\x4a\x57\x55',
        '\x64\x68\x67\x72\x64',
        '\x4c\x61\x73\x74\x43\x68\x61\x6e\x67\x65',
        '\x68\x67\x48\x74\x73',
        '\x58\x64\x75\x64\x59',
        '\x42\x65\x65\x70',
        '\x71\x73\x49\x62\x4d',
        '\x74\x61\x62\x6c\x65',
        '\x66\x69\x63\x75\x78',
        '\x45\x4c\x4b\x62\x46',
        '\x70\x58\x51\x77\x79',
        '\x30\x7c\x32\x7c\x31\x7c\x34\x7c\x33',
        '\x76\x78\x51\x71\x4e',
        '\x75\x61\x4b\x6b\x42',
        '\x64\x75\x52\x71\x49',
        '\x6a\x68\x62\x42\x72',
        '\x43\x55\x62\x61\x78',
        '\x6a\x77\x65\x55\x6f',
        '\x53\x65\x6c\x66\x42\x6f\x6e\x64\x61\x67\x65',
        '\x70\x6a\x70\x58\x58',
        '\x32\x7c\x35\x7c\x36\x7c\x34\x7c\x30\x7c\x31\x7c\x33',
        '\x78\x77\x78\x6b\x4f',
        '\x4a\x71\x69\x58\x74',
        '\u95e8\u94a5\u5319',
        '\x5a\x56\x6e\x6c\x58',
        '\x78\x6f\x54\x47\x62',
        '\x4b\x4d\x6e\x61\x46',
        '\x4f\x76\x6c\x5a\x58',
        '\x4c\x65\x61\x74\x68\x65\x72\x42\x65\x6c\x74',
        '\x70\x77\x4f\x65\x78',
        '\x6b\x48\x57\x59\x7a',
        '\x6e\x4d\x55\x62\x6b',
        '\x73\x70\x6c\x69\x74',
        '\x20\x3d\x3e\x20',
        '\x73\x66\x79\x4d\x48',
        '\x49\x74\x65\x6d\x48\x61\x6e\x64\x73',
        '\x47\x49\x4e\x6c\x6b',
        '\x68\x4f\x62\x73\x4d',
        '\x70\x43\x44\x57\x6b',
        '\x78\x4c\x68\x79\x56',
        '\x52\x68\x64\x65\x53',
        '\x62\x58\x59\x61\x47',
        '\x6c\x48\x4a\x49\x4b',
        '\x56\x6f\x4d\x77\x5a',
        '\x69\x64\x76\x6c\x7a',
        '\x43\x74\x6f\x56\x66',
        '\x4c\x54\x47\x49\x4b',
        '\x4c\x6f\x63\x6b\x4d\x65\x6d\x62\x65\x72\x4e\x75\x6d\x62\x65\x72',
        '\x6c\x6f\x67',
        '\x53\x51\x78\x44\x69',
        '\x49\x74\x65\x6d\x4e\x69\x70\x70\x6c\x65\x73\x50\x69\x65\x72\x63\x69\x6e\x67\x73',
        '\x77\x53\x4e\x76\x58',
        '\x42\x48\x49\x58\x59',
        '\x61\x77\x42\x4f\x54\x20',
        '\x49\x6e\x76\x65\x6e\x74\x6f\x72\x79',
        '\x42\x59\x72\x42\x4a',
        '\x4d\x70\x53\x53\x46',
        '\x78\x6e\x46\x7a\x56',
        '\x4b\x78\x53\x65\x4e',
        '\x4c\x59\x64\x50\x72',
        '\x39\x6f\x54\x78\x54\x68\x65',
        '\x43\x57\x49\x6e\x53',
        '\x58\x50\x66\x6b\x7a',
        '\x77\x6c\x4f\x6e\x6d',
        '\x53\x66\x45\x48\x51',
        '\x70\x77\x62\x67\x65',
        '\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x5a\x68',
        '\x45\x7a\x77\x67\x6b',
        '\u53e3\u7403\u7834\u8bd1',
        '\x54\x68\x7a\x57\x44',
        '\x74\x4b\x44\x76\x64',
        '\x78\x4e\x54\x71\x6b',
        '\x59\x4e\x63\x45\x4a',
        '\x68\x47\x53\x6a\x64',
        '\x49\x70\x76\x75\x68',
        '\x42\x69\x74\x63\x68\x53\x75\x69\x74',
        '\u63d0\u5347\u5185\u9b3c\u7b49\u7ea7',
        '\x75\x6b\x4d\x45\x4c',
        '\x48\x4c\x48\x57\x68',
        '\x43\x6a\x62\x64\x76',
        '\x4f\x77\x6e\x65\x72\x73\x68\x69\x70',
        '\x63\x57\x59\x6b\x54',
        '\x6e\x48\x51\x55\x41',
        '\x6c\x42\x61\x57\x71',
        '\x42\x6f\x6e\x64\x61\x67\x65',
        '\x50\x55\x49\x75\x49',
        '\x42\x49\x6a\x4a\x6f',
        '\x62\x61\x6e\x6d\x65',
        '\x48\x67\x74\x42\x5a',
        '\x42\x43\x45\x4d\x73\x67',
        '\x6a\x4f\x4c\x74\x55',
        '\x47\x68\x6d\x5a\x41',
        '\x56\x4d\x4b\x6f\x44',
        '\x70\x7a\x4b\x67\x4d',
        '\x6c\x69\x63\x6b',
        '\x41\x4d\x68\x65\x77',
        '\x32\x33\x36\x6a\x58\x75\x68\x7a\x79',
        '\x51\x74\x4d\x69\x53',
        '\u5c01\u7981\u5931\u8d25\x3a\u73a9\u5bb6\u6ca1\u6709\u88ab\u5c01\u7981',
        '\x56\x49\x6a\x52\x6d',
        '\x79\x69\x6b\x54\x6f',
        '\x69\x6e\x48\x41\x70',
        '\x43\x68\x61\x74\x52\x6f\x6f\x6d',
        '\x33\x32\x33\x36\x35\x33\x30\x41\x4a\x4a\x69\x71\x68',
        '\x7a\x65\x6f\x75\x46',
        '\x6f\x4c\x54\x58\x54',
        '\x4a\x61\x48\x64\x44',
        '\x52\x44\x6b\x4b\x53',
        '\x51\x64\x6c\x44\x49',
        '\x6e\x55\x68\x59\x44',
        '\x67\x52\x50\x58\x71',
        '\x78\x46\x47\x67\x53',
        '\x55\x65\x4d\x76\x46',
        '\x73\x70\x6c\x69\x63\x65',
        '\x68\x43\x69\x41\x67',
        '\x72\x6f\x51\x75\x73',
        '\x44\x45\x6b\x49\x68',
        '\x47\x7a\x43\x62\x64',
        '\x6c\x53\x46\x69\x74',
        '\x68\x45\x41\x7a\x51',
        '\x76\x78\x52\x56\x46',
        '\x4c\x65\x61\x74\x68\x65\x72\x48\x6f\x6f\x64\x4f\x70\x65\x6e\x4d\x6f\x75\x74\x68',
        '\x42\x72\x6b\x54\x78',
        '\x62\x69\x54\x70\x4f',
        '\x32\x31\x33\x39\x34\x30\x36\x66\x66\x78\x7a\x43\x44',
        '\x7a\x65\x4c\x4d\x4f',
        '\x4a\x61\x54\x63\x54',
        '\x6a\x6d\x62\x7a\x6a',
        '\x62\x49\x68\x51\x43',
        '\x49\x52\x51\x71\x54',
        '\x76\x6b\x6f\x4f\x4c',
        '\x51\x52\x49\x48\x64',
        '\x76\x57\x74\x47\x47',
        '\x56\x57\x59\x72\x4f',
        '\x41\x7a\x6b\x43\x78',
        '\x4a\x65\x6d\x71\x55',
        '\x61\x77\x42\x4f\x54\x5f\u5207\u6362\u9677\u9631\u5c4b\u8bed\u8a00',
        '\x4e\x75\x53\x7a\x53',
        '\x41\x4f\x44\x75\x52',
        '\u5047\u88c5\u6709\x42\x43\x45\u4e0e\x42\x43\x58',
        '\x6a\x6d\x76\x75\x44',
        '\x69\x48\x50\x58\x65',
        '\x74\x54\x49\x51\x71',
        '\x64\x6b\x77\x76\x64',
        '\x66\x6f\x6d\x64\x4c',
        '\x61\x78\x4c\x52\x42',
        '\x69\x45\x75\x5a\x76',
        '\x55\x41\x46\x64\x52',
        '\x6d\x4b\x55\x72\x7a',
        '\x63\x4f\x44\x48\x54',
        '\x33\x31\x34\x36\x35\x70\x4f\x6d\x63\x4d\x66',
        '\x44\x42\x73\x69\x72',
        '\x7a\x47\x54\x68\x6a',
        '\x68\x68\x55\x44\x70',
        '\x49\x74\x65\x6d\x4d\x6f\x75\x74\x68',
        '\x65\x4f\x6e\x7a\x69',
        '\x71\x71\x73\x65\x65',
        '\x78\x6f\x50\x75\x55',
        '\x41\x77\x71',
        '\x67\x49\x7a\x54\x45',
        '\x71\x79\x59\x6a\x6f',
        '\x75\x6c\x63\x4e\x59',
        '\x44\x72\x6c\x4c\x50',
        '\x61\x77\x42\x4f\x54\x20\x53\x6f\x72\x72\x79\x20\x62\x75\x74\x20\x79\x6f\x75\x27\x76\x65\x20\x62\x65\x65\x6e\x20\x62\x61\x6e\x6e\x65\x64\x20\x62\x79\x20\x61\x6e\x20\x6f\x70\x65\x72\x61\x74\x6f\x72\x2e',
        '\x53\x47\x53\x6a\x61',
        '\x54\x6f\x48\x44\x59',
        '\x66\x6f\x72\x45\x61\x63\x68',
        '\x50\x47\x6b\x44\x62',
        '\x49\x65\x47\x57\x43',
        '\x79\x42\x7a\x4e\x57',
        '\x67\x7a\x57\x53\x72',
        '\x4d\x4d\x43\x71\x73',
        '\x57\x45\x4d\x69\x6d',
        '\x59\x58\x4f\x4f\x4b',
        '\x52\x4a\x53\x63\x54',
        '\x47\x62\x79\x6b\x79',
        '\x6a\x52\x64\x70\x76',
        '\x78\x42\x78\x4c\x45',
        '\x68\x44\x47\x50\x78',
        '\x4f\x57\x63\x58\x41',
        '\u6e05\u80cc\u5305',
        '\x57\x44\x56\x51\x70',
        '\x61\x62\x6f\x75\x74',
        '\u5e7b\u5f71\u79fb\u5f62\x28\u80fd\u7ed9\u522b\u4eba\u5f00\u9501\x29',
        '\x49\x65\x48\x51\x4a',
        '\x5f\u521d\u59cb\u5316\x5f',
        '\x69\x4c\x4c\x6b\x49',
        '\x74\x49\x54\x4e\x4b',
        '\x6c\x65\x6e\x67\x74\x68',
        '\x62\x46\x68\x4c\x6f',
        '\x57\x6e\x4a\x49\x45',
        '\x61\x77\x42\x4f\x54\x5f\u5f00\u5173\u9677\u9631\u5c4b',
        '\x69\x68\x5a\x63\x57',
        '\x47\x71\x72\x4f\x79',
        '\x68\x6e\x6b\x6d\x6f',
        '\x75\x53\x72\x4f\x62',
        '\x70\x67\x4f\x69\x51',
        '\x49\x74\x65\x6d\x48\x65\x61\x64',
        '\x69\x61\x79\x53\x54',
        '\x61\x77\x61\x71\x77\x71',
        '\x79\x54\x56\x41\x73',
        '\x5f\x5f\x70\x72\x6f\x74\x6f\x5f\x5f',
        '\x64\x6c\x62\x46\x65',
        '\x70\x49\x63\x7a\x43',
        '\x4b\x4d\x51\x5a\x6d',
        '\x49\x74\x65\x6d\x4e\x65\x63\x6b\x52\x65\x73\x74\x72\x61\x69\x6e\x74\x73',
        '\u5c01\u7981\u5931\u8d25\x3a\u73a9\u5bb6\u5df2\u7ecf\u88ab\u5c01\u7981',
        '\x77\x67\x44\x75\x79',
        '\x41\x78\x7a\x46\x63',
        '\x43\x68\x61\x74\x52\x6f\x6f\x6d\x43\x68\x61\x74',
        '\x68\x7a\x6b\x75\x4e',
        '\x41\x77\x41\x75\x74\x6f\x4b\x69\x63\x6b\x3a\x20\u7c98\u8d34\x2e',
        '\x4d\x43\x6b\x55\x75',
        '\x74\x72\x61\x63\x65',
        '\x62\x6e\x67\x6c\x4d',
        '\x50\x52\x77\x62\x49',
        '\x4d\x4b\x6f\x61\x75',
        '\x53\x66\x75\x4d\x58',
        '\x65\x77\x47\x58\x55',
        '\x41\x76\x61\x69\x6c\x61\x62\x6c\x65\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x2d\x77\x6f\x72\x64\x73\x3a\x72\x65\x6c\x65\x61\x73\x65\x2c\x62\x6f\x6e\x64\x61\x67\x65\x2c\x70\x6c\x61\x79\x73\x75\x69\x74\x2c\x6c\x6f\x63\x6b\x2c\x61\x62\x6f\x75\x74\x2c\x6c\x69\x63\x6b\x2c\x72\x61\x6e\x64\x6f\x6d\x2c\x62\x61\x6e\x6d\x65\x28\x74\x6f\x20\x67\x65\x74\x20\x73\x74\x75\x63\x6b\x2c\x75\x73\x65\x20\x74\x68\x69\x73\x20\x61\x66\x74\x65\x72\x20\x72\x61\x6e\x64\x6f\x6d\x20\x61\x6e\x64\x20\x6c\x6f\x63\x6b\x2e\x29\x2e\x49\x66\x20\x61\x20\x73\x65\x6e\x74\x65\x6e\x63\x65\x20\x69\x6e\x63\x6c\x75\x64\x69\x6e\x67\x20\x27\x61\x77\x71\x27\x20\x68\x61\x73\x20\x61\x20\x63\x6f\x6d\x6d\x61\x6e\x64\x2d\x77\x6f\x72\x64\x20\x61\x74\x20\x74\x68\x65\x20\x73\x61\x6d\x65\x20\x74\x69\x6d\x65\x2c\x20\x74\x68\x65\x6e\x20\x74\x68\x65\x20\x63\x6f\x72\x72\x65\x73\x70\x6f\x6e\x64\x69\x6e\x67\x20\x61\x63\x74\x69\x6f\x6e\x20\x77\x69\x6c\x6c\x20\x62\x65\x20\x74\x61\x6b\x65\x6e\x2e',
        '\x54\x55\x54\x63\x77',
        '\x62\x51\x41\x78\x67',
        '\x6c\x42\x4d\x67\x64',
        '\x4c\x65\x61\x74\x68\x65\x72\x48\x61\x72\x6e\x65\x73\x73',
        '\x30\x2e\x38\x2e\x33\x2d\x33\x65\x35\x34\x35\x62\x63\x32',
        '\x48\x54\x75\x50\x78',
        '\x59\x52\x73\x46\x65',
        '\x69\x79\x45\x6b\x79',
        '\x76\x64\x79\x52\x6c',
        '\x66\x64\x51\x62\x78',
        '\x49\x74\x65\x6d\x4e\x65\x63\x6b\x41\x63\x63\x65\x73\x73\x6f\x72\x69\x65\x73',
        '\u548c\u6211\u7b7e\u8ba2\u5951\u7ea6\uff0c\u6210\u4e3a\u9b54\u6cd5\u5c11\u5973\u5427\uff01',
        '\x4d\x44\x47\x42\x63',
        '\x43\x71\x44\x7a\x51',
        '\x74\x4c\x74\x5a\x4e'
    ];
    _0x29a0 = function () {
        return _0x36319a;
    };
    return _0x29a0();
}