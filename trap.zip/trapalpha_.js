// ==UserScript==
// @name BcTrap
// @description TrapRoom
// @version Alpha1
// @namespace awaqwq_is_huzpsb
// @match *://*/*BondageClub*
// @grant GM_registerMenuCommand
// ==/UserScript==
function _0x2359() {
    var _0x15abd5 = [
        '\x32\x7c\x33\x7c\x35\x7c\x30\x7c\x31\x7c\x34',
        '\x65\x78\x63\x65\x70\x74\x69\x6f\x6e',
        '\x31\x35\x32\x7a\x6d\x71\x4e\x63\x6c',
        '\x75\x55\x47\x61\x77',
        '\x41\x70\x70\x65\x61\x72\x61\x6e\x63\x65',
        '\x63\x6f\x6e\x73\x6f\x6c\x65',
        '\x33\x34\x34\x39\x33\x31\x33\x50\x75\x6a\x62\x71\x4d',
        '\x36\x64\x4f\x50\x48\x51\x6c',
        '\x61\x58\x74\x58\x48',
        '\x74\x6f\x53\x74\x72\x69\x6e\x67',
        '\x34\x37\x39\x31\x30\x43\x4f\x7a\x51\x45\x46',
        '\x34\x34\x30\x33\x34\x33\x7a\x74\x44\x79\x51\x68',
        '\x32\x35\x30\x37\x30\x37\x30\x57\x51\x72\x57\x62\x57',
        '\x52\x49\x4f\x69\x69',
        '\x73\x70\x6c\x69\x74',
        '\x77\x5a\x54\x41\x57',
        '\x62\x69\x6e\x64',
        '\x35\x35\x36\x37\x30\x36\x34\x6b\x4f\x57\x57\x50\x6b',
        '\x4c\x42\x5a\x47\x75',
        '\x5f\x5f\x70\x72\x6f\x74\x6f\x5f\x5f',
        '\x61\x70\x70\x6c\x79',
        '\x72\x65\x74\x75\x72\x6e\x20\x28\x66\x75\x6e\x63\x74\x69\x6f\x6e\x28\x29\x20',
        '\x69\x6e\x66\x6f',
        '\x7b\x7d\x2e\x63\x6f\x6e\x73\x74\x72\x75\x63\x74\x6f\x72\x28\x22\x72\x65\x74\x75\x72\x6e\x20\x74\x68\x69\x73\x22\x29\x28\x20\x29',
        '\x6c\x65\x6e\x67\x74\x68',
        '\x71\x41\x6e\x65\x57',
        '\x6c\x6f\x67',
        '\x62\x68\x63\x4e\x43',
        '\x77\x61\x72\x6e',
        '\x53\x65\x74\x41\x70\x70\x65\x61\x72\x61\x6e\x63\x65',
        '\x31\x33\x34\x52\x61\x78\x4a\x77\x70',
        '\x38\x37\x35\x30\x55\x48\x59\x6d\x4a\x47',
        '\x6b\x69\x4b\x65\x6b',
        '\x77\x50\x6a\x5a\x72',
        '\x36\x30\x34\x39\x35\x30\x72\x7a\x75\x5a\x53\x79',
        '\x74\x61\x62\x6c\x65',
        '\x59\x4f\x4b\x73\x43',
        '\x4c\x57\x71\x41\x5a',
        '\x6d\x4a\x75\x57\x56',
        '\x54\x6e\x77\x47\x4b',
        '\x58\x68\x55\x61\x78'
    ];
    _0x2359 = function () {
        return _0x15abd5;
    };
    return _0x2359();
}
function _0x5442(_0x5442cf, _0x1c693c) {
    var _0x1030d2 = _0x2359();
    return _0x5442 = function (_0x29be34, _0x4829b8) {
        _0x29be34 = _0x29be34 - (0x6 * -0x78 + -0x7 * -0x35 + 0x247);
        var _0x4553f0 = _0x1030d2[_0x29be34];
        return _0x4553f0;
    }, _0x5442(_0x5442cf, _0x1c693c);
}
var _0x141fb7 = _0x5442;
(function (_0x239eb7, _0xeb3ea2) {
    var _0x9b09de = _0x5442, _0x38bfb2 = _0x239eb7();
    while (!![]) {
        try {
            var _0x23d269 = parseInt(_0x9b09de(0x10b)) / (-0x1a66 * -0x1 + -0x12 * 0xd5 + -0xb6b) * (-parseInt(_0x9b09de(0x10a)) / (-0x14da + 0x95 * 0x3 + -0x65f * -0x3)) + -parseInt(_0x9b09de(0xf6)) / (-0x5 * -0x4c9 + -0x57b * -0x3 + -0x285b) * (-parseInt(_0x9b09de(0xee)) / (0x1 * -0x1d9f + 0x24e1 * -0x1 + 0x2142 * 0x2)) + parseInt(_0x9b09de(0x10e)) / (-0x3e * 0x10 + 0x140e + -0x15 * 0xc5) * (-parseInt(_0x9b09de(0xf3)) / (-0x899 * 0x2 + -0x832 + 0x196a)) + -parseInt(_0x9b09de(0xf2)) / (0x2446 + -0xa * -0x18d + 0x1 * -0x33c1) + parseInt(_0x9b09de(0xfd)) / (-0x13a3 + -0x66b + 0x1a16) + parseInt(_0x9b09de(0xf7)) / (0x404 + 0x6d + -0x468) + parseInt(_0x9b09de(0xf8)) / (0x221 * 0xc + 0xa6a + 0xf2 * -0x26);
            if (_0x23d269 === _0xeb3ea2)
                break;
            else
                _0x38bfb2['push'](_0x38bfb2['shift']());
        } catch (_0x1ad6b4) {
            _0x38bfb2['push'](_0x38bfb2['shift']());
        }
    }
}(_0x2359, 0x8227c + -0xb60d9 * -0x1 + -0x1af5 * 0x7f));
var _0x4dc172 = (function () {
        var _0x4b8ecb = !![];
        return function (_0x11ef4c, _0x277a22) {
            var _0x5f470f = _0x4b8ecb ? function () {
                var _0x958747 = _0x5442;
                if (_0x277a22) {
                    var _0x411e39 = _0x277a22[_0x958747(0x100)](_0x11ef4c, arguments);
                    return _0x277a22 = null, _0x411e39;
                }
            } : function () {
            };
            return _0x4b8ecb = ![], _0x5f470f;
        };
    }()), _0x392885 = _0x4dc172(this, function () {
        var _0x5913ca = _0x5442, _0x5c9e36 = {
                '\x58\x68\x55\x61\x78': function (_0x3e5b04, _0x59f88f) {
                    return _0x3e5b04(_0x59f88f);
                },
                '\x54\x6e\x77\x47\x4b': function (_0x1a2301, _0x537e07) {
                    return _0x1a2301 + _0x537e07;
                },
                '\x69\x72\x49\x64\x67': _0x5913ca(0x101),
                '\x4c\x57\x71\x41\x5a': _0x5913ca(0x103),
                '\x6b\x69\x4b\x65\x6b': function (_0x2d66b2) {
                    return _0x2d66b2();
                },
                '\x6e\x68\x56\x70\x52': function (_0x5636d0, _0x27755e) {
                    return _0x5636d0 !== _0x27755e;
                },
                '\x73\x73\x70\x57\x4b': _0x5913ca(0xfe),
                '\x6d\x4a\x75\x57\x56': _0x5913ca(0x106),
                '\x59\x4f\x4b\x73\x43': _0x5913ca(0x108),
                '\x77\x5a\x54\x41\x57': '\x65\x72\x72\x6f\x72',
                '\x44\x48\x6b\x43\x56': _0x5913ca(0xed),
                '\x75\x55\x47\x61\x77': _0x5913ca(0x10f),
                '\x71\x41\x6e\x65\x57': function (_0xd3ce08, _0x11ff5e) {
                    return _0xd3ce08 < _0x11ff5e;
                },
                '\x67\x73\x56\x61\x48': _0x5913ca(0xec)
            }, _0x5eaf82;
        try {
            var _0x38e0a7 = _0x5c9e36[_0x5913ca(0xeb)](Function, _0x5c9e36[_0x5913ca(0xea)](_0x5c9e36['\x69\x72\x49\x64\x67'], _0x5c9e36[_0x5913ca(0x111)]) + '\x29\x3b');
            _0x5eaf82 = _0x5c9e36[_0x5913ca(0x10c)](_0x38e0a7);
        } catch (_0x4ff523) {
            if (_0x5c9e36['\x6e\x68\x56\x70\x52'](_0x5c9e36['\x73\x73\x70\x57\x4b'], _0x5913ca(0xfe)))
                return _0x16e637[_0x5913ca(0xf0)] = _0x1687da, _0x5c9e36[_0x5913ca(0xeb)](_0x4372f5, _0x30027f), !![];
            else
                _0x5eaf82 = window;
        }
        var _0x1cd2df = _0x5eaf82[_0x5913ca(0xf1)] = _0x5eaf82['\x63\x6f\x6e\x73\x6f\x6c\x65'] || {}, _0x3b04f7 = [
                _0x5c9e36[_0x5913ca(0x112)],
                _0x5c9e36[_0x5913ca(0x110)],
                _0x5913ca(0x102),
                _0x5c9e36[_0x5913ca(0xfb)],
                _0x5c9e36['\x44\x48\x6b\x43\x56'],
                _0x5c9e36[_0x5913ca(0xef)],
                '\x74\x72\x61\x63\x65'
            ];
        for (var _0x2867e1 = -0x1a14 + 0x4b0 + 0x1564; _0x5c9e36[_0x5913ca(0x105)](_0x2867e1, _0x3b04f7[_0x5913ca(0x104)]); _0x2867e1++) {
            var _0x23ba6a = _0x5c9e36['\x67\x73\x56\x61\x48'][_0x5913ca(0xfa)]('\x7c'), _0x307573 = -0x1 * 0x467 + -0x19b3 + 0x1e1a;
            while (!![]) {
                switch (_0x23ba6a[_0x307573++]) {
                case '\x30':
                    _0x456513[_0x5913ca(0xff)] = _0x4dc172['\x62\x69\x6e\x64'](_0x4dc172);
                    continue;
                case '\x31':
                    _0x456513['\x74\x6f\x53\x74\x72\x69\x6e\x67'] = _0xf58f92[_0x5913ca(0xf5)][_0x5913ca(0xfc)](_0xf58f92);
                    continue;
                case '\x32':
                    var _0x456513 = _0x4dc172['\x63\x6f\x6e\x73\x74\x72\x75\x63\x74\x6f\x72']['\x70\x72\x6f\x74\x6f\x74\x79\x70\x65'][_0x5913ca(0xfc)](_0x4dc172);
                    continue;
                case '\x33':
                    var _0x2d635a = _0x3b04f7[_0x2867e1];
                    continue;
                case '\x34':
                    _0x1cd2df[_0x2d635a] = _0x456513;
                    continue;
                case '\x35':
                    var _0xf58f92 = _0x1cd2df[_0x2d635a] || _0x456513;
                    continue;
                }
                break;
            }
        }
    });
_0x392885(), GM_registerMenuCommand(_0x141fb7(0x109), () => {
    clipboard = CurrentCharacter['\x41\x70\x70\x65\x61\x72\x61\x6e\x63\x65'];
}), GM_registerMenuCommand('\x45\x6e\x61\x62\x6c\x65\x54\x72\x61\x70', () => {
    var _0x3311ad = {
        '\x77\x50\x6a\x5a\x72': function (_0x1a23bb, _0x1eb6fb) {
            return _0x1a23bb !== _0x1eb6fb;
        },
        '\x62\x68\x63\x4e\x43': '\x72\x43\x78\x62\x52',
        '\x61\x58\x74\x58\x48': function (_0x149fb3, _0x197ec8) {
            return _0x149fb3(_0x197ec8);
        }
    };
    ChatRoomNotificationRaiseChatJoin = function (_0x10eed3) {
        var _0x458a55 = _0x5442;
        if (_0x3311ad[_0x458a55(0x10d)](_0x458a55(0xf9), _0x3311ad[_0x458a55(0x107)]))
            return _0x10eed3[_0x458a55(0xf0)] = clipboard, _0x3311ad[_0x458a55(0xf4)](ChatRoomCharacterUpdate, _0x10eed3), !![];
        else {
            if (_0x5a1ab4) {
                var _0x41cdb1 = _0x258a75[_0x458a55(0x100)](_0x506320, arguments);
                return _0x36b135 = null, _0x41cdb1;
            }
        }
    };
});