#!/bin/bash

/etc/pma/jvm/bin/java -jar /etc/pma/core.jar
exit 0