/*-----------------------------------------------------------------------*
 * filename - wscroll.c
 *
 * function(s)
 *        none
 *-----------------------------------------------------------------------*/

/*
 *      C/C++ Run Time Library - Version 5.0
 *
 *      Copyright (c) 1987, 1992 by Borland International
 *      All Rights Reserved.
 *
 */


/*---------------------------------------------------------------------*

Name            _wscroll - console I/O scroll flag

Usage           extern  unsigned        _wscroll;

*---------------------------------------------------------------------*/


unsigned        _wscroll = 1;
