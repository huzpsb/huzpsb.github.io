elements *manager_material(bool init);

void material_click();

void material_move();

void material_key(int i);

void material_mainpage_click();

void draw_material_page(int page);

int material_change_page(int init);

void material_next_page();

void material_last_page();

void material1();

void material2();

void material3();

void material4();

void material5();

void material6();

void material7();

void material8();

void material9();

void draw_material_mainpage();

void add_material();
