elements *manager_eprospem(bool init);

void eprospem_click();

void eprospem_key(int i);

void eprospem_move();

void eprospem_add();

void eprospem_empromap_click();

void draw_emprospe_material();