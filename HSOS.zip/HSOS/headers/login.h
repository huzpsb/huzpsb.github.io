elements *manager_login(int init);

void login_click();

void login_key(int i);

void login_move();

void login_register_click();

void login_login_click();

void draw_login();
