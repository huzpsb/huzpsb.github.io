elements *manager_emprospe(bool init);

void emprospe_click();

void emprospe_key(int i);

void emprospe_move();

void emprospe_empro_click();

void emprospe_matlist_click();

void material_increase();

void material_decrease();
