elements *manager_emprofin(bool init);

void emprofin_empro_click();

void emprofin_click();

void emprofin_key(int i);

void emprofin_move();

void change_finish_project();

void draw_emprofin();
