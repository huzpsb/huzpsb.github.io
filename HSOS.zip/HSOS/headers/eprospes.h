elements *manager_eprospes(bool init);

void eprospes_click();

void eprospes_key(int i);

void eprospes_move();

void eprospes_empro_click();

void draw_emprospe_supply();
