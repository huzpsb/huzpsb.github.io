elements *manager_empage(bool init);

void empage_click();

void empage_key(int i);

void empage_move();

void empage_project_click();

void empage_materail_click();

void empage_login_click();

void draw_empage();
