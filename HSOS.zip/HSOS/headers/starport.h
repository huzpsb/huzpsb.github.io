elements *manager_starport(bool init);

void starport_click();

void starport_key(int i);

void starport_move();

void starport_material_click();

void starport_add();

void draw_material_specific();

void draw_starport();