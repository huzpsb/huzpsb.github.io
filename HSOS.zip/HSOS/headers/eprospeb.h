elements *manager_eprospeb(bool init);

void eprospeb_click();

void eprospeb_key(int i);

void eprospeb_move();

void eprospeb_empro_click();

void draw_emprospe_build();

