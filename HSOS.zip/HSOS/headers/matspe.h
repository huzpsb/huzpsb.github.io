elements *manager_matspe(bool init);

void matspe_click();

void matspe_key(int i);

void matspe_move();

void matspe_material_click();

void draw_material_specific();
