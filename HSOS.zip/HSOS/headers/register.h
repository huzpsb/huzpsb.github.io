elements *manager_register(bool init);

void register_click();

void register_register_click();

void register_back_click();

void register_key(int i);

void register_move();

void draw_register();
