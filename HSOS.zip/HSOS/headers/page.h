void paint(int i); 
