elements *manager_destroy(bool init);

void destroy_click();

void destroy_key(int i);

void destroy_move();

void sure_destroy_click();

void destroy_empromap_click();

void draw_destroy();
