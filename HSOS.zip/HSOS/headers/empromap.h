elements *manager_empromap(bool init);

void empromap_click();

void empromap_key(int i);

void empromap_move();

void empromap_empro_click();

void draw_emprospe_map();

void map();

void empromap_starport_click();
