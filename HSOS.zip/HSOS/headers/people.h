//��ʼ������ 
void person_click();

void person_key(int i);

void person_move();

void people_click();

void people_key(int i);

void people_move();

//��ť����
elements *manager_people(bool init);

elements *manager_person(bool init);

//��ť��Ӧ(���ܣ�����
void next_page();

void last_page();

void change_boss();

void change_work();

void change_phone();

void people_person1();

void people_person2();

void people_person3();

void people_person4();

void people_person5();

void people_person6();

void people_person7();

void people_person8();

void people_person9();

void people_mainpage_click();

void person_people_click();

void delete_person();

//ҳ����ƺ��� 
int change_page(int init);

//���ƽ��溯��
void draw_people();

void draw_person_page(int num);

void draw_people_page(int page);
