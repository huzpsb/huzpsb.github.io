elements *manager_project(bool init);

void project_click();

void project_key(int i);

void project_move();

void project_mainpage_click();

void draw_project();

void create_project();

void search_project();

void project_list();
