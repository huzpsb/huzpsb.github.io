elements *manager_prospe(bool init);

void prospe_project_click();

void prospe_click();

void prospe_key(int i);

void prospe_move();

void draw_project_specific();

void delete_project();

void send_back_project();
