elements *manager_empro(bool init);

void empro_click();

void empro_key(int i);

void empro_move();

void empro_empage_click();

void draw_empro_page(int page);

int empro_change_page(int init);

void empro_next_page();

void empro_last_page();

void empro1();

void empro2();

void empro3();

void empro4();

void empro5();

void empro6();

void empro7();

void empro8();

void empro9();

void draw_empro_mainpage();
