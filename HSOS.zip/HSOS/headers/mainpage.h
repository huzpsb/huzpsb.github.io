elements *manager_mainpage(bool init);

void mainpage_click();

void mainpage_key(int i);

void mainpage_move();

void mainpage_people_click();

void mainpage_progarm_click();

void mainpage_materail_click();

void mainpage_login_click();

void draw_mainpage();
