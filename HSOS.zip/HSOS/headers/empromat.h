elements *manager_empromat(bool init);

void empromat_click();

void empromat_key(int i);

void empromat_move();

void draw_empro_specific();

void empromat_emprospe_click();

void draw_emprospe_matlist();