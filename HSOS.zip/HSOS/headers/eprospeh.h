elements *manager_eprospeh(bool init);

void eprospeh_click();

void eprospeh_key(int i);

void eprospeh_move();

void eprospeh_empromap_click();

void draw_emprospe_house();

void eprospeh_building(int i);

void eprospeh_building3();

void eprospeh_building2();

void eprospeh_building1();

void eprospeh_decrease(char *text, int y);