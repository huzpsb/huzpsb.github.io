#include "HsOS.h"

#include "page.h"
#include "login.h"

#include <stdlib.h>
#include <time.h>

#ifdef DEBUG

#include <stdio.h>

#endif

void mainX()
{
    long prev, now, delta;
    _init();
    delay(1000);
    print_login_msg("��ӭʹ�ñ�ϵͳ��");
    paint(1);
    while (1)
    {
        _update();
    }
}

#ifdef DEBUG

/* ��ѹ�������ú��� */
void boot(int loop)
{
    if (loop == 0)
    {
        mainX();
    } else
    {
        boot(loop - 1);
    }
}

int main()
{
    int i;
    void *p = malloc(10000);
    // �˷��ڴ��ջ�ռ䣬ȷ���ڴ治��ʱ�ܹ���������
    if (p == NULL)
        return -1;
    for (i = 0; i < 50; i++)
        printf("--!WARNING:DEBUG MODE IS ON!-- --!WARNING:DEBUG MODE IS ON!--\n");
    delay(1000);
    boot(10);
    return 0;
}

#else

int main()
{
    mainX();
    return 0;
}

#endif
