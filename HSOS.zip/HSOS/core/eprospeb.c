#include "HsOS.h"
#include "page.h"
#include "string.h"
#include "stdio.h"
#include "eprospeb.h"
#include "general.h"

elements *manager_eprospeb(bool init)
{
    static elements *eprospeb_data = NULL;
    element *btn;
    if (init)
    {
        if (isnull(eprospeb_data))
        {
            btn = new_button(0, 0, 60, 30, "����", IvoryWhite, 0xfded, 0x4227, eprospeb_empro_click);
            eprospeb_data = push(btn, NULL);
            btn = new_button(406, 426, 534, 530, "�������", IvoryWhite, 0xfded, 0x4227, finish_project);
            eprospeb_data = push(btn, eprospeb_data);
        }
    }
    return eprospeb_data;
}

void eprospeb_click()
{
    if (isopen_map(2))
    {
        if (mouse.x > 545 && mouse.y > 354 && mouse.x < 965 && mouse.y < 624)
        {
            if ((vague_semantic_recognition_project(remember_empro(0)) == 2) ||
                (vague_semantic_recognition_project(remember_empro(0)) == 4))
            {
                supply_or_build(2);
            } else if (vague_semantic_recognition_project(remember_empro(0)) == 3)
            {
                supply_or_build(1);
            }
            paint(16);
        }
    }
    tick_click(manager_eprospeb(false));
}

void eprospeb_key(int i)
{
    tick_key(manager_eprospeb(false), i);
}

void eprospeb_move()
{
    tick_move(manager_eprospeb(false));
}

void eprospeb_empro_click()
{
    paint(10);
}

void draw_emprospe_build()
{
    char tmp[30];
    char tmp1[30];
    FILE *fp;
    strcpy(tmp, remember_empro(0));
    Picture(0, 0, "res\\people.bmp");
    Box(583, 43, 754, 89, BLACK, 3);
    Text(640, 54, "�������", BLACK);
    Box(365, 132, 985, 724, BLACK, 5);
    EngText(648, 145, tmp, BLACK);
    Text(421, 222, "����Ŀ��", BLACK);
    strcpy(tmp1, "data\\project\\mark\\");
    strcat(tmp1, tmp);
    fp = fopen(tmp1, "rb");
    fscanf(fp, "%s", tmp1);
    fclose(fp);
    Text(569, 217, tmp1, BLACK);
    background();
    show_map();
    emprospe_text(NULL);
    tick_init(manager_eprospeb(true));
    set_functions(eprospeb_click, eprospeb_key, eprospeb_move);
}
