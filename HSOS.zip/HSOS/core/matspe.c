#include "HsOS.h"
#include "page.h"
#include "string.h"
#include "matspe.h"
#include "stdio.h"
#include "general.h"
// extern FILE *logger;

// void l_flush();

int count(char *log)
{
    FILE *fp;
    char buffer[256], *uwu;
    int lineCount = 0;
    if ((fp = fopen(log, "r")) == NULL)
    {
        if ((fp = fopen(log, "w")) == NULL)
        {
            draw_error("File System Panic - Can not create file (mat_spe.c::assert)!", log);
        }
        uwu = remember_material(0);
        fprintf(fp, "����Ա %s �������־�����ࣺ%d\n", remember_id(NULL), getCount(uwu));
        fclose(fp);
        return 1;
    }
    while (fgets(buffer, sizeof(buffer), fp))
    {
        lineCount++;
    }
    fclose(fp);
    return lineCount;
}

void render(char *file, int begin, int end, int now, int total)
{
    FILE *fp;
    char buffer[256];
    int lineCount = 0;
    Bar(322, 450, 1024, 768, 0x867e);
    if ((fp = fopen(file, "r")) == NULL)
    {
        draw_error("File System Panic - Can not open file (mat_spe.c::render)!", file);
    }
    while (fgets(buffer, sizeof(buffer), fp))
    {
        lineCount++;
        if (lineCount >= begin && lineCount <= end)
        {
            Text(322, 450 + 50 * (lineCount - begin), transform(buffer), BLACK);
        }
    }
    sprintf(buffer, "��%dҳ����%dҳ", now, total);
    Text(312, 730, transform(buffer), BLACK);
    fclose(fp);
}

void page(int opr)
{
    static int now = 0;
    char tmp[50];
    int begin, end, items, pages;
    strcpy(tmp, "data\\logs\\");
    strcat(tmp, remember_material(0));
    items = count(tmp);
    pages = items / 5;
    if (pages * 5 != items)
    {
        pages++;
    }
    now += opr;
    if (now <= 0)
    {
        now = 1;
    }
    if (now > pages)
    {
        now = pages;
    }
    begin = now * 5 - 4;
    end = now * 5;
    if (end > items)
    {
        end = items;
    }
    render(tmp, begin, end, now, pages);
}

void ms_prev()
{
    page(-1);
}

void ms_next()
{
    page(1);
}

void ms_remake()
{
    char tmp[50];
    strcpy(tmp, "data\\logs\\");
    strcat(tmp, remember_material(0));
    IFileDelete(tmp);
    page(0);
}

elements *manager_matspe(bool init)
{
    static elements *matspe_data = NULL;
    element *btn;
    if (init)
    {
        if (isnull(matspe_data))
        {
            btn = new_button(0, 0, 60, 30, "����", IvoryWhite, 0xfded, 0x4227, matspe_material_click);
            matspe_data = push(btn, NULL);
        }
    }
    return matspe_data;
}

void matspe_click()
{
    tick_click(manager_matspe(false));
}

void matspe_key(int i)
{
    switch (i)
    {
        case 'q':
            ms_prev();
            break;
        case 'w':
            ms_next();
            break;
            // case 'r':
            //     ms_push_debug();
            //     break;
        case 'e':
            if (ismanager(remember_id(NULL)))
            {
                ms_remake();
            }
            break;
        default:
            break;
    }
    tick_key(manager_matspe(false), i);
}

void matspe_move()
{
    tick_move(manager_matspe(false));
}

void matspe_material_click()
{
    paint(6);
}

void draw_material_specific()
{
    char tmp[30];
    FILE *fp;
    int x;
    double i;
    Bar(312, 0, 1024, 768, 0x867e);
    Box(373, 139, 558, 291, BLACK, 5);
    Text(373, 300, "����һҳ����һҳ�����", BLACK);
    Text(658, 139, "����������", BLACK);
    EngText(800, 144, ": 10000", BLACK);
    Text(658, 163, "�ִ�", BLACK);
    Box(658, 196, 913, 263, BLACK, 2);
    strcpy(tmp, "data\\material\\");
    strcat(tmp, remember_material(0));
    fp = fopen(tmp, "rb");
    if (fp == NULL)
    {
        draw_error("File System Panic - Can not open file (mat_spe.c::draw_material_specific)!", tmp);
    } else
    {
        fscanf(fp, "%s", tmp);
        fclose(fp);
        Text(440, 200, tmp, BLACK);
    }
    x = getCount(remember_material(0));
    // draw_error(toString(y), "hhh");
    i = x / 100.0;
    i = (i * 255) / 100.0;
    // draw_error(toString((int)i), "hhh");
    if (i > 127)
    {
        Bar(660, 198, 660 + (int) i, 261, ForestGreen);
    } else if (i > 64 && i <= 127)
    {
        Bar(660, 198, 660 + (int) i, 261, YELLOW);
    } else
    {
        Bar(660, 198, 660 + (int) i, 261, 0xf800);
    }
    // Bar(0, 0, 60, 60, WHITE);
    tick_init(manager_matspe(true));
    // Bar(0, 0, 40, 40, BLACK);
    set_functions(matspe_click, matspe_key, matspe_move);
    // Bar(0, 0, 20, 20, WHITE);
    page(0);
    // Bar(0, 0, 10, 10, BLACK);
}
