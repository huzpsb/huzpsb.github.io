// Reviewed by huzpsb 2023/04/05. Two errors and four warnings. Approved.

#include "HsOS.h"
#include "page.h"
#include "string.h"
#include "stdio.h"
#include "emprospe.h"
#include "general.h"

elements *manager_emprospe(bool init)
{
    static elements *emprospe_data = NULL;
    element *btn;
    if (init)
    {
        if (isnull(emprospe_data))
        {
            btn = new_button(0, 0, 60, 30, "����", IvoryWhite, 0xfded, 0x4227, emprospe_empro_click);
            emprospe_data = push(btn, NULL);
            btn = new_button(561, 291, 617, 340, "����", IvoryWhite, 0xfded, 0x4227, emprospe_matlist_click);
            emprospe_data = push(btn, emprospe_data);
            btn = new_input(658, 291, 738, 340, "mat_increase", 4, BLACK, WHITE, IvoryWhite, false, false);
            emprospe_data = push(btn, emprospe_data);
            btn = new_button(739, 291, 805, 340, "���", IvoryWhite, 0xfded, 0x4227, material_increase);
            emprospe_data = push(btn, emprospe_data);
            btn = new_input(819, 291, 899, 340, "mat_decrease", 4, BLACK, WHITE, IvoryWhite, false, false);
            emprospe_data = push(btn, emprospe_data);
            btn = new_button(900, 291, 966, 340, "����", IvoryWhite, 0xfded, 0x4227, material_decrease);
            emprospe_data = push(btn, emprospe_data);
            btn = new_button(406, 426, 534, 530, "�������", IvoryWhite, 0xfded, 0x4227, finish_project);
            emprospe_data = push(btn, emprospe_data);
        }
    }
    return emprospe_data;
}

void emprospe_click()
{
    tick_click(manager_emprospe(false));
}

void emprospe_key(int i)
{
    tick_key(manager_emprospe(false), i);
}

void emprospe_move()
{
    tick_move(manager_emprospe(false));
}

void emprospe_empro_click()
{
    paint(10);
}

void emprospe_matlist_click()
{
    isexpand(1);
    paint(12);
}

void material_increase()
{
    char tmp[100];
    char tmp1[30];
    FILE *fp;
    long x, y;
    x = getCount(remember_empro_mat(NULL));
    y = atoi(get_input(manager_emprospe(false), "mat_increase"));
    if (y > 10000)
    {
        emprospe_text("��Դ�����Ƿ�");
        // paint(11);
    } else if (y <= 0)
    {
        emprospe_text("��Դ�仯������Ϊ����");
        // paint(11);
    } else if (x + y > 10000)
    {
        emprospe_text("��Դ������������");
        // paint(11);
    } else
    {
        x += y;
        strcpy(tmp1, "data\\material\\");
        strcat(tmp1, remember_empro_mat(NULL));
        fp = fopen(tmp1, "rb");
        fscanf(fp, "%s", tmp1);
        fclose(fp);
        // draw_error(remember_empro_mat(NULL), tmp1);
        strcpy(tmp, "�û�");
        strcat(tmp, remember_id(NULL));
        strcat(tmp, "������");
        strcat(tmp, remember_empro(0));
        strcat(tmp, "�л����");
        strcat(tmp, toString(y));
        strcat(tmp, "����λ��");
        strcat(tmp, tmp1);
        strcat(tmp, "�����ࣺ");
        strcat(tmp, toString(x));
        ms_append(remember_empro_mat(NULL), transform(tmp));
        ms_append(remember_empro_mat(NULL), "\n");
        setCount(remember_empro_mat(NULL), x);
        progress_bar(550, 643, 750, 700, 5);
        emprospe_text("�����");
        strcpy(get_input(manager_emprospe(false), "mat_increase"), "\0");
        Bar(659, 292, 737, 339, IvoryWhite);
        // paint(11);
    }
}

void material_decrease()
{
    char tmp[100];
    char tmp1[30];
    FILE *fp;
    int x, y;
    x = getCount(remember_empro_mat(NULL));
    y = atoi(get_input(manager_emprospe(false), "mat_decrease"));
    if (y > 10000)
    {
        emprospe_text("���ķǷ�");
        // paint(11);
    } else if (y <= 0)
    {
        emprospe_text("��Դ�仯������Ϊ����");
        // paint(11);
    } else if (x - y < 0)
    {
        emprospe_text("��治��");
        // paint(11);
    } else
    {
        x -= y;
        strcpy(tmp1, "data\\material\\");
        strcat(tmp1, remember_empro_mat(NULL));
        fp = fopen(tmp1, "rb");
        fscanf(fp, "%s", tmp1);
        fclose(fp);
        // draw_error(tmp1, "hhh");
        strcpy(tmp, "�û�");
        strcat(tmp, remember_id(NULL));
        strcat(tmp, "������");
        strcat(tmp, remember_empro(0));
        strcat(tmp, "��������");
        strcat(tmp, toString(y));
        strcat(tmp, "����λ��");
        strcat(tmp, tmp1);
        strcat(tmp, "�����ࣺ");
        strcat(tmp, toString(x));
        ms_append(remember_empro_mat(NULL), transform(tmp));
        ms_append(remember_empro_mat(NULL), "\n");
        setCount(remember_empro_mat(NULL), x);
        progress_bar(550, 643, 750, 700, 5);
        emprospe_text("�����");
        strcpy(get_input(manager_emprospe(false), "mat_decrease"), "\0");
        Bar(820, 292, 898, 339, IvoryWhite);
        // paint(11);
    }
}

void draw_empro_specific()
{
    char tmp[30];
    char tmp1[30];
    FILE *fp;
    strcpy(tmp, remember_empro(0));
    Picture(0, 0, "res\\people.bmp");
    Box(583, 43, 754, 89, BLACK, 3);
    Text(640, 54, "����", BLACK);
    Box(365, 132, 985, 724, BLACK, 5);
    EngText(648, 145, tmp, BLACK);
    Text(421, 222, "����Ŀ��", BLACK);
    strcpy(tmp1, "data\\project\\mark\\");
    strcat(tmp1, tmp);
    fp = fopen(tmp1, "rb");
    fscanf(fp, "%s", tmp1);
    fclose(fp);
    Text(569, 217, tmp1, BLACK);
    Box(406, 291, 472, 340, BLACK, 2);
    Text(409, 294, "��Դ", BLACK);
    Box(470, 291, 560, 340, BLACK, 2);
    strcpy(tmp1, "data\\material\\");
    strcat(tmp1, remember_empro_mat(NULL));
    fp = fopen(tmp1, "rb");
    fscanf(fp, "%s", tmp1);
    fclose(fp);
    Text(473, 294, tmp1, BLACK);
    background();
    show_map();
    emprospe_text(NULL);
    tick_init(manager_emprospe(true));
    set_functions(emprospe_click, emprospe_key, emprospe_move);
}
