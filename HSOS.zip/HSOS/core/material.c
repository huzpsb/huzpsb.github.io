// Reviewed by huzpsb 2023/04/05. Two warnings. Approved.

#include "HsOS.h"
#include "page.h"
#include "string.h"
#include "stdio.h"
#include "material.h"
#include "general.h"

elements *manager_material(bool init)
{
    static elements *material_data = NULL;
    static elements *material_data2 = NULL;
    static elements *material_dataX = NULL;
    int x1 = 347, y1 = 57;
    element *btn;
    if (init)
    {
        if (ismanager(remember_id(NULL)))
        {
            if (isnull(material_data))
            {
                btn = new_button(0, 0, 60, 30, "����", IvoryWhite, 0xfded, 0x4227, material_mainpage_click);
                material_data = push(btn, NULL);
                btn = new_button(341, 707, 441, 745, "��һҳ", IvoryWhite, 0xfded, 0x4227, material_last_page);
                material_data = push(btn, material_data);
                btn = new_button(917, 707, 1017, 745, "��һҳ", IvoryWhite, 0xfded, 0x4227, material_next_page);
                material_data = push(btn, material_data);
                btn = new_button(x1, y1 + 118, x1 + 183, y1 + 173, "����", IvoryWhite, 0xfded, 0x4227, material1);
                material_data = push(btn, material_data);
                btn = new_button(x1 + 234, y1 + 118, x1 + 183 + 234, y1 + 173, "����", IvoryWhite, 0xfded, 0x4227,
                                 material2);
                material_data = push(btn, material_data);
                btn = new_button(x1 + 468, y1 + 118, x1 + 183 + 468, y1 + 173, "����", IvoryWhite, 0xfded, 0x4227,
                                 material3);
                material_data = push(btn, material_data);
                btn = new_button(x1, y1 + 118 + 226, x1 + 183, y1 + 173 + 226, "����", IvoryWhite, 0xfded, 0x4227,
                                 material4);
                material_data = push(btn, material_data);
                btn = new_button(x1 + 234, y1 + 118 + 226, x1 + 183 + 234, y1 + 173 + 226, "����", IvoryWhite, 0xfded,
                                 0x4227, material5);
                material_data = push(btn, material_data);
                btn = new_button(x1 + 468, y1 + 118 + 226, x1 + 183 + 468, y1 + 173 + 226, "����", IvoryWhite, 0xfded,
                                 0x4227, material6);
                material_data = push(btn, material_data);
                btn = new_button(x1, y1 + 118 + 452, x1 + 183, y1 + 173 + 452, "����", IvoryWhite, 0xfded, 0x4227,
                                 material7);
                material_data = push(btn, material_data);
                btn = new_button(x1 + 234, y1 + 118 + 452, x1 + 183 + 234, y1 + 173 + 452, "����", IvoryWhite, 0xfded,
                                 0x4227, material8);
                material_data = push(btn, material_data);
                btn = new_button(x1 + 468, y1 + 118 + 452, x1 + 183 + 468, y1 + 173 + 452, "����", IvoryWhite, 0xfded,
                                 0x4227, material9);
                material_data = push(btn, material_data);

                btn = new_input(312, 0, 520, 25, "add", 15, BLACK, WHITE, IvoryWhite, false, false);
                material_data = push(btn, material_data);
                btn = new_input(521, 0, 720, 25, "addname", 15, BLACK, WHITE, IvoryWhite, false, true);
                material_data = push(btn, material_data);
                btn = new_button(721, 0, 921, 48, "������Դ����", IvoryWhite, 0xfded, 0x4227, add_material);
                material_data = push(btn, material_data);
            }
            material_dataX = material_data;
            return material_data;
        } else
        {
            if (isnull(material_data2))
            {
                btn = new_button(0, 0, 60, 30, "����", IvoryWhite, 0xfded, 0x4227, material_mainpage_click);
                material_data2 = push(btn, NULL);
                btn = new_button(341, 707, 441, 745, "��һҳ", IvoryWhite, 0xfded, 0x4227, material_last_page);
                material_data2 = push(btn, material_data2);
                btn = new_button(917, 707, 1017, 745, "��һҳ", IvoryWhite, 0xfded, 0x4227, material_next_page);
                material_data2 = push(btn, material_data2);
                btn = new_button(x1, y1 + 118, x1 + 183, y1 + 173, "����", IvoryWhite, 0xfded, 0x4227, material1);
                material_data2 = push(btn, material_data2);
                btn = new_button(x1 + 234, y1 + 118, x1 + 183 + 234, y1 + 173, "����", IvoryWhite, 0xfded, 0x4227,
                                 material2);
                material_data2 = push(btn, material_data2);
                btn = new_button(x1 + 468, y1 + 118, x1 + 183 + 468, y1 + 173, "����", IvoryWhite, 0xfded, 0x4227,
                                 material3);
                material_data2 = push(btn, material_data2);
                btn = new_button(x1, y1 + 118 + 226, x1 + 183, y1 + 173 + 226, "����", IvoryWhite, 0xfded, 0x4227,
                                 material4);
                material_data2 = push(btn, material_data2);
                btn = new_button(x1 + 234, y1 + 118 + 226, x1 + 183 + 234, y1 + 173 + 226, "����", IvoryWhite, 0xfded,
                                 0x4227, material5);
                material_data2 = push(btn, material_data2);
                btn = new_button(x1 + 468, y1 + 118 + 226, x1 + 183 + 468, y1 + 173 + 226, "����", IvoryWhite, 0xfded,
                                 0x4227, material6);
                material_data2 = push(btn, material_data2);
                btn = new_button(x1, y1 + 118 + 452, x1 + 183, y1 + 173 + 452, "����", IvoryWhite, 0xfded, 0x4227,
                                 material7);
                material_data2 = push(btn, material_data2);
                btn = new_button(x1 + 234, y1 + 118 + 452, x1 + 183 + 234, y1 + 173 + 452, "����", IvoryWhite, 0xfded,
                                 0x4227, material8);
                material_data2 = push(btn, material_data2);
                btn = new_button(x1 + 468, y1 + 118 + 452, x1 + 183 + 468, y1 + 173 + 452, "����", IvoryWhite, 0xfded,
                                 0x4227, material9);
                material_data2 = push(btn, material_data2);
            }
            material_dataX = material_data2;
            return material_data2;
        }
    } else
    {
        return material_dataX;
    }
}

void material_click()
{
    tick_click(manager_material(false));
}

void material_key(int i)
{
    tick_key(manager_material(false), i);
}

void material_move()
{
    tick_move(manager_material(false));
}

void material_mainpage_click()
{
    if (ismanager(remember_id(NULL)))
    {
        paint(3);
    } else
    {
        if (starport_or_material(0) == 1)
        {
            paint(16);
        } else
        {
            paint(9);
        }
    }
}

void add_material()
{
    char tmp[50];
    char tmp1[50];
    FILE *fp;
    strcpy(tmp, get_input(manager_material(false), "add"));
    strcpy(tmp1, "data\\material\\");
    strcat(tmp1, tmp);
    fp = fopen(tmp1, "wb");
    fprintf(fp, "%s", get_input(manager_material(false), "addname"));
    fclose(fp);
    strcpy(tmp1, "data\\matnum\\");
    strcat(tmp1, tmp);
    fp = fopen(tmp1, "wb");
    fprintf(fp, "0");
    fclose(fp);
    paint(6);
}

void draw_material_page(int page)
{
    int i, j, x1 = 347, y1 = 62;
    char tmp[100];
    FILE *fp;
    IFileList("C:\\HSOS\\data\\material\\*");
    i = IFileCount();
    for (j = (page - 1) * 9; j < page * 9; j++)
    {
        Bar(x1 + (j % 3) * 234, y1 + ((j - (page - 1) * 9) / 3) * 226, x1 + (j % 3) * 234 + 183,
            y1 + ((j - (page - 1) * 9) / 3) * 226 + 118, MAR_ORANGE);
        if (j < i)
        {
            strcpy(tmp, "data\\material\\");
            strcat(tmp, IFileGet(j));
            fp = fopen(tmp, "rb");
            fgets(tmp, 30, fp);
            Text(x1 + (j % 3) * 234 + 10, y1 + ((j - (page - 1) * 9) / 3) * 226 + 5, tmp, IvoryWhite);
            fclose(fp);
        } else
            Text(x1 + (j % 3) * 234 + 10, y1 + ((j - (page - 1) * 9) / 3) * 226 + 5, "��", IvoryWhite);
    }
}

int material_change_page(int init)
{
    static int now_page = 1;
    int Total_page, i;
    IFileList("C:\\HSOS\\data\\material\\*");
    i = IFileCount();
    if (i % 9 != 0)
        Total_page = i / 9 + 1;
    else
        Total_page = i / 9;
    if (init == 1)
    {
        if (now_page < Total_page)
            now_page = now_page + 1;
    } else if (init == 2)
    {
        if (now_page > 1)
            now_page = now_page - 1;
    } else if (init == 4)
    {
        now_page = 1;
    }
    return now_page;
}

void material_next_page()
{
    draw_material_page(material_change_page(1));
}

void material_last_page()
{
    draw_material_page(material_change_page(2));
}

void material1()
{
    if (starport_or_material(0) == 1)
    {
        remember_material(1);
        paint(19);
    } else
    {
        if (isexist_material(1))
        {
            remember_material(1);
            paint(7);
        }
    }
}

void material2()
{
    if (starport_or_material(0) == 1)
    {
        remember_material(2);
        paint(19);
    } else
    {
        if (isexist_material(2))
        {
            remember_material(2);
            paint(7);
        }
    }
}

void material3()
{
    if (starport_or_material(0) == 1)
    {
        remember_material(3);
        paint(19);
    } else
    {
        if (isexist_material(3))
        {
            remember_material(3);
            paint(7);
        }
    }
}

void material4()
{
    if (starport_or_material(0) == 1)
    {
        remember_material(4);
        paint(19);
    } else
    {
        if (isexist_material(4))
        {
            remember_material(4);
            paint(7);
        }
    }
}

void material5()
{
    if (starport_or_material(0) == 1)
    {
        remember_material(5);
        paint(19);
    } else
    {
        if (isexist_material(5))
        {
            remember_material(5);
            paint(7);
        }
    }
}

void material6()
{
    if (starport_or_material(0) == 1)
    {
        remember_material(6);
        paint(19);
    } else
    {
        if (isexist_material(6))
        {
            remember_material(6);
            paint(7);
        }
    }
}

void material7()
{
    if (starport_or_material(0) == 1)
    {
        remember_material(7);
        paint(19);
    } else
    {
        if (isexist_material(7))
        {
            remember_material(7);
            paint(7);
        }
    }
}

void material8()
{
    if (starport_or_material(0) == 1)
    {
        remember_material(8);
        paint(19);
    } else
    {
        if (isexist_material(8))
        {
            remember_material(8);
            paint(7);
        }
    }
}

void material9()
{
    if (starport_or_material(0) == 1)
    {
        remember_material(9);
        paint(19);
    } else
    {
        if (isexist_material(9))
        {
            remember_material(9);
            paint(7);
        }
    }
}

void draw_material_mainpage()
{
    Picture(0, 0, "res\\people.bmp");
    Text(350, 26, "��Դ����", BLACK);
    Text(560, 26, "��Դ������", BLACK);
    if (!ismanager(remember_id(NULL)))
    {
        Picture(311, 0, "res\\back1.bmp");
    }
    Bar(311, 49, 1024, 56, LIGHT_GREY);
    background();
    draw_material_page(material_change_page(4));
    tick_init(manager_material(true));
    set_functions(material_click, material_key, material_move);
}
