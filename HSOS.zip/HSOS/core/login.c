// Reviewed by huzpsb 2023/04/05. A warning. Approved.

#include "HsOS.h"
#include "page.h"
#include "login.h"
#include "string.h"
#include "stdio.h"
#include "general.h"

elements *manager_login(bool init)
{
    static elements *login_data = NULL;
    if (init)
    {
        if (isnull(login_data))
        {
            element *btn;
            btn = new_input(330, 290, 740, 316, "user", 15, BLACK, WHITE, IvoryWhite, false, false);
            login_data = push(btn, NULL);
            btn = new_input(330, 380, 740, 406, "password", 15, BLACK, WHITE, IvoryWhite, true, false);
            login_data = push(btn, login_data);
            btn = new_button(250, 520, 450, 600, "��¼", IvoryWhite, 0xaac2, 0x4227, login_login_click);
            login_data = push(btn, login_data);
            btn = new_button(574, 520, 774, 600, "ע��", IvoryWhite, 0xaac2, 0x4227, login_register_click);
            login_data = push(btn, login_data);
        }
    }
    return login_data;
}

void login_click()
{
    tick_click(manager_login(false));
}

void login_key(int i)
{
    int bx, by;
    if (i == 13)
    {
        login_login_click();
        return;
    }
    if (i == 9)
    {
        bx = mouse.x;
        by = mouse.y;
        mouse.x = 335;
        mouse.y = 390;
        tick_click(manager_login(false));
        mouse.x = bx;
        mouse.y = by;
        return;
    }
    tick_key(manager_login(false), i);
}

void login_move()
{
    tick_move(manager_login(false));
}

void login_register_click()
{
    paint(2);
}

void login_login_click()
{
    char tmp[30];
    char tmp1[30];
    FILE *fp;
    FILE *fp1;
    strcpy(tmp, "data\\num\\");
    strcat(tmp, get_input(manager_login(false), "user"));
    fp = fopen(tmp, "rb");
    strcpy(tmp1, "data\\boss\\");
    strcat(tmp1, get_input(manager_login(false), "user"));
    fp1 = fopen(tmp1, "rb");
    if (fp == NULL)
    {
        print_login_msg("��¼ʧ�ܣ��û������ڣ�");
        paint(1);
    } else
    {
        remember_id(get_input(manager_login(false), "user"));
        fgets(tmp, 45, fp);
        fclose(fp);
        if (!strcmp(tmp, get_input(manager_login(false), "password")))
        {
            fgets(tmp1, 30, fp1);
            fclose(fp1);
            if (ismanager(remember_id(NULL)))
            {
                print_login_msg("��ӭʹ�ñ�ϵͳ��");
                paint(3);
            } else
            {
                print_login_msg("��ӭʹ�ñ�ϵͳ��");
                paint(9);
            }
        } else
        {
            print_login_msg("��¼ʧ�ܣ��������");
            paint(1);
        }
    }
}

void draw_login()
{
    Picture(0, 0, "res\\login.bmp");
    tick_init(manager_login(true));
    print_login_msg(NULL);
    set_functions(login_click, login_key, login_move);
}
