#include "HsOS.h"
#include "page.h"
#include "project.h"
#include "string.h"
#include "stdio.h"
#include "login.h"
#include "general.h"

elements *manager_project(bool init)
{
  static elements *project_data = NULL;
  if (init)
  {
    if (isnull(project_data))
    {
      element *btn;
      btn = new_button(0, 0, 60, 30, "����", IvoryWhite, 0xfded, 0x4227, project_mainpage_click);
      project_data = push(btn, NULL);
      btn = new_input(571, 233, 919, 277, "pro_id", 8, BLACK, WHITE, IvoryWhite, false, false);
      project_data = push(btn, project_data);
      btn = new_input(571, 328, 919, 372, "pro_per", 8, BLACK, WHITE, IvoryWhite, false, false);
      project_data = push(btn, project_data);
      btn = new_input(571, 423, 919, 467, "pro_mat", 33, BLACK, WHITE, IvoryWhite, false, false);
      project_data = push(btn, project_data);
      btn = new_input(571, 518, 919, 602, "pro_mark", 30, BLACK, WHITE, IvoryWhite, false, true);
      project_data = push(btn, project_data);
      btn = new_button(555, 681, 761, 725, "��������", IvoryWhite, 0xfded, 0x4227, create_project);
      project_data = push(btn, project_data);
      btn = new_input(800, 0, 923, 50, "search_id", 10, BLACK, WHITE, IvoryWhite, false, false);
      project_data = push(btn, project_data);
      btn = new_button(924, 0, 1024, 50, "��������", IvoryWhite, 0xfded, 0x4227, search_project);
      project_data = push(btn, project_data);
      btn = new_button(312, 0, 451, 45, "�����б�", IvoryWhite, 0xfded, 0x4227, project_list);
      project_data = push(btn, project_data);
    }
  }
  return project_data;
}

void project_list()
{
  paint(10);
}

void search_project()
{
  const char *tmp;
  char tmp1[25];
  char *qwqwq = "search_id";
  FILE *fp;
  tmp = get_input(manager_project(false), qwqwq);
  strcpy(tmp1, "data\\project\\per\\");
  strcat(tmp1, tmp);
  fp = fopen(tmp1, "rb");
  if (fp == NULL)
  {
    print_pro_msg("������Ų�����");
    paint(5);
  }
  else
  {
    fclose(fp);
    remember_pro_id(tmp);
    paint(8);
  }
}

void create_project()
{
  const char *id, *user, *mats, *note;
  char tmp[40];
  char *s1, heap[40];
  int top = 0;
  bool can_save = true;
  FILE *fp;
  id = get_input(manager_project(false), "pro_id");
  user = get_input(manager_project(false), "pro_per");
  mats = get_input(manager_project(false), "pro_mat");
  note = get_input(manager_project(false), "pro_mark");
  // �����Ƿ����
  if (strlen(id) == 0)
  {
    print_pro_msg("����Ų���Ϊ��");
  }
  else if (strlen(user) == 0)
  {
    print_pro_msg("��ί���˲���Ϊ��");
  }
  else if (strlen(mats) == 0)
  {
    print_pro_msg("�й���Դ����Ϊ��");
  }
  else if (strlen(note) == 0)
  {
    print_pro_msg("����Ŀ�겻��Ϊ��");
  }
  else
  {
    // ������ί����
    strcpy(tmp, "data\\num\\");
    strcat(tmp, user);
    fp = fopen(tmp, "rb");
    if (fp == NULL)
    {
      print_pro_msg("��ί���˲�����");
    }
    else
    {
      fclose(fp);
      if (id_person_material_is_right(user))
      {
        strcpy(tmp, "data\\boss\\");
        strcat(tmp, user);
        fp = fopen(tmp, "rb");
        fscanf(fp, "%s", tmp);
        fclose(fp);
        if (!strcmp(tmp, "true"))
        {
          print_pro_msg("��ί���˲���Ϊ����Ա");
        }
        else
        {
          // ������Դ
          if (id_person_material_is_right(mats))
          {
            strcpy(tmp, mats);
            strcat(tmp, ",");
            for (s1 = tmp; *s1 != '\0'; s1++)
            {
              if (*s1 == ',')
              {
                strcpy(tmp, "data\\material\\");
                strcat(tmp, heap);
                fp = fopen(tmp, "rb");
                if (fp == NULL)
                {
                  print_pro_msg("�й���Դ������");
                  can_save = false;
                  break;
                }
                else
                {
                  fclose(fp);
                }
                top = 0;
              }
              else
              {
                heap[top++] = *s1;
                heap[top] = '\0';
              }
            }
            if (can_save)
            {
              // ���������
              strcpy(tmp, "data\\project\\per\\");
              strcat(tmp, id);
              fp = fopen(tmp, "rb");
              if (fp != NULL)
              {
                print_pro_msg("������ظ�");
                fclose(fp);
              }
              else
              {
                fclose(fp);
                if (id_person_material_is_right(id))
                {
                  fp = fopen(tmp, "wb");
                  fprintf(fp, "%s", user);
                  fclose(fp);
                  // ��������
                  strcpy(tmp, "data\\project\\mat\\");
                  strcat(tmp, id);
                  fp = fopen(tmp, "wb");
                  if (fp == NULL)
                  {
                    draw_error("FileSystem Panicked",
                               "project.c::create_project | Can not create mat!");
                  }
                  else
                  {
                    fprintf(fp, "%s", mats);
                    fclose(fp);
                  }
                  // ��������״̬�ļ�
                  strcpy(tmp, "data\\project\\state\\");
                  strcat(tmp, id);
                  fp = fopen(tmp, "wb");
                  if (fp == NULL)
                  {
                    draw_error("FileSystem Panicked",
                               "project.c::create_project | Can not create state!");
                  }
                  else
                  {
                    fprintf(fp, "%s", "δ���");
                    fclose(fp);
                  }
                  // ��������Ŀ���ļ�
                  strcpy(tmp, "data\\project\\mark\\");
                  strcat(tmp, id);
                  fp = fopen(tmp, "w");
                  if (fp == NULL)
                  {
                    draw_error("FileSystem Panicked",
                               "project.c::create_project | Can not create mark!");
                  }
                  else
                  {
                    if (strlen(note) < 2)
                    {
                      draw_error("FileSystem Panicked", "project.c::create_project | NPE!");
                    }
                    fprintf(fp, "%s\n", note);
                    fclose(fp);
                    print_pro_msg("�����ɹ�");
                  }
                }
                else
                {
                  print_pro_msg("����Ų����Ϲ淶");
                }
              }
            }
          }
          else
          {
            print_pro_msg("�й���Դ������");
          }
        }
      }
      else
      {
        print_pro_msg("��ί���˲�����");
      }
    }
  }
  paint(5);
}

void project_click()
{
  tick_click(manager_project(false));
}

void project_key(int i)
{
  tick_key(manager_project(false), i);
}

void project_move()
{
  tick_move(manager_project(false));
}

void project_mainpage_click()
{
  paint(3);
}

void draw_project()
{
  Picture(0, 0, "res\\people.bmp");
  background();
  print_pro_msg(NULL);
  Box(497, 95, 789, 187, BLACK, 7);
  Text(600, 130, "�������", BLACK);
  Box(425, 233, 549, 277, BLACK, 3);
  Text(429, 237, "�����", BLACK);
  Box(425, 328, 549, 372, BLACK, 3);
  Text(429, 332, "��ί����", BLACK);
  Box(425, 423, 549, 467, BLACK, 3);
  Text(429, 427, "�й���Դ", BLACK);
  Box(425, 518, 549, 562, BLACK, 3);
  Text(429, 522, "����Ŀ��", BLACK);
  tick_init(manager_project(true));
  set_functions(project_click, project_key, project_move);
}
