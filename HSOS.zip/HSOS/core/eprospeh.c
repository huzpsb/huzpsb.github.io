#include "HsOS.h"
#include "page.h"
#include "string.h"
#include "stdio.h"
#include "eprospeh.h"
#include "general.h"
#include "empromap.h"

elements *manager_eprospeh(bool init)
{
    static elements *eprospeh_data = NULL;
    element *btn;
    if (init)
    {
        if (isnull(eprospeh_data))
        {
            btn = new_button(0, 0, 60, 30, "����", IvoryWhite, 0xfded, 0x4227, eprospeh_empromap_click);
            eprospeh_data = push(btn, NULL);
            btn = new_button(384, 548, 532, 605, "ȷ�Ͻ���", IvoryWhite, 0xfded, 0x4227, eprospeh_building1);
            eprospeh_data = push(btn, eprospeh_data);
            btn = new_button(592, 548, 740, 605, "ȷ�Ͻ���", IvoryWhite, 0xfded, 0x4227, eprospeh_building2);
            eprospeh_data = push(btn, eprospeh_data);
            btn = new_button(800, 548, 948, 605, "ȷ�Ͻ���", IvoryWhite, 0xfded, 0x4227, eprospeh_building3);
            eprospeh_data = push(btn, eprospeh_data);
        }
    }
    return eprospeh_data;
}

void eprospeh_click()
{
    tick_click(manager_eprospeh(false));
}

void eprospeh_key(int i)
{
    tick_key(manager_eprospeh(false), i);
}

void eprospeh_move()
{
    tick_move(manager_eprospeh(false));
}

void eprospeh_building1()
{
    eprospeh_building(1);
}

void eprospeh_building2()
{
    eprospeh_building(2);
}

void eprospeh_building3()
{
    eprospeh_building(3);
}

void eprospeh_building(int i)
{
    switch (i)
    {
        case 1:
            if (check_material_num("concrete", 5) && check_material_num("rebar", 10) && check_material_num("nano", 6) &&
                check_material_num("robot", 10))
            {
                eprospeh_decrease("concrete", 5);
                eprospeh_decrease("rebar", 10);
                eprospeh_decrease("nano", 6);
                eprospeh_decrease("robot", 10);
                Picture_house(1, remember_emprospe_building(0, 0), -1, -1);
                progress_bar(501, 692, 814, 723, 5);
                eprospeh_text("�����");
                paint(16);
            } else
            {
                eprospeh_text("���ϲ���");
            }
            break;
        case 2:
            if (check_material_num("concrete", 3) && check_material_num("rebar", 2) && check_material_num("nano", 4) &&
                check_material_num("wood", 7) && check_material_num("robot", 3))
            {
                eprospeh_decrease("concrete", 3);
                eprospeh_decrease("rebar", 2);
                eprospeh_decrease("nano", 4);
                eprospeh_decrease("wood", 7);
                eprospeh_decrease("robot", 3);
                Picture_house(2, remember_emprospe_building(0, 0), -1, -1);
                progress_bar(501, 692, 814, 723, 5);
                eprospeh_text("�����");
                paint(16);
            } else
            {
                eprospeh_text("���ϲ���");
            }
            break;
        case 3:
            if (check_material_num("concrete", 5) && check_material_num("rebar", 8) && check_material_num("nano", 6) &&
                check_material_num("robot", 5))
            {
                eprospeh_decrease("concrete", 5);
                eprospeh_decrease("rebar", 8);
                eprospeh_decrease("nano", 6);
                eprospeh_decrease("robot", 5);
                Picture_house(3, remember_emprospe_building(0, 0), -1, -1);
                progress_bar(501, 692, 814, 723, 5);
                eprospeh_text("�����");
                paint(16);
            } else
            {
                eprospeh_text("���ϲ���");
            }
            break;
        default:
            break;
    }
}

void eprospeh_empromap_click()
{
    paint(16);
}

void eprospeh_decrease(char *text, int y)
{
    char tmp[100];
    char tmp1[30];
    FILE *fp;
    int x;
    x = getCount(text);
    x -= y;
    strcpy(tmp1, "data\\material\\");
    strcat(tmp1, text);
    fp = fopen(tmp1, "rb");
    fscanf(fp, "%s", tmp1);
    fclose(fp);
    // draw_error(tmp1, "hhh");
    strcpy(tmp, "�û�");
    strcat(tmp, remember_id(NULL));
    strcat(tmp, "������");
    strcat(tmp, remember_empro(0));
    strcat(tmp, "��������");
    strcat(tmp, toString(y));
    strcat(tmp, "����λ��");
    strcat(tmp, tmp1);
    strcat(tmp, "�����ࣺ");
    strcat(tmp, toString(x));
    ms_append(text, transform(tmp));
    ms_append(text, "\n");
    setCount(text, x);
}

void draw_emprospe_house()
{
    Picture(0, 0, "res\\people.bmp");
    background();
    Box(369, 108, 555, 638, BLACK, 5);
    Box(577, 108, 763, 638, BLACK, 5);
    Box(785, 108, 971, 638, BLACK, 5);
    Picture(412, 130, "res\\7.bmp");
    Picture(640, 150, "res\\3.bmp");
    Picture(848, 150, "res\\6.bmp");
    Text(420, 260, "ͨ�÷���", BLACK);
    Text(630, 260, "һ��ֿ�", BLACK);
    Text(830, 260, "����ֿ�", BLACK);
    Text(435, 295, "��Ҫ", BLACK);
    Text(645, 295, "��Ҫ", BLACK);
    Text(845, 295, "��Ҫ", BLACK);
    Text(409, 325, "������", BLACK);
    EngText(489, 325 + 3, ":5", BLACK);
    Text(409, 370, "�ֽ�", BLACK);
    EngText(465, 370 + 3, ":10", BLACK);
    Text(409, 415, "���ײ���", BLACK);
    EngText(513, 415 + 3, ":6", BLACK);
    Text(409, 460, "������", BLACK);
    EngText(489, 460 + 3, ":10", BLACK);
    Text(617, 325, "������", BLACK);
    EngText(697, 325 + 3, ":3", BLACK);
    Text(617, 370, "�ֽ�", BLACK);
    EngText(673, 370 + 3, ":2", BLACK);
    Text(617, 415, "���ײ���", BLACK);
    EngText(721, 415 + 3, ":4", BLACK);
    Text(617, 460, "ľͷ", BLACK);
    EngText(673, 460 + 3, ":7", BLACK);
    Text(617, 505, "������", BLACK);
    EngText(697, 505 + 3, ":3", BLACK);
    Text(825, 325, "������", BLACK);
    EngText(905, 325 + 3, ":5", BLACK);
    Text(825, 370, "�ֽ�", BLACK);
    EngText(881, 370 + 3, ":8", BLACK);
    Text(825, 415, "���ײ���", BLACK);
    EngText(929, 415 + 3, ":6", BLACK);
    Text(825, 460, "������", BLACK);
    EngText(905, 460 + 3, ":5", BLACK);
    tick_init(manager_eprospeh(true));
    set_functions(eprospeh_click, eprospeh_key, eprospeh_move);
}
