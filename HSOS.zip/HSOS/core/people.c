// Reviewed by huzpsb 2023/04/05. Three warnings. Approved.

#include "HsOS.h"
#include "page.h"
#include "people.h"
#include "string.h"
#include "stdio.h"
#include "login.h"
#include "general.h"

elements *manager_people(bool init)
{
    static elements *people_data = NULL;
    int x1 = 347, y1 = 57;
    element *btn;
    if (init)
    {
        if (isnull(people_data))
        {
            btn = new_button(0, 0, 60, 30, "����", IvoryWhite, 0xfded, 0x4227, people_mainpage_click);
            people_data = push(btn, NULL);
            btn = new_button(351, 697, 451, 735, "��һҳ", IvoryWhite, 0xfded, 0x4227, last_page);
            people_data = push(btn, people_data);
            btn = new_button(917, 697, 1017, 735, "��һҳ", IvoryWhite, 0xfded, 0x4227, next_page);
            people_data = push(btn, people_data);
            btn = new_button(x1, y1 + 118, x1 + 183, y1 + 173, "����", IvoryWhite, 0xfded, 0x4227, people_person1);
            people_data = push(btn, people_data);
            btn = new_button(x1 + 234, y1 + 118, x1 + 183 + 234, y1 + 173, "����", IvoryWhite, 0xfded, 0x4227,
                             people_person2);
            people_data = push(btn, people_data);
            btn = new_button(x1 + 468, y1 + 118, x1 + 183 + 468, y1 + 173, "����", IvoryWhite, 0xfded, 0x4227,
                             people_person3);
            people_data = push(btn, people_data);
            btn = new_button(x1, y1 + 118 + 226, x1 + 183, y1 + 173 + 226, "����", IvoryWhite, 0xfded, 0x4227,
                             people_person4);
            people_data = push(btn, people_data);
            btn = new_button(x1 + 234, y1 + 118 + 226, x1 + 183 + 234, y1 + 173 + 226, "����", IvoryWhite, 0xfded, 0x4227,
                             people_person5);
            people_data = push(btn, people_data);
            btn = new_button(x1 + 468, y1 + 118 + 226, x1 + 183 + 468, y1 + 173 + 226, "����", IvoryWhite, 0xfded, 0x4227,
                             people_person6);
            people_data = push(btn, people_data);
            btn = new_button(x1, y1 + 118 + 452, x1 + 183, y1 + 173 + 452, "����", IvoryWhite, 0xfded, 0x4227,
                             people_person7);
            people_data = push(btn, people_data);
            btn = new_button(x1 + 234, y1 + 118 + 452, x1 + 183 + 234, y1 + 173 + 452, "����", IvoryWhite, 0xfded, 0x4227,
                             people_person8);
            people_data = push(btn, people_data);
            btn = new_button(x1 + 468, y1 + 118 + 452, x1 + 183 + 468, y1 + 173 + 452, "����", IvoryWhite, 0xfded, 0x4227,
                             people_person9);
            people_data = push(btn, people_data);
        }
    }
    return people_data;
}

void people_click()
{
    tick_click(manager_people(false));
}

void people_key(int i)
{
    tick_key(manager_people(false), i);
}

void people_move()
{
    tick_move(manager_people(false));
}

elements *manager_person(bool init)
{
    static elements *person_data = NULL;
    element *btn;
    if (init)
    {
        if (isnull(person_data))
        {
            btn = new_button(0, 0, 60, 30, "����", IvoryWhite, 0xfded, 0x4227, person_people_click);
            person_data = push(btn, NULL);
            btn = new_button(818, 340, 954, 376, "ȷ���޸�", IvoryWhite, 0xfded, 0x4227, change_boss);
            person_data = push(btn, person_data);
            btn = new_button(818, 507, 954, 543, "ȷ���޸�", IvoryWhite, 0xfded, 0x4227, change_work);
            person_data = push(btn, person_data);
            btn = new_button(818, 674, 954, 710, "ȷ���޸�", IvoryWhite, 0xfded, 0x4227, change_phone);
            person_data = push(btn, person_data);
            btn = new_input(424, 340, 773, 376, "boss", 15, BLACK, WHITE, IvoryWhite, false, false);
            person_data = push(btn, person_data);
            btn = new_input(424, 507, 773, 543, "work", 15, BLACK, WHITE, IvoryWhite, false, true);
            person_data = push(btn, person_data);
            btn = new_input(424, 674, 773, 710, "phone", 15, BLACK, WHITE, IvoryWhite, false, false);
            person_data = push(btn, person_data);
            btn = new_button(736, 104, 928, 171, "ɾ������", IvoryWhite, 0xfded, 0x4227, delete_person);
            person_data = push(btn, person_data);
        }
    }
    return person_data;
}

void person_click()
{
    tick_click(manager_person(false));
}

void person_key(int i)
{
    tick_key(manager_person(false), i);
}

void person_move()
{
    tick_move(manager_person(false));
}

void delete_person()
{
    char tmp[50];
    IFileList("C:\\HSOS\\data\\work\\*");
    strcpy(tmp, "C:\\HSOS\\data\\phone\\");
    strcat(tmp, IFileGet(remember_person(-1)));
    IFileDelete(tmp);
    strcpy(tmp, "C:\\HSOS\\data\\work\\");
    strcat(tmp, IFileGet(remember_person(-1)));
    IFileDelete(tmp);
    strcpy(tmp, "C:\\HSOS\\data\\boss\\");
    strcat(tmp, IFileGet(remember_person(-1)));
    IFileDelete(tmp);
    strcpy(tmp, "C:\\HSOS\\data\\num\\");
    strcat(tmp, IFileGet(remember_person(-1)));
    IFileDelete(tmp);
    Bar(312, 0, 1024, 768, 0x867e);
    draw_people_page(change_page(3));
    set_functions(people_click, people_key, people_move);
    tick_init(manager_people(true));
    update_mouse(0, 0, 1024, 768);
    mouse.x = 1;
    mouse.y = 1;
    tick_move(manager_people(false));
    mouse.x = 100;
    mouse.y = 1;
    tick_move(manager_people(false));
    mouse.x = 1;
    mouse.y = 1;
    tick_move(manager_people(false));
}

void person_people_click()
{
    Picture(311, 0, "res\\back2.bmp");
    draw_people_page(change_page(3));
    set_functions(people_click, people_key, people_move);
    tick_init(manager_people(true));
    tick_click(NULL);
    mouse.x = 1;
    mouse.y = 1;
    tick_move(manager_people(false));
    mouse.x = 100;
    mouse.y = 1;
    tick_move(manager_people(false));
    mouse.x = 1;
    mouse.y = 1;
    tick_move(manager_people(false));
}

void change_boss()
{
    char tmp[50];
    FILE *fp;
    IFileList("C:\\HSOS\\data\\work\\*");
    strcpy(tmp, "data\\boss\\");
    strcat(tmp, IFileGet(remember_person(-1)));
    fp = fopen(tmp, "wb");
    fprintf(fp, "%s", get_input(manager_person(false), "boss"));
    fclose(fp);
    Bar(550, 284, 827, 315, 0x867e);
    EngText(554, 290, get_input(manager_person(false), "boss"), BLACK);
    strcpy(get_input(manager_person(false), "boss"), "\0");
    Bar(425, 341, 772, 375, IvoryWhite);
}

void change_work()
{
    char tmp[50];
    FILE *fp;
    IFileList("C:\\HSOS\\data\\work\\*");
    strcpy(tmp, "data\\work\\");
    strcat(tmp, IFileGet(remember_person(-1)));
    fp = fopen(tmp, "wb");
    fprintf(fp, "%s", get_input(manager_person(false), "work"));
    fclose(fp);
    Bar(550, 456, 827, 498, 0x867e);
    Text(554, 458, get_input(manager_person(false), "work"), BLACK);
    strcpy(get_input(manager_person(false), "work"), "\0");
    Bar(425, 508, 772, 542, IvoryWhite);
}

void change_phone()
{
    char tmp[50];
    FILE *fp;
    IFileList("C:\\HSOS\\data\\work\\*");
    strcpy(tmp, "data\\phone\\");
    strcat(tmp, IFileGet(remember_person(-1)));
    fp = fopen(tmp, "wb");
    fprintf(fp, "%s", get_input(manager_person(false), "phone"));
    fclose(fp);
    Bar(550, 620, 827, 660, 0x867e);
    fp = fopen(tmp, "rb");
    fscanf(fp, "%s", tmp);
    EngText(554, 624, tmp, BLACK);
    fclose(fp);
    strcpy(get_input(manager_person(false), "phone"), "\0");
    Bar(425, 675, 772, 709, IvoryWhite);
}

void people_mainpage_click()
{
    paint(3);
}


void draw_people_page(int page)
{
    int i, j, x1 = 347, y1 = 57;
    IFileList("C:\\HSOS\\data\\work\\*");
    i = IFileCount();
    for (j = (page - 1) * 9; j < page * 9; j++)
    {
        Bar(x1 + (j % 3) * 234, y1 + ((j - (page - 1) * 9) / 3) * 226, x1 + (j % 3) * 234 + 183,
            y1 + ((j - (page - 1) * 9) / 3) * 226 + 118, MAR_ORANGE);
        if (j < i)
            EngText(x1 + (j % 3) * 234 + 10, y1 + ((j - (page - 1) * 9) / 3) * 226 + 5, IFileGet(j), IvoryWhite);
        else
            Text(x1 + (j % 3) * 234 + 10, y1 + ((j - (page - 1) * 9) / 3) * 226 + 5, "��", IvoryWhite);
    }
}

int change_page(int init)
{
    static int now_page = 1;
    int Total_page, i;
    IFileList("C:\\HSOS\\data\\work\\*");
    i = IFileCount();
    if (i % 9 != 0)
        Total_page = i / 9 + 1;
    else
        Total_page = i / 9;
    if (init == 1)
    {
        if (now_page < Total_page)
            now_page = now_page + 1;
    } else if (init == 2)
    {
        if (now_page > 1)
            now_page = now_page - 1;
    } else if (init == 4)
    {
        now_page = 1;
    }
    return now_page;
}

void next_page()
{
    draw_people_page(change_page(1));
}

void last_page()
{
    draw_people_page(change_page(2));
}

void people_person1()
{
    if (isexist_people(1))
    {
        draw_person_page(1);
    }
}

void people_person2()
{

    if (isexist_people(2))
    {
        draw_person_page(2);
    }
}

void people_person3()
{

    if (isexist_people(3))
    {
        draw_person_page(3);
    }
}

void people_person4()
{

    if (isexist_people(4))
    {
        draw_person_page(4);
    }
}

void people_person5()
{

    if (isexist_people(5))
    {
        draw_person_page(5);
    }
}

void people_person6()
{

    if (isexist_people(6))
    {
        draw_person_page(6);
    }
}

void people_person7()
{

    if (isexist_people(7))
    {
        draw_person_page(7);
    }
}

void people_person8()
{

    if (isexist_people(8))
    {
        draw_person_page(8);
    }
}

void people_person9()
{

    if (isexist_people(9))
    {
        draw_person_page(9);
    }
}

void draw_person_page(int num)
{
    int page, p;
    char tmp3[50];
    char tmp4[50];
    char tmp5[50];
    char tmp6[50];
    char qr[100];
    FILE *fp1;

    // ��Ա����
    page = change_page(3);
    p = (page - 1) * 9 + num - 1;
    remember_person(p);
    IFileList("C:\\HSOS\\data\\work\\*");
    strcpy(tmp3, "data\\boss\\");
    strcat(tmp3, IFileGet(p));
    fp1 = fopen(tmp3, "rb");
    fscanf(fp1, "%s", tmp3);
    fclose(fp1);
    if (!strcmp(transform_Atoa(IFileGet(p)), transform_Atoa(remember_id(NULL))))
    {
        // paint(4);
        Text(550, 693, "����Ա�����޸��Լ�����Ϣ", BLACK);
    } else
    {
        // �����ʼ��
        Bar(312, 0, 1024, 768, 0x867e);
        Text(385, 288, "����Ա����", BLACK);
        Text(385, 456, "ְλ", BLACK);
        Text(385, 621, "�绰", BLACK);
        EngText(554, 290, tmp3, BLACK);
        strcpy(tmp4, "data\\work\\");
        strcat(tmp4, IFileGet(p));
        fp1 = fopen(tmp4, "rb");
        fscanf(fp1, "%s", tmp4);
        Text(554, 458, tmp4, BLACK);
        fclose(fp1);
        strcpy(tmp5, "data\\phone\\");
        strcat(tmp5, IFileGet(p));
        fp1 = fopen(tmp5, "rb");
        fscanf(fp1, "%s", tmp5);
        EngText(554, 624, tmp5, BLACK);
        fclose(fp1);
        strcpy(tmp6, "res\\");
        strcat(tmp6, IFileGet(p));
        strcat(tmp6, ".bmp");
        Text(385, 220, "�û���", BLACK);
        EngText(485, 223, IFileGet(p), BLACK);
        fp1 = fopen(tmp6, "r");
        if (fp1 == NULL)
        {
            Picture(385, 77, "res\\aperson.bmp");
            sprintf(qr,
                    "BEGIN:VCARD\nVERSION:2.1\nN:%s\nTEL:%s\nEMAIL:%s@HustMars.edu.cn\nORG:HUST\nPHOTO;TYPE=JPEG;VALUE=URI:http://38.60.35.180/qwqrt/%s.bmp\nEND:VCARD",
                    IFileGet(p), tmp5, IFileGet(p), "aperson");
        } else
        {
            fclose(fp1);
            Picture(385, 77, tmp6);
            sprintf(qr,
                    "BEGIN:VCARD\nVERSION:2.1\nN:%s\nTEL:%s\nEMAIL:%s@HustMars.edu.cn\nORG:HUST\nPHOTO;TYPE=JPEG;VALUE=URI:http://38.60.35.180/qwqrt/%s.bmp\nEND:VCARD",
                    IFileGet(p), tmp5, IFileGet(p), IFileGet(p));
        }
        draw_qr(qr, 687, 208);
        tick_init(manager_person(true));
        update_mouse(0, 0, SCR_WIDTH, SCR_HEIGHT);
        set_functions(person_click, person_key, person_move);
    }
}

void draw_people()
{
    Picture(0, 0, "res\\people.bmp");
    background();
    draw_people_page(change_page(4));
    tick_init(manager_people(true));
    set_functions(people_click, people_key, people_move);
}
