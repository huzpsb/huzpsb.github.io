// Reviewed by huzpsb 2023/04/05. One error and two warnings. Approved.

#include "HsOS.h"
#include "page.h"
#include "string.h"
#include "starport.h"
#include "stdio.h"
#include "general.h"

elements *manager_starport(bool init)
{
    static elements *starport_data = NULL;
    element *btn;
    if (init)
    {
        if (isnull(starport_data))
        {
            btn = new_button(0, 0, 60, 30, "����", IvoryWhite, 0xfded, 0x4227, starport_material_click);
            starport_data = push(btn, NULL);
            btn = new_input(374, 321, 597, 365, "mat_increase", 4, BLACK, WHITE, IvoryWhite, false, false);
            starport_data = push(btn, starport_data);
            btn = new_button(433, 408, 539, 446, "���", IvoryWhite, 0xfded, 0x4227, starport_add);
            starport_data = push(btn, starport_data);
        }
    }
    return starport_data;
}

void starport_click()
{
    tick_click(manager_starport(false));
}

void starport_key(int i)
{
    tick_key(manager_starport(false), i);
}

void starport_move()
{
    tick_move(manager_starport(false));
}

void starport_material_click()
{
    paint(6);
}

void starport_add()
{
    char tmp[100];
    char tmp1[30];
    FILE *fp;
    long x, y;
    x = getCount(remember_material(0));
    y = atoi(get_input(manager_starport(false), "mat_increase"));
    if (y > 10000)
    {
        starport_text("��Դ�����Ƿ�");
    } else if (y <= 0)
    {
        starport_text("��Դ�仯������Ϊ����");
    } else if (x + y > 10000)
    {
        starport_text("��Դ������������");
    } else
    {
        x += y;
        strcpy(tmp1, "data\\material\\");
        strcat(tmp1, remember_material(0));
        fp = fopen(tmp1, "rb");
        fscanf(fp, "%s", tmp1);
        fclose(fp);
        // draw_error(remember_empro_mat(NULL), tmp1);
        strcpy(tmp, "�û�");
        strcat(tmp, remember_id(NULL));
        strcat(tmp, "�����");
        strcat(tmp, toString(y));
        strcat(tmp, "����λ��");
        strcat(tmp, tmp1);
        strcat(tmp, "�����ࣺ");
        strcat(tmp, toString(x));
        ms_append(remember_material(0), transform(tmp));
        ms_append(remember_material(0), "\n");
        setCount(remember_material(0), x);
        progress_bar(357, 467, 618, 500, 5);
        Bar(361, 520, 634, 568, WHITE);
        Text(447, 543, "�����", BLACK);
        strcpy(get_input(manager_starport(false), "mat_increase"), "\0");

        // paint(11);
    }
}

void draw_starport()
{
    char tmp1[30];
    FILE *fp;
    Box(259, 187, 733, 618, BLACK, 5);
    strcpy(tmp1, "data\\material\\");
    strcat(tmp1, remember_material(0));
    fp = fopen(tmp1, "rb");
    fscanf(fp, "%s", tmp1);
    fclose(fp);
    // draw_error(tmp1, remember_material(NULL));
    Box(427, 218, 539, 269, BLACK, 3);
    Text(432, 223, tmp1, BLACK);
    tick_init(manager_starport(true));
    set_functions(starport_click, starport_key, starport_move);
}
