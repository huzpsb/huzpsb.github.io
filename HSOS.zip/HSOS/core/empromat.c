#include "HsOS.h"
#include "page.h"
#include "string.h"
#include "stdio.h"
#include "general.h"
#include "emprospe.h"
#include "empromat.h"


elements *manager_empromat(bool init)
{
    static elements *empromat_data = NULL;
    element *btn;
    if (init)
    {
        if (isnull(empromat_data))
        {
            btn = new_button(561, 291, 617, 340, "����", IvoryWhite, 0xfded, 0x4227, empromat_emprospe_click);
            empromat_data = push(btn, NULL);
        }
    }
    return empromat_data;
}

void empromat_emprospe_click()
{
    isexpand(0);
    Picture(470, 341, "res\\a.bmp");
    tick_init(manager_emprospe(true));
    set_functions(emprospe_click, emprospe_key, emprospe_move);
    // paint(11);
}

void empromat_click()
{
    if (isexpand(2))
    {
        char mat[10][10];
        int n = 0, x1 = 470, y1 = 340, i;
        char tmp[30];
        FILE *fp;
        strcpy(tmp, "data\\project\\mat\\");
        strcat(tmp, remember_empro(0));
        fp = fopen(tmp, "rb");
        fscanf(fp, "%s", tmp);
        fclose(fp);
        pro_mat_divide(mat, tmp, &n);
        for (i = 0; i < n; i++)
        {
            if (mouse.x > x1 && mouse.x < x1 + 90 && mouse.y > y1 + i * 30 && mouse.y < y1 + (i + 1) * 30)
            {
                // draw_error(toString(i), "\b");
                remember_empro_mat(mat[i]);
                strcpy(tmp, "data\\material\\");
                strcat(tmp, remember_empro_mat(NULL));
                fp = fopen(tmp, "rb");
                fscanf(fp, "%s", tmp);
                fclose(fp);
                Bar(472, 293, 558, 338, WHITE);
                Text(473, 294, tmp, BLACK);
            }
        }
    }
    tick_click(manager_empromat(false));
}

void empromat_key(int i)
{
    tick_key(manager_empromat(false), i);
}

void empromat_move()
{
    tick_move(manager_empromat(false));
}

void draw_emprospe_matlist()
{
    char mat[10][10];
    int n1 = 0, x1 = 470, y1 = 340, i;
    char tmp[30];
    FILE *fp;
    strcpy(tmp, "data\\project\\mat\\");
    strcat(tmp, remember_empro(0));
    fp = fopen(tmp, "rb");
    fscanf(fp, "%s", tmp);
    fclose(fp);
    pro_mat_divide_chinese(mat, tmp, &n1);
    for (i = 0; i < n1; i++)
    {
        Bar(x1, y1 + i * 30, x1 + 90, y1 + (i + 1) * 30, LIGHT_BLUE);
        Text(x1 + 1, y1 + i * 30 + 1, mat[i], BLACK);
    }
    Bar(561, 341, 617, 353, WHITE);
    Bar(617, 291, 650, 340, WHITE);
    tick_init(manager_empromat(true));
    set_functions(empromat_click, empromat_key, empromat_move);
}
