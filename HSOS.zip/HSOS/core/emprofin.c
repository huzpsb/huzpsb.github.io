#include "HsOS.h"
#include "page.h"
#include "string.h"
#include "stdio.h"
#include "general.h"
#include "emprofin.h"
#include "general.h"

elements *manager_emprofin(bool init)
{
    static elements *emprofin_data = NULL;
    element *btn;
    if (init)
    {
        if (isnull(emprofin_data))
        {
            btn = new_button(0, 0, 60, 30, "����", IvoryWhite, 0xfded, 0x4227, emprofin_empro_click);
            emprofin_data = push(btn, NULL);
            btn = new_button(406, 426, 534, 530, "��������", IvoryWhite, 0xfded, 0x4227, change_finish_project);
            emprofin_data = push(btn, emprofin_data);
        }
    }
    return emprofin_data;
}

void emprofin_empro_click()
{
    paint(10);
}

void emprofin_click()
{
    tick_click(manager_emprofin(false));
}

void emprofin_key(int i)
{
    tick_key(manager_emprofin(false), i);
}

void emprofin_move()
{
    tick_move(manager_emprofin(false));
}

void change_finish_project()
{
    char tmp[50];
    FILE *fp;
    if ((strcmp(remember_empro(0), "001") == 0) || (strcmp(remember_empro(0), "002") == 0) ||
        (strcmp(remember_empro(0), "003") == 0))
    {
        Bar(550, 640, 850, 700, WHITE);
        Text(550, 650, "�������ܱ�����", BLACK);
    } else
    {
        strcpy(tmp, "data\\project\\state\\");
        strcat(tmp, remember_empro(0));
        fp = fopen(tmp, "wb");
        fprintf(fp, "%s", "δ���");
        fclose(fp);
        emprospe_text("��ӭʹ�ñ�ϵͳ");
        if (vague_semantic_recognition_project(remember_empro(0)) == 1)
        {
            paint(11);
        } else if (vague_semantic_recognition_project(remember_empro(0)) == 2)
        {
            paint(15);
        } else if (vague_semantic_recognition_project(remember_empro(0)) == 3)
        {
            paint(14);
        }
    }
}

void draw_emprofin()
{
    char tmp[30];
    char tmp1[30];
    FILE *fp;
    strcpy(tmp, remember_empro(0));
    Picture(0, 0, "res\\people.bmp");
    Box(583, 43, 754, 89, BLACK, 3);
    Text(640, 54, "����", BLACK);
    Box(365, 132, 985, 724, BLACK, 5);
    EngText(648, 145, tmp, BLACK);
    Text(421, 222, "����Ŀ��", BLACK);
    strcpy(tmp1, "data\\project\\mark\\");
    strcat(tmp1, tmp);
    fp = fopen(tmp1, "rb");
    fscanf(fp, "%s", tmp1);
    fclose(fp);
    Text(569, 217, tmp1, BLACK);
    background();
    show_map();
    emprospe_text(NULL);
    tick_init(manager_emprofin(true));
    set_functions(emprofin_click, emprofin_key, emprofin_move);
}
