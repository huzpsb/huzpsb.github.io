#include "HsOS.h"
#include "page.h"
#include "string.h"
#include "destroy.h"
#include "general.h"

elements *manager_destroy(bool init)
{
    static elements *destroy_data = NULL;
    element *btn;
    if (init)
    {
        if (isnull(destroy_data))
        {

            btn = new_button(300, 605, 370, 629, "ȷ��", IvoryWhite, 0xfded, 0x4227, sure_destroy_click);
            destroy_data = push(btn, NULL);
            btn = new_button(380, 605, 450, 629, "ȡ��", IvoryWhite, 0xfded, 0x4227, destroy_empromap_click);
            destroy_data = push(btn, destroy_data);
        }
    }
    return destroy_data;
}

void destroy_empromap_click()
{
    paint(16);
}

void sure_destroy_click()
{
    Picture_house(0, (remember_j(-1)) * 6 + remember_i(-1), -1, -1);
    progress_bar(501, 620, 769, 640, 3);
    paint(16);
}

void destroy_click()
{
    tick_click(manager_destroy(false));
}

void destroy_key(int i)
{
    tick_key(manager_destroy(false), i);
}

void destroy_move()
{
    tick_move(manager_destroy(false));
}

void draw_destroy()
{
    update_mouse(0, 0, 1024, 768);
    tick_init(manager_destroy(true));
    set_functions(destroy_click, destroy_key, destroy_move);
}