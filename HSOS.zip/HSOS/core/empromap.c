#include "HsOS.h"
#include "page.h"
#include "string.h"
#include "empromap.h"
#include "general.h"

elements *manager_empromap(bool init)
{
    static elements *empromap_data = NULL;
    element *btn;
    if (init)
    {
        if (isnull(empromap_data))
        {
            btn = new_button(0, 0, 60, 30, "����", IvoryWhite, 0xfded, 0x4227, empromap_empro_click);
            empromap_data = push(btn, NULL);
            btn = new_button(451, 664, 819, 734, "�Ǹ�", IvoryWhite, 0xfded, 0x4227, empromap_starport_click);
            empromap_data = push(btn, empromap_data);
        }
    }
    return empromap_data;
}

void empromap_click()
{
    int x1 = 0, y1 = 0;
    int x2 = 320, y2 = 80;
    int i, j;
    if (supply_or_build(0) == 1)
    {
        if ((mouse.x > 60 && mouse.x < 270 && mouse.y > y1 && mouse.y < 192) ||
            (mouse.x > 0 && mouse.x < 60 && mouse.y > 30 && mouse.y < 192))
        {
            remember_eprospes_material("concrete");
            paint(17);
        } else if (mouse.x > x1 && mouse.x < 270 && mouse.y > y1 + 192 && mouse.y < 192 * 2)
        {
            remember_eprospes_material("rebar");
            paint(17);
        } else if (mouse.x > x1 && mouse.x < 270 && mouse.y > y1 + 192 * 2 && mouse.y < 192 * 3)
        {
            remember_eprospes_material("robot");
            paint(17);
        } else if (mouse.x > x1 && mouse.x < 270 && mouse.y > y1 + 192 * 3 && mouse.y < 192 * 4)
        {
            remember_eprospes_material("water");
            paint(17);
        }
    } else if (supply_or_build(0) == 2)
    {
        for (i = 0; i < 6; i++)
        {
            for (j = 0; j < 5; j++)
            {
                if ((i > 1) || (j > 0))
                {
                    if (vague_semantic_recognition_project(remember_empro(0)) == 2)
                    {
                        if (Picture_house(-1, 0, j, i))
                        {
                            if (mouse.x > x2 + i * 104 && mouse.x < x2 + 100 + i * 104 && mouse.y > y2 + j * 104 &&
                                mouse.y < y2 + 100 + j * 104)
                            {
                                remember_emprospe_building(j, i);
                                paint(18);
                            }
                        }
                    } else if (vague_semantic_recognition_project(remember_empro(0)) == 4)
                    {
                        if (!Picture_house(-1, 0, j, i))
                        {
                            if (mouse.x > x2 + i * 104 && mouse.x < x2 + 100 + i * 104 && mouse.y > y2 + j * 104 &&
                                mouse.y < y2 + 100 + j * 104)
                            {
                                remember_i(i);
                                remember_j(j);
                                draw_mouse(-114, 516);
                                paint(20);
                            }
                        }
                    }
                }
            }
        }
    }
    tick_click(manager_empromap(false));
}

void empromap_key(int i)
{
    tick_key(manager_empromap(false), i);
}

void empromap_move()
{
    int x1 = 0, y1 = 0;
    int x2 = 320, y2 = 80;
    int i, j;
    pre_mouse();
    if (supply_or_build(0) == 1)
    {
        if ((mouse.x > 60 && mouse.x < 270 && mouse.y > y1 && mouse.y < 192) ||
            (mouse.x > 0 && mouse.x < 60 && mouse.y > 30 && mouse.y < 192))
        {
            Box_frame(x1, y1, 270, 192, BLACK, 2);
        } else
        {
            Box_frame(x1, y1, 270, 192, LIGHT_GREY, 2);
        }
        if (mouse.x > x1 && mouse.x < 270 && mouse.y > y1 + 192 && mouse.y < 192 * 2)
        {
            Box_frame(x1, 192, 270, 384, BLACK, 2);
        } else
        {
            Box_frame(x1, 192, 270, 384, LIGHT_GREY, 2);
        }
        if (mouse.x > x1 && mouse.x < 270 && mouse.y > y1 + 192 * 2 && mouse.y < 192 * 3)
        {
            Box_frame(x1, 192 * 2, 270, 192 * 3, BLACK, 2);
        } else
        {
            Box_frame(x1, 192 * 2, 270, 192 * 3, LIGHT_GREY, 2);
        }
        if (mouse.x > x1 && mouse.x < 270 && mouse.y > y1 + 192 * 3 && mouse.y < 192 * 4)
        {
            Box_frame(x1, 192 * 3, 270, 192 * 4, BLACK, 2);
        } else
        {
            Box_frame(x1, 192 * 3, 270, 192 * 4, LIGHT_GREY, 2);
        }
    } else if (supply_or_build(0) == 2)
    {

        for (i = 0; i < 6; i++)
        {
            for (j = 0; j < 5; j++)
            {
                if ((i > 1) || (j > 0))
                {

                    if (mouse.x > x2 + i * 104 && mouse.x < x2 + 100 + i * 104 && mouse.y > y2 + j * 104 &&
                        mouse.y < y2 + 100 + j * 104)
                    {
                        if (vague_semantic_recognition_project(remember_empro(0)) == 2)
                        {
                            if (Picture_house(-1, 0, j, i))
                            {
                                Box_frame(x2 + i * 104, y2 + j * 104, x2 + 100 + i * 104, y2 + 100 + j * 104, BLACK, 2);
                            } else
                            {
                                Box_frame(x2 + i * 104, y2 + j * 104, x2 + 100 + i * 104, y2 + 100 + j * 104,
                                          LIGHT_GREY, 2);
                            }
                        } else if (vague_semantic_recognition_project(remember_empro(0)) == 4)
                        {
                            if (!Picture_house(-1, 0, j, i))
                            {
                                Box_frame(x2 + i * 104, y2 + j * 104, x2 + 100 + i * 104, y2 + 100 + j * 104,
                                          MAR_ORANGE, 2);
                            } else
                            {
                                Box_frame(x2 + i * 104, y2 + j * 104, x2 + 100 + i * 104, y2 + 100 + j * 104,
                                          LIGHT_GREY, 2);
                            }
                        }
                    } else
                    {
                        Box_frame(x2 + i * 104, y2 + j * 104, x2 + 100 + i * 104, y2 + 100 + j * 104, LIGHT_GREY, 2);
                    }
                }
            }
        }
    }
    tick_move(manager_empromap(false));
}

void empromap_starport_click()
{
    if (vague_semantic_recognition_project(remember_empro(0)) == 3)
    {
        starport_or_material(1);
        paint(6);
    }
}

void empromap_empro_click()
{
    if (vague_semantic_recognition_project(remember_empro(0)) == 1)
    {
        if (isfinish(remember_empro(0)))
        {
            paint(13);
        } else
        {
            paint(11);
        }
    } else if ((vague_semantic_recognition_project(remember_empro(0)) == 2) ||
               (vague_semantic_recognition_project(remember_empro(0)) == 4))
    {
        isopen_map(1);
        if (isfinish(remember_empro(0)))
        {
            paint(13);
        } else
        {
            paint(15);
        }
    } else if (vague_semantic_recognition_project(remember_empro(0)) == 3)
    {
        isopen_map(1);
        if (isfinish(remember_empro(0)))
        {
            paint(13);
        } else
        {
            paint(14);
        }
    }
}

void draw_emprospe_map()
{
    isopen_map(0);
    map();
    // draw_error(toString(supply_or_build(0)), "hhh");
    update_mouse(0, 0, 1024, 768);
    tick_init(manager_empromap(true));
    set_functions(empromap_click, empromap_key, empromap_move);
}

void map()
{
    int x1 = 320, y1 = 80;
    Picture(0, 0, "res\\map1.bmp");
    if (isfinish("001"))
    {
        EngText(10, 750, "Under the Protection of the Mars Dome", BLACK);
    }
    if (isfinish("002"))
    {
        Picture(x1, y1, "res\\7.bmp");
    }
    if (isfinish("003"))
    {
        Picture(x1 + 104, y1, "res\\7.bmp");
    }
    Picture(66, 46, "res\\2.bmp");
    Text(66, 150, "��������", BLACK);
    Picture(66, 238, "res\\5.bmp");
    Text(66, 342, "���ֳ�", BLACK);
    Picture(66, 430, "res\\4.bmp");
    Text(66, 534, "�����˳�", BLACK);
    Bar(66, 622, 180, 700, LIGHT_BLUE);
    Text(66, 704, "ˮ��", BLACK);
    if (vague_semantic_recognition_project(remember_empro(0)) == 4)
    {
        Text(480, 10, "�ݻ�ģʽ", BLACK);
    }
    Picture_house(-1, 0, -1, -1);
}