#include "HsOS.h"
#include "page.h"
#include "stdio.h"
#include "mainpage.h"
#include "general.h"

elements *manager_mainpage(bool init)
{
    static elements *mainpage_data = NULL;
    if (init)
    {
        if (isnull(mainpage_data))
        {
            element *btn;
            btn = new_button(279, 267, 726, 321, "��Ա����", IvoryWhite, 0xfded, 0x4227, mainpage_people_click);
            mainpage_data = push(btn, NULL);
            btn = new_button(279, 332, 726, 386, "�������", IvoryWhite, 0xfded, 0x4227, mainpage_progarm_click);
            mainpage_data = push(btn, mainpage_data);
            btn = new_button(279, 397, 726, 451, "��Դ����", IvoryWhite, 0xfded, 0x4227, mainpage_materail_click);
            mainpage_data = push(btn, mainpage_data);
            btn = new_button(0, 0, 60, 30, "����", IvoryWhite, 0xfded, 0x4227, mainpage_login_click);
            mainpage_data = push(btn, mainpage_data);
        }
    }
    return mainpage_data;
}

void mainpage_click()
{
    tick_click(manager_mainpage(false));
}

void mainpage_key(int i)
{
    tick_key(manager_mainpage(false), i);
}

void mainpage_move()
{
    tick_move(manager_mainpage(false));
}

void mainpage_people_click()
{
    paint(4);
}

void mainpage_progarm_click()
{
    paint(5);
}

void mainpage_materail_click()
{
    paint(6);
}

void mainpage_login_click()
{
    paint(1);
}

void draw_mainpage()
{
    Picture(0, 0, "res\\mainpage.bmp");
    Bar(259, 257, 746, 461, MAR_ORANGE);
    tick_init(manager_mainpage(true));
    set_functions(mainpage_click, mainpage_key, mainpage_move);
}
