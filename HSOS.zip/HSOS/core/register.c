#include "HsOS.h"
#include "page.h"
#include "register.h"
#include "string.h"
#include "stdio.h"
#include "general.h"

elements *manager_register(bool init)
{
  static elements *register_data = NULL;
  if (init)
  {
    if (isnull(register_data))
    {
      element *btn;
      btn = new_input(329, 295, 686, 326, "user", 8, BLACK, WHITE, IvoryWhite, false, false);
      register_data = push(btn, NULL);
      btn = new_input(329, 382, 686, 413, "password", 8, BLACK, WHITE, IvoryWhite, true, false);
      register_data = push(btn, register_data);
      btn = new_input(329, 474, 686, 505, "password2", 8, BLACK, WHITE, IvoryWhite, true, false);
      register_data = push(btn, register_data);
      btn = new_button(275, 556, 485, 643, "ע��", IvoryWhite, MAR_ORANGE, 0x4227, register_register_click);
      register_data = push(btn, register_data);
      btn = new_button(540, 556, 750, 643, "����", IvoryWhite, MAR_ORANGE, 0x4227, register_back_click);
      register_data = push(btn, register_data);
    }
  }

  return register_data;
}

void register_click()
{
  tick_click(manager_register(false));
}

void register_register_click()
{
  char tmp[50];
  char tmp1[50];
  char tmp2[50];
  char tmp3[50];
  FILE *fp;
  FILE *fp1;
  FILE *fp2;
  FILE *fp3;
  if (strlen(get_input(manager_register(false), "user")) < 1)
  {
    print_login_msg("ע��ʧ�ܣ��û�������Ϊ�գ�");
    paint(1);
    return;
  }
  strcpy(tmp, "data\\num\\");
  strcat(tmp, get_input(manager_register(false), "user"));
  fp = fopen(tmp, "rb");
  if (fp != NULL)
  {
    fclose(fp);
    Text(430, 660, "ע��ʧ�ܣ��û�����ռ�ã�", MAR_ORANGE);
  }
  else
  {
    if (strcmp(get_input(manager_register(false), "password"), get_input(manager_register(false), "password2")) !=
        0)
    {
      print_login_msg("ע��ʧ�ܣ�������ȷ�����벻һ�£�");
      paint(1);
      return;
    }
    else
    {
      if (strlen(get_input(manager_register(false), "password")) < 5)
      {
        print_login_msg("ע��ʧ�ܣ�������̣�");
        paint(1);
        return;
      }
      fp = fopen(tmp, "wb");
      fputs(get_input(manager_register(false), "password"), fp);
      fclose(fp);
      print_login_msg("ע��ɹ������¼��");
      strcpy(tmp1, "data\\phone\\");
      strcat(tmp1, get_input(manager_register(false), "user"));
      fp1 = fopen(tmp1, "rb");
      fclose(fp1);
      fp1 = fopen(tmp1, "wb");
      fputs("unknown", fp1);
      fclose(fp1);
      strcpy(tmp2, "data\\work\\");
      strcat(tmp2, get_input(manager_register(false), "user"));
      fp2 = fopen(tmp2, "rb");
      fclose(fp2);
      fp2 = fopen(tmp2, "wb");
      fputs("δ֪", fp2);
      fclose(fp2);
      strcpy(tmp3, "data\\boss\\");
      strcat(tmp3, get_input(manager_register(false), "user"));
      fp3 = fopen(tmp3, "rb");
      fclose(fp3);
      fp3 = fopen(tmp3, "wb");
      fputs("unknown", fp3);
      fclose(fp3);
      paint(1);
    }
  }
}

void register_back_click()
{
  print_login_msg("");
  paint(1);
}

void register_key(int i)
{
  tick_key(manager_register(false), i);
}

void register_move()
{
  tick_move(manager_register(false));
}

void draw_register()
{
  Picture(0, 0, "res\\register.bmp");
  tick_init(manager_register(true));
  set_functions(register_click, register_key, register_move);
  music(true);
}
