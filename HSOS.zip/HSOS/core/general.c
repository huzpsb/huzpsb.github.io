// Reviewed by huzpsb 2023/04/05. Two errors and thirteen warnings. Approved.

#include "HsOS.h"
#include "login.h"
#include "register.h"
#include "people.h"
#include "material.h"
#include "stdio.h"
#include "matspe.h"
#include "project.h"
#include "prospe.h"
#include "empage.h"
#include "emprospe.h"
#include "empromat.h"
#include "empro.h"
#include "string.h"
#include "stdlib.h"
#include "page.h"
#include "emprofin.h"
#include "general.h"

void background()
{
    char tmp[30];
    char tmp1[30];
    char tmp2[30];
    char tmp3[30];
    char qr[100];
    FILE *fp;
    strcpy(tmp, remember_id(NULL));
    strcpy(tmp1, "res\\");
    strcat(tmp1, tmp);
    strcat(tmp1, ".bmp");
    Text(48, 267, "�û���", BLACK);
    EngText(150, 273, tmp, BLACK);
    fp = fopen(tmp1, "r");
    if (fp == NULL)
    {
        Picture(82, 77, "res\\aperson.bmp");
    } else
    {
        fclose(fp);
        Picture(82, 77, tmp1);
    }
    strcpy(tmp2, "data\\");
    strcat(tmp2, "work\\");
    strcat(tmp2, tmp);
    fp = fopen(tmp2, "rb");
    fgets(tmp2, 30, fp);
    Text(48, 336, "ְλ", BLACK);
    Text(120, 336, tmp2, BLACK);
    fclose(fp);
    strcpy(tmp3, "data\\");
    strcat(tmp3, "phone\\");
    strcat(tmp3, tmp);
    fp = fopen(tmp3, "rb");
    fgets(tmp3, 30, fp);
    Text(48, 405, "�绰", BLACK);
    EngText(120, 411, tmp3, BLACK);
    fclose(fp);
    sprintf(qr,
            "BEGIN:VCARD\nVERSION:2.1\nN:%s\nTEL:%s\nEMAIL:%s@HustMars.edu.cn\nORG:HUST\nPHOTO;TYPE=JPEG;VALUE=URI:http://38.60.35.180/qwqrt/%s.bmp\nEND:VCARD",
            tmp, tmp3, tmp, tmp);
    draw_qr(qr, 230, 650);
}

char *remember_empro(int num)
{
    int p, page, j, n = 0, i;
    static int m;
    char tmp[50];
    FILE *fp;
    int now[50] = {0};
    if (num != 0)
    {
        m = num;
        return NULL;
    }
    IFileList("C:\\HSOS\\data\\project\\per\\*");
    i = IFileCount();
    page = empro_change_page(3);
    if (!ismanager(remember_id(NULL)))
    {
        for (j = 0; j < i; j++)
        {
            strcpy(tmp, "data\\project\\per\\");
            strcat(tmp, IFileGet(j));
            fp = fopen(tmp, "rb");
            fscanf(fp, "%s", tmp);
            fclose(fp);
            if (strcmp(tmp, remember_id(NULL)) == 0)
            {
                now[n] = j;
                n++;
            }
        }
        p = (page - 1) * 9 + now[m - 1];
        return IFileGet(p);
    } else
    {
        p = (page - 1) * 9 + m - 1;
        return IFileGet(p);
    }
}

bool isexist_project(int i)
{
    bool exist;
    int j, page, num;
    num = Get_num();
    page = empro_change_page(3);
    j = (page - 1) * 9 + i;
    if (j <= num)
        exist = true;
    else
        exist = false;
    // draw_error(toString(i), toString(j));
    return exist;
}

int Get_num()
{
    char tmp[50];
    int i, j, cnt = 0;
    FILE *fp;
    // Bar(0, 0, 50, 50, WHITE);
    IFileList("C:\\HSOS\\data\\project\\per\\*");
    i = IFileCount();
    if (!ismanager(remember_id(NULL)))
    {
        for (j = 0; j < i; j++)
        {
            strcpy(tmp, "data\\project\\per\\");
            strcat(tmp, IFileGet(j));
            fp = fopen(tmp, "rb");
            fscanf(fp, "%s", tmp);
            fclose(fp);
            if (strcmp(tmp, remember_id(NULL)) == 0)
            {
                cnt++;
            }
        }
        return cnt;
    } else
    {
        // Bar(0, 0, 90, 90, BLACK);
        return i;
    }
}

void print_login_msg(char *text)
{
    static char *sample = NULL;
    if (text == NULL)
    {
        Text(430, 660, sample, 0xf5ae);
    } else
    {
        sample = text;
    }
}

char *remember_id(char *text)
{
    static char *id = NULL;
    if (text != NULL)
    {
        id = text;
    }
    return id;
}

bool ismanager(char *id)
{
    char tmp[30];
    FILE *fp;
    strcpy(tmp, "data\\boss\\");
    strcat(tmp, id);
    fp = fopen(tmp, "rb");
    fscanf(fp, "%s", tmp);
    fclose(fp);
    return (strcmp(tmp, "true") == 0);
}

bool isexist_material(int i)
{
    bool exist;
    int j, page, num;
    IFileList("C:\\HSOS\\data\\material\\*");
    num = IFileCount();
    page = material_change_page(3);
    j = (page - 1) * 9 + i;
    if (j <= num)
        exist = true;
    else
        exist = false;
    // draw_error(toString(i), toString(j));
    return exist;
}

char *remember_material(int num)
{
    int p, page;
    static int i;
    if (num != 0)
    {
        i = num;
        return NULL;
    }
    IFileList("C:\\HSOS\\data\\material\\*");
    page = material_change_page(3);
    p = (page - 1) * 9 + i - 1;
    return IFileGet(p);
}

char *transform(const char *mixture)
{
    static char mixed[200], now;
    int read = 0, write = 0, tmp;
    char *to_num = "��������������������";
    char *to_low = "����������������������������������";
    char *to_cap = "���£ãģţƣǣȣɣʣˣ̣ͣΣϣУѣңӣԣգ֣ףأ٣�";
    char *tox = "��";
    while (true)
    {
        now = mixture[read];
        if (now == ' ')
        {
            // Do nothing
        } else if (now == '\0')
        {
            break;
        } else if (now < 0)
        {
            mixed[write++] = now;
        } else if (now >= '0' && now <= '9')
        {
            tmp = now - '0';
            mixed[write++] = to_num[tmp * 2];
            mixed[write++] = to_num[tmp * 2 + 1];
        } else if (now >= 'a' && now <= 'z')
        {
            tmp = now - 'a';
            mixed[write++] = to_low[tmp * 2];
            mixed[write++] = to_low[tmp * 2 + 1];
        } else if (now >= 'A' && now <= 'Z')
        {
            tmp = now - 'A';
            mixed[write++] = to_cap[tmp * 2];
            mixed[write++] = to_cap[tmp * 2 + 1];
        } else if (now == '_')
        {
            mixed[write++] = tox[0];
            mixed[write++] = tox[1];
        }
        read++;
    }
    mixed[write] = '\0';
    return mixed;
}

int getCount(char *mat_id)
{
    FILE *fp;
    char tmp[50];
    int result;
    strcpy(tmp, "data\\matnum\\");
    strcat(tmp, mat_id);
    fp = fopen(tmp, "rb");
    fscanf(fp, "%d", &result);
    fclose(fp);
    return result;
}

void setCount(char *mat_id, int num)
{
    FILE *fp;
    char tmp[50];
    strcpy(tmp, "data\\matnum\\");
    strcat(tmp, mat_id);
    fp = fopen(tmp, "wb");
    fprintf(fp, "%d", num);
    fclose(fp);
}

void ms_append(char *mat_id, char *content)
{
    char tmp[50];
    FILE *fp;
    strcpy(tmp, "data\\logs\\");
    strcat(tmp, mat_id);
    fp = fopen(tmp, "a");
    if (fp == NULL)
    {
        draw_error("File System Panic - Can not append log (mat_spe.c::ms_append)!", tmp);
    }
    fprintf(fp, content);
    fclose(fp);
}

int remember_person(int p)
{
    static int num;
    if (p != -1)
    {
        num = p;
    }
    return num;
}

bool isexist_people(int i)
{
    bool exist;
    int j, page, num;
    IFileList("C:\\HSOS\\data\\work\\*");
    num = IFileCount();
    page = change_page(3);
    j = (page - 1) * 9 + i;
    if (j <= num)
        exist = true;
    else
        exist = false;
    // draw_error(toString(i), toString(j));
    return exist;
}

char *transform_Atoa(char *tmp)
{
    char *s1;
    for (s1 = tmp; *s1 != '\0'; s1++)
    {
        if (*s1 >= 97 && *s1 <= 122)
        {
            *s1 -= 32;
        }
    }
    return tmp;
}

char *remember_pro_id(const char *tmp)
{
    static char sample2[25] = {'\0'};
    if (tmp == NULL)
    {
        return sample2;
    } else
    {
        strcpy(sample2, tmp);
        return sample2;
    }
}

void print_pro_msg(char *text)
{
    static char *sample1 = "";
    if (text == NULL)
    {
        Text(513, 726, sample1, MAR_ORANGE);
        return;
    }
    sample1 = text;
}

bool id_person_material_is_right(const char *id)
{
    const char *qwq;
    qwq = id;
    while (1)
    {
        if (*qwq == '\0')
        {
            return true;
        }
        if (!((*qwq >= '0' && *qwq <= '9') || (*qwq >= 'a' && *qwq <= 'z') || (*qwq >= 'A' && *qwq <= 'Z') ||
              (*qwq == ',')))
        {
            return false;
        }
        qwq++;
    }
}

void getandput_Chinese(char *text1, char *text2, int x1, int x2)
{
    char tmp[50];
    FILE *fp;
    strcpy(tmp, text1);
    strcat(tmp, text2);
    fp = fopen(tmp, "r");
    fscanf(fp, "%s", tmp);
    Text(x1, x2, tmp, BLACK);
    fclose(fp);
}

void getandput_English(char *text1, char *text2, int x1, int x2)
{
    char tmp[50];
    FILE *fp;
    strcpy(tmp, text1);
    strcat(tmp, text2);
    fp = fopen(tmp, "rb");
    fgets(tmp, 50, fp);
    EngText(x1, x2, tmp, BLACK);
    fclose(fp);
}

void pro_mat_divide(char (*mat)[10], char *s1, int *np)
{
    int i, j;
    char *s2 = s1;
    *np = 0;
    j = strlen(s1);
    for (i = 0; i < j; i++)
    {
        if (s1[i] == ',')
        {
            s1[i] = '\0';
            strcpy(mat[(*np)], s2);
            (*np)++;
            s2 = s2 + strlen(s2) + 1;
        }
    }
    strcpy(mat[(*np)], s2);
    (*np)++;
}

void mat_EnglishToChinese(char (*mat)[10], int n, char *tmp)
{
    char tmp1[50], tmp2[10];
    int i;
    FILE *fp;
    tmp[0] = '\0';
    for (i = 0; i < n; i++)
    {
        strcpy(tmp1, "data\\material\\");
        strcat(tmp1, mat[i]);
        fp = fopen(tmp1, "rb");
        fscanf(fp, "%s", tmp2);
        strcat(tmp, tmp2);
        strcat(tmp, "��");
        fclose(fp);
    }
    if (strlen(tmp) < 2)
    {
        draw_error("Invalid Operation | NPE in reading material", "prospe.c::mat_EnglishToChinese");
    }
    tmp[strlen(tmp) - 2] = '\0';
}

void output_mat_Chinese(int x, int y, char *text)
{
    char tmp[50];
    char ret[50];
    int n = 0;
    int *np = &n;
    char mat[10][10];
    FILE *fp;
    strcpy(tmp, "data\\project\\mat\\");
    strcat(tmp, text);
    fp = fopen(tmp, "rb");
    fscanf(fp, "%s", tmp);
    fclose(fp);
    pro_mat_divide(mat, tmp, np);
    mat_EnglishToChinese(mat, *np, ret);
    Text(x, y, ret, BLACK);
}

void pro_mat_divide_chinese(char (*mat)[10], char *s1, int *np)
{
    int i, j;
    char *s2 = s1;
    char tmp[30];
    FILE *fp;
    *np = 0;
    j = strlen(s1);
    for (i = 0; i < j; i++)
    {
        if (s1[i] == ',')
        {
            s1[i] = '\0';
            strcpy(tmp, "data\\material\\");
            strcat(tmp, s2);
            fp = fopen(tmp, "rb");
            fscanf(fp, "%s", mat[(*np)]);
            fclose(fp);
            (*np)++;
            s2 = s2 + strlen(s2) + 1;
            // chinese_draw_error(mat[(*np)], "hhh");
        }
    }
    strcpy(tmp, "data\\material\\");
    strcat(tmp, s2);
    fp = fopen(tmp, "rb");
    fscanf(fp, "%s", mat[(*np)]);
    fclose(fp);
    // chinese_draw_error(mat[(*np)], "hhh");
    (*np)++;
}

bool isexpand(int init)
{
    static bool expand = false;
    if (init == 2)
    {
        return expand;
    }
    expand = init;
}

void emprospe_text(char *tmp)
{
    static char sample4[25] = "��ӭʹ�ñ�ϵͳ";
    Bar(550, 643, 900, 700, WHITE);
    if (tmp == NULL)
    {
        Text(550, 643, sample4, BLACK);
    } else
    {
        strcpy(sample4, tmp);
        Text(550, 643, sample4, BLACK);
    }
}

char *remember_empro_mat(char *tmp)
{
    static char sample3[25] = {'\0'};
    if (tmp == NULL)
    {
        return sample3;
    } else
    {
        strcpy(sample3, tmp);
    }
}

void show_map()
{
    int x1 = 545, y1 = 354;
    Picture(x1, y1, "res\\mapempty.bmp");
    if (isfinish("001"))
    {
        EngText(550, 360, "Under the Protection of the Mars Dome", BLACK);
    }
    if (isfinish("002"))
    {
        Picture(x1 + 144, y1 + 100, "res\\7.bmp");
    }
    if (isfinish("003"))
    {
        Picture(x1 + 244, y1 + 100, "res\\7.bmp");
    }
}

bool isfinish(char *id)
{
    char tmp[30];
    FILE *fp;
    strcpy(tmp, "data\\project\\state\\");
    strcat(tmp, id);
    fp = fopen(tmp, "rb");
    fscanf(fp, "%s", tmp);
    fclose(fp);
    if (!strcmp(tmp, "�����"))
    {
        return true;
    } else
    {
        return false;
    }
}

void progress_bar(int x1, int y1, int x2, int y2, int v)
{
    int i;
    Box(x1, y1, x2, y2, BLACK, 1);
    for (i = x1 + 1; i < x2; i++)
    {
        Line(i, y1 + 1, i, y2 - 1, ForestGreen);
        delay(10);
    }
    delay(v);
    Bar(x1, y1, x2, y2, WHITE);
}

int vague_semantic_recognition_project(char *text)
{
    static char tmp[50] = {'\0'};
    static int i = 0;
    if (strcmp(text, tmp) == 0)
    {
        return i;
    }
    strcpy(tmp, text);
    i = vague_semantic_recognition_internal(tmp);
    return i;
}

int vague_semantic_recognition_internal(char *text)
{
    char tmp[50];
    FILE *fp;
    strcpy(tmp, "data\\project\\mark\\");
    strcat(tmp, text);
    fp = fopen(tmp, "rb");
    fscanf(fp, "%s", tmp);
    fclose(fp);
    if ((strcmp(text, "001") == 0) || (strcmp(text, "002") == 0) || (strcmp(text, "003") == 0))
    {
        return 1;
    } else
    {
        // draw_error(tmp, "hhh");
        if ((strstr(tmp, "����") != NULL) || (strstr(tmp, "����") != NULL) || (strstr(tmp, "����") != NULL) ||
            (strstr(tmp, "����") != NULL) || (strstr(tmp, "����") != NULL))
        {
            if ((strstr(tmp, "������") != NULL))
            {
                return 3;
            } else
            {
                return 2;
            }
        } else if ((strstr(tmp, "����") != NULL) || (strstr(tmp, "�ռ�") != NULL) || (strstr(tmp, "�ɼ�") != NULL) ||
                   (strstr(tmp, "�ھ�") != NULL) || (strstr(tmp, "����") != NULL))
        {
            return 3;
        } else if ((strstr(tmp, "���") != NULL) || (strstr(tmp, "���") != NULL) || (strstr(tmp, "���") != NULL) ||
                   (strstr(tmp, "�ݻ�") != NULL) || (strstr(tmp, "��Ǩ") != NULL))
        {
            return 4;
        } else
        {
            return 1;
        }
    }
}

void finish_project()
{
    char tmp[30];
    FILE *fp;
    strcpy(tmp, "data\\project\\state\\");
    strcat(tmp, remember_empro(0));
    fp = fopen(tmp, "wb");
    fprintf(fp, "%s", "�����");
    fclose(fp);
    progress_bar(550, 643, 750, 700, 10);
    emprospe_text("�����������");
    paint(13);
}

bool isopen_map(int n)
{
    static bool isopen = false;
    if (n == 2)
    {
        return isopen;
    } else
    {
        isopen = n;
    }
}

int supply_or_build(int i)
{
    static int n = 0;
    if (i != 0)
    {
        n = i;
    }
    return n;
}

char *remember_eprospes_material(char *tmp)
{
    static char *text = NULL;
    if (tmp != NULL)
    {
        text = tmp;
    }
    return text;
}

void eprospem_text(char *tmp)
{
    static char sample5[25] = "��ӭʹ�ñ�ϵͳ";
    Bar(30, 600, 210, 700, WHITE);
    if (tmp == NULL)
    {
        Text(30, 620, sample5, BLACK);
    } else
    {
        strcpy(sample5, tmp);
        Text(30, 620, sample5, BLACK);
    }
}

int starport_or_material(int i)
{
    static int n = 2;
    if (i != 0)
    {
        n = i;
    }
    return n;
}

void starport_text(char *tmp)
{
    static char sample6[25] = "��ӭʹ�ñ�ϵͳ";
    Bar(361, 520, 614, 568, WHITE);
    if (tmp == NULL)
    {
        Text(390, 533, sample6, BLACK);
    } else
    {
        strcpy(sample6, tmp);
        Text(390, 533, sample6, BLACK);
    }
}

int remember_emprospe_building(int x, int y)
{
    static int n = 0;
    if (x == 0 && y == 0)
    {
        return n;
    } else
    {
        n = x * 6 + y;
    }
}

void eprospeh_text(char *tmp)
{
    static char sample7[25] = "��ӭʹ�ñ�ϵͳ";
    Box(418, 682, 902, 737, WHITE, 3);
    if (tmp == NULL)
    {
        Text(558, 689, sample7, BLACK);
    } else
    {
        strcpy(sample7, tmp);
        Text(558, 689, sample7, BLACK);
    }
}

bool check_material_num(char *material, int i)
{
    bool init = true;
    int n = getCount(material);
    if (i > n)
    {
        init = false;
    }
    return init;
}

bool Picture_house(int i, int j, int x, int y)
{
    int m, n;
    bool init;
    char tmp[50];
    FILE *fp;
    int house[5][6] = {{0, 0, 0, 0, 0, 0},
                       {0, 0, 0, 0, 0, 0},
                       {0, 0, 0, 0, 0, 0},
                       {0, 0, 0, 0, 0, 0},
                       {0, 0, 0, 0, 0, 0}};
    // �ָ���һ�ε�����
    for (m = 0; m < 5; m++)
    {
        for (n = 0; n < 6; n++)
        {
            strcpy(tmp, "data\\house\\");
            strcat(tmp, toString(m * 6 + n));
            fp = fopen(tmp, "r");
            if (fp == NULL)
            {
                draw_error("File System Error :: Open Failed (general.c::Picture_house)", tmp);
            }
            fscanf(fp, "%d", &house[m][n]);
            fclose(fp);
        }
    }
    m = j / 6;
    n = j % 6;
    // д��ֵ���ļ�
    if ((x == -1) && (y == -1))
    {
        if (i != -1)
        {
            house[m][n] = i;
            strcpy(tmp, "data\\house\\");
            strcat(tmp, toString(m * 6 + n));
            fp = fopen(tmp, "w");
            fprintf(fp, "%d", house[m][n]);
            fclose(fp);
        } else
        {
            for (m = 0; m < 5; m++)
            {
                for (n = 0; n < 6; n++)
                {
                    if (house[m][n] == 1)
                    {
                        Picture(320 + n * 104, 80 + m * 104, "res\\7.bmp");
                    } else if (house[m][n] == 2)
                    {
                        Picture(320 + n * 104, 80 + m * 104, "res\\3.bmp");
                    } else if (house[m][n] == 3)
                    {
                        Picture(320 + n * 104, 80 + m * 104, "res\\6.bmp");
                    }
                }
            }
        }
    } else
    {
        if (house[x][y] == 0)
        {
            init = true;
        } else
        {
            init = false;
        }
        return init;
    }
}

int remember_i(int x)
{
    static int i1 = 0;
    if (x == -1)
    {
        return i1;
    } else
    {
        i1 = x;
    }
}

int remember_j(int x)
{
    static int j1 = 0;
    if (x == -1)
    {
        return j1;
    } else
    {
        j1 = x;
    }
}
