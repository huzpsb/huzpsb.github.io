// Reviewed by huzpsb 2023/04/05. One error and two warnings. Approved.

#include "HsOS.h"
#include "page.h"
#include "string.h"
#include "stdio.h"
#include "eprospem.h"
#include "general.h"
#include "empromap.h"

elements *manager_eprospem(bool init)
{
  static elements *eprospem_data = NULL;
  element *btn;
  if (init)
  {
    if (isnull(eprospem_data))
    {
      btn = new_button(0, 0, 60, 30, "����", IvoryWhite, 0xfded, 0x4227, eprospem_empromap_click);
      eprospem_data = push(btn, NULL);
      btn = new_input(60, 300, 210, 350, "mat_increase", 4, BLACK, WHITE, IvoryWhite, false, false);
      eprospem_data = push(btn, eprospem_data);
      btn = new_button(60, 400, 210, 470, "���", IvoryWhite, 0xfded, 0x4227, eprospem_add);
      eprospem_data = push(btn, eprospem_data);
    }
  }
  return eprospem_data;
}

void eprospem_click()
{
  tick_click(manager_eprospem(false));
}

void eprospem_key(int i)
{
  tick_key(manager_eprospem(false), i);
}

void eprospem_move()
{
  tick_move(manager_eprospem(false));
}

void eprospem_add()
{
  char tmp[100];
  char tmp1[30];
  FILE *fp;
  long x, y;
  x = getCount(remember_eprospes_material(NULL));
  y = atoi(get_input(manager_eprospem(false), "mat_increase"));
  if (y > 10000)
  {
    eprospem_text("��Դ�����Ƿ�");
  }
  else if (y <= 0)
  {
    eprospem_text("��Դ�仯������Ϊ����");
  }
  else if (x + y > 10000)
  {
    eprospem_text("��Դ������������");
  }
  else
  {
    x += y;
    strcpy(tmp1, "data\\material\\");
    strcat(tmp1, remember_eprospes_material(NULL));
    fp = fopen(tmp1, "rb");
    fscanf(fp, "%s", tmp1);
    fclose(fp);
    strcpy(tmp, "�û�");
    strcat(tmp, remember_id(NULL));
    strcat(tmp, "�����");
    strcat(tmp, toString(y));
    strcat(tmp, "����λ��");
    strcat(tmp, tmp1);
    strcat(tmp, "�����ࣺ");
    strcat(tmp, toString(x));
    ms_append(remember_eprospes_material(NULL), transform(tmp));
    ms_append(remember_eprospes_material(NULL), "\n");
    setCount(remember_eprospes_material(NULL), x);
    progress_bar(60, 500, 210, 540, 5);
    Text(95, 600, "�����", BLACK);
    strcpy(get_input(manager_eprospem(false), "mat_increase"), "\0");
    Bar(61, 301, 209, 349, WHITE);
    // paint(11);
  }
}

void eprospem_empromap_click()
{
  Picture(0, 0, "res\\left.bmp");
  tick_init(manager_empromap(true));
  set_functions(empromap_click, empromap_key, empromap_move);
  tick_click(NULL);
  update_mouse(0, 0, SCR_WIDTH, SCR_HEIGHT);
}

void draw_emprospe_material()
{
  char tmp1[30];
  FILE *fp;
  Box(0, 0, 270, 1024, BLACK, 5);
  strcpy(tmp1, "data\\material\\");
  strcat(tmp1, remember_eprospes_material(NULL));
  fp = fopen(tmp1, "rb");
  fscanf(fp, "%s", tmp1);
  fclose(fp);
  Box(95, 150, 175, 190, BLACK, 3);
  Text(100, 155, tmp1, BLACK);
  tick_init(manager_eprospem(true));
  set_functions(eprospem_click, eprospem_key, eprospem_move);
}
