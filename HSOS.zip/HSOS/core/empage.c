#include "HsOS.h"
#include "page.h"
#include "stdio.h"
#include "empage.h"
#include "general.h"

elements *manager_empage(bool init)
{
    static elements *empage_data = NULL;
    if (init)
    {
        if (isnull(empage_data))
        {
            element *btn;
            btn = new_button(279, 332, 726, 386, "�������", IvoryWhite, 0xfded, 0x4227, empage_project_click);
            empage_data = push(btn, NULL);
            btn = new_button(279, 397, 726, 451, "��Դ����", IvoryWhite, 0xfded, 0x4227, empage_materail_click);
            empage_data = push(btn, empage_data);
            btn = new_button(0, 0, 60, 30, "����", IvoryWhite, 0xfded, 0x4227, empage_login_click);
            empage_data = push(btn, empage_data);
        }
    }
    return empage_data;
}

void empage_click()
{
    tick_click(manager_empage(false));
}

void empage_key(int i)
{
    tick_key(manager_empage(false), i);
}

void empage_move()
{
    tick_move(manager_empage(false));
}

void empage_project_click()
{
    paint(10);
}

void empage_materail_click()
{
    starport_or_material(2);
    paint(6);
}

void empage_login_click()
{
    paint(1);
}

void draw_empage()
{
    Picture(0, 0, "res\\mainpage.bmp");
    Bar(259, 322, 746, 461, MAR_ORANGE);
    tick_init(manager_empage(true));
    // set_functions(unset,unset,unset);
    set_functions(empage_click, empage_key, empage_move);
}
