#include "HsOS.h"
#include "empromap.h"
#include "starport.h"
#include "login.h"
#include "register.h"
#include "people.h"
#include "material.h"
#include "stdio.h"
#include "matspe.h"
#include "project.h"
#include "prospe.h"
#include "empage.h"
#include "emprospe.h"
#include "empromat.h"
#include "empro.h"
#include "page.h"
#include "emprofin.h"
#include "general.h"
#include "eprospes.h"
#include "eprospeb.h"
#include "eprospem.h"
#include "eprospeh.h"
#include "destroy.h"
#include "mainpage.h"

#ifdef DEBUG
extern FILE *logger;
#endif

void paint(int i)
{
#ifdef DEBUG
    char tmp[10];
    fprintf(logger, "Rendering page %d\n", i);
#endif
    music(false);
    switch (i)
    {
        default:
            draw_error("Page not found.", toString(i));
            break;
        case 1:
            draw_login();
            break;
        case 2:
            draw_register();
            break;
        case 3:
            draw_mainpage();
            break;
        case 4:
            draw_people();
            break;
        case 5:
            draw_project();
            break;
        case 6:
            draw_material_mainpage();
            break;
        case 7:
            draw_material_specific();
            break;
        case 8:
            draw_project_specific();
            break;
        case 9:
            draw_empage();
            break;
        case 10:
            draw_empro_mainpage();
            break;
        case 11:
            draw_empro_specific();
            break;
        case 12:
            draw_emprospe_matlist();
            break;
        case 13:
            draw_emprofin();
            break;
        case 14:
            draw_emprospe_supply();
            break;
        case 15:
            draw_emprospe_build();
            break;
        case 16:
            draw_emprospe_map();
            break;
        case 17:
            draw_emprospe_material();
            break;
        case 18:
            draw_emprospe_house();
            break;
        case 19:
            draw_starport();
            break;
        case 20:
            draw_destroy();
            break;
    }
    tick_click(NULL);
    update_mouse(0, 0, SCR_WIDTH, SCR_HEIGHT);
#ifdef DEBUG
    fprintf(logger, "Rendered page %d\n", i);
    sprintf(tmp, "Page %d", i);
    Bar(0, SCR_HEIGHT - 20, 85, SCR_HEIGHT, BLACK);
    EngText(1, SCR_HEIGHT - 19, tmp, WHITE);
#endif
}
