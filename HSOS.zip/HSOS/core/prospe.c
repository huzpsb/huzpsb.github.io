#include "HsOS.h"
#include "page.h"
#include "string.h"
#include "stdio.h"
#include "prospe.h"
#include "matspe.h"
#include "general.h"

elements *manager_prospe(bool init)
{
  static elements *prospe_data = NULL;
  if (init)
  {
    if (isnull(prospe_data))
    {
      element *btn;
      btn = new_button(0, 0, 60, 30, "����", IvoryWhite, 0xfded, 0x4227, prospe_project_click);
      prospe_data = push(btn, NULL);
      btn = new_button(475, 700, 650, 740, "ɾ������", IvoryWhite, 0xfded, 0x4227, delete_project);
      prospe_data = push(btn, prospe_data);
      btn = new_button(675, 700, 850, 740, "�˻ط���", IvoryWhite, 0xfded, 0x4227, send_back_project);
      prospe_data = push(btn, prospe_data);
    }
  }
  return prospe_data;
}

void prospe_project_click()
{
  paint(5);
}

void prospe_click()
{
  tick_click(manager_prospe(false));
}

void prospe_key(int i)
{
  tick_key(manager_prospe(false), i);
}

void prospe_move()
{
  tick_move(manager_prospe(false));
}

void delete_project()
{
  char tmp[50];
  strcpy(tmp, "data\\project\\state\\");
  strcat(tmp, remember_pro_id(NULL));
  if ((strcmp(remember_pro_id(NULL), "001") == 0) || (strcmp(remember_pro_id(NULL), "002") == 0) ||
      (strcmp(remember_pro_id(NULL), "003") == 0))
  {
    Text(500, 50, "�������ܱ�ɾ����", BLACK);
  }
  else
  {
    strcpy(tmp, "C:\\HSOS\\data\\project\\");
    strcat(tmp, "\\mark\\");
    strcat(tmp, remember_pro_id(NULL));
    IFileDelete(tmp);
    strcpy(tmp, "C:\\HSOS\\data\\project\\");
    strcat(tmp, "\\per\\");
    strcat(tmp, remember_pro_id(NULL));
    IFileDelete(tmp);
    strcpy(tmp, "C:\\HSOS\\data\\project\\");
    strcat(tmp, "\\mat\\");
    strcat(tmp, remember_pro_id(NULL));
    IFileDelete(tmp);
    strcpy(tmp, "C:\\HSOS\\data\\project\\");
    strcat(tmp, "\\state\\");
    strcat(tmp, remember_pro_id(NULL));
    IFileDelete(tmp);
    remove(tmp);
    paint(5);
  }
}

void send_back_project()
{
  char tmp[40];
  char tmp1[15];
  FILE *fp;
  if ((strcmp(remember_pro_id(NULL), "001") != 0) && (strcmp(remember_pro_id(NULL), "002") != 0) &&
      (strcmp(remember_pro_id(NULL), "003") != 0))
  {
    strcpy(tmp, "data\\project\\state\\");
    strcat(tmp, remember_pro_id(NULL));
    fp = fopen(tmp, "rb");
    fscanf(fp, "%s", tmp1);
    fclose(fp);
    if (strcmp(tmp1, "�����") == 0)
    {
      fp = fopen(tmp, "wb");
      fprintf(fp, "%s", "δ���");
      fclose(fp);
      paint(8);
    }
  }
}

void draw_project_specific()
{
  char tmp[50];
  strcpy(tmp, remember_pro_id(NULL));
  Picture(0, 0, "res\\people.bmp");
  background();
  Box(497, 95, 789, 187, BLACK, 7);
  Text(600, 130, "�������", BLACK);
  Box(425, 233, 549, 277, BLACK, 3);
  Text(429, 237, "�����", BLACK);
  EngText(590, 240, tmp, BLACK);
  Box(425, 328, 549, 372, BLACK, 3);
  Text(429, 332, "��ί����", BLACK);
  getandput_English("data\\project\\per\\", tmp, 590, 335);
  Box(425, 423, 549, 467, BLACK, 3);
  Text(429, 427, "�й���Դ", BLACK);
  output_mat_Chinese(570, 430, tmp);
  Box(425, 518, 549, 562, BLACK, 3);
  Text(429, 522, "����Ŀ��", BLACK);
  getandput_Chinese("data\\project\\mark\\", tmp, 590, 525);
  Box(425, 613, 549, 657, BLACK, 3);
  Text(429, 617, "����״̬", BLACK);
  getandput_Chinese("data\\project\\state\\", tmp, 590, 620);
  tick_init(manager_prospe(true));
  set_functions(prospe_click, prospe_key, prospe_move);
}
