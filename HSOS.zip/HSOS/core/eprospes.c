#include "HsOS.h"
#include "page.h"
#include "string.h"
#include "stdio.h"
#include "eprospes.h"
#include "general.h"

elements *manager_eprospes(bool init)
{
    static elements *eprospes_data = NULL;
    element *btn;
    if (init)
    {
        if (isnull(eprospes_data))
        {
            btn = new_button(0, 0, 60, 30, "����", IvoryWhite, 0xfded, 0x4227, eprospes_empro_click);
            eprospes_data = push(btn, NULL);
            btn = new_button(406, 426, 534, 530, "�������", IvoryWhite, 0xfded, 0x4227, finish_project);
            eprospes_data = push(btn, eprospes_data);
        }
    }
    return eprospes_data;
}

void eprospes_click()
{
    if (isopen_map(2))
    {
        if (mouse.x > 545 && mouse.y > 354 && mouse.x < 965 && mouse.y < 624)
        {
            if (vague_semantic_recognition_project(remember_empro(0)) == 2)
            {
                supply_or_build(2);
            } else if (vague_semantic_recognition_project(remember_empro(0)) == 3)
            {
                supply_or_build(1);
            }
            paint(16);
        }
    }
    tick_click(manager_eprospes(false));
}

void eprospes_key(int i)
{
    tick_key(manager_eprospes(false), i);
}

void eprospes_move()
{
    tick_move(manager_eprospes(false));
}

void eprospes_empro_click()
{
    paint(10);
}

void draw_emprospe_supply()
{
    char tmp[30];
    char tmp1[30];
    FILE *fp;
    strcpy(tmp, remember_empro(0));
    Picture(0, 0, "res\\people.bmp");
    Box(583, 43, 754, 89, BLACK, 3);
    Text(640, 54, "�������", BLACK);
    Box(365, 132, 985, 724, BLACK, 5);
    EngText(648, 145, tmp, BLACK);
    Text(421, 222, "����Ŀ��", BLACK);
    strcpy(tmp1, "data\\project\\mark\\");
    strcat(tmp1, tmp);
    fp = fopen(tmp1, "rb");
    fscanf(fp, "%s", tmp1);
    fclose(fp);
    Text(569, 217, tmp1, BLACK);
    Box(406, 291, 472, 340, BLACK, 2);
    Text(409, 294, "��Դ", BLACK);
    output_mat_Chinese(490, 294, remember_empro(0));
    background();
    show_map();
    emprospe_text(NULL);
    tick_init(manager_eprospes(true));
    set_functions(eprospes_click, eprospes_key, eprospes_move);
}
