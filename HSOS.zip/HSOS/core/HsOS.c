// Reviewed by huzpsb 2023/04/05. Approved.

#include<conio.h>
#include<dos.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>
#include"HsOS.h"

// �ⲻ�Ǳ�ʹ�õ���ȫ�ֱ�����ֻ�ж����˺�Ż�����롣
#ifdef DEBUG
FILE *logger;

void l_flush()
{
    fclose(logger);
    logger = fopen("os.log", "a");
}

#define dbg_flush l_flush
#endif

void SetSVGA64k()
{
    union REGS graph_regs;
    graph_regs.x.ax = 0x4f02;
    graph_regs.x.bx = 0x117;
    int86(0x10, &graph_regs, &graph_regs);
}

void Selectpage(register char page)
{
    union REGS graph_regs;
    static unsigned char old_page = 0;
    static int flag = 0;
    graph_regs.x.ax = 0x4f05;
    graph_regs.x.bx = 0;
    if (flag == 0)
    {
        old_page = page;
        graph_regs.x.dx = page;
        int86(0x10, &graph_regs, &graph_regs);
        flag++;
    } else if (page != old_page)
    {
        old_page = page;
        graph_regs.x.dx = page;
        int86(0x10, &graph_regs, &graph_regs);
    }
}

void Putpixel64k(int x, int y, unsigned int color)
{
    unsigned int far
    *
    const video_buffer =(unsigned int far
    *)0xa0000000L;
    unsigned char new_page;
    unsigned long int page;
    if (x < 0 || x > (SCR_WIDTH - 1) || y < 0 || y > (SCR_HEIGHT - 1))
    {
        return;
    }
    page = ((unsigned long int) y << 10) + x;
    new_page = page >> 15;
    Selectpage(new_page);
    video_buffer[page] = color;
}

unsigned int Getpixel64k(int x, int y)
{
    unsigned int far
    *
    const video_buffer =(unsigned int far
    *)0xa0000000L;
    unsigned char page;
    unsigned long int page_dev;
    if (x < 0 || x > (SCR_WIDTH - 1) || y < 0 || y > (SCR_HEIGHT - 1))
    {
        return 0;
    }
    page_dev = ((unsigned long int) y << 10) + x;
    page = page_dev >> 15;
    Selectpage(page);
    return video_buffer[page_dev];
}

bool Picture(int x, int y, const char *path)
{
    FILE *fpbmp;
    COLORS24 *buffer;
    long int width, height, linebytes;
    int i, j;
    unsigned int bit;
    unsigned long int compression;
    if ((fpbmp = fopen(path, "rb")) == NULL)
    {
        return false;
    }
    fseek(fpbmp, 28L, 0);
    fread(&bit, 2, 1, fpbmp);
    if (bit != 24U)
    {
        return false;
    }
    fseek(fpbmp, 30L, 0);
    fread(&compression, 4, 1, fpbmp);
    if (compression != 0UL)
    {
        return false;
    }
    fseek(fpbmp, 18L, 0);
    fread(&width, 4, 1, fpbmp);
    fread(&height, 4, 1, fpbmp);
    if (width > SCR_WIDTH)
    {
        return false;
    }
    linebytes = (3 * width) % 4;
    if (!linebytes)
    {
        linebytes = 3 * width;
    } else
    {
        linebytes = 3 * width + 4 - linebytes;
    }
    if ((buffer = (COLORS24 *) malloc(linebytes)) == 0)
    {
        return false;
    }
    fseek(fpbmp, 54L, 0);
    for (i = height - 1; i > -1; i--)
    {
        fread(buffer, linebytes, 1, fpbmp);
        for (j = 0; j < width; j++)
        {
            buffer[j].R >>= 3;
            buffer[j].G >>= 2;
            buffer[j].B >>= 3;
            Putpixel64k(j + x, i + y, ((((unsigned int) buffer[j].R) << 11) | (((unsigned int) buffer[j].G) << 5) |
                                       ((unsigned int) buffer[j].B)));
        }
    }
    free(buffer);
    fclose(fpbmp);
    return true;
}

void Line(int x1, int y1, int x2, int y2, unsigned int color)
{
    int i;
    if (x1 == x2)
    {
        for (i = y1; i <= y2; i++)
        {
            Putpixel64k(x1, i, color);
        }
    } else if (y1 == y2)
    {
        for (i = x1; i <= x2; i++)
        {
            Putpixel64k(i, y1, color);
        }
    }
}

void Bar(int x1, int y1, int x2, int y2, unsigned int color)
{
    int j;
    for (j = y1; j <= y2; j++)
    {
        Line(x1, j, x2, j, color);
    }
}

void Box(int x1, int y1, int x2, int y2, unsigned int color, int thickness)
{
    Bar(x1, y1, x2, y2, color);
    if ((x1 + 2 * thickness) < x2 && (y1 + 2 * thickness) < y2)
        Bar(x1 + thickness, y1 + thickness, x2 - thickness, y2 - thickness, WHITE);
}

void Box_frame(int x1, int y1, int x2, int y2, unsigned int color, int thickness)
{
    int i = 0;
    for (i = 0; i < thickness; i++)
    {
        if (((x1 + i) < (x2 - i)) && ((y1 + i) < (y2 - i)))
        {
            Line(x1 + i, y1 + i, x1 + i, y2 - i, color);
            Line(x1 + i, y1 + i, x2 - i, y1 + i, color);
            Line(x2 - i, y1 + i, x2 - i, y2 - i, color);
            Line(x1 + i, y2 - i, x2 - i, y2 - i, color);
        }
    }
}

int TextBoundary(int i)
{
    static int x = SCR_WIDTH;
    int y;
    if (i < 0)
    {
        y = x;
        x = SCR_WIDTH;
        return y;
    }
    x = i;
}

void Text(int x, int y, const char *s, unsigned int color)
{
    FILE *fp = NULL;
    char buffer[72] = {0};
    int i, j, x0;
    unsigned char qh, wh;
    unsigned long offset;
    unsigned char mask[] = {0x80, 0x40, 0x20, 0x10, 0x08, 0x04, 0x02, 0x01};
    int bound;

    bound = TextBoundary(-1) - 16;
    x0 = x;
    fp = fopen("res\\hs_HZK", "rb");
    rewind(fp);
    while (*s)
    {
        qh = *s - 160;
        wh = *(s + 1) - 160;
        offset = (94 * (qh - 1) + (wh - 1)) * 72L;
        fseek(fp, offset, SEEK_SET);
        fread(buffer, 72, 1, fp);
        for (i = 0; i < 24; i++)
            for (j = 0; j < 24; j++)
            {
                if ((mask[j % 8] & buffer[i * 3 + j / 8]) != 0)
                {
                    Putpixel64k(x + j, y + i, color);
                }
            }
        s += 2;
        x += 24;
        if (x > bound)
        {
            x = x0;
            y += 24;
        }
    }
    fclose(fp);
}

void EngText(int x, int y, const char *s, unsigned int color)
{
    FILE *fp = NULL;
    int i, j;
    unsigned long offset;
    char buffer[16] = {0};
    int bound, x0;
    x0 = x;
    bound = TextBoundary(-1) - 10;
    fp = fopen("res\\hs_YWK", "rb");
    rewind(fp);
    while (*s)
    {
        offset = *s * 16L;
        fseek(fp, offset, 0);
        fread(buffer, 16, 1, fp);
        for (i = 0; i < 16; i++)
        {
            for (j = 0; j < 8; j++)
            {
                if ((buffer[i] >> (7 - j)) & 0x1)
                {
                    Putpixel64k(x + j, y + i, color);
                }
            }
        }
        s++;
        x += 10;
        if (x > bound)
        {
            x = x0;
            y += 7;
        }
    }
    fclose(fp);
}

MOUSE mouse = {0, 0, 0};

void caller1(void (*callback1)(void))
{
    static void (*data1)(void);
    if (callback1 == NULL)
    {
#ifdef DEBUG
        fprintf(logger, "Clicked (x=%d y=%d key=%d) Processing...\n", mouse.x, mouse.y, mouse.key);
        dbg_flush();
#endif
        data1();
#ifdef DEBUG
        fprintf(logger, "Click - Done!\n");
        dbg_flush();
#endif
    } else
    {
        data1 = callback1;
    }
}

void caller2(void (*callback2)(int), int arg)
{
    static void (*data2)(int);
    if (callback2 == NULL)
    {
#ifdef DEBUG
        char pos[50];
        fprintf(logger, "Keyboard (key_down=%d) Processing...\n", arg);
        dbg_flush();
        if (arg == 96)
        {
            sprintf(pos, "%d,%d", mouse.x, mouse.y);
            Bar(0, SCR_HEIGHT - 20, 85, SCR_HEIGHT, BLACK);
            EngText(1, SCR_HEIGHT - 19, pos, WHITE);
        }
#endif
        data2(arg);
#ifdef DEBUG
        fprintf(logger, "Keyboard - Done!\n");
        dbg_flush();
#endif
    } else
    {
        data2 = callback2;
    }
}

void caller3(void (*callback3)(void))
{
    static void (*data3)(void);
    if (callback3 == NULL)
    {
        data3();
    } else
    {
        data3 = callback3;
    }
}

void set_functions(void(*callback_a)(void), void(*callback_b)(int), void(*callback_c)(void))
{
    caller1(callback_a);
    caller2(callback_b, 0);
    caller3(callback_c);
}

void MouseInit()
{
    union REGS regs;
    regs.x.ax = 0;
    int86(0x33, &regs, &regs);
    if (regs.x.ax == 0)
    {
        printf("mouse error");
        exit(1);
    }
}

void MouseSpeed(int x, int y)
{
    union REGS regs;
    regs.x.ax = 0x0f;
    regs.x.cx = x;
    regs.x.dx = y;
    int86(0x33, &regs, &regs);
}

void MouseRange(int x1, int y1, int x2, int y2)
{
    union REGS mouse;
    mouse.x.ax = 7;
    mouse.x.cx = x1;
    mouse.x.dx = x2;
    int86(0x33, &mouse, &mouse);
    mouse.x.ax = 8;
    mouse.x.cx = y1;
    mouse.x.dx = y2;
    int86(0x33, &mouse, &mouse);
}

int MouseGet(MOUSE *mouse)
{
    union REGS regs;
    regs.x.ax = 3;
    int86(0x33, &regs, &regs);
    mouse->x = regs.x.cx;
    mouse->y = regs.x.dx;
    mouse->key = regs.x.bx;
    return mouse->key;
}

int lastX(int set)
{
    static int data = -1;
    if (set != -1)
    {
        data = set;
    }
    return data;
}

int lastY(int set)
{
    static int data = -1;
    if (set != -1)
    {
        data = set;
    }
    return data;
}

unsigned int last_access(int x, int y, bool write, unsigned int value)
{
    static unsigned int last_shape[H][W];
    if (write)
    {
        last_shape[x][y] = value;
        return 0;
    }
    return last_shape[x][y];
}

void pre_mouse()
{
    draw_mouse(-114, 514);
}

void post_mouse()
{
    draw_mouse(-114, 515);
}

void draw_mouse(int mx, int my)
{
    static bool flag = false;
    static bool c3 = false;
    int mouse_shape[H][W] = {{3, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                             {1, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                             {1, 2, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0},
                             {1, 2, 2, 2, 1, 0, 0, 0, 0, 0, 0, 0},
                             {1, 2, 2, 2, 2, 1, 0, 0, 0, 0, 0, 0},
                             {1, 2, 2, 2, 2, 2, 1, 0, 0, 0, 0, 0},
                             {1, 2, 2, 2, 2, 2, 2, 1, 0, 0, 0, 0},
                             {1, 2, 2, 2, 2, 2, 2, 2, 1, 0, 0, 0},
                             {1, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0, 0},
                             {1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 0},
                             {1, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1},
                             {1, 2, 2, 1, 2, 2, 2, 1, 0, 0, 0, 0},
                             {1, 2, 1, 0, 1, 2, 2, 2, 1, 0, 0, 0},
                             {1, 1, 0, 0, 0, 1, 2, 2, 2, 1, 0, 0},
                             {1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 3}};
    int i, j;

    // ħ��ֵ1��������ص����и߹������񣬾���ǰ�������
    if (mx == -114 && my == 514)
    {
        flag = true;
        for (i = 0; i < H; i++)
        {
            for (j = 0; j < W; j++)
            {
                last_access(i, j, true, Getpixel64k(lastX(-1) + j, lastY(-1) + i));
            }
        }
        for (i = 0; i < H; i++)
        {
            for (j = 0; j < W; j++)
            {
                if (mouse_shape[i][j] == 1)
                    Putpixel64k(lastX(-1) + j, lastY(-1) + i, BLACK);
                else if (mouse_shape[i][j] == 2)
                    Putpixel64k(lastX(-1) + j, lastY(-1) + i, WHITE);
                else if (mouse_shape[i][j] == 3)
                    Putpixel64k(lastX(-1) + j, lastY(-1) + i, NAVY);
            }
        }
        return;
    }

    if (c3)
    {
        draw_error("Mouse event loop", "Called draw_mouse() with unexpected params in c3");
    }

    // ħ��ֵ2���ػ����
    if (mx == -114 && my == 515)
    {
        if ((Getpixel64k(lastX(-1), lastY(-1)) == NAVY) && (Getpixel64k(lastX(-1) + 1, lastY(-1) + 1) == WHITE) &&
            (Getpixel64k(lastX(-1) + 11, lastY(-1) + 14) == NAVY))
        {
            // ʶ������ã�˵����껹�ڣ�����Ҫ�ػ�
            return;
        }
        for (i = 0; i < H; i++)
        {
            for (j = 0; j < W; j++)
            {
                if (mouse_shape[i][j] == 1)
                    Putpixel64k(lastX(-1) + j, lastY(-1) + i, BLACK);
                else if (mouse_shape[i][j] == 2)
                    Putpixel64k(lastX(-1) + j, lastY(-1) + i, WHITE);
                else if (mouse_shape[i][j] == 3)
                    Putpixel64k(lastX(-1) + j, lastY(-1) + i, NAVY);
            }
        }
        return;
    }

    // ħ��ֵ3����������������
    if (mx == -114 && my == 516)
    {
        if (lastX(-1) != -1 && lastY(-1) != -1)
        {
            for (i = 0; i < H; i++)
            {
                for (j = 0; j < W; j++)
                {
                    Putpixel64k(lastX(-1) + j, lastY(-1) + i, last_access(i, j, false, 0));
                }
            }
        }
        return;
    }

    // ��ħ��ֵ���֣������������
    if (lastX(-1) != mx || lastY(-1) != my)
    {
        // ������λ�÷����仯

        // ��ԭ��Ļ
        if (lastX(-1) != -1 && lastY(-1) != -1)
        {
            for (i = 0; i < H; i++)
            {
                for (j = 0; j < W; j++)
                {
                    Putpixel64k(lastX(-1) + j, lastY(-1) + i, last_access(i, j, false, 0));
                }
            }
        }

        // ���»��Ƽ�¼
        lastX(mx);
        lastY(my);

        // ����caller3ʱ����Ļ��û����꣬��¼��mouseͬ��
        c3 = true;
        // c3���ڼ�¼�Ƿ�����caller3����
        caller3(NULL);
        c3 = false;

        if (flag)
        {
            flag = false;
            return;
        }
        for (i = 0; i < H; i++)
        {
            for (j = 0; j < W; j++)
            {
                last_access(i, j, true, Getpixel64k(mx + j, my + i));
            }
        }
        for (i = 0; i < H; i++)
        {
            for (j = 0; j < W; j++)
            {
                if (mouse_shape[i][j] == 1)
                    Putpixel64k(mx + j, my + i, BLACK);
                else if (mouse_shape[i][j] == 2)
                    Putpixel64k(mx + j, my + i, WHITE);
                else if (mouse_shape[i][j] == 3)
                    Putpixel64k(mx + j, my + i, NAVY);
            }
        }
    }
}

void update_mouse(int x1, int y1, int x2, int y2)
{
    int i, j;
    for (i = 0; i < H; i++)
    {
        for (j = 0; j < W; j++)
        {
            if ((lastX(-1) + j) >= x1 && (lastX(-1) + j) <= x2 && (lastY(-1) + i) >= y1 && (lastY(-1) + i) <= y2)
            {
                last_access(i, j, true, Getpixel64k(lastX(-1) + j, lastY(-1) + i));
            }
        }
    }
}

void unset()
{
}

void _init()
{
    int x;
#ifdef DEBUG
    logger = fopen("os.log", "w");
#endif
    SetSVGA64k();
    MouseInit();
    MouseRange(0, 0, SCR_WIDTH, SCR_HEIGHT);
    MouseGet(&mouse);
    MouseSpeed(6, 4);
    set_functions(unset, unset, unset);
#ifdef DEBUG
    Bar(0, 0, SCR_WIDTH, SCR_HEIGHT, BLACK);
    EngText(10, 10, "HsOS v2.01 Release1", WHITE);
    EngText(10, 30, "Booting...", WHITE);
#else
    Picture(0, 0, "res\\boot.bmp");

    delay(1500);
    for (x = 0; x < 111; x++)
    {
        Bar(211 + (5 * x), 597, 211 + (5 * (x + 1)), 605, 0xee55);
        delay(100);
    }
#endif
    delay(1500);
    if (kbhit())
    {
        getch();
    }
}

void _update()
{
    static bool lastkey = false;
    MouseGet(&mouse);
    if (!lastkey && mouse.key)
    {
        caller1(NULL);
        post_mouse();
    }
    if (kbhit())
    {
        int key = getch();
        if (key == 27)
        {
            exit(0);
        }
        caller2(NULL, key);
        post_mouse();
    }
    draw_mouse(mouse.x, mouse.y);
    lastkey = mouse.key;
    internal_music(0);
}

elements *new_node()
{
    elements *b = malloc(sizeof(struct _btns));
    b->next = NULL;
    return b;
}

elements *push(element *b, elements *s)
{
    elements *chain;
    chain = s;
    if (chain == NULL)
    {
        chain = new_node();
        chain->now = b;
        return chain;
    }
    while (true)
    {
        if (chain->next == NULL)
        {
            break;
        }
        chain = chain->next;
    }
    chain->next = new_node();
    chain->next->now = b;
    return s;
}

bool isnull(elements *b)
{
    elements *chain = b;
    if (b == NULL)
    {
        return true;
    }
    while (true)
    {
        if (chain->now->id != NULL)
        {
            chain->now->text[0] = '\0';
            chain->now->selected = false;
            chain->now->was = false;
            if (chain->now->chinese != NULL)
            {
                chain->now->chinese[0] = '\0';
            }
        } else
        {
            chain->now->was = false;
        }
        if (chain->next == NULL)
        {
            return false;
        }
        chain = chain->next;
    }
}

element *new_button(int x1, int y1, int x2, int y2, char *text, unsigned int text_color, unsigned int default_color,
                    unsigned int selected_color, void(*click)(void))
{
    element *b = malloc(sizeof(struct _btn));
    b->x1 = x1;
    b->x2 = x2;
    b->y1 = y1;
    b->y2 = y2;
    b->text = text;
    b->text_color = text_color;
    b->default_color = default_color;
    b->selected_color = selected_color;
    b->was = false;
    b->click = click;
    b->id = NULL;
    b->selected = false;
    b->capacity = 0;
    b->password = false;
    b->chinese = NULL;
#ifdef DEBUG
    fprintf(logger, "Created Button %s\n", text);
    dbg_flush();
#endif
    return b;
}

element *
new_input(int x1, int y1, int x2, int y2, char *id, int capacity, unsigned int text_color, unsigned int default_color,
          unsigned int selected_color, bool password, bool chinese)
{
    element *b = malloc(sizeof(struct _btn));
    b->x1 = x1;
    b->x2 = x2;
    b->y1 = y1;
    b->y2 = y2;
    b->text = malloc(sizeof(char) * (capacity + 1));
    b->text[0] = '\0';
    b->text_color = text_color;
    b->default_color = default_color;
    b->selected_color = selected_color;
    b->was = false;
    b->click = NULL;
    b->id = id;
    b->selected = false;
    b->capacity = capacity;
    b->password = password;
    if (chinese)
    {
        b->chinese = malloc(10);
        b->chinese[0] = '\0';
    } else
    {
        b->chinese = NULL;
    }
#ifdef DEBUG
    fprintf(logger, "Created Input %s\n", id);
    dbg_flush();
#endif
    return b;
}

const char *get_input(elements *b, char *id)
{
    elements *chain = b;
    while (true)
    {
        if (chain->now->id != NULL)
        {
            if (!strcmp(chain->now->id, id))
            {
#ifdef DEBUG
                fprintf(logger, "Input (%s) is get.(Value=%s).\n", chain->now->id, chain->now->text);
                dbg_flush();
#endif
                return chain->now->text;
            }
        }
        if (chain->next == NULL)
        {
            draw_error("Input not found", id);
        }
        chain = chain->next;
    }
}

void draw_char(int x1, int y1, int x2, int y2, char *text, unsigned int background_color, unsigned int text_color,
               bool password)
{
    int char_len;
    int i;
    char char_cover[30];
    Bar(x1 + 1, y1 + 1, x2 - 1, y2 - 1, background_color);
    if (password)
    {
        char_len = strlen(text);
        for (i = 0; i < char_len; i++)
        {
            char_cover[i] = '*';
        }
        char_cover[char_len] = '\0';
        TextBoundary(x2 - 1);
        EngText(x1 + 3, y1 + 3, char_cover, text_color);
    } else
    {
        TextBoundary(x2 - 1);
        EngText(x1 + 3, y1 + 3, text, text_color);
    }
    update_mouse(x1 + 1, y1 + 1, x2 - 1, y2 - 1);
}

void tick_click(elements *b)
{
    static bool stop = false;
    elements *chain = b;
    bool canSelectInput = true;
    if (b == NULL)
    {
        stop = true;
#ifdef DEBUG
        fprintf(logger, "Click Handling Abortion Scheduled!\n");
        dbg_flush();
#endif
        return;
    }
#ifdef DEBUG
    fprintf(logger, "System Click Handling Started!\n");
    dbg_flush();
#endif
    while (true)
    {
        if (chain->now->id == NULL)
        {
            if (mouse.x > chain->now->x1 && mouse.x < chain->now->x2 && mouse.y > chain->now->y1 &&
                mouse.y < chain->now->y2 && canSelectInput)
            {
#ifdef DEBUG
                fprintf(logger, "Button (%s) is clicked.\n", chain->now->text);
                dbg_flush();
#endif
                chain->now->click();
                canSelectInput = false;
            }
        } else
        {
            if (mouse.x > chain->now->x1 && mouse.x < chain->now->x2 && mouse.y > chain->now->y1 &&
                mouse.y < chain->now->y2 && canSelectInput)
            {
                chain->now->selected = true;
                canSelectInput = false;
                if (chain->now->chinese == NULL)
                {
                    draw_char(chain->now->x1, chain->now->y1, chain->now->x2, chain->now->y2, chain->now->text,
                              chain->now->selected_color, chain->now->text_color, chain->now->password);
                } else
                {
                    chain->now->chinese[0] = '\0';
                    Bar(chain->now->x1 + 1, chain->now->y1 + 1, chain->now->x2 - 1, chain->now->y2 - 1,
                        chain->now->selected_color);
                    TextBoundary(chain->now->x2 - 1);
                    Text(chain->now->x1 + 1, chain->now->y1 + 1, chain->now->text, chain->now->text_color);
                }
            } else
            {
                chain->now->selected = false;
                if (chain->now->chinese == NULL)
                {
                    draw_char(chain->now->x1, chain->now->y1, chain->now->x2, chain->now->y2, chain->now->text,
                              chain->now->default_color, chain->now->text_color, chain->now->password);
                } else
                {
                    chain->now->chinese[0] = '\0';
                    Bar(chain->now->x1 + 1, chain->now->y1 + 1, chain->now->x2 - 1, chain->now->y2 - 1,
                        chain->now->default_color);
                    TextBoundary(chain->now->x2 - 1);
                    Text(chain->now->x1 + 1, chain->now->y1 + 1, chain->now->text, chain->now->text_color);
                }
            }
        }
        if (chain->next == NULL)
        {
            if (canSelectInput)
            {
#ifdef DEBUG
                fprintf(logger, "System Click Handling Failed (Nothing Selected)!\n");
                dbg_flush();
#endif
            } else
            {
#ifdef DEBUG
                fprintf(logger, "System Click Handling Done!\n");
                dbg_flush();
#endif
            }
            break;
        }
        if (stop)
        {
            break;
        }
        chain = chain->next;
    }
    if (stop)
    {
        stop = false;
#ifdef DEBUG
        fprintf(logger, "Click Handling Aborted (Page Changed)!\n");
        dbg_flush();
#endif
    }
}

void tick_move(elements *b)
{
    elements *chain = b;
    bool updted = false;
    while (true)
    {
        bool is = false;
        if (chain->now->id == NULL)
        {
            if (mouse.x > chain->now->x1 && mouse.x < chain->now->x2 && mouse.y > chain->now->y1 &&
                mouse.y < chain->now->y2)
            {
                is = true;
            }
            if (is && !chain->now->was)
            {
                Bar(chain->now->x1, chain->now->y1, chain->now->x2, chain->now->y2, chain->now->selected_color);
                updted = true;
            } else if (!is && chain->now->was)
            {
                Bar(chain->now->x1, chain->now->y1, chain->now->x2, chain->now->y2, chain->now->default_color);
                updted = true;
            }
            if (updted)
            {
                TextBoundary(chain->now->x2 - 1);
                Text((((chain->now->x1 + chain->now->x2) / 2) - (strlen(chain->now->text) * 6)),
                     ((chain->now->y1 + chain->now->y2) / 2) - 12, chain->now->text, chain->now->text_color);
                update_mouse(chain->now->x1, chain->now->y1, chain->now->x2, chain->now->y2);
            }
            chain->now->was = is;
        }
        if (chain->next == NULL)
        {
            break;
        }
        chain = chain->next;
    }
}

void tick_init(elements *b)
{
    elements *chain = b;
#ifdef DEBUG
    fprintf(logger, "\nRendering\n");
    dbg_flush();
#endif
    while (true)
    {
        if (chain->now->id == NULL)
        {
#ifdef DEBUG
            fprintf(logger, "Init Button ");
            dbg_flush();
#endif
            Bar(chain->now->x1, chain->now->y1, chain->now->x2, chain->now->y2, chain->now->default_color);
            TextBoundary(chain->now->x2 - 1);
            Text((((chain->now->x1 + chain->now->x2) / 2) - (strlen(chain->now->text) * 6)),
                 ((chain->now->y1 + chain->now->y2) / 2) - 12, chain->now->text, chain->now->text_color);
#ifdef DEBUG
            fprintf(logger, "%s\n", chain->now->text);
            dbg_flush();
#endif
        } else
        {
#ifdef DEBUG
            fprintf(logger, "Init Input ");
            dbg_flush();
#endif
            Bar(chain->now->x1 + 1, chain->now->y1 + 1, chain->now->x2 - 1, chain->now->y2 - 1,
                chain->now->default_color);
            Line(chain->now->x1, chain->now->y1, chain->now->x2, chain->now->y1, chain->now->text_color);
            Line(chain->now->x1, chain->now->y1, chain->now->x1, chain->now->y2, chain->now->text_color);
            Line(chain->now->x2, chain->now->y1, chain->now->x2, chain->now->y2, chain->now->text_color);
            Line(chain->now->x1, chain->now->y2, chain->now->x2, chain->now->y2, chain->now->text_color);
#ifdef DEBUG
            fprintf(logger, "%s\n", chain->now->id);
            dbg_flush();
#endif
        }
        if (chain->next == NULL)
        {
            break;
        }
        chain = chain->next;
    }
#ifdef DEBUG
    fprintf(logger, "Done\n\n");
    dbg_flush();
#endif
}

void tick_key(elements *b, int i)
{
    int length, c_length;
    elements *chain = b;
    while (true)
    {
        if (chain->now->id != NULL)
        {
            if (chain->now->selected)
            {
                if (chain->now->chinese == NULL)
                {
                    length = strlen(chain->now->text);
                    if (i == 8)
                    {
                        if (length > 0)
                        {
                            chain->now->text[length - 1] = '\0';
                        }
                    } else if (i >= 32 && i <= 126)
                    {
                        if (length < chain->now->capacity)
                        {
                            chain->now->text[length] = i;
                            chain->now->text[length + 1] = '\0';
                        }
                    }
                    draw_char(chain->now->x1, chain->now->y1, chain->now->x2, chain->now->y2, chain->now->text,
                              chain->now->selected_color, chain->now->text_color, chain->now->password);
#ifdef DEBUG
                    fprintf(logger, "Input (%s) is set to (%s).\n", chain->now->id, chain->now->text);
                    dbg_flush();
#endif
                } else
                {
// -
// ���������
                    c_length = strlen(chain->now->chinese);
                    length = strlen(chain->now->text);
// ������״̬ c_length=0 ������ʾ c_length!=0 ����ʱ��ƴ����ʾ i==13 ƴ��ת����ѡ���
                    if (i == 8)
                    {
                        if (c_length > 0)
                        {
                            chain->now->chinese[c_length - 1] = '\0';
                            c_length--;
                        } else if (length > 0)
                        {
                            chain->now->text[length - 2] = '\0';
                        }
                    } else if (i >= 32 && i <= 126)
                    {
                        if (((c_length != 0) && (c_length < 9)) || (length < chain->now->capacity - 2))
                        {
                            chain->now->chinese[c_length] = i;
                            chain->now->chinese[c_length + 1] = '\0';
                            c_length++;
                        }
                    } else if (i == 13 && c_length != 0)
                    {
                        char ime[50], cont[250], now[21];
// Ime �ֿ�·�� cont �ֿ����� now ��ʱ�ı�
                        int clen, index, index_now, j;
                        bool update = true;
                        FILE *fp;
                        strcpy(ime, "res\\py\\");
                        strcat(ime, chain->now->chinese);
                        strcat(ime, ".txt");
                        fp = fopen(ime, "rb");
                        if (fp != NULL)
                        {
                            fgets(cont, 250, fp);
                            fclose(fp);
                            clen = strlen(cont) / 2;
                            index = 0;
                            while (true)
                            {
                                if (kbhit())
                                {
                                    int key = getch();
                                    if (key == 27)
                                    {
                                        c_length = 0;
                                        chain->now->chinese[0] = '\0';
                                        break;
                                    }
                                    if (key > '0' && key < '7')
                                    {
                                        index_now = index * 6 + (key - '1');
                                        now[0] = cont[index_now * 2];
                                        now[1] = cont[index_now * 2 + 1];
                                        now[2] = '\0';
                                        strcat(chain->now->text, now);
                                        c_length = 0;
                                        chain->now->chinese[0] = '\0';
                                        break;
                                    }
                                    if (key == 'a')
                                    {
                                        if (index > 0)
                                        {
                                            index--;
                                        }
                                    }
                                    if (key == 'd')
                                    {
                                        if ((index + 1) * 6 < clen)
                                        {
                                            index++;
                                        }
                                    }
                                    update = true;
                                }
                                if (update)
                                {
                                    update = false;
                                    now[0] = '\0';
                                    for (j = 0; j < 6; j++)
                                    {
                                        index_now = index * 6 + j;
                                        if (index_now <= clen)
                                        {
                                            now[2 * j] = cont[index_now * 2];
                                            now[2 * j + 1] = cont[index_now * 2 + 1];
                                            now[2 * j + 2] = '\0';
                                        }
                                    }
                                    Bar(chain->now->x1 + 1, chain->now->y1 + 1, chain->now->x2 - 1, chain->now->y2 - 1,
                                        chain->now->selected_color);
                                    TextBoundary(chain->now->x2 - 1);
                                    Text(chain->now->x1 + 1, chain->now->y1 + 1, now, chain->now->text_color);
                                }
                            }
                        } else
                        {
                            c_length = 0;
                            chain->now->chinese[0] = '\0';
                        }
                    }

                    Bar(chain->now->x1 + 1, chain->now->y1 + 1, chain->now->x2 - 1, chain->now->y2 - 1,
                        chain->now->selected_color);
                    if (c_length == 0)
                    {
                        TextBoundary(chain->now->x2 - 1);
                        Text(chain->now->x1 + 1, chain->now->y1 + 1, chain->now->text, chain->now->text_color);
                    } else
                    {
                        EngText(chain->now->x1 + 1, chain->now->y1 + 1, chain->now->chinese, chain->now->text_color);
                    }
// -
                }
                break;
            }
        }
        if (chain->next == NULL)
        {
            break;
        }
        chain = chain->next;
    }
}

void draw_error(char *s1, char *s2)
{
    set_functions(unset, unset, unset);
    TextBoundary(-1); // Reset TextBoundary
    Bar(0, 0, SCR_WIDTH, SCR_HEIGHT, BLUE);
    EngText(2, 2, "A fatal error has occured :(", WHITE);
    EngText(2, 17, "Details:", WHITE);
    EngText(2, 32, s1, WHITE);
    EngText(2, 47, "Caused by:", WHITE);
    if (s2[0] > 0)
    {
        EngText(2, 62, s2, WHITE);
    } else
    {
        Text(2, 62, s2, WHITE);
    }
    while (true)
    {
        if (kbhit())
        {
            int key = getch();
            if (key == 27)
            {
                exit(0);
            }
        }
        delay(100);
    }
}

char *toString(int i)
{
    int len = 0;
    int now = i;
    static char *ret = NULL;
    if (ret != NULL)
    {
        free(ret);
    }
    while (true)
    {
        len++;
        now = now / 10;
        if (now == 0)
        {
            break;
        }
    }
    if (i < 0)
    {
        len++;
    }
    ret = malloc(sizeof(char) * (len + 1));
    ret[len] = '\0';
    now = i;
    if (i < 0)
    {
        now = -i;
        ret[0] = '-';
    }
    while (true)
    {
        len--;
        ret[len] = (now % 10) + '0';
        now = now / 10;
        if (now == 0)
        {
            break;
        }
    }
    return ret;
}

void internal_music(int opr)
{
    static bool playing = false;
    static int m_index = 0;
    static unsigned long timestamp = 0;
    int frq[279] = {0, 1318, 1318, 1318, 0, 1046, 1318, 1568, 0, 784, 0, 1046, 0, 784, 0, 659, 0, 880, 988, 0, 932, 880,
                    784, 1318, 1568, 1760, 1397, 1568, 0, 1318, 1046, 1175, 988, 0, 1046, 0, 784, 0, 659, 0, 880, 988,
                    0, 932, 880, 784, 1318, 1568, 1760, 1397, 1568, 0, 1318, 1046, 1175, 988, 0, 0, 1568, 1480, 1397,
                    1318, 1245, 0, 831, 880, 1046, 0, 880, 1046, 1175, 0, 1568, 1480, 1397, 1245, 1318, 0, 2093, 2093,
                    2093, 0, 0, 1568, 1480, 1397, 1245, 1318, 0, 831, 880, 1046, 0, 880, 1046, 1175, 0, 1245, 0, 1175,
                    0, 1046, 0, 0, 0, 1568, 1480, 1397, 1245, 1318, 0, 831, 880, 1046, 0, 880, 1046, 1175, 0, 1568,
                    1480, 1397, 1245, 1318, 0, 2093, 2093, 2093, 0, 0, 1568, 1480, 1397, 1245, 1318, 0, 831, 880, 1046,
                    0, 880, 1046, 1175, 0, 1245, 0, 1175, 0, 1046, 0, 0, 1046, 1046, 1046, 0, 1046, 1175, 1318, 1046,
                    880, 784, 0, 1046, 1046, 1046, 0, 1046, 1175, 1318, 0, 0, 1046, 1046, 1046, 0, 1046, 1175, 1318,
                    1046, 880, 784, 0, 1318, 1318, 1318, 0, 1046, 1318, 1568, 0, 784, 0, 1046, 0, 784, 0, 659, 0, 880,
                    988, 0, 932, 880, 0, 784, 1318, 1568, 1760, 1397, 1568, 0, 1318, 1046, 1175, 988, 0, 1046, 0, 784,
                    0, 659, 0, 880, 988, 0, 932, 880, 784, 1318, 1568, 1760, 1397, 1568, 0, 1318, 1046, 1175, 988, 0,
                    1318, 1046, 784, 0, 831, 880, 1397, 1397, 880, 0, 988, 1760, 1760, 1760, 1568, 1397, 1318, 1046,
                    880, 784, 0, 1318, 1046, 784, 0, 831, 880, 1397, 1397, 880, 0, 988, 1397, 1397, 1397, 1318, 1175,
                    1046, 0, 0};
    int tm[279] = {0, 160, 320, 160, 160, 160, 320, 320, 320, 320, 320, 320, 160, 160, 320, 320, 160, 320, 160, 160,
                   160, 320, 213, 213, 213, 320, 160, 160, 160, 320, 160, 160, 320, 160, 320, 160, 160, 320, 320, 160,
                   320, 160, 160, 160, 320, 213, 213, 213, 320, 160, 160, 160, 320, 160, 160, 320, 160, 320, 160, 160,
                   160, 320, 160, 160, 160, 160, 160, 160, 160, 160, 160, 320, 160, 160, 160, 320, 160, 160, 320, 160,
                   320, 320, 320, 160, 160, 160, 320, 160, 160, 160, 160, 160, 160, 160, 160, 160, 320, 320, 160, 320,
                   160, 320, 320, 640, 320, 160, 160, 160, 320, 160, 160, 160, 160, 160, 160, 160, 160, 160, 320, 160,
                   160, 160, 320, 160, 160, 320, 160, 320, 320, 320, 160, 160, 160, 320, 160, 160, 160, 160, 160, 160,
                   160, 160, 160, 320, 320, 160, 320, 160, 320, 320, 640, 160, 320, 160, 160, 160, 320, 160, 320, 160,
                   320, 320, 160, 320, 160, 160, 160, 160, 160, 640, 640, 160, 320, 160, 160, 160, 320, 160, 320, 160,
                   320, 320, 160, 320, 160, 160, 160, 320, 320, 320, 320, 320, 320, 160, 160, 320, 320, 160, 320, 160,
                   160, 160, 160, 160, 213, 213, 213, 320, 160, 160, 160, 320, 160, 160, 320, 160, 320, 160, 160, 320,
                   320, 160, 320, 160, 160, 160, 320, 213, 213, 213, 320, 160, 160, 160, 320, 160, 160, 320, 160, 160,
                   320, 160, 320, 320, 160, 320, 160, 320, 320, 213, 213, 213, 213, 213, 213, 160, 320, 160, 320, 320,
                   160, 320, 160, 320, 320, 160, 320, 160, 320, 320, 160, 320, 160, 213, 213, 213, 320, 320, 640};
    unsigned long now;
    if (opr == 1)
    {
        playing = true;
        m_index = 0;
    } else if (opr == 2)
    {
        playing = false;
        nosound();
    }
    if (!playing)
    {
        return;
    }
    now = ((1000.0 * clock()) / CLOCKS_PER_SEC);
    if (now > timestamp + tm[m_index])
    {
        timestamp = now;
        m_index++;
        if (m_index >= 279)
        {
            m_index = 0;
        }
    }
    sound(frq[m_index]);
}

void music(bool status)
{
    FILE *fp;
    fp = fopen("C:\\MUSIC\\STAT", "r");
    if (fp != NULL)
    {
        fclose(fp);
        if (status)
        {
            fp = fopen("C:\\MUSIC\\PLAY", "w");
            fprintf(fp, "PLAY");
            fclose(fp);
        } else
        {
            IFileDelete("C:\\MUSIC\\PLAY");
        }
    } else if (status)
    {
        internal_music(1);
    } else
    {
        internal_music(2);
    }
}

int is_mask_applicable(int row, int column, unsigned char mask_number)
{
    switch (mask_number)
    {
        case 0:
            return ((row + column) % 2 == 0);
        case 1:
            return ((row % 2) == 0);
        case 2:
            return ((column % 3) == 0);
        case 3:
            return ((row + column) % 3 == 0);
        case 4:
            return ((((row / 2) + (column / 3)) % 2) == 0);
        case 5:
            return ((((row * column) % 2) + ((row * column) % 3)) == 0);
        case 6:
            return ((((row * column) % 2) + ((row * column) % 3)) % 2 == 0);
        case 7:
            return ((((row + column) % 2) + ((row * column) % 3)) % 2 == 0);
        default:
            return 0;
    }
}

void draw_qr(const char *freetext, int x2, int y2)
{
    unsigned char a_original[] = {1, 2, 4, 8, 16, 32, 64, 128, 29, 58, 116, 232, 205, 135, 19, 38, 76, 152, 45, 90, 180,
                                  117, 234, 201, 143, 3, 6, 12, 24, 48, 96, 192, 157, 39, 78, 156, 37, 74, 148, 53, 106,
                                  212, 181, 119, 238, 193, 159, 35, 70, 140, 5, 10, 20, 40, 80, 160, 93, 186, 105, 210,
                                  185, 111, 222, 161, 95, 190, 97, 194, 153, 47, 94, 188, 101, 202, 137, 15, 30, 60,
                                  120, 240, 253, 231, 211, 187, 107, 214, 177, 127, 254, 225, 223, 163, 91, 182, 113,
                                  226, 217, 175, 67, 134, 17, 34, 68, 136, 13, 26, 52, 104, 208, 189, 103, 206, 129, 31,
                                  62, 124, 248, 237, 199, 147, 59, 118, 236, 197, 151, 51, 102, 204, 133, 23, 46, 92,
                                  184, 109, 218, 169, 79, 158, 33, 66, 132, 21, 42, 84, 168, 77, 154, 41, 82, 164, 85,
                                  170, 73, 146, 57, 114, 228, 213, 183, 115, 230, 209, 191, 99, 198, 145, 63, 126, 252,
                                  229, 215, 179, 123, 246, 241, 255, 227, 219, 171, 75, 150, 49, 98, 196, 149, 55, 110,
                                  220, 165, 87, 174, 65, 130, 25, 50, 100, 200, 141, 7, 14, 28, 56, 112, 224, 221, 167,
                                  83, 166, 81, 162, 89, 178, 121, 242, 249, 239, 195, 155, 43, 86, 172, 69, 138, 9, 18,
                                  36, 72, 144, 61, 122, 244, 245, 247, 243, 251, 235, 203, 139, 11, 22, 44, 88, 176,
                                  125, 250, 233, 207, 131, 27, 54, 108, 216, 173, 71, 142, 1};
    unsigned char a_inv[] = {0, 0, 1, 25, 2, 50, 26, 198, 3, 223, 51, 238, 27, 104, 199, 75, 4, 100, 224, 14, 52, 141,
                             239, 129, 28, 193, 105, 248, 200, 8, 76, 113, 5, 138, 101, 47, 225, 36, 15, 33, 53, 147,
                             142, 218, 240, 18, 130, 69, 29, 181, 194, 125, 106, 39, 249, 185, 201, 154, 9, 120, 77,
                             228, 114, 166, 6, 191, 139, 98, 102, 221, 48, 253, 226, 152, 37, 179, 16, 145, 34, 136, 54,
                             208, 148, 206, 143, 150, 219, 189, 241, 210, 19, 92, 131, 56, 70, 64, 30, 66, 182, 163,
                             195, 72, 126, 110, 107, 58, 40, 84, 250, 133, 186, 61, 202, 94, 155, 159, 10, 21, 121, 43,
                             78, 212, 229, 172, 115, 243, 167, 87, 7, 112, 192, 247, 140, 128, 99, 13, 103, 74, 222,
                             237, 49, 197, 254, 24, 227, 165, 153, 119, 38, 184, 180, 124, 17, 68, 146, 217, 35, 32,
                             137, 46, 55, 63, 209, 91, 149, 188, 207, 205, 144, 135, 151, 178, 220, 252, 190, 97, 242,
                             86, 211, 171, 20, 42, 93, 158, 132, 60, 57, 83, 71, 109, 65, 162, 31, 45, 67, 216, 183,
                             123, 164, 118, 196, 23, 73, 236, 127, 12, 111, 246, 108, 161, 59, 82, 41, 157, 85, 170,
                             251, 96, 134, 177, 187, 204, 62, 90, 203, 89, 95, 176, 156, 169, 160, 81, 11, 245, 22, 235,
                             122, 117, 44, 215, 79, 174, 213, 233, 230, 231, 173, 232, 116, 214, 244, 234, 168, 80, 88,
                             175};
    unsigned char gen_poly[] = {74, 152, 176, 100, 86, 100, 106, 104, 130, 218, 206, 140, 78, 215, 234, 158, 94, 184,
                                97, 118, 170, 79, 187, 152, 148, 252, 179, 5, 98, 96, 153, 17, 60, 79, 50, 61, 163, 26,
                                187, 202, 180, 221, 225, 83, 239, 156, 164, 212, 212, 188, 190, 210, 171, 247, 242, 93,
                                230, 14, 109, 221, 53, 200, 74, 8, 172, 98, 80, 219, 134, 160, 105, 165, 231, 229, 121,
                                135, 48, 211, 117, 251, 126, 159, 180, 169, 152, 192, 226, 228, 218, 111, 0, 117, 232,
                                87, 96, 227, 21, 173, 125, 158, 2, 103, 182, 118, 17, 145, 201, 111, 28, 165, 53, 161,
                                21, 245, 142, 13, 102, 48, 227, 153, 145, 218, 70, 168, 223, 200, 104, 224, 234, 108,
                                180, 110, 190, 195, 147, 205, 27, 232, 201, 21, 43, 245, 87, 42, 195, 212, 119, 242, 37,
                                9, 123, 41, 173, 145, 152, 216, 31, 179, 182, 50, 48, 110, 86, 239, 96, 222, 125, 42,
                                173, 226, 193, 224, 130, 156, 37, 251, 216, 238, 40, 192, 180};
    unsigned char gen_offset[] = {0, 0, 0, 0, 0, 13, 0, 31, 0, 51, 0, 73, 0, 97, 0, 123, 0, 151};
    int mask_info[] = {13663, 12392, 16177, 14854, 9396, 8579, 11994, 11245};
    unsigned char version_info[] = {20, 50, 7, 60, 22, 8, 25, 42, 9, 19, 19, 10, 54, 47, 11, 34, 29, 12, 7, 33, 13, 13,
                                    24, 14, 40, 36, 15, 56, 45, 16, 29, 17, 17, 23, 40, 18, 50, 20, 19, 38, 38, 20, 3,
                                    26, 21, 9, 35, 22, 44, 31, 23, 4, 59, 24, 33, 7, 25, 43, 62, 26, 14, 2, 27, 26, 48,
                                    28, 63, 12, 29, 53, 53, 30, 16, 9, 31, 21, 39, 32, 48, 27, 33, 58, 34, 34, 31, 30,
                                    35, 11, 44, 36, 46, 16, 37, 36, 41, 38, 1, 21, 39, 41, 49, 40};
    unsigned char codeword_parameters[40][12] = {{13, 1,  13, 0,  0,  0, 0,  0,  0,  0,   0,   0},
                                                 {22, 1,  22, 0,  0,  7, 18, 0,  0,  0,   0,   0},
                                                 {18, 2,  17, 0,  0,  7, 22, 0,  0,  0,   0,   0},
                                                 {26, 2,  24, 0,  0,  7, 26, 0,  0,  0,   0,   0},
                                                 {18, 2,  15, 2,  16, 7, 30, 0,  0,  0,   0,   0},
                                                 {24, 4,  19, 0,  0,  7, 34, 0,  0,  0,   0,   0},
                                                 {18, 2,  14, 4,  15, 0, 22, 38, 0,  0,   0,   0},
                                                 {22, 4,  18, 2,  19, 0, 24, 42, 0,  0,   0,   0},
                                                 {20, 4,  16, 4,  17, 0, 26, 46, 0,  0,   0,   0},
                                                 {24, 6,  19, 2,  20, 0, 28, 50, 0,  0,   0,   0},
                                                 {28, 4,  22, 4,  23, 0, 30, 54, 0,  0,   0,   0},
                                                 {26, 4,  20, 6,  21, 0, 32, 58, 0,  0,   0,   0},
                                                 {24, 8,  20, 4,  21, 0, 34, 62, 0,  0,   0,   0},
                                                 {20, 11, 16, 5,  17, 3, 26, 46, 66, 0,   0,   0},
                                                 {30, 5,  24, 7,  25, 3, 26, 48, 70, 0,   0,   0},
                                                 {24, 15, 19, 2,  20, 3, 26, 50, 74, 0,   0,   0},
                                                 {28, 1,  22, 15, 23, 3, 30, 54, 78, 0,   0,   0},
                                                 {28, 17, 22, 1,  23, 3, 30, 56, 82, 0,   0,   0},
                                                 {26, 17, 21, 4,  22, 3, 30, 58, 86, 0,   0,   0},
                                                 {30, 15, 24, 5,  25, 3, 34, 62, 90, 0,   0,   0},
                                                 {28, 17, 22, 6,  23, 4, 28, 50, 72, 94,  0,   0},
                                                 {30, 7,  24, 16, 25, 4, 26, 50, 74, 98,  0,   0},
                                                 {30, 11, 24, 14, 25, 4, 30, 54, 78, 102, 0,   0},
                                                 {30, 11, 24, 16, 25, 4, 28, 54, 80, 106, 0,   0},
                                                 {30, 7,  24, 22, 25, 4, 32, 58, 84, 110, 0,   0},
                                                 {28, 28, 22, 6,  23, 4, 30, 58, 86, 114, 0,   0},
                                                 {30, 8,  23, 26, 24, 4, 34, 62, 90, 118, 0,   0},
                                                 {30, 4,  24, 31, 25, 3, 26, 50, 74, 98,  122, 0},
                                                 {30, 1,  23, 37, 24, 3, 30, 54, 78, 102, 126, 0},
                                                 {30, 15, 24, 25, 25, 3, 26, 52, 78, 104, 130, 0},
                                                 {30, 42, 24, 1,  25, 3, 30, 56, 82, 108, 134, 0},
                                                 {30, 10, 24, 35, 25, 3, 34, 60, 86, 112, 138, 0},
                                                 {30, 29, 24, 19, 25, 3, 30, 58, 86, 114, 142, 0},
                                                 {30, 44, 24, 7,  25, 3, 34, 62, 90, 118, 146, 0},
                                                 {30, 39, 24, 14, 25, 0, 30, 54, 78, 102, 126, 150},
                                                 {30, 46, 24, 10, 25, 0, 24, 50, 76, 102, 128, 154},
                                                 {30, 49, 24, 10, 25, 0, 28, 54, 80, 106, 132, 158},
                                                 {30, 48, 24, 14, 25, 0, 32, 58, 84, 110, 136, 162},
                                                 {30, 43, 24, 22, 25, 0, 26, 54, 82, 110, 138, 166},
                                                 {30, 34, 24, 34, 25, 0, 30, 58, 86, 114, 142, 170}};
    int i, j, k, x, y;
    unsigned char message[1666] = {0};
    int message_length = (int) strlen(freetext);
    int qr_version = -1;
    unsigned char *message_parameters;
    int message_index;
    int error_codewords;
    unsigned char errorcode[30] = {0};
    int total_blocks;
    unsigned char interleaved_output[3706] = {0};
    int message_offset = 0;
    int block_number = 0;
    int groups, blocks;
    int dir;
    int primary_bits;
    int remainder_bits;
    unsigned char working_byte = 0;
    int interleaved_index = -1;
    int interleaved_output_offset;
    int output_size;
    int max_pixels;
    unsigned char **image;
    int finder_pattern;
    unsigned char mask_number;
    int mask, skip;
    for (i = 0; i < 40; i++)
    {
        int capacity = codeword_parameters[i][1] * codeword_parameters[i][2] +
                       codeword_parameters[i][3] * codeword_parameters[i][4] - 2;
        if (i > 8)
            capacity--;
        if (message_length <= capacity)
        {
            qr_version = i;
            break;
        }
    }
    if (qr_version < 0)
    {
        return;
    }
    message_parameters = codeword_parameters[qr_version];
    message_index = 0;
    message[message_index] = 64;
    if (qr_version > 8)
    {
        message_index++;
        message[message_index++] = ((message_length & 5888) >> 4) | ((message_length & 240) >> 4);
    } else
    {
        message[message_index++] |= ((message_length & 240) >> 4);
    }
    message[message_index++] = ((message_length & 15) << 4) | ((freetext[0] & 240) >> 4);
    for (i = 0; i < message_length; i++)
        message[message_index++] = ((freetext[i] & 15) << 4) | ((freetext[i + 1] & 240) >> 4);
    {
        unsigned char pad[] = {236, 17};
        int pad_index = 0;
        int needed_pad_bytes =
                (message_parameters[1] * message_parameters[2]) + (message_parameters[3] * message_parameters[4]) -
                message_index;
        for (i = 0; i < needed_pad_bytes; i++)
        {
            message[message_index++] = pad[pad_index];
            pad_index ^= 1;
        }
    }
    error_codewords = message_parameters[0];
    total_blocks = message_parameters[1] + message_parameters[3];
    for (groups = 0; groups < 2; groups++)
    {
        int num_blocks = message_parameters[groups * 2 + 1];
        int data_codewords = message_parameters[groups * 2 + 2];
        for (blocks = 0; blocks < num_blocks; blocks++)
        {
            int i1, j1;
            for (i1 = 0; i1 < data_codewords; i1++)
                errorcode[i1] = message[i1 + message_offset];
            for (i1 = data_codewords; i1 < error_codewords; i1++)
                errorcode[i1] = 0;
            for (j1 = 1; j1 <= data_codewords; j1++)
            {
                int leadTerm = a_inv[errorcode[0]];
                if (errorcode[0] != 0)
                {
                    for (i1 = 1; i1 <= error_codewords; i1++)
                    {
                        unsigned char tempValue = 0;
                        if (i1 < error_codewords)
                            tempValue = errorcode[i1];
                        errorcode[i1 - 1] = tempValue ^ a_original[
                                ((&gen_poly[gen_offset[message_parameters[0] - 13]])[i1 - 1] + leadTerm) % 255];
                    }
                } else
                {
                    for (i1 = 1; i1 <= error_codewords; i1++)
                        errorcode[i1 - 1] = errorcode[i1];
                }
                for (i1 = error_codewords + 1; i1 <= data_codewords; i1++)
                {
                    errorcode[i1 - 1] = errorcode[i1];
                }
            }
            interleaved_output_offset = block_number;
            for (i = 0; i < data_codewords; i++)
            {
                interleaved_output[interleaved_output_offset] = message[i + message_offset];
                if (i + 1 < message_parameters[2])
                    interleaved_output_offset += message_parameters[1];
                if (i + 1 < message_parameters[4])
                    interleaved_output_offset += message_parameters[3];
            }
            interleaved_output_offset =
                    message_parameters[1] * message_parameters[2] + message_parameters[3] * message_parameters[4] +
                    block_number;
            for (i = 0; i < error_codewords; i++)
            {
                interleaved_output[interleaved_output_offset] = errorcode[i];
                interleaved_output_offset += total_blocks;
            }
            message_offset += data_codewords;
            block_number++;
        }
    }
    output_size = (message_parameters[1] * message_parameters[2]) + (message_parameters[3] * message_parameters[4]) +
                  ((message_parameters[1] + message_parameters[3])) * message_parameters[0];
    max_pixels = (qr_version * 4) + 21;
    image = malloc(max_pixels * sizeof(unsigned char *));
    if (image == 0)
    {
        return;
    }
    for (i = 0; i < max_pixels; i++)
    {
        image[i] = malloc(max_pixels);
        if (image[i] == 0)
        {
            return;
        }
    }
    for (i = 0; i < max_pixels; i++)
    {
        for (j = 0; j < max_pixels; j++)
        {
            image[i][j] = 255;
        }
    }
    finder_pattern = (qr_version * 4) + 14;
    for (i = 0; i < 7; i++)
    {
        image[0][i] = 0;
        image[6][i] = 0;
        image[0][finder_pattern + i] = 0;
        image[6][finder_pattern + i] = 0;
        image[finder_pattern][i] = 0;
        image[max_pixels - 1][i] = 0;
    }
    for (i = 1; i < 6; i++)
    {
        image[i][0] = 0;
        image[i][6] = 0;
        image[i][finder_pattern] = 0;
        image[i][max_pixels - 1] = 0;
        image[finder_pattern + i][0] = 0;
        image[finder_pattern + i][6] = 0;
    }
    for (i = 2; i < 5; i++)
    {
        for (j = 0; j < 3; j++)
        {
            image[2 + j][i] = 0;
            image[2 + j][i + finder_pattern] = 0;
            image[finder_pattern + 2 + j][i] = 0;
        }
    }
    if (qr_version > 0)
    {
        unsigned char center[7] = {0};
        center[0] = 6;
        for (i = 1; i < 7; i++)
            center[i] = message_parameters[5 + i];
        for (i = 0; i < 7; i++)
        {
            for (j = 0; j < 7; j++)
            {
                if ((center[i] != 0) && (center[j] != 0))
                {
                    if (image[center[i]][center[j]] == 255)
                    {
                        image[center[i]][center[j]] = 0;
                        for (k = 0; k < 5; k++)
                        {
                            image[center[i] - 2][center[j] - 2 + k] = 0;
                            image[center[i] + 2][center[j] - 2 + k] = 0;
                        }
                        for (k = 0; k < 3; k++)
                        {
                            image[center[i] - 1 + k][center[j] - 2] = 0;
                            image[center[i] - 1 + k][center[j] + 2] = 0;
                        }
                    }
                }
            }
        }
    }
    for (i = 8; i < max_pixels - 8; i += 2)
    {
        image[6][i] = 0;
        image[i][6] = 0;
    }
    image[(qr_version * 4) + 13][8] = 0;
    mask_number = 1;
    mask = mask_info[mask_number];
    skip = 0;
    for (i = 0; i < 8; i++)
    {
        if (i == 6)
            skip = 1;
        if ((mask & 1) > 0)
        {
            image[8][max_pixels - i - 1] = 0;
            image[i + skip][8] = 0;
        }
        mask = mask >> 1;
    }
    skip = 0;
    for (i = 0; i < 7; i++)
    {
        if (i == 1)
            skip = -1;
        if ((mask & 1) > 0)
        {
            image[max_pixels - 7 + i][8] = 0;
            image[8][7 - i + skip] = 0;
        }
        mask = mask >> 1;
    }
    if (qr_version > 5)
    {
        int offset = (qr_version - 6) * 3;
        for (i = 0; i < 3; i++)
        {
            unsigned char ver = version_info[offset + i];
            for (j = 0; j < 2; j++)
            {
                for (k = 0; k < 3; k++)
                {
                    if ((ver & 1) > 0)
                    {
                        image[0 + j + (i * 2)][max_pixels - 11 + k] = 0;
                        image[max_pixels - 11 + k][0 + j + (i * 2)] = 0;
                    }
                    ver = ver >> 1;
                }
            }
        }
    }
    y = max_pixels - 1;
    x = max_pixels - 1;
    dir = -1;
    primary_bits = output_size * 8;
    remainder_bits = message_parameters[5];
    for (i = 0; i < primary_bits + remainder_bits; i++)
    {
        if (image[y][x] == 0)
        {
            if (image[y][x - 1] == 0)
                y = y + dir * 5;
            else
            {
                x = x - 1;
                for (j = 0; j < 5; j++)
                {
                    if (y != 6)
                    {
                        if (i % 8 == 0)
                        {
                            working_byte = interleaved_output[++interleaved_index];
                        } else
                        {
                            working_byte = working_byte << 1;
                        }
                        if ((working_byte & 128) > 0)
                            image[y][x] = 0;
                        if (is_mask_applicable(y, x, mask_number))
                            image[y][x] = ~image[y][x];
                        i++;
                    }
                    y = y + dir;
                }
                x = x + 1;
            }
        }
        if (i < primary_bits)
        {
            if (i % 8 == 0)
            {
                working_byte = interleaved_output[++interleaved_index];
            } else
            {
                working_byte = working_byte << 1;
            }
            if ((working_byte & 128) > 0)
                image[y][x] = 0;
        }
        if (is_mask_applicable(y, x, mask_number))
            image[y][x] = ~image[y][x];
        i++;
        x = x - 1;
        if (i < primary_bits)
        {
            if (i % 8 == 0)
            {
                working_byte = interleaved_output[++interleaved_index];
            } else
            {
                working_byte = working_byte << 1;
            }
            if ((working_byte & 128) > 0)
                image[y][x] = 0;
        }
        if (is_mask_applicable(y, x, mask_number))
            image[y][x] = ~image[y][x];
        y = y + dir;
        x = x + 1;
        if (((x < 9) && (y == 8)) || ((x > max_pixels - 8) && (y == 8)) || (y < 0))
        {
            dir = +1;
            y = y + 1;
            x = x - 2;
        } else if ((qr_version > 5) && (x == max_pixels - 9) && (y == 6))
        {
            i++;
            dir = +1;
            y = 0;
            x = x - 3;
            for (j = 0; j < 6; j++)
            {
                if (i % 8 == 0)
                {
                    working_byte = interleaved_output[++interleaved_index];
                } else
                {
                    working_byte = working_byte << 1;
                }
                if ((working_byte & 128) > 0)
                    image[y][x] = 0;
                if (is_mask_applicable(y, x, mask_number))
                    image[y][x] = ~image[y][x];
                i++;
                y = y + dir;
            }
            i--;
            x = x + 1;
        } else if ((x == 10) && (y == max_pixels))
        {
            dir = -1;
            y = max_pixels - 9;
            x = x - 2;
        } else if (y == max_pixels)
        {
            dir = -1;
            y = max_pixels - 1;
            x = x - 2;
        } else if ((x < 10) && (y > max_pixels - 9))
        {
            dir = -1;
            y = max_pixels - 9;
            x = x - 2;
        } else if ((qr_version > 5) && (x < 7) && (y > max_pixels - 12))
        {
            dir = -1;
            y = max_pixels - 12;
            x = x - 2;
        }
        if (y == 6)
            y += dir;
        else if (x == 6)
            x = x - 1;
    }

    for (i = -1; i <= max_pixels; i++)
    {
        for (j = -1; j <= max_pixels; j++)
        {
            if (i == -1 || i == max_pixels || j == -1 || j == max_pixels)
            {
                Putpixel64k(x2 - ((max_pixels + 2) * 2 - 1) + ((i + 1) * 2),
                            y2 - ((max_pixels + 2) * 2 - 1) + ((j + 1) * 2), WHITE);
                Putpixel64k(x2 - ((max_pixels + 2) * 2 - 1) + ((i + 1) * 2) + 1,
                            y2 - ((max_pixels + 2) * 2 - 1) + ((j + 1) * 2), WHITE);
                Putpixel64k(x2 - ((max_pixels + 2) * 2 - 1) + ((i + 1) * 2),
                            y2 - ((max_pixels + 2) * 2 - 1) + ((j + 1) * 2) + 1, WHITE);
                Putpixel64k(x2 - ((max_pixels + 2) * 2 - 1) + ((i + 1) * 2) + 1,
                            y2 - ((max_pixels + 2) * 2 - 1) + ((j + 1) * 2) + 1, WHITE);
            } else
            {
                Putpixel64k(x2 - ((max_pixels + 2) * 2 - 1) + ((i + 1) * 2),
                            y2 - ((max_pixels + 2) * 2 - 1) + ((j + 1) * 2), image[i][j] ? WHITE : BLACK);
                Putpixel64k(x2 - ((max_pixels + 2) * 2 - 1) + ((i + 1) * 2) + 1,
                            y2 - ((max_pixels + 2) * 2 - 1) + ((j + 1) * 2), image[i][j] ? WHITE : BLACK);
                Putpixel64k(x2 - ((max_pixels + 2) * 2 - 1) + ((i + 1) * 2),
                            y2 - ((max_pixels + 2) * 2 - 1) + ((j + 1) * 2) + 1, image[i][j] ? WHITE : BLACK);
                Putpixel64k(x2 - ((max_pixels + 2) * 2 - 1) + ((i + 1) * 2) + 1,
                            y2 - ((max_pixels + 2) * 2 - 1) + ((j + 1) * 2) + 1, image[i][j] ? WHITE : BLACK);
            }
        }
    }

    for (i = 0; i < max_pixels; i++)
        free(image[i]);
    free(image);
}

char *IFileLister(char *dir, int *index)
{
    int ret, i;
    struct find_t ft;
    static char result[50][10];
    static int counts;
    if (dir != NULL)
    {
        counts = 0;
        ret = _dos_findfirst(dir, 0xf7, &ft);
        while (1)
        {
            while (!strcmp(ft.name, ".") || !strcmp(ft.name, ".."))
            {
                ret = _dos_findnext(&ft);
                continue;
            }
            if (ret)
            {
                break;
            }
            if (counts == 49)
            {
                draw_error("File Overflow", dir);
            }
            result[counts][0] = '\0';
            strcpy(result[counts++], ft.name);
            ret = _dos_findnext(&ft);
        }
        return NULL;
    }
    if (*index == -1)
    {
        *index = counts;
        return NULL;
    }
    return result[*index];
}

void IFileList(char *dir)
{
    IFileLister(dir, NULL);
}

int IFileCount()
{
    int result = -1;
    IFileLister(NULL, &result);
    return result;
}

char *IFileGet(int index)
{
    return IFileLister(NULL, &index);
}

bool IFileDelete(char *dir)
{
    return unlink(dir) == 0;
}

const char *translate(char *src)
{
    static char result[100];
    FILE *fp;
    fp = fopen("C:\\MUSIC\\STAT", "r");
    if (fp != NULL)
    {
        fclose(fp);
        fp = fopen("C:\\MUSIC\\TREE", "w");
        fprintf(fp, "1");
        fclose(fp);
        fp = fopen("C:\\MUSIC\\TRAN", "w");
        fprintf(fp, "%s", src);
        fclose(fp);
        IFileDelete("C:\\MUSIC\\TREE");
        while (1)
        {
            fp = fopen("C:\\MUSIC\\TREE", "r");
            if (fp == NULL)
            {
                delay(100);
            } else
            {
                fscanf(fp, "%s", result);
                fclose(fp);
                IFileDelete("C:\\MUSIC\\TREE");
                return result;
            }
        }
    } else
    {
        strcpy(result, "����ģ��δʹ�ܡ�");
        return result;
    }
}
