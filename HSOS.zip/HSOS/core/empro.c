#include "HsOS.h"
#include "page.h"
#include "string.h"
#include "stdio.h"
#include "general.h"

#include "empro.h"

elements *manager_empro(bool init)
{
  static elements *empro_data = NULL;
  int x1 = 347, y1 = 57;
  element *btn;
  if (init)
  {
    if (isnull(empro_data))
    {
      btn = new_button(0, 0, 60, 30, "����", IvoryWhite, 0xfded, 0x4227, empro_empage_click);
      empro_data = push(btn, NULL);
      btn = new_button(341, 707, 441, 745, "��һҳ", IvoryWhite, 0xfded, 0x4227, empro_last_page);
      empro_data = push(btn, empro_data);
      btn = new_button(917, 707, 1017, 745, "��һҳ", IvoryWhite, 0xfded, 0x4227, empro_next_page);
      empro_data = push(btn, empro_data);
      btn = new_button(x1, y1 + 118, x1 + 183, y1 + 173, "����", IvoryWhite, 0xfded, 0x4227, empro1);
      empro_data = push(btn, empro_data);
      btn = new_button(x1 + 234, y1 + 118, x1 + 183 + 234, y1 + 173, "����", IvoryWhite, 0xfded, 0x4227, empro2);
      empro_data = push(btn, empro_data);
      btn = new_button(x1 + 468, y1 + 118, x1 + 183 + 468, y1 + 173, "����", IvoryWhite, 0xfded, 0x4227, empro3);
      empro_data = push(btn, empro_data);
      btn = new_button(x1, y1 + 118 + 226, x1 + 183, y1 + 173 + 226, "����", IvoryWhite, 0xfded, 0x4227, empro4);
      empro_data = push(btn, empro_data);
      btn = new_button(x1 + 234, y1 + 118 + 226, x1 + 183 + 234, y1 + 173 + 226, "����", IvoryWhite, 0xfded, 0x4227,
                       empro5);
      empro_data = push(btn, empro_data);
      btn = new_button(x1 + 468, y1 + 118 + 226, x1 + 183 + 468, y1 + 173 + 226, "����", IvoryWhite, 0xfded, 0x4227,
                       empro6);
      empro_data = push(btn, empro_data);
      btn = new_button(x1, y1 + 118 + 452, x1 + 183, y1 + 173 + 452, "����", IvoryWhite, 0xfded, 0x4227, empro7);
      empro_data = push(btn, empro_data);
      btn = new_button(x1 + 234, y1 + 118 + 452, x1 + 183 + 234, y1 + 173 + 452, "����", IvoryWhite, 0xfded, 0x4227,
                       empro8);
      empro_data = push(btn, empro_data);
      btn = new_button(x1 + 468, y1 + 118 + 452, x1 + 183 + 468, y1 + 173 + 452, "����", IvoryWhite, 0xfded, 0x4227,
                       empro9);
      empro_data = push(btn, empro_data);
    }
  }
  return empro_data;
}

void empro_click()
{
  tick_click(manager_empro(false));
}

void empro_key(int i)
{
  tick_key(manager_empro(false), i);
}

void empro_move()
{
  tick_move(manager_empro(false));
}

void empro_empage_click()
{
  if (!ismanager(remember_id(NULL)))
  {
    paint(9);
  }
  else
  {
    paint(5);
  }
}

void draw_empro_page(int page)
{

  int i, j, x1 = 347, y1 = 62, m = 0, cnt = 0;
  int now[50] = {0};
  char tmp[30];
  FILE *fp;
  // Bar(0, 0, 40, 40, WHITE);
  IFileList("C:\\HSOS\\data\\project\\per\\*");
  i = IFileCount();
  if (!ismanager(remember_id(NULL)))
  {
    for (j = 0; j < i; j++)
    {
      strcpy(tmp, "data\\project\\per\\");
      strcat(tmp, IFileGet(j));
      fp = fopen(tmp, "rb");
      fscanf(fp, "%s", tmp);
      fclose(fp);
      if (strcmp(tmp, remember_id(NULL)) == 0)
      {
        cnt++;
        now[m] = j + 1;
        m++;
      }
    }
    i = cnt;
  }
  else
  {
    for (j = 0; j < i; j++)
    {
      now[m] = j + 1;
      m++;
    }
  }
  for (j = (page - 1) * 9; j < page * 9; j++)
  {
    Bar(x1 + (j % 3) * 234, y1 + ((j - (page - 1) * 9) / 3) * 226, x1 + (j % 3) * 234 + 183,
        y1 + ((j - (page - 1) * 9) / 3) * 226 + 118, MAR_ORANGE);
    if (j < i)
    {
      if (now[j] != 0)
      {
        EngText(x1 + (j % 3) * 234 + 10, y1 + ((j - (page - 1) * 9) / 3) * 226 + 5, IFileGet((now[j] - 1)),
                IvoryWhite);
      }
    }
    else
    {
      Text(x1 + (j % 3) * 234 + 10, y1 + ((j - (page - 1) * 9) / 3) * 226 + 5, "��", IvoryWhite);
    }
  }
}

int empro_change_page(int init)
{
  static int now_page = 1;
  int Total_page, i;
  i = Get_num();
  // Bar(0, 0, 50, 50, BLACK);
  if (i % 9 != 0)
    Total_page = i / 9 + 1;
  else
    Total_page = i / 9;
  if (init == 1)
  {
    if (now_page < Total_page)
      now_page = now_page + 1;
  }
  else if (init == 2)
  {
    if (now_page > 1)
      now_page = now_page - 1;
  }
  else if (init == 4)
  {
    now_page = 1;
  }
  // Bar(0, 0, 100, 100, WHITE);
  return now_page;
}

void empro_next_page()
{
  draw_empro_page(empro_change_page(1));
}

void empro_last_page()
{
  draw_empro_page(empro_change_page(2));
}

void empro1()
{
  if (isexist_project(1))
  {
    if (!ismanager(remember_id(NULL)))
    {
      remember_empro(1);
      if (vague_semantic_recognition_project(remember_empro(0)) == 1)
      {
        if (isfinish(remember_empro(0)))
        {
          paint(13);
        }
        else
        {
          paint(11);
        }
      }
      else if ((vague_semantic_recognition_project(remember_empro(0)) == 2) ||
               (vague_semantic_recognition_project(remember_empro(0)) == 4))
      {
        isopen_map(1);
        if (isfinish(remember_empro(0)))
        {
          paint(13);
        }
        else
        {
          paint(15);
        }
      }
      else if (vague_semantic_recognition_project(remember_empro(0)) == 3)
      {
        isopen_map(1);
        if (isfinish(remember_empro(0)))
        {
          paint(13);
        }
        else
        {
          paint(14);
        }
      }
    }
    else
    {
      remember_empro(1);
      remember_pro_id(remember_empro(0));
      paint(8);
    }
  }
}

void empro2()
{
  if (isexist_project(2))
  {
    if (!ismanager(remember_id(NULL)))
    {
      remember_empro(2);
      if (vague_semantic_recognition_project(remember_empro(0)) == 1)
      {
        if (isfinish(remember_empro(0)))
        {
          paint(13);
        }
        else
        {
          paint(11);
        }
      }
      else if ((vague_semantic_recognition_project(remember_empro(0)) == 2) ||
               (vague_semantic_recognition_project(remember_empro(0)) == 4))
      {
        isopen_map(1);
        if (isfinish(remember_empro(0)))
        {
          paint(13);
        }
        else
        {
          paint(15);
        }
      }
      else if (vague_semantic_recognition_project(remember_empro(0)) == 3)
      {
        isopen_map(1);
        if (isfinish(remember_empro(0)))
        {
          paint(13);
        }
        else
        {
          paint(14);
        }
      }
    }
    else
    {
      remember_empro(2);
      remember_pro_id(remember_empro(0));
      paint(8);
    }
  }
}

void empro3()
{
  if (isexist_project(3))
  {
    if (!ismanager(remember_id(NULL)))
    {
      remember_empro(3);
      if (vague_semantic_recognition_project(remember_empro(0)) == 1)
      {
        if (isfinish(remember_empro(0)))
        {
          paint(13);
        }
        else
        {
          paint(11);
        }
      }
      else if ((vague_semantic_recognition_project(remember_empro(0)) == 2) ||
               (vague_semantic_recognition_project(remember_empro(0)) == 4))
      {
        isopen_map(1);
        if (isfinish(remember_empro(0)))
        {
          paint(13);
        }
        else
        {
          paint(15);
        }
      }
      else if (vague_semantic_recognition_project(remember_empro(0)) == 3)
      {
        isopen_map(1);
        if (isfinish(remember_empro(0)))
        {
          paint(13);
        }
        else
        {
          paint(14);
        }
      }
    }
    else
    {
      remember_empro(3);
      remember_pro_id(remember_empro(0));
      paint(8);
    }
  }
}

void empro4()
{
  if (isexist_project(4))
  {
    if (!ismanager(remember_id(NULL)))
    {
      remember_empro(4);
      if (vague_semantic_recognition_project(remember_empro(0)) == 1)
      {
        if (isfinish(remember_empro(0)))
        {
          paint(13);
        }
        else
        {
          paint(11);
        }
      }
      else if ((vague_semantic_recognition_project(remember_empro(0)) == 2) ||
               (vague_semantic_recognition_project(remember_empro(0)) == 4))
      {
        isopen_map(1);
        if (isfinish(remember_empro(0)))
        {
          paint(13);
        }
        else
        {
          paint(15);
        }
      }
      else if (vague_semantic_recognition_project(remember_empro(0)) == 3)
      {
        isopen_map(1);
        if (isfinish(remember_empro(0)))
        {
          paint(13);
        }
        else
        {
          paint(14);
        }
      }
    }
    else
    {
      remember_empro(4);
      remember_pro_id(remember_empro(0));
      paint(8);
    }
  }
}

void empro5()
{
  if (isexist_project(5))
  {
    if (!ismanager(remember_id(NULL)))
    {
      remember_empro(5);
      if (vague_semantic_recognition_project(remember_empro(0)) == 1)
      {
        if (isfinish(remember_empro(0)))
        {
          paint(13);
        }
        else
        {
          paint(11);
        }
      }
      else if ((vague_semantic_recognition_project(remember_empro(0)) == 2) ||
               (vague_semantic_recognition_project(remember_empro(0)) == 4))
      {
        isopen_map(1);
        if (isfinish(remember_empro(0)))
        {
          paint(13);
        }
        else
        {
          paint(15);
        }
      }
      else if (vague_semantic_recognition_project(remember_empro(0)) == 3)
      {
        isopen_map(1);
        if (isfinish(remember_empro(0)))
        {
          paint(13);
        }
        else
        {
          paint(14);
        }
      }
    }
    else
    {
      remember_empro(5);
      remember_pro_id(remember_empro(0));
      paint(8);
    }
  }
}

void empro6()
{
  if (isexist_project(6))
  {
    if (!ismanager(remember_id(NULL)))
    {
      remember_empro(6);
      if (vague_semantic_recognition_project(remember_empro(0)) == 1)
      {
        if (isfinish(remember_empro(0)))
        {
          paint(13);
        }
        else
        {
          paint(11);
        }
      }
      else if ((vague_semantic_recognition_project(remember_empro(0)) == 2) ||
               (vague_semantic_recognition_project(remember_empro(0)) == 4))
      {
        isopen_map(1);
        if (isfinish(remember_empro(0)))
        {
          paint(13);
        }
        else
        {
          paint(15);
        }
      }
      else if (vague_semantic_recognition_project(remember_empro(0)) == 3)
      {
        isopen_map(1);
        if (isfinish(remember_empro(0)))
        {
          paint(13);
        }
        else
        {
          paint(14);
        }
      }
    }
    else
    {
      remember_empro(6);
      remember_pro_id(remember_empro(0));
      paint(8);
    }
  }
}

void empro7()
{
  if (isexist_project(7))
  {
    if (!ismanager(remember_id(NULL)))
    {
      remember_empro(7);
      if (vague_semantic_recognition_project(remember_empro(0)) == 1)
      {
        if (isfinish(remember_empro(0)))
        {
          paint(13);
        }
        else
        {
          paint(11);
        }
      }
      else if ((vague_semantic_recognition_project(remember_empro(0)) == 2) ||
               (vague_semantic_recognition_project(remember_empro(0)) == 4))
      {
        isopen_map(1);
        if (isfinish(remember_empro(0)))
        {
          paint(13);
        }
        else
        {
          paint(15);
        }
      }
      else if (vague_semantic_recognition_project(remember_empro(0)) == 3)
      {
        isopen_map(1);
        if (isfinish(remember_empro(0)))
        {
          paint(13);
        }
        else
        {
          paint(14);
        }
      }
    }
    else
    {
      remember_empro(7);
      remember_pro_id(remember_empro(0));
      paint(8);
    }
  }
}

void empro8()
{
  if (isexist_project(8))
  {
    if (!ismanager(remember_id(NULL)))
    {
      remember_empro(8);
      if (isfinish(remember_empro(0)))
      {
        if (vague_semantic_recognition_project(remember_empro(0)) == 1)
        {
          if (isfinish(remember_empro(0)))
          {
            paint(13);
          }
          else
          {
            paint(11);
          }
        }
        else if ((vague_semantic_recognition_project(remember_empro(0)) == 2) ||
                 (vague_semantic_recognition_project(remember_empro(0)) == 4))
        {
          isopen_map(1);
          if (isfinish(remember_empro(0)))
          {
            paint(13);
          }
          else
          {
            paint(15);
          }
        }
        else if (vague_semantic_recognition_project(remember_empro(0)) == 3)
        {
          isopen_map(1);
          if (isfinish(remember_empro(0)))
          {
            paint(13);
          }
          else
          {
            paint(14);
          }
        }
      }
    }
    else
    {
      remember_empro(8);
      remember_pro_id(remember_empro(0));
      paint(8);
    }
  }
}

void empro9()
{
  if (isexist_project(9))
  {
    if (!ismanager(remember_id(NULL)))
    {
      remember_empro(9);
      if (vague_semantic_recognition_project(remember_empro(0)) == 1)
      {
        if (isfinish(remember_empro(0)))
        {
          paint(13);
        }
        else
        {
          paint(11);
        }
      }
      else if ((vague_semantic_recognition_project(remember_empro(0)) == 2) ||
               (vague_semantic_recognition_project(remember_empro(0)) == 4))
      {
        isopen_map(1);
        if (isfinish(remember_empro(0)))
        {
          paint(13);
        }
        else
        {
          paint(15);
        }
      }
      else if (vague_semantic_recognition_project(remember_empro(0)) == 3)
      {
        isopen_map(1);
        if (isfinish(remember_empro(0)))
        {
          paint(13);
        }
        else
        {
          paint(14);
        }
      }
    }
    else
    {
      remember_empro(9);
      remember_pro_id(remember_empro(0));
      paint(8);
    }
  }
}

void draw_empro_mainpage()
{
  Picture(0, 0, "res\\people.bmp");
  background();
  // Bar(0, 0, 20, 20, BLACK);
  draw_empro_page(empro_change_page(4));
  tick_init(manager_empro(true));
  set_functions(empro_click, empro_key, empro_move);
}
